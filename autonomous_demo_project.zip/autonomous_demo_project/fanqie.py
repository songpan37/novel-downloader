import os
import re
import time
from playwright.sync_api import TimeoutError, Page, BrowserContext

from agent import deepseek
from agent.toutiao import toutiao_login_url
from common import log
from common import credential
from common import utils
from common import ptool
from novel.snowflake.snowflake import ds_page
import random
from datetime import datetime, timedelta

logger = log.get_logger()

fanqie_login_url = "https://fanqienovel.com/main/writer/login"
fanqie_domain = "https://fanqienovel.com"

# fanqie_url = "https://fanqienovel.com/reader/7605250539030318105?enter_from=reader"  # 替换为实际登录URL
# fanqie_book_url = "https://fanqienovel.com/main/writer/chapter-manage/7605250539030318105&%E6%9C%AB%E4%B8%96%E7%81%BE%E5%8F%98%EF%BC%9A%E6%88%91%E7%9A%84%E8%9A%81%E5%B7%A2%E6%97%A0%E9%99%90%E5%8D%87%E7%BA%A7?type=1"
# fanqie_draft_url = "https://fanqienovel.com/main/writer/7605250539030318105/publish/?enter_from=newdraft"


# fanqie_url = "https://fanqienovel.com/reader/7598829918146808894?enter_from=reader"  # 替换为实际登录URL
# fanqie_book_url = "https://fanqienovel.com/main/writer/chapter-manage/7598829918146808894&%E9%95%87%E5%8C%97%EF%BC%9A%E4%BB%8E%E7%BD%AA%E5%8D%92%E5%BC%80%E5%A7%8B?type=1"
# fanqie_draft_url = "https://fanqienovel.com/main/writer/7598829918146808894/publish/?enter_from=newdraft"

fanqie_url = "https://fanqienovel.com/reader/7609544542479469592?enter_from=reader"  # 替换为实际登录URL
fanqie_book_url = "https://fanqienovel.com/main/writer/chapter-manage/7609544542479469592&%E9%83%BD%E5%B8%82%E4%B9%8B%E4%B8%B9%E5%B8%9D%E5%BD%92%E6%9D%A5?type=1"
fanqie_draft_url = "https://fanqienovel.com/main/writer/7609544542479469592/publish/?enter_from=newdraft"



ds_page : Page

def login() -> Page:
    page = ptool.context.new_page()
    page.goto(fanqie_login_url)

    password_login_btn = page.locator('button.arco-btn.arco-btn-text.arco-btn-size-default.arco-btn-shape-round.serial-arco-btn.slogin-form-button span:has-text("密码登录")')
    password_login_btn.click()

    phone_input = page.locator('input[placeholder="请输入手机号/邮箱"][name="username"]')
    phone_input.fill(credential.fanqie_phone)

    password_input = page.locator('input[placeholder="请输入密码"][type="password"]')
    password_input.fill(credential.fanqie_password)

    # phone_input = page.locator('input[placeholder="手机号"][name="username"]')
    # phone_input.fill(credential.phone_number)

    # get_vr_code_btn = page.locator('div.slogin-form-input__button-text:has-text("获取验证码")')
    # get_vr_code_btn.click()

    # vr_code_input = page.locator('input[placeholder="请输入验证码"]')
    # while True:
    #     code = vr_code_input.input_value()
    #     if len(code) == 4 and code.isdigit():
    #         logger.info(f"received verify code: {code}")
    #         break
    #
    #     logger.info(f"received verify code: {code}")
    #     time.sleep(1)

    checkbox = page.locator("div.slogin-form-protocol__checkbox")
    checkbox.click()

    login_btn = page.locator('button.arco-btn.arco-btn-primary.arco-btn-size-large.arco-btn-shape-round.serial-arco-btn.slogin-form-button span:has-text("登录")')
    login_btn.click()

    return page



def remove_chapter_title(novel_text: str) -> str:
    """删除所有章节名行，返回纯正文"""
    chapter_pattern = re.compile(r'^第[\d一二三四五六七八九十百千]+章.*$', re.M)
    pure_text = chapter_pattern.sub('', novel_text)
    pure_text = re.sub(r'\n+', '\n', pure_text).strip()
    return pure_text



def split_novel_to_chapters(novel_text, max_word_count: int=2000) -> list[str]:
    # 存储最终的所有章节
    chapters = []
    # 存储当前章节的所有行内容
    current_chapter_lines = []
    # 统计当前章节的累计字数
    current_total_words = 0

    # 按行分割正文，兼容所有换行符(\n、\r\n)，返回不带换行符的行列表
    for line in novel_text.splitlines():
        # 过滤空行/纯空格行，避免无效内容占用字数
        stripped_line = line.strip()
        if not stripped_line:
            continue

        current_chapter_lines.append(line)
        # 计算当前行的有效字数，包含换行符
        current_total_words = current_total_words + len(stripped_line) + 1

        if stripped_line.endswith("：") or stripped_line.endswith(":"):
            continue

        # 核心判断：如果追加当前行后，超过阈值 → 生成新章节
        if current_total_words > max_word_count and len(current_chapter_lines) > 0:
            chapter_content = "\n".join(current_chapter_lines)
            chapters.append(chapter_content)
            # 重置当前章节的行和字数统计
            current_chapter_lines = []
            current_total_words = 0

    # 处理最后一段内容：循环结束后，剩余的行作为最后一个章节
    if current_total_words > 0 and len(current_chapter_lines) > 0:
        chapter_content = "\n".join(current_chapter_lines)
        chapters.append(chapter_content)


    if len(chapters) > 1 and len(chapters[len(chapters) - 1]) < max_word_count and len(chapters[len(chapters) - 1]) < 1800:
        last_one = chapters[len(chapters) - 1]
        second_last_one = chapters[len(chapters) - 2] + "\n" + last_one
        chapters = chapters[0:len(chapters) - 2]
        chapters.append(second_last_one)

    if len(chapters) > 0:
        last_one = chapters[len(chapters) - 1]
        if len(last_one) > 3600:
            chapters = chapters[0:len(chapters) - 1]
            childs = split_novel_to_chapters(last_one, 1800)
            chapters.extend(childs)

    return chapters


# 定义排序的关键函数：提取字符串中的数字部分并转为整数
def get_number_from_str(s):
    if "." in s:
        s = s.split('.')[0]
    if "-" in s:
        return int(s.split('-')[1])

    return int(s.split('.')[0])



def get_chapters(dir_path: str, start_chapter: int, end_chapter: int) -> list[str]:
    files = os.listdir(dir_path)
    # 按数字大小排序
    files = sorted(files, key=get_number_from_str)

    novel_content = ""
    for i, file in enumerate(files):
        if file.endswith("cplt"):
            s = file
            if "." in s:
                s = s.split('.')[0]
            if "-" in s:
                start = int(s.split('-')[0])
                end = int(s.split('-')[1])
                start_in = start_chapter <= start <= end_chapter
                end_in = start_chapter <= end <= end_chapter
                if not start_in or not end_in:
                    continue
            else:
                chapter = int(file.split(".")[0])
                chapter_in = start_chapter <= chapter <= end_chapter
                if not chapter_in:
                    continue
            novel_content = novel_content + utils.read_file(os.path.join(dir_path, file)) + "\n"

    novel_content = remove_chapter_title(novel_content)
    chapters = split_novel_to_chapters(novel_content, 2000)
    return chapters



def split_chapters(dir_path: str, start_chapter: int, end_chapter: int) -> list[str]:
    files = os.listdir(dir_path)
    # 按数字大小排序
    files = sorted(files, key=get_number_from_str)

    chapters = []
    for i, file in enumerate(files):
        if file.endswith("cplt"):
            s = file
            if "." in s:
                s = s.split('.')[0]
            if "-" in s:
                start = int(s.split('-')[0])
                end = int(s.split('-')[1])
                start_in = start_chapter <= start <= end_chapter
                end_in = start_chapter <= end <= end_chapter
                if not start_in or not end_in:
                    continue
            else:
                chapter = int(file.split(".")[0])
                chapter_in = start_chapter <= chapter <= end_chapter
                if not chapter_in:
                    continue
            novel_content = utils.read_file(os.path.join(dir_path, file))
            novel_content = remove_chapter_title(novel_content)
            total_words = len(novel_content)
            left_words = total_words % 2000
            chapter_number = total_words / 2000

            words_per_chapter = 2000 + int(left_words / chapter_number)
            splited_chapters = split_novel_to_chapters(novel_content, words_per_chapter)
            logger.info(f"file [{file}] -> {len(chapters) + 1} -> {len(chapters) + len(splited_chapters)}")
            chapters.extend(splited_chapters)

    return chapters


def publish_chapter(chapter_number: int, chapter_title: str, chapter_content:str, publish_day: str, publish_time:str):
    draft_page = ptool.context.new_page()
    draft_page.goto(fanqie_draft_url)
    time.sleep(1)

    chapter_title_input = draft_page.locator('div.serial-editor-title-right div.serial-editor-input-hint.input input[placeholder="请输入标题"]')

    while True:
        if chapter_title_input.input_value() == chapter_title:
            break
        chapter_title_input.fill(chapter_title)
        logger.info(f"try input title: {chapter_title}, input: {chapter_title_input}")
        time.sleep(1)

    chapter_content_input = draft_page.locator('div.ProseMirror[contenteditable="true"][spellcheck="false"][translate="no"]')

    while True:
        if len(chapter_content_input.text_content()) == len(chapter_content.replace("\n", "")):
            break
        chapter_content_input.fill("")

        chapter_content_input.type(chapter_content)
        logger.info(f"try input chapter_content: {len(chapter_content)}, input: {chapter_content_input}")
        time.sleep(1)


    chapter_number_input = draft_page.locator('div.serial-editor-title-left span.left-input input[type="text"]')
    while True:
        if chapter_number_input.input_value() == str(chapter_number):
            break
        chapter_number_input.fill(str(chapter_number))
        logger.info(f"try input chapter_number: {chapter_number}, input: {chapter_number_input}")
        time.sleep(1)

    save_draft_btn = draft_page.locator('div.publish-header-right button.arco-btn span:has-text("存草稿")')
    while True:
        try:
            save_draft_btn.click(timeout=10000)
        except Exception as ex:
            logger.info(f"click publish_time_confirm_btn failed: {ex}")
            continue
        break


    next_step_btn = draft_page.locator('div.publish-header-right button.arco-btn span:has-text("下一步")')
    while True:
        try:
            next_step_btn.click(timeout=10000)
            logger.info(f"click [下一步] btn")
        except Exception as ex:
            logger.info(f"click publish_time_confirm_btn failed: {ex}")
            time.sleep(1)
            continue
        break


    typo_submit_btn = draft_page.locator('div.arco-modal-wrapper div.arco-modal[role="dialog"] button.arco-btn span:has-text("提交")')
    risk_check_btn = draft_page.locator('div.arco-modal-wrapper div.arco-modal[role="dialog"] button.arco-btn span:has-text("确定")')
    while True:
        try:
            typo_tips = draft_page.query_selector_all('div.arco-modal-content:has-text("检测到你还有错别字未修改，是否确定提交？")')
            if len(typo_tips) > 0:
                typo_submit_btn.click(timeout=1000)
                logger.info(f"click [错别字未修改] btn")
        except Exception as ex:
            logger.info(f"click typo_submit_btn failed: {ex}")

        try:
            risk_check_btn.click(timeout=1000)
        except Exception as ex:
            logger.info(f"click risk_check_btn failed: {ex}")
            continue
        break

    while True:
        try:
            typo_tips = draft_page.query_selector_all('div.arco-modal-content:has-text("非章节内容请使用“作者有话说”功能，章末附带无关内容可能会影响章节审核结果。是否确定提交？")')
            if len(typo_tips) > 0:
                typo_submit_btn.click(timeout=1000)
                logger.info(f"click [作者有话说] btn")
        except Exception as ex:
            logger.info(f"click typo_submit_btn failed: {ex}")
            time.sleep(1)
            continue
        break

    use_ai_btn = draft_page.locator('div.publish-confirm-card div.card-content-line-control div.arco-radio-group[role="radiogroup"] span.arco-radio-text:has-text("否")')
    while True:
        try:
            use_ai_btn.click(timeout=1000)
            logger.info(f"click [使用AI] btn")
        except Exception as ex:
            logger.info(f"click [使用AI] failed: {ex}")
            time.sleep(1)
            continue
        break

    schedule_publish_btn = draft_page.locator('div.publish-confirm-card div.card-content-line-control button.arco-switch.arco-switch-type-circle[role="switch"] div.arco-switch-dot')
    while True:
        try:
            schedule_publish_btn.click(timeout=1000)
        except Exception as ex:
            logger.info(f"click publish_time_confirm_btn failed: {ex}")
            continue
        break

    card = draft_page.locator('div.publish-confirm-card div.card-content-line-label:has-text("日期")')
    publish_day_input = draft_page.locator('div.publish-confirm-card div.card-content-line-control div.arco-picker-input input.arco-picker-start-time[placeholder="请选择日期"]')
    publish_time_input = draft_page.locator('div.publish-confirm-card div.card-content-line-control div.arco-picker-input input.arco-picker-start-time[placeholder="请选择时间"]')
    publish_time_confirm_btn = draft_page.locator('div.arco-modal[role="dialog"] div.arco-modal-content span.arco-trigger div.arco-timepicker-container button.arco-btn span:has-text("确定")')
    select_date_btn = draft_page.locator('span.arco-trigger[trigger-placement="top"] div.arco-picker-container div.arco-panel-date div.arco-picker-row div.arco-picker-cell.arco-picker-cell-in-view.arco-picker-cell-selected')
    while publish_day_input.input_value() != publish_day or publish_time_input.input_value() != publish_time:
        publish_day_input.focus()
        publish_day_input.click()
        publish_day_input.fill(publish_day)
        try:
            select_date_btn.click(timeout=1000)
        except Exception as ex:
            logger.info(f"click select_date_btn failed: {ex}")
            time.sleep(1)
            continue

        card.click()
        logger.info(f"try input {publish_day} to publish_day_input  :{publish_day_input}")

        publish_time_input.focus()
        publish_time_input.click()
        publish_time_input.fill(publish_time)
        logger.info(f"try input {publish_time} to publish_time_input {publish_time}")

        try:
            publish_time_confirm_btn.click(timeout=1000)
        except Exception as ex:
            logger.info(f"click publish_time_confirm_btn failed: {ex}")
        card.click()
        time.sleep(1)

    publish_confirm_btn = draft_page.locator('div.arco-modal[role="dialog"] div.arco-modal-footer button.arco-btn span:has-text("确认发布")')
    while True:
        try:
            publish_confirm_btn.click(timeout=1000)
        except Exception as ex:
            logger.info(f"click publish_time_confirm_btn failed: {ex}")
            time.sleep(1)
            continue
        break

    draft_page.close()



def replace_chapter(chapter_number: int, chapter_title: str, chapter_content:str):
    novel_page = ptool.context.new_page()
    novel_page.goto(fanqie_book_url)
    time.sleep(1)

    logger.info(f"[replace_chapter] chapter_number: {chapter_number}, chapter_title: {chapter_title}")

    next_page_btn = novel_page.locator('div.arco-table-pagination.arco-table-pagination-center div.arco-pagination ul.arco-pagination-list li.arco-pagination-item[aria-label="下一页"]')
    page_index = 1
    while True:
        found = False
        chapter_tr = novel_page.locator('div.chapter-table.auto-editor-chapter div.arco-table-content-inner table tbody tr.arco-table-tr')
        for i, e in enumerate(chapter_tr.all()):
            a_links = e.locator('a').all()
            if len(a_links) < 2:
                logger.info(f"a_links: {a_links}")
            if f"第{chapter_number}章" in a_links[0].text_content():
                url = f"{fanqie_domain}{a_links[1].get_attribute('href')}"
                modify_chapter(url, chapter_number, chapter_title, chapter_content)
                found = True
                break
        if found:
            break
        logger.info(f"chapter not found in current page: {page_index}, try next page")
        next_page_btn.click()
        page_index = page_index + 1
        time.sleep(1)

    novel_page.close()



def modify_chapter(url:str, chapter_number: int, chapter_title: str, chapter_content:str):
    novel_page = ptool.context.new_page()
    novel_page.goto(url)

    chapter_title_input = novel_page.locator('div.serial-editor-title-right div.serial-editor-input-hint.input input[placeholder="请输入标题"]')
    while True:
        if chapter_title_input.input_value() == chapter_title:
            break
        chapter_title_input.fill(chapter_title)
        logger.info(f"try input title: {chapter_title}, input: {chapter_title_input}")
        time.sleep(1)

    chapter_content_input = novel_page.locator('div.ProseMirror[contenteditable="true"][spellcheck="false"][translate="no"]')
    chapter_content_input.fill("")

    while True:
        if len(chapter_content_input.text_content()) == len(chapter_content.replace("\n", "")):
            break
        chapter_content_input.fill("")

        chapter_content_input.type(chapter_content)
        logger.info(f"try input chapter_content: {len(chapter_content)}, input: {chapter_content_input}")
        time.sleep(1)


    chapter_number_input = novel_page.locator('div.serial-editor-title-left span.left-input input[type="text"]')
    while True:
        if chapter_number_input.input_value() == str(chapter_number):
            break
        chapter_number_input.fill(str(chapter_number))
        logger.info(f"try input chapter_number: {chapter_number}, input: {chapter_number_input}")
        time.sleep(1)


    tip_30_mins = novel_page.locator('div.byte-modal-wrapper[role="dialog"] button.byte-btn.byte-btn-primary span:has-text("我知道了")')
    if tip_30_mins.is_visible():
        try:
            tip_30_mins.click(timeout=10000)
            logger.info(f"click [我知道了] btn")
        except Exception as ex:
            logger.info(f"click tip_30_mins failed: {ex}")


    next_step_btn = novel_page.locator('div.publish-header-right button.arco-btn span:has-text("下一步")')
    while True:
        try:
            next_step_btn.click(timeout=10000)
            logger.info(f"click [下一步] btn")
        except Exception as ex:
            logger.info(f"click publish_time_confirm_btn failed: {ex}")
            time.sleep(1)
            continue
        break


    typo_submit_btn = novel_page.locator('div.arco-modal-wrapper div.arco-modal[role="dialog"] button.arco-btn span:has-text("提交")')
    while True:
        try:
            typo_tips = novel_page.query_selector_all('div.arco-modal-content:has-text("检测到你还有错别字未修改，是否确定提交？")')
            if len(typo_tips) > 0:
                typo_submit_btn.click(timeout=1000)
                logger.info(f"click [错别字未修改] btn")
        except Exception as ex:
            logger.info(f"click typo_submit_btn failed: {ex}")
            time.sleep(1)
            continue
        break


    use_ai_btn = novel_page.locator('div.publish-confirm-card div.card-content-line-control div.arco-radio-group[role="radiogroup"] span.arco-radio-text:has-text("否")')
    while True:
        try:
            use_ai_btn.click(timeout=1000)
            logger.info(f"click [使用AI] btn")
        except Exception as ex:
            logger.info(f"click [使用AI] failed: {ex}")
            time.sleep(1)
            continue
        break


    publish_confirm_btn = novel_page.locator('div.arco-modal[role="dialog"] div.arco-modal-footer button.arco-btn span:has-text("确认发布")')
    while True:
        try:
            publish_confirm_btn.click(timeout=1000)
        except Exception as ex:
            logger.info(f"click publish_time_confirm_btn failed: {ex}")
            time.sleep(1)
            continue
        break

    novel_page.close()




def generate_times(start_date_str, start_hour=9, start_minute=50, max_random_minutes=10, num_times=10):
    """
    生成从指定日期和时间开始，每次随机增加分钟数的时间序列

    参数:
        start_date_str: 开始日期字符串 (格式: "2026-01-19")
        start_hour: 开始小时 (默认: 9)
        start_minute: 开始分钟 (默认: 50)
        max_random_minutes: 最大随机增加分钟数 (默认: 10)
        num_times: 生成的时间点数量 (默认: 10)
    """
    # 解析开始日期
    start_date = datetime.strptime(start_date_str, "%Y-%m-%d")

    # 计算开始时间（第二天的9:50）
    current_time = start_date.replace(hour=start_hour, minute=start_minute)

    times = []

    for i in range(num_times):
        # 格式化日期和时间
        date_str = current_time.strftime("%Y-%m-%d")
        time_str = current_time.strftime("%H:%M")

        # 添加到结果列表
        times.append({
            'date': date_str,
            'time': time_str,
            'datetime': current_time
        })

        # 生成1到max_random_minutes之间的随机分钟数
        random_minutes = random.randint(1, max_random_minutes)

        # 增加随机分钟数
        current_time += timedelta(minutes=random_minutes)

    return times


def get_chapter_title_prompt(chapter_content:str) -> str:
    prompt =f'''你是一个专业的番茄小说编辑，擅长创作吸引读者的章节标题。请根据以下章节内容，生成1个符合番茄平台风格的章节标题。

【番茄平台标题风格特点】：
1. **悬念钩子型**：用问句或悬念结尾，让读者忍不住点开
2. **冲突对抗型**：突出主角与反派的矛盾，制造紧张感
3. **爽点预告型**：预告本章的核心爽点或主角高光时刻
4. **反转意外型**：暗示剧情会有出人意料的发展
5. **情感引爆型**：聚焦感情线的高潮或转折点

【章节内容】：
{chapter_content}

【标题要求】：
1. 标题长度在15字之内，要有网文感，不要有逗号
2. 标题要与本章核心剧情强相关
3. 避免过于文艺或晦涩的表达
4. 不要用这种"他怎么怎么样" 的第三人称代替主角
5. 不要用这种"我怎么怎么样" 的第一人称代替主角
6. 不要有逗号，一句话标题

【输出格式】：
只输出最终的标题,不要有其他任何总结或说明性文字.'''
    return prompt



def publish_novel(publish_date:str, start_chapter:int, chapters: list[list[str]]):
    start_hour = random.randint(0, 12)
    start_minute = random.randint(0, 59)
    publish_times = generate_times(publish_date, start_hour=start_hour, start_minute=start_minute, num_times=len(chapters))
    for i, chapter in enumerate(chapters):
        title = chapter[0]
        if title.endswith(".txt"):
            title = title[0:len(title)-4]
        if title.startswith("第"):
            title = title.split("章 ")[1]
        content = chapter[1]
        # if i + start_chapter < 24:
        #     continue
        logger.info(f"[fanqie] chapter [{i + start_chapter}], length: {len(chapter)}, title: {title}, date: {publish_times[i]["date"]}, time: {publish_times[i]["time"]}")
        publish_chapter(i + start_chapter, title, content, publish_times[i]["date"], publish_times[i]["time"])




# 定义排序的key函数：提取章节数字并转为整数
def get_chapter_number(s: list[str]):
    # 正则匹配"第"和"章"之间的数字（\d+匹配1个或多个数字）
    match = re.search(r"第(\d+)章", s[0])
    # 提取匹配到的数字并转为整数
    return int(match.group(1))


def publish_first_three_days(dir_path: str) -> list[list[str]]:
    chapters_to_publish = []
    for i, file in enumerate(os.listdir(dir_path)):
        chapters_to_publish.append([file, utils.read_file(os.path.join(dir_path, file))])

    chapters_to_publish = sorted(chapters_to_publish, key=get_chapter_number)

    # 获取当前日期
    today = datetime.now()
    # 计算明天日期
    today_plus_1 = (today + timedelta(days=0)).strftime("%Y-%m-%d")
    today_plus_2 = (today + timedelta(days=1)).strftime("%Y-%m-%d")
    today_plus_3 = (today + timedelta(days=2)).strftime("%Y-%m-%d")

    chapters_nums = [14, 13, 13]
    start_date = [today_plus_1, today_plus_2, today_plus_3]

    day = 0
    chapter_start_number = 1
    while len(chapters_to_publish) > 0:
        chapter_num = chapters_nums[day]
        publish_chapters = chapters_to_publish
        if len(chapters_to_publish) < chapter_num:
            chapters_to_publish = []
        else:
            publish_chapters = chapters_to_publish[0:chapter_num]
            chapters_to_publish = chapters_to_publish[chapter_num:]

        publish_novel(start_date[day], chapter_start_number, publish_chapters)
        chapter_start_number = chapter_start_number + len(publish_chapters)
        day = day + 1
        if day == len(chapters_nums):
            break

    return chapters_to_publish


def publish_daily(start_day: datetime, chapters_to_publish: list[list[str]], chapter_start_number:int = 41, daily_chapter_num:int = 2):
    while len(chapters_to_publish) > 0:
        start_day = start_day + timedelta(days=1)
        publish_chapters = chapters_to_publish
        if len(chapters_to_publish) < daily_chapter_num:
            chapters_to_publish = []
        else:
            publish_chapters = chapters_to_publish[0:daily_chapter_num]
            chapters_to_publish = chapters_to_publish[daily_chapter_num:]
        publish_novel(start_day.strftime("%Y-%m-%d"), chapter_start_number, publish_chapters)
        chapter_start_number = chapter_start_number + len(publish_chapters)



def resave_novels(ds_page, dir_path: str, save_path: str, start_chapter: int, end_chapter: int):
    chapters = get_chapters(dir_path=dir_path, start_chapter=start_chapter, end_chapter=end_chapter)
    utils.ensure_directory_exists(save_path)
    files = os.listdir(save_path)
    for i, chapter in enumerate(chapters):
        already_generate = False
        for file in files:
            if  f"第{i+1}章" in file:
                already_generate = True
                logger.info(f"[{i+1}/{len(chapters)}] chapter file [{file}] already generate")
                break
        if already_generate:
            continue

        title = deepseek.complete(ds_page, get_chapter_title_prompt(chapter), True, 1, utils.default_wait_timeout)
        file = os.path.join(save_path,  f"第{i+1}章 {title}.txt")
        utils.write_file(file, chapter)
        logger.info(f"[{i+1}/{len(chapters)}] chapter file [{file}] generated")



def regroup_novels(dir_path: str, save_path: str, start_chapter: int, end_chapter: int, output_start_chapter: int):
    chapters = split_chapters(dir_path=dir_path, start_chapter=start_chapter, end_chapter=end_chapter)
    utils.ensure_directory_exists(save_path)
    files = os.listdir(save_path)
    for i, chapter in enumerate(chapters):
        already_generate = False
        for file in files:
            if  f"第{output_start_chapter}章" in file:
                already_generate = True
                logger.info(f"[{i+1}/{len(chapters)}] chapter file [{file}] already generate")
                break
        if already_generate:
            continue

        global ds_page
        if ds_page is None:
            ds_page = deepseek.login()

        title = deepseek.complete(ds_page, get_chapter_title_prompt(chapter), True, 1, utils.default_wait_timeout)
        while True:
            exists_chapters = os.listdir(save_path)
            exists = False
            for j, exists_chapter in enumerate(exists_chapters):
                if f"章 {title}.txt" in exists_chapter:
                    logger.info(f"chapter name already exists: [{exists_chapter}]")
                    exists = True
                    break
            if exists:
                title = deepseek.complete(ds_page, get_chapter_title_prompt(chapter), True, 1, utils.default_wait_timeout)
                continue
            break
        # title = ""
        file = os.path.join(save_path, f"第{output_start_chapter}章 {title}.txt")
        utils.write_file(file, chapter)
        output_start_chapter = output_start_chapter + 1
        logger.info(f"[{i+1}/{len(chapters)}] chapter file [{file}] generated")


def sort_chapters(chapter_list):
    """
    对章节名列表按照章节数字进行升序排序

    参数:
        chapter_list (list): 包含章节名的列表，格式如 ["第41章 一刀封喉战五匪", ...]

    返回:
        list: 按章节数字排序后的章节名列表
    """

    def extract_chapter_number(chapter_name):
        """辅助函数：提取章节名中的数字，处理异常情况"""
        try:
            # 截取"第"和"章"之间的部分，提取纯数字
            num_str = chapter_name.split("章 ")[0].split("第")[1]
            # 转换为整数返回
            return int(num_str)
        except (IndexError, ValueError):
            # 处理格式不规范的情况，返回极大值让其排在最后
            return float('inf')

    # 按照提取的章节号进行排序
    sorted_list = sorted(chapter_list, key=extract_chapter_number)
    return sorted_list



def replace_chapters(source_dir_path: str, source_start_chapter: int, publish_start_chapter):
    chapters = os.listdir(source_dir_path)
    # 按数字大小排序
    chapters = sort_chapters(chapters)
    chapters = chapters[source_start_chapter-1:]

    start_chapter = publish_start_chapter
    for i, chapter in enumerate(chapters):
        title = chapter.split("章 ")[1]
        if title.endswith(".txt"):
            title = title[0:len(title)-4]
        replace_chapter(start_chapter, title, utils.read_file(os.path.join(source_dir_path, chapter)))
        start_chapter = start_chapter + 1



def delete_chapters():
    draft_page = login()
    draft_page.goto(fanqie_book_url)
    while True:
        delete_chapter = draft_page.locator("span.icon-delete.tomato-delete.auto-editor-chapter-delete")
        logger.info(f"find chapters to delete: {len(delete_chapter.all())}")
        for i, e in enumerate(delete_chapter.all()):
            try:
                e.click(timeout=1000)
            except Exception as ex:
                logger.info(f"click delete btn failed: {ex}")
                time.sleep(1)
                continue

            delete_confirm_btn = draft_page.locator('div.arco-modal[role="dialog"] div.arco-modal-footer button.arco-btn span:has-text("删除")')
            while True:
                try:
                    delete_confirm_btn.click(timeout=1000)
                except Exception as ex:
                    logger.info(f"click delete_confirm_btn failed: {ex}")
                    time.sleep(1)
                    continue
                break
        time.sleep(1)



# if __name__ == '__main__':
#     delete_chapters()




# if __name__ == '__main__':
#     dir_path = r"D:\workspace\dreamland\fs_storage\remake\20260216\chapter_merge\c1"
#     book_name = "都市丹尊"
#     save_path = f"E:/novel/repo/AI/{book_name}"
#     regroup_novels(dir_path, save_path, 21, 40, 42)


# if __name__ == '__main__':
#     fanqie_page = login()
#     source_dir_path = r"E:\novel\repo\AI\末世灾变：我的蚁巢无限升级"
#     replace_chapters(source_dir_path, 68, 68)


# 示例使用
# if __name__ == "__main__":
#     # 生成10个时间点，从2026-01-20的09:50开始
#     result = generate_times("2026-01-19", start_hour=9, start_minute=50, num_times=10)
#
#     print("时间序列 (从第二天9:50开始，每次增加1-10随机分钟):")
#     print("-" * 40)
#
#     for i, item in enumerate(result, 1):
#         print(f"{i:2}. 日期: {item['date']}  时间: {item['time']}")
#
#     # 如果需要只输出时间部分
#     print("\n仅时间部分:")
#     print("-" * 20)
#     for i, item in enumerate(result, 1):
#         print(f"{i:2}. {item['time']}")



if __name__ == '__main__':
    fanqie_page = login()
    dir_path = r"E:\novel\repo\AI\都市丹尊"
    # chapters = publish_first_three_days(dir_path)

    chapters = []
    for i, file in enumerate(os.listdir(dir_path)):
        chapters.append([file, utils.read_file(os.path.join(dir_path, file))])

    chapters = sorted(chapters, key=get_chapter_number)
    chapters = chapters[41:]
    publish_daily(datetime.now() + timedelta(1), chapters, chapter_start_number=42, daily_chapter_num=2)

    utils.wait_forever()

