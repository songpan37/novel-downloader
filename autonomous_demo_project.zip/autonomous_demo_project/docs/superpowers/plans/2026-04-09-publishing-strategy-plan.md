# 发布策略步骤实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在发布流程中新增"发布策略"步骤（步骤5），包含更新已发布章节元数据、章节范围对齐、定时发布计划生成功能。

**Architecture:** 在现有步骤4（选择账号）和步骤5（汇总发布）之间插入新步骤5（发布策略），包含三个子阶段。章节元数据存储在 `chapters/` 目录下，使用番茄平台返回的原始字段。

**Tech Stack:** Python + PyQt6 + Playwright

---

## 文件结构

```
src/
├── services/
│   ├── fanqie_book_service.py    # 新增 list_published_chapters() 方法
│   └── fanqie_publisher.py       # 新增 update_chapter() 方法
└── core/
    └── work_manager.py           # 新增章节元数据读写方法

src/gui/views/
└── publishing_view.py           # 新增步骤5 UI和逻辑

tests/
└── (对应的测试文件)
```

---

## Task 1: FanqieBookService.list_published_chapters()

**Files:**
- Modify: `src/services/fanqie_book_service.py` (末尾添加新方法)

- [ ] **Step 1: 添加 list_published_chapters() 方法**

在 `fanqie_book_service.py` 文件末尾 `__exit__` 方法之后添加：

```python
def list_published_chapters(self, book_id: str, volume_id: str = None) -> Dict[str, Any]:
    """
    获取番茄平台指定书籍的所有已发布章节。

    Args:
        book_id: 番茄书籍ID
        volume_id: 卷ID（可选，不传则自动获取）

    Returns:
        Dict包含:
            - success: bool
            - chapters: List[Dict] 所有章节元数据列表
            - total_count: int 章节总数
            - error: str 错误信息（如果失败）
    """
    if not self._is_logged_in:
        return {"success": False, "chapters": [], "total_count": 0, "error": "未登录"}

    try:
        all_chapters = []
        page_index = 1
        page_count = 15  # 每页章节数
        total_count = 0

        while True:
            # 构建API URL
            # 注意：msToken需要从cookie或页面获取，这里简化处理
            url = f"https://fanqienovel.com/api/author/chapter/chapter_list/v1"
            params = {
                "aid": "2503",
                "app_name": "muye_novel",
                "book_id": book_id,
                "page_index": page_index,
                "page_count": page_count,
                "status": "0",
                "must_have_correction_feedback": "0",
                "need_correction_feedback_num": "1",
                "sort": "",
            }

            # 如果有volume_id则添加
            if volume_id:
                params["volume_id"] = volume_id

            self.logger.info(f"[fanqie_book] Fetching chapter list page {page_index}...")

            # 发送请求
            response = self.page.request.get(url, params=params)
            data = response.json()

            if data.get("code") != 0:
                return {
                    "success": False,
                    "chapters": all_chapters,
                    "total_count": total_count,
                    "error": data.get("message", "获取章节列表失败")
                }

            result_data = data.get("data", {})
            if page_index == 1:
                total_count = result_data.get("total_count", 0)
                self.logger.info(f"[fanqie_book] Total chapters: {total_count}")

            items = result_data.get("item_list", [])
            all_chapters.extend(items)

            # 获取volume_id（第一页时获取）
            if page_index == 1 and not volume_id:
                volume_id = result_data.get("volume_id", "")
                self.logger.info(f"[fanqie_book] Volume ID: {volume_id}")

            self.logger.info(f"[fanqie_book] Page {page_index}: got {len(items)} chapters")

            # 检查是否到达最后一页
            if len(items) < page_count:
                break

            page_index += 1

        return {
            "success": True,
            "chapters": all_chapters,
            "total_count": total_count,
            "volume_id": volume_id,
            "error": None
        }

    except Exception as e:
        self.logger.error(f"[fanqie_book] Failed to list chapters: {e}")
        return {"success": False, "chapters": [], "total_count": 0, "error": str(e)}
```

- [ ] **Step 2: 验证语法**

运行: `python -m py_compile src/services/fanqie_book_service.py`
Expected: 无输出（语法正确）

- [ ] **Step 3: 提交**

```bash
git add src/services/fanqie_book_service.py
git commit -m "feat: add FanqieBookService.list_published_chapters() method"
```

---

## Task 2: FanqieBookService.navigate_to_chapter_manage()

**Files:**
- Modify: `src/services/fanqie_book_service.py`

- [ ] **Step 1: 添加 navigate_to_chapter_manage() 方法**

在 `FanqieBookService` 类中添加：

```python
def navigate_to_chapter_manage(self, book_id: str, book_name: str = "") -> bool:
    """
    导航到章节管理页面。

    Args:
        book_id: 书籍ID
        book_name: 书籍名称（用于URL编码，可选）

    Returns:
        True if navigation successful
    """
    if not self._is_logged_in:
        self.logger.error("[fanqie_book] Not logged in")
        return False

    try:
        import urllib.parse
        encoded_name = urllib.parse.quote(book_name) if book_name else ""
        url = f"https://fanqienovel.com/main/writer/chapter-manage/{book_id}&{encoded_name}?type=1"

        self.logger.info(f"[fanqie_book] Navigating to chapter manage: {url}")
        self.page.goto(url)
        self.page.wait_for_load_state("networkidle", timeout=30000)
        time.sleep(2)

        self.logger.info("[fanqie_book] Chapter manage page loaded")
        return True

    except Exception as e:
        self.logger.error(f"[fanqie_book] Navigate to chapter manage failed: {e}")
        return False
```

- [ ] **Step 2: 提交**

```bash
git add src/services/fanqie_book_service.py
git commit -m "feat: add FanqieBookService.navigate_to_chapter_manage()"
```

---

## Task 3: WorkManager 章节元数据读写方法

**Files:**
- Modify: `src/core/work_manager.py`

- [ ] **Step 1: 添加章节元数据相关方法**

在 `WorkManager` 类中添加以下方法：

```python
def _get_chapters_dir(self, work_id: str) -> str:
    """
    获取章节元数据目录路径。

    Args:
        work_id: 作品ID

    Returns:
        章节目录的完整路径
    """
    return os.path.join(self._get_work_dir(work_id), "chapters")

def _ensure_chapters_dir(self, work_id: str) -> str:
    """
    确保章节目录存在。

    Args:
        work_id: 作品ID

    Returns:
        章节目录的完整路径
    """
    chapters_dir = self._get_chapters_dir(work_id)
    os.makedirs(chapters_dir, exist_ok=True)
    return chapters_dir

def save_chapter_metadata(self, work_id: str, chapter_index: int, metadata: Dict[str, Any]) -> bool:
    """
    保存单个章节的元数据到文件。

    Args:
        work_id: 作品ID
        chapter_index: 章节号
        metadata: 章节元数据字典

    Returns:
        True if saved successfully
    """
    try:
        chapters_dir = self._ensure_chapters_dir(work_id)
        file_path = os.path.join(chapters_dir, f"chapter_{chapter_index}.json")

        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)

        self.logger.info(f"[work_manager] Saved chapter metadata: chapter_{chapter_index}")
        return True

    except Exception as e:
        self.logger.error(f"[work_manager] Failed to save chapter metadata: {e}")
        return False

def load_chapter_metadata(self, work_id: str, chapter_index: int) -> Optional[Dict[str, Any]]:
    """
    读取单个章节的元数据。

    Args:
        work_id: 作品ID
        chapter_index: 章节号

    Returns:
        章节元数据字典，如果不存在则返回None
    """
    try:
        chapters_dir = self._get_chapters_dir(work_id)
        file_path = os.path.join(chapters_dir, f"chapter_{chapter_index}.json")

        if not os.path.exists(file_path):
            return None

        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    except Exception as e:
        self.logger.error(f"[work_manager] Failed to load chapter metadata: {e}")
        return None

def load_all_chapter_metadata(self, work_id: str) -> List[Dict[str, Any]]:
    """
    读取所有章节的元数据。

    Args:
        work_id: 作品ID

    Returns:
        章节元数据列表
    """
    chapters = []
    try:
        chapters_dir = self._get_chapters_dir(work_id)
        if not os.path.exists(chapters_dir):
            return chapters

        for filename in os.listdir(chapters_dir):
            if filename.startswith("chapter_") and filename.endswith(".json"):
                file_path = os.path.join(chapters_dir, filename)
                with open(file_path, 'r', encoding='utf-8') as f:
                    chapters.append(json.load(f))

        # 按章节号排序
        chapters.sort(key=lambda x: x.get("index", 0))
        return chapters

    except Exception as e:
        self.logger.error(f"[work_manager] Failed to load all chapter metadata: {e}")
        return chapters

def save_fanqie_chapters(self, work_id: str, chapters: List[Dict[str, Any]]) -> bool:
    """
    保存番茄已发布章节列表到文件（兼容旧接口）。

    Args:
        work_id: 作品ID
        chapters: 章节元数据列表

    Returns:
        True if saved successfully
    """
    try:
        for chapter in chapters:
            index = chapter.get("index")
            if index is not None:
                self.save_chapter_metadata(work_id, index, chapter)
        return True
    except Exception as e:
        self.logger.error(f"[work_manager] Failed to save fanqie chapters: {e}")
        return False
```

- [ ] **Step 2: 添加必要的import**

在文件顶部添加：
```python
import json
from typing import List
```

- [ ] **Step 3: 验证语法**

Run: `python -m py_compile src/core/work_manager.py`
Expected: 无输出

- [ ] **Step 4: 提交**

```bash
git add src/core/work_manager.py
git commit -m "feat: add WorkManager chapter metadata methods"
```

---

## Task 4: FanqiePublisher.update_chapter()

**Files:**
- Modify: `src/services/fanqie_publisher.py`

- [ ] **Step 1: 添加 update_chapter() 方法**

在 `FanqiePublisher` 类中添加：

```python
def update_chapter(
    self,
    chapter_number: int,
    chapter_title: str,
    chapter_content: str,
    chapter_id: str = None,
    progress_callback: Optional[Callable[[PublishProgress], None]] = None
) -> bool:
    """
    更新番茄平台已发布的章节。

    Args:
        chapter_number: 章节号
        chapter_title: 章节标题
        chapter_content: 章节正文
        chapter_id: 番茄平台章节ID（用于URL，如果不传则使用book_id构造）
        progress_callback: 进度回调

    Returns:
        True if update successful, False otherwise
    """
    if not self.ensure_logged_in():
        if progress_callback:
            progress_callback(PublishProgress(
                current_chapter=0,
                total_chapters=1,
                status="error",
                message="登录失败"
            ))
        return False

    if not self._check_page_valid():
        self.logger.error("[fanqie] Page is invalid before updating chapter")
        return False

    try:
        # 构造编辑页面URL
        if chapter_id:
            edit_url = f"https://fanqienovel.com/main/writer/{self._book_id}/publish/{chapter_id}/?enter_from=modifychapter"
        else:
            # 如果没有chapter_id，无法编辑已有章节
            self.logger.error("[fanqie] chapter_id is required for updating")
            return False

        self.logger.info(f"[fanqie] Navigating to chapter edit: {edit_url}")
        self.page.goto(edit_url)
        self.page.wait_for_load_state("networkidle", timeout=30000)
        time.sleep(2)

        if progress_callback:
            progress_callback(PublishProgress(
                current_chapter=chapter_number,
                total_chapters=1,
                status="publishing",
                message=f"正在更新第 {chapter_number} 章..."
            ))

        # 填写章节标题
        self.logger.info("[fanqie] Filling chapter title...")
        title_input = self.page.locator(
            'div.serial-editor-title-right div.serial-editor-input-hint.input input[placeholder="请输入标题"]'
        )
        title_input.wait_for(state="visible", timeout=10000)
        self._wait_for_input_value(title_input, chapter_title)
        self.logger.info(f"[fanqie] Chapter title filled: {chapter_title}")

        # 填写章节正文
        self.logger.info("[fanqie] Filling chapter content...")
        content_input = self.page.locator(
            'div.ProseMirror[contenteditable="true"][spellcheck="false"][translate="no"]'
        )
        content_input.wait_for(state="visible", timeout=10000)

        max_fill_attempts = 3
        for attempt in range(max_fill_attempts):
            content_input.fill("")
            content_input.fill(chapter_content)
            current_len = len(content_input.text_content() or "")
            if current_len >= len(chapter_content.replace("\n", "")) - 10:
                break
            self.logger.warning(f"[fanqie] Content fill attempt {attempt + 1} failed, retrying...")
            time.sleep(1)

        self.logger.info(f"[fanqie] Chapter content filled ({len(chapter_content)} chars)")

        # 点击下一步
        self.logger.info("[fanqie] Clicking next step button...")
        next_step_btn = self.page.locator(
            'div.publish-header-right button.arco-btn span:has-text("下一步")'
        )
        next_step_btn.wait_for(state="visible", timeout=10000)
        next_step_btn.click()
        self.logger.info("[fanqie] Clicked next step button")

        time.sleep(1)

        # 处理各种提示框
        self._handle_typo_warning()
        self._handle_author_note_warning()

        # 选择是否使用AI - 选择"否"
        self.logger.info("[fanqie] Selecting AI usage option...")
        use_ai_btn = self.page.locator(
            'div.publish-confirm-card div.card-content-line-control div.arco-radio-group[role="radiogroup"] span.arco-radio-text:has-text("否")'
        )
        if use_ai_btn.count() > 0:
            use_ai_btn.click()
            self.logger.info("[fanqie] Disabled AI usage")

        # 点击确认发布
        self.logger.info("[fanqie] Clicking confirm publish button...")
        confirm_btn = self.page.locator(
            'div.arco-modal[role="dialog"] div.arco-modal-footer button.arco-btn span:has-text("确认发布")'
        )
        confirm_btn.wait_for(state="visible", timeout=10000)
        confirm_btn.click()
        self.logger.info("[fanqie] Clicked confirm publish button")

        time.sleep(2)

        if progress_callback:
            progress_callback(PublishProgress(
                current_chapter=chapter_number,
                total_chapters=1,
                status="completed",
                message="更新成功",
                success=True
            ))

        return True

    except Exception as e:
        self.logger.error(f"[fanqie] Update chapter failed: {e}")
        if progress_callback:
            progress_callback(PublishProgress(
                current_chapter=chapter_number,
                total_chapters=1,
                status="error",
                message=f"更新失败: {str(e)}"
            ))
        return False
```

- [ ] **Step 2: 验证语法**

Run: `python -m py_compile src/services/fanqie_publisher.py`
Expected: 无输出

- [ ] **Step 3: 提交**

```bash
git add src/services/fanqie_publisher.py
git commit -m "feat: add FanqiePublisher.update_chapter() method"
```

---

## Task 5: PublishingView 步骤5 UI框架

**Files:**
- Modify: `src/gui/views/publishing_view.py`

- [ ] **Step 1: 修改步骤指示器和导航按钮**

找到 `_setup_step_indicator()` 方法，将步骤列表修改为：
```python
steps = ["选择平台", "选择作品", "发布范围", "选择账号", "发布策略", "汇总发布"]
```

找到 `_update_step_visibility()` 方法，将最大值从 5 改为 6：
```python
self.next_btn.setVisible(self._current_step < 6)
```

- [ ] **Step 2: 添加步骤5的步骤条**

在 `PublishingView` 类中添加内部方法：

```python
def _setup_strategy_sub_steps(self) -> None:
    """设置发布策略子阶段指示器。"""
    self.strategy_sub_steps = ["更新元数据", "选择范围", "发布方式"]
    self._current_strategy_sub_step = 1

def _update_strategy_sub_step_visibility(self) -> None:
    """更新发布策略子阶段的可见性。"""
    # 子阶段指示器在步骤5显示时更新
    pass
```

- [ ] **Step 3: 创建步骤5 Widget**

在 `_create_step5_widget()` 之后添加新方法：

```python
def _create_step5_widget(self) -> QWidget:
    """Step 5: Publish strategy with three sub-stages."""
    scroll_area = QScrollArea()
    scroll_area.setWidgetResizable(True)
    scroll_area.setFrameShape(QScrollArea.Shape.NoFrame)

    widget = QWidget()
    layout = QVBoxLayout(widget)
    layout.setSpacing(20)

    # Title
    title = QLabel("发布策略")
    title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
    layout.addWidget(title)

    # Sub-stage indicator
    self.strategy_sub_indicator = QWidget()
    strategy_layout = QHBoxLayout(self.strategy_sub_indicator)
    strategy_layout.setContentsMargins(0, 10, 0, 10)
    strategy_layout.setSpacing(20)

    self.strategy_sub_labels = []
    for i, step_name in enumerate(self.strategy_sub_steps):
        label = QLabel(f"{i+1}. {step_name}")
        label.setStyleSheet("color: #7f8c8d; font-size: 13px; padding: 5px 10px;")
        if i == 0:
            label.setStyleSheet("color: #3498db; font-size: 13px; font-weight: bold; padding: 5px 10px;")
        strategy_layout.addWidget(label)
        self.strategy_sub_labels.append(label)
        if i < len(self.strategy_sub_steps) - 1:
            arrow = QLabel(" > ")
            arrow.setStyleSheet("color: #bdc3c7;")
            strategy_layout.addWidget(arrow)

    strategy_layout.addStretch()
    layout.addWidget(self.strategy_sub_indicator)

    # Container for sub-stage content
    self.strategy_content_stack = QWidget()
    self.strategy_content_layout = QVBoxLayout(self.strategy_content_stack)
    self.strategy_content_layout.setSpacing(15)

    # Create sub-stage widgets
    self.strategy_stage1_widget = self._create_strategy_stage1_widget()  # 更新元数据
    self.strategy_stage2_widget = self._create_strategy_stage2_widget()  # 选择范围
    self.strategy_stage3_widget = self._create_strategy_stage3_widget()  # 发布方式

    self.strategy_content_layout.addWidget(self.strategy_stage1_widget)
    self.strategy_content_layout.addWidget(self.strategy_stage2_widget)
    self.strategy_content_layout.addWidget(self.strategy_stage3_widget)

    layout.addWidget(self.strategy_content_stack)

    # Navigation buttons for sub-stages
    nav_row = QHBoxLayout()
    nav_row.addStretch()

    self.strategy_prev_btn = QPushButton("上一步")
    self.strategy_prev_btn.setFixedSize(100, 32)
    self.strategy_prev_btn.setVisible(False)
    nav_row.addWidget(self.strategy_prev_btn)

    self.strategy_next_btn = QPushButton("下一步")
    self.strategy_next_btn.setFixedSize(100, 32)
    nav_row.addWidget(self.strategy_next_btn)

    layout.addLayout(nav_row)
    layout.addStretch()

    scroll_area.setWidget(widget)
    return scroll_area
```

- [ ] **Step 4: 创建子阶段1 Widget（更新元数据）**

添加方法：

```python
def _create_strategy_stage1_widget(self) -> QWidget:
    """子阶段1: 更新已发布章节元数据。"""
    widget = QWidget()
    layout = QVBoxLayout(widget)
    layout.setSpacing(15)

    # 说明文字
    info_label = QLabel("从番茄平台获取已发布章节的元数据，同步到本地")
    info_label.setStyleSheet("color: #7f8c8d; font-size: 13px;")
    layout.addWidget(info_label)

    # 状态显示
    self.stage1_status_label = QLabel("准备获取番茄已发布章节...")
    self.stage1_status_label.setStyleSheet("color: #34495e; font-size: 14px; padding: 10px; background-color: #f5f5f5; border-radius: 4px;")
    layout.addWidget(self.stage1_status_label)

    # 章节列表（可折叠）
    self.stage1_chapter_list = QWidget()
    stage1_list_layout = QVBoxLayout(self.stage1_chapter_list)
    stage1_list_layout.setSpacing(5)

    self.stage1_chapter_scroll = QScrollArea()
    self.stage1_chapter_scroll.setWidgetResizable(True)
    self.stage1_chapter_scroll.setMaximumHeight(200)

    self.stage1_chapter_container = QWidget()
    self.stage1_chapter_container_layout = QVBoxLayout(self.stage1_chapter_container)
    self.stage1_chapter_container_layout.setSpacing(3)
    self.stage1_chapter_scroll.setWidget(self.stage1_chapter_container)

    stage1_list_layout.addWidget(self.stage1_chapter_scroll)
    self.stage1_chapter_list.setVisible(False)
    layout.addWidget(self.stage1_chapter_list)

    # 获取按钮
    self.stage1_fetch_btn = QPushButton("获取番茄已发布章节")
    self.stage1_fetch_btn.setFixedHeight(36)
    self.stage1_fetch_btn.setStyleSheet("""
        QPushButton {
            background-color: #3498db;
            color: #ffffff;
            border: none;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #2980b9;
        }
    """)
    layout.addWidget(self.stage1_fetch_btn)

    layout.addStretch()
    return widget
```

- [ ] **Step 5: 创建子阶段2 Widget（选择范围）**

添加方法：

```python
def _create_strategy_stage2_widget(self) -> QWidget:
    """子阶段2: 选择章节范围。"""
    widget = QWidget()
    layout = QVBoxLayout(widget)
    layout.setSpacing(15)

    # 说明文字
    info_label = QLabel("选择本地章节和番茄平台对齐的章节范围")
    info_label.setStyleSheet("color: #7f8c8d; font-size: 13px;")
    layout.addWidget(info_label)

    # 当前状态
    status_group = QGroupBox("章节状态")
    status_layout = QVBoxLayout(status_group)
    status_layout.setSpacing(8)

    self.stage2_local_label = QLabel("本地章节: - 章")
    self.stage2_local_label.setStyleSheet("color: #34495e; font-size: 13px;")
    status_layout.addWidget(self.stage2_local_label)

    self.stage2_fanqie_label = QLabel("番茄已发布: - 章")
    self.stage2_fanqie_label.setStyleSheet("color: #34495e; font-size: 13px;")
    status_layout.addWidget(self.stage2_fanqie_label)

    self.stage2_new_label = QLabel("将新发布: - 章")
    self.stage2_new_label.setStyleSheet("color: #27ae60; font-size: 13px; font-weight: bold;")
    status_layout.addWidget(self.stage2_new_label)

    self.stage2_update_label = QLabel("将更新: - 章")
    self.stage2_update_label.setStyleSheet("color: #e67e22; font-size: 13px;")
    status_layout.addWidget(self.stage2_update_label)

    layout.addWidget(status_group)

    # 范围选择
    range_group = QGroupBox("发布章节范围")
    range_layout = QVBoxLayout(range_group)
    range_layout.setSpacing(10)

    range_row = QHBoxLayout()
    range_row.setSpacing(15)

    range_row.addWidget(QLabel("从第"))
    self.stage2_start_input = QSpinBox()
    self.stage2_start_input.setMinimum(1)
    self.stage2_start_input.setMaximum(9999)
    self.stage2_start_input.setFixedWidth(80)
    range_row.addWidget(self.stage2_start_input)

    range_row.addWidget(QLabel("章 到 第"))

    self.stage2_end_input = QSpinBox()
    self.stage2_end_input.setMinimum(1)
    self.stage2_end_input.setMaximum(9999)
    self.stage2_end_input.setFixedWidth(80)
    range_row.addWidget(self.stage2_end_input)

    range_row.addWidget(QLabel("章"))
    range_row.addStretch()
    range_layout.addLayout(range_row)

    # 预览信息
    self.stage2_preview_label = QLabel("")
    self.stage2_preview_label.setStyleSheet("color: #7f8c8d; font-size: 12px; padding: 5px 0;")
    range_layout.addWidget(self.stage2_preview_label)

    layout.addWidget(range_group)

    layout.addStretch()
    return widget
```

- [ ] **Step 6: 创建子阶段3 Widget（发布方式）**

添加方法：

```python
def _create_strategy_stage3_widget(self) -> QWidget:
    """子阶段3: 选择发布方式（直接发布/定时发布）。"""
    widget = QWidget()
    layout = QVBoxLayout(widget)
    layout.setSpacing(15)

    # 发布方式选择
    mode_group = QGroupBox("发布方式")
    mode_layout = QVBoxLayout(mode_group)
    mode_layout.setSpacing(10)

    self.publish_mode_group = QButtonGroup()

    self.direct_publish_radio = QRadioButton("直接发布")
    self.direct_publish_radio.setChecked(True)
    self.direct_publish_radio.setFixedHeight(32)
    mode_layout.addWidget(self.direct_publish_radio)
    self.publish_mode_group.addButton(self.direct_publish_radio)

    self.timed_publish_radio = QRadioButton("定时发布")
    self.timed_publish_radio.setFixedHeight(32)
    mode_layout.addWidget(self.timed_publish_radio)
    self.publish_mode_group.addButton(self.timed_publish_radio)

    layout.addWidget(mode_group)

    # 定时发布设置（默认隐藏）
    self.timed_settings_widget = QWidget()
    self.timed_settings_widget.setVisible(False)
    timed_layout = QVBoxLayout(self.timed_settings_widget)
    timed_layout.setSpacing(10)

    # 每日发布数量
    daily_row = QHBoxLayout()
    daily_row.addWidget(QLabel("每日发布"))
    self.daily_count_input = QSpinBox()
    self.daily_count_input.setMinimum(1)
    self.daily_count_input.setMaximum(20)
    self.daily_count_input.setValue(2)
    self.daily_count_input.setFixedWidth(80)
    daily_row.addWidget(self.daily_count_input)
    daily_row.addWidget(QLabel("章"))
    daily_row.addStretch()
    timed_layout.addLayout(daily_row)

    # 开始日期
    date_row = QHBoxLayout()
    date_row.addWidget(QLabel("开始日期"))
    self.start_date_input = QLineEdit()
    self.start_date_input.setPlaceholderText("YYYY-MM-DD")
    self.start_date_input.setFixedWidth(120)
    date_row.addWidget(self.start_date_input)
    date_row.addStretch()
    timed_layout.addLayout(date_row)

    # 时间范围
    time_row = QHBoxLayout()
    time_row.addWidget(QLabel("时间范围"))
    self.start_time_input = QLineEdit()
    self.start_time_input.setPlaceholderText("HH:MM")
    self.start_time_input.setFixedWidth(80)
    time_row.addWidget(self.start_time_input)
    time_row.addWidget(QLabel(" - "))
    self.end_time_input = QLineEdit()
    self.end_time_input.setPlaceholderText("HH:MM")
    self.end_time_input.setFixedWidth(80)
    time_row.addWidget(self.end_time_input)
    time_row.addStretch()
    timed_layout.addLayout(time_row)

    # 生成按钮
    self.generate_schedule_btn = QPushButton("生成发布时间表")
    self.generate_schedule_btn.setFixedHeight(32)
    self.generate_schedule_btn.setStyleSheet("""
        QPushButton {
            background-color: #9b59b6;
            color: #ffffff;
            border: none;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #8e44ad;
        }
    """)
    timed_layout.addWidget(self.generate_schedule_btn)

    layout.addWidget(self.timed_settings_widget)

    # 发布时间表（默认隐藏）
    self.schedule_table_widget = QWidget()
    self.schedule_table_widget.setVisible(False)
    schedule_layout = QVBoxLayout(self.schedule_table_widget)
    schedule_layout.setSpacing(5)

    schedule_title = QLabel("发布时间表")
    schedule_title.setStyleSheet("font-weight: bold; color: #2c3e50;")
    schedule_layout.addWidget(schedule_title)

    self.schedule_list_widget = QListWidget()
    self.schedule_list_widget.setMaximumHeight(200)
    schedule_layout.addWidget(self.schedule_list_widget)

    layout.addWidget(self.schedule_table_widget)

    layout.addStretch()
    return widget
```

- [ ] **Step 7: 修改 _setup_ui() 方法**

找到 `_setup_ui()` 方法，修改步骤widget的创建部分：

将：
```python
self.step5_widget = self._create_step5_widget()  # 汇总发布
```

改为（在 step4_widget 创建之后添加 step5_widget）：
```python
self.step5_widget = self._create_step5_widget()  # 发布策略
self.step6_widget = self._create_step6_widget()  # 汇总发布
```

注意：需要将原来的 `_create_step5_widget` 重命名或移动内容。

- [ ] **Step 8: 验证语法**

Run: `python -m py_compile src/gui/views/publishing_view.py`
Expected: 无输出（如果有错误，需要修复）

- [ ] **Step 9: 提交**

```bash
git add src/gui/views/publishing_view.py
git commit -m "feat: add PublishingView step5 UI framework with 3 sub-stages"
```

---

## Task 6: PublishingView 步骤5逻辑连接

**Files:**
- Modify: `src/gui/views/publishing_view.py`

- [ ] **Step 1: 添加子阶段切换逻辑**

在 `PublishingView` 类中添加：

```python
def _update_strategy_stage_visibility(self) -> None:
    """更新发布策略子阶段的可见性。"""
    stages = [self.strategy_stage1_widget, self.strategy_stage2_widget, self.strategy_stage3_widget]

    for i, stage in enumerate(stages, 1):
        stage.setVisible(i == self._current_strategy_sub_step)

    # 更新子阶段指示器
    for i, label in enumerate(self.strategy_sub_labels, 1):
        if i == self._current_strategy_sub_step:
            label.setStyleSheet("color: #3498db; font-size: 13px; font-weight: bold; padding: 5px 10px;")
        elif i < self._current_strategy_sub_step:
            label.setStyleSheet("color: #27ae60; font-size: 13px; padding: 5px 10px;")
        else:
            label.setStyleSheet("color: #7f8c8d; font-size: 13px; padding: 5px 10px;")

    # 更新导航按钮
    self.strategy_prev_btn.setVisible(self._current_strategy_sub_step > 1)

    if self._current_strategy_sub_step == 3:
        self.strategy_next_btn.setText("完成")
    else:
        self.strategy_next_btn.setText("下一步")

def _on_strategy_prev(self) -> None:
    """处理子阶段上一步按钮。"""
    if self._current_strategy_sub_step > 1:
        self._current_strategy_sub_step -= 1
        self._update_strategy_stage_visibility()

def _on_strategy_next(self) -> None:
    """处理子阶段下一步按钮。"""
    if self._current_strategy_sub_step < 3:
        self._current_strategy_sub_step += 1
        self._update_strategy_stage_visibility()
    else:
        # 完成，进入汇总发布
        self._current_step = 6
        self._update_step_visibility()
        self._update_summary()
```

- [ ] **Step 2: 连接信号**

在 `_setup_connections()` 方法末尾添加：

```python
# Step 5: Publish strategy sub-stages
self.strategy_prev_btn.clicked.connect(self._on_strategy_prev)
self.strategy_next_btn.clicked.connect(self._on_strategy_next)
self.stage1_fetch_btn.clicked.connect(self._on_fetch_fanqie_chapters)
self.direct_publish_radio.toggled.connect(self._on_publish_mode_changed)
self.timed_publish_radio.toggled.connect(self._on_publish_mode_changed)
self.generate_schedule_btn.clicked.connect(self._on_generate_schedule)
self.stage2_start_input.valueChanged.connect(self._on_strategy_range_changed)
self.stage2_end_input.valueChanged.connect(self._on_strategy_range_changed)
```

- [ ] **Step 3: 添加槽函数**

添加以下槽函数实现：

```python
def _on_fetch_fanqie_chapters(self) -> None:
    """获取番茄已发布章节。"""
    if not self._current_work or not self._current_work.fanqie_book_id:
        QMessageBox.warning(self, "提示", "该作品尚未创建番茄书本")
        return

    self.stage1_fetch_btn.setEnabled(False)
    self.stage1_status_label.setText("正在获取番茄已发布章节...")
    QTimer.singleShot(100, self._do_fetch_fanqie_chapters)

def _do_fetch_fanqie_chapters(self) -> None:
    """执行获取番茄章节的后台操作。"""
    try:
        # 调用 FanqieBookService 获取章节
        from services.fanqie_account_manager import FanqieAccountManager
        # ... (需要从UI获取账号信息并调用)

        self.stage1_status_label.setText("获取完成！")
        self.stage1_chapter_list.setVisible(True)
        self.stage1_fetch_btn.setEnabled(True)

    except Exception as e:
        self.logger.error(f"[publish] Failed to fetch chapters: {e}")
        self.stage1_status_label.setText(f"获取失败: {e}")
        self.stage1_fetch_btn.setEnabled(True)

def _on_publish_mode_changed(self) -> None:
    """发布方式改变。"""
    self.timed_settings_widget.setVisible(self.timed_publish_radio.isChecked())

def _on_generate_schedule(self) -> None:
    """生成发布时间表。"""
    # 获取输入值
    start_date = self.start_date_input.text()
    start_time = self.start_time_input.text()
    end_time = self.end_time_input.text()
    daily_count = self.daily_count_input.value()

    # 验证输入
    if not start_date or not start_time or not end_time:
        QMessageBox.warning(self, "提示", "请填写完整的日期和时间")
        return

    # 生成时间表
    # ... (根据设计文档的规则生成)

    self.schedule_table_widget.setVisible(True)

def _on_strategy_range_changed(self) -> None:
    """章节范围改变。"""
    start = self.stage2_start_input.value()
    end = self.stage2_end_input.value()
    # 更新预览信息
    if start <= end:
        new_count = max(0, end - max(start, self._current_work.fanqie_last_published_chapter))
        update_count = min(end - start + 1 - new_count, self._current_work.fanqie_last_published_chapter - start + 1 if start <= self._current_work.fanqie_last_published_chapter else 0)
        self.stage2_preview_label.setText(f"将新发布 {new_count} 章，更新 {update_count} 章")
```

- [ ] **Step 4: 验证语法**

Run: `python -m py_compile src/gui/views/publishing_view.py`
Expected: 无输出

- [ ] **Step 5: 提交**

```bash
git add src/gui/views/publishing_view.py
git commit -m "feat: connect PublishingView step5 logic and signals"
```

---

## Task 7: 集成测试

**Files:**
- 测试所有新增功能

- [ ] **Step 1: 测试 FanqieBookService.list_published_chapters()**

手动测试或编写单元测试验证方法正确性。

- [ ] **Step 2: 测试 WorkManager 章节元数据方法**

```python
# 在 Python 控制台测试
from src.core.work_manager import WorkManager
# ... 初始化并测试 save_chapter_metadata 和 load_chapter_metadata
```

- [ ] **Step 3: 测试 PublishingView 步骤5**

启动应用，导航到发布流程，验证UI正确显示。

- [ ] **Step 4: 提交**

```bash
git add .
git commit -m "test: add integration tests for publishing strategy feature"
```

---

## 实施检查清单

- [ ] Task 1: FanqieBookService.list_published_chapters()
- [ ] Task 2: FanqieBookService.navigate_to_chapter_manage()
- [ ] Task 3: WorkManager 章节元数据方法
- [ ] Task 4: FanqiePublisher.update_chapter()
- [ ] Task 5: PublishingView 步骤5 UI框架
- [ ] Task 6: PublishingView 步骤5逻辑连接
- [ ] Task 7: 集成测试
