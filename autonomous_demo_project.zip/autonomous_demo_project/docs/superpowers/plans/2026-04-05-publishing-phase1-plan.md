# 发布中心重构 - Phase 1 实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 建立发布中心重构的基础框架 - 步骤导航 + 番茄账号管理（增删改查）

**Architecture:**
- 单页面引导式布局，步骤动态切换
- 番茄账号独立管理，数据存储在 `storage_root/fanqie_accounts.json`
- 账号对话框独立组件，支持增删改查

**Tech Stack:** PyQt6, dataclass, JSON文件存储

---

## 文件结构

```
src/
├── models/
│   ├── work.py              # 修改：添加番茄发布字段
│   └── fanqie_account.py    # 新建：番茄账号数据模型
├── services/
│   └── fanqie_account_manager.py  # 新建：账号CRUD服务
└── gui/
    ├── dialogs/
    │   └── fanqie_account_dialog.py  # 新建：账号管理对话框
    └── views/
        └── publishing_view.py  # 修改：步骤导航框架
```

---

## Task 1: 扩展 Work 模型，添加番茄发布字段

**Files:**
- Modify: `src/models/work.py:40-60`（在 `Work` dataclass 中添加字段）

- [ ] **Step 1: 添加 fanqie_* 字段到 Work 模型**

在 `Work` dataclass 中找到 `last_published_chapter: int = 0` 字段，在其下方添加：

```python
    # Fanqie publishing related fields
    fanqie_book_id: str = ""                        # 番茄平台book_id
    fanqie_book_url: str = ""                       # 番茄作品URL
    fanqie_book_title: str = ""                     # 番茄平台书名
    fanqie_account_id: str = ""                     # 发布时使用的账号ID
    fanqie_last_published_chapter: int = 0          # 番茄平台已发布章节数
    fanqie_chapters: List[Dict] = field(default_factory=list)  # [{chapter_num, url, published_at}, ...]
    fanqie_publish_config: Optional[Dict] = None    # 上次发布配置
```

- [ ] **Step 2: 更新 to_dict 方法**

在 `to_dict` 方法中添加新字段的序列化（约第79行）：

```python
            "fanqie_book_id": self.fanqie_book_id,
            "fanqie_book_url": self.fanqie_book_url,
            "fanqie_book_title": self.fanqie_book_title,
            "fanqie_account_id": self.fanqie_account_id,
            "fanqie_last_published_chapter": self.fanqie_last_published_chapter,
            "fanqie_chapters": self.fanqie_chapters,
            "fanqie_publish_config": self.fanqie_publish_config,
```

- [ ] **Step 3: 添加 List 导入**

确认文件头部有 `from typing import Optional, List, Dict, Any`（已有 Optional）

- [ ] **Step 4: 验证模型可以正常序列化/反序列化**

```bash
cd D:\workspace\aiwriter-local\generations\autonomous_demo_project
python -c "from models.work import Work; w = Work(); print('fanqie_book_id:', w.fanqie_book_id); import json; print(json.dumps(w.to_dict()))"
```

预期输出包含新的 fanqie_ 字段

- [ ] **Step 5: 提交**

```bash
git add src/models/work.py
git commit -m "feat: add fanqie publishing fields to Work model"
```

---

## Task 2: 创建番茄账号数据模型

**Files:**
- Create: `src/models/fanqie_account.py`

- [ ] **Step 1: 创建 fanqie_account.py**

```python
"""
Fanqie Account model for AI Writer application.

Represents a番茄小说 writer account with credentials.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Dict, Any


@dataclass
class FanqieAccount:
    """
    Represents a番茄小说 writer account.

    Attributes:
        id: Unique identifier (format: fanqie_YYYYMMDD_XXX)
        phone: Full phone number
        password: Account password
        nickname: User-defined nickname/remark
        created_at: Creation timestamp
    """
    id: str = ""
    phone: str = ""
    password: str = ""
    nickname: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def __post_init__(self) -> None:
        """Generate ID if not provided."""
        if not self.id:
            import random
            timestamp = datetime.now().strftime("%Y%m%d")
            suffix = f"{random.randint(1, 999):03d}"
            self.id = f"fanqie_{timestamp}_{suffix}"

    def get_display_name(self) -> str:
        """
        Get display name for the account.

        Returns:
            Nickname if set, otherwise masked phone number (138****1234)
        """
        if self.nickname:
            return f"{self.nickname} ({self._masked_phone()})"
        return self._masked_phone()

    def _masked_phone(self) -> str:
        """
        Get masked phone number.

        Returns:
            Masked phone like 138****1234
        """
        if len(self.phone) >= 11:
            return f"{self.phone[:3]}****{self.phone[-4:]}"
        return self.phone

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "phone": self.phone,
            "password": self.password,
            "nickname": self.nickname,
            "created_at": self.created_at
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FanqieAccount':
        """Create instance from dictionary."""
        account = cls()
        for key, value in data.items():
            if hasattr(account, key):
                setattr(account, key, value)
        return account

    @staticmethod
    def validate_id(account_id: str) -> bool:
        """Validate account ID format (fanqie_YYYYMMDD_XXX)."""
        import re
        pattern = r'^fanqie_\d{8}_\d{3}$'
        return bool(re.match(pattern, account_id))
```

- [ ] **Step 2: 验证模型**

```bash
cd D:\workspace\aiwriter-local\generations\autonomous_demo_project
python -c "from models.fanqie_account import FanqieAccount; a = FanqieAccount(phone='13812345678', password='test123', nickname='主号'); print(a.get_display_name()); print(a.to_dict())"
```

预期输出：
```
主号 (138****5678)
{'id': 'fanqie_20260405_XXX', 'phone': '13812345678', 'password': 'test123', 'nickname': '主号', 'created_at': '...'}
```

- [ ] **Step 3: 提交**

```bash
git add src/models/fanqie_account.py
git commit -m "feat: add FanqieAccount model"
```

---

## Task 3: 创建番茄账号管理服务

**Files:**
- Create: `src/services/fanqie_account_manager.py`

- [ ] **Step 1: 创建 fanqie_account_manager.py**

```python
"""
Fanqie Account Manager for AI Writer application.

Handles CRUD operations for番茄小说 writer accounts.
"""
import json
import os
from typing import List, Optional, Dict, Any
from datetime import datetime

from models.fanqie_account import FanqieAccount
from utils.logger import get_logger


class FanqieAccountManager:
    """
    Manager for fanqie account operations.

    Handles CRUD operations for番茄小说 writer accounts,
    stored in fanqie_accounts.json under storage_root.
    """

    def __init__(self, storage_root: str):
        """
        Initialize the account manager.

        Args:
            storage_root: Root directory for application data
        """
        self.storage_root = storage_root
        self.accounts_file = os.path.join(storage_root, "fanqie_accounts.json")
        self._accounts_cache: Dict[str, FanqieAccount] = {}
        self.logger = get_logger()
        self._load_accounts()

    def _ensure_storage(self) -> None:
        """Ensure storage directory exists."""
        os.makedirs(self.storage_root, exist_ok=True)

    def _load_accounts(self) -> None:
        """Load accounts from JSON file."""
        self._accounts_cache.clear()
        if not os.path.exists(self.accounts_file):
            return

        try:
            with open(self.accounts_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for account_data in data.get("accounts", []):
                    account = FanqieAccount.from_dict(account_data)
                    self._accounts_cache[account.id] = account
            self.logger.info(f"Loaded {len(self._accounts_cache)} fanqie accounts")
        except (json.JSONDecodeError, IOError) as e:
            self.logger.error(f"Failed to load accounts: {e}")

    def _save_accounts(self) -> None:
        """Save accounts to JSON file."""
        self._ensure_storage()
        data = {
            "accounts": [acc.to_dict() for acc in self._accounts_cache.values()]
        }
        with open(self.accounts_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        self.logger.debug(f"Saved {len(self._accounts_cache)} accounts")

    def get_all_accounts(self) -> List[FanqieAccount]:
        """Get all accounts."""
        return list(self._accounts_cache.values())

    def get_account(self, account_id: str) -> Optional[FanqieAccount]:
        """Get account by ID."""
        return self._accounts_cache.get(account_id)

    def add_account(self, phone: str, password: str, nickname: str = "") -> FanqieAccount:
        """
        Add a new account.

        Args:
            phone: Phone number
            password: Password
            nickname: Optional nickname

        Returns:
            Created account
        """
        account = FanqieAccount(phone=phone, password=password, nickname=nickname)
        self._accounts_cache[account.id] = account
        self._save_accounts()
        self.logger.info(f"Added fanqie account: {account.id}")
        return account

    def update_account(self, account_id: str, phone: str = None,
                       password: str = None, nickname: str = None) -> Optional[FanqieAccount]:
        """
        Update an existing account.

        Args:
            account_id: Account ID to update
            phone: New phone number (if provided)
            password: New password (if provided)
            nickname: New nickname (if provided)

        Returns:
            Updated account or None if not found
        """
        account = self._accounts_cache.get(account_id)
        if not account:
            return None

        if phone is not None:
            account.phone = phone
        if password is not None:
            account.password = password
        if nickname is not None:
            account.nickname = nickname

        self._save_accounts()
        self.logger.info(f"Updated fanqie account: {account_id}")
        return account

    def delete_account(self, account_id: str) -> bool:
        """
        Delete an account.

        Args:
            account_id: Account ID to delete

        Returns:
            True if deleted, False if not found
        """
        if account_id not in self._accounts_cache:
            return False

        del self._accounts_cache[account_id]
        self._save_accounts()
        self.logger.info(f"Deleted fanqie account: {account_id}")
        return True

    def reload(self) -> None:
        """Reload accounts from disk."""
        self._load_accounts()
```

- [ ] **Step 2: 验证服务**

```bash
cd D:\workspace\aiwriter-local\generations\autonomous_demo_project
python -c "
from services.fanqie_account_manager import FanqieAccountManager
import tempfile
import os

# Use temp directory for testing
tmpdir = tempfile.mkdtemp()
mgr = FanqieAccountManager(tmpdir)

# Add account
acc = mgr.add_account('13812345678', 'password123', '主号')
print('Added:', acc.get_display_name())

# Get all
accounts = mgr.get_all_accounts()
print('Count:', len(accounts))

# Update
updated = mgr.update_account(acc.id, nickname='新主号')
print('Updated:', updated.get_display_name())

# Delete
deleted = mgr.delete_account(acc.id)
print('Deleted:', deleted)

# Verify file
print('File exists:', os.path.exists(os.path.join(tmpdir, 'fanqie_accounts.json')))
"
```

预期：正常执行，无异常

- [ ] **Step 3: 提交**

```bash
git add src/services/fanqie_account_manager.py
git commit -m "feat: add FanqieAccountManager service"
```

---

## Task 4: 创建番茄账号管理对话框

**Files:**
- Create: `src/gui/dialogs/fanqie_account_dialog.py`

- [ ] **Step 1: 创建 fanqie_account_dialog.py**

参考现有的 `multi_title_dialog.py` 模式，创建账号管理对话框：

```python
"""
Fanqie Account Management Dialog for AI Writer application.

Provides UI for CRUD operations on番茄小说 writer accounts.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QLineEdit, QListWidget, QListWidgetItem,
    QMessageBox, QWidget, QGridLayout, QFrame
)
from PyQt6.QtCore import Qt, pyqtSignal
from typing import Optional

from models.fanqie_account import FanqieAccount
from services.fanqie_account_manager import FanqieAccountManager


class FanqieAccountDialog(QDialog):
    """
    Dialog for managing番茄小说 writer accounts.

    Signals:
        account_selected: Emitted when an account is selected (account_id)
    """

    account_selected = pyqtSignal(str)

    def __init__(self, account_manager: FanqieAccountManager, parent=None):
        """
        Initialize the account dialog.

        Args:
            account_manager: FanqieAccountManager instance
            parent: Parent widget
        """
        super().__init__(parent)
        self.account_manager = account_manager
        self._selected_account_id: Optional[str] = None
        self.setObjectName("fanqieAccountDialog")
        self._setup_ui()
        self._setup_connections()
        self._apply_styles()
        self._refresh_account_list()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        self.setWindowTitle("管理番茄账号")
        self.setMinimumSize(500, 400)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # Title
        title_label = QLabel("管理番茄账号")
        title_label.setObjectName("dialogTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Account list
        self.account_list = QListWidget()
        self.account_list.setObjectName("accountList")
        self.account_list.setMinimumHeight(200)
        layout.addWidget(self.account_list)

        # Buttons row
        button_row = QHBoxLayout()
        button_row.setSpacing(10)

        self.add_btn = QPushButton("添加账号")
        self.add_btn.setObjectName("addAccountBtn")
        self.add_btn.setFixedHeight(32)
        button_row.addWidget(self.add_btn)

        button_row.addStretch()

        self.edit_btn = QPushButton("编辑")
        self.edit_btn.setObjectName("editAccountBtn")
        self.edit_btn.setFixedHeight(32)
        self.edit_btn.setEnabled(False)
        button_row.addWidget(self.edit_btn)

        self.delete_btn = QPushButton("删除")
        self.delete_btn.setObjectName("deleteAccountBtn")
        self.delete_btn.setFixedHeight(32)
        self.delete_btn.setEnabled(False)
        button_row.addWidget(self.delete_btn)

        layout.addLayout(button_row)

        # Form area (for add/edit)
        self.form_widget = QWidget()
        self.form_widget.setObjectName("formWidget")
        self.form_widget.setVisible(False)
        form_layout = QGridLayout(self.form_widget)
        form_layout.setContentsMargins(0, 10, 0, 10)
        form_layout.setSpacing(10)

        # Phone
        phone_label = QLabel("手机号:")
        phone_label.setObjectName("phoneLabel")
        self.phone_input = QLineEdit()
        self.phone_input.setObjectName("phoneInput")
        self.phone_input.setPlaceholderText("请输入手机号")
        self.phone_input.setFixedHeight(32)
        form_layout.addWidget(phone_label, 0, 0)
        form_layout.addWidget(self.phone_input, 0, 1)

        # Password
        password_label = QLabel("密码:")
        password_label.setObjectName("passwordLabel")
        self.password_input = QLineEdit()
        self.password_input.setObjectName("passwordInput")
        self.password_input.setPlaceholderText("请输入密码")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_input.setFixedHeight(32)
        form_layout.addWidget(password_label, 1, 0)
        form_layout.addWidget(self.password_input, 1, 1)

        # Nickname
        nickname_label = QLabel("备注:")
        nickname_label.setObjectName("nicknameLabel")
        self.nickname_input = QLineEdit()
        self.nickname_input.setObjectName("nicknameInput")
        self.nickname_input.setPlaceholderText("可选，如'主号'、'备用'")
        self.nickname_input.setFixedHeight(32)
        form_layout.addWidget(nickname_label, 2, 0)
        form_layout.addWidget(self.nickname_input, 2, 1)

        layout.addWidget(self.form_widget)

        # Form buttons (save/cancel)
        self.form_buttons = QHBoxLayout()
        self.form_buttons.setSpacing(10)
        self.form_buttons.addStretch()

        self.cancel_form_btn = QPushButton("取消")
        self.cancel_form_btn.setObjectName("cancelFormBtn")
        self.cancel_form_btn.setFixedHeight(32)
        self.form_buttons.addWidget(self.cancel_form_btn)

        self.save_form_btn = QPushButton("保存")
        self.save_form_btn.setObjectName("saveFormBtn")
        self.save_form_btn.setFixedHeight(32)
        self.form_buttons.addWidget(self.save_form_btn)

        layout.addLayout(self.form_buttons)

        # Dialog buttons
        dialog_buttons = QHBoxLayout()
        dialog_buttons.addStretch()

        self.close_btn = QPushButton("关闭")
        self.close_btn.setObjectName("closeBtn")
        self.close_btn.setFixedHeight(36)
        self.close_btn.setMinimumWidth(100)
        dialog_buttons.addWidget(self.close_btn)

        layout.addLayout(dialog_buttons)

    def _setup_connections(self) -> None:
        """Connect signals and slots."""
        self.add_btn.clicked.connect(self._on_add_clicked)
        self.edit_btn.clicked.connect(self._on_edit_clicked)
        self.delete_btn.clicked.connect(self._on_delete_clicked)
        self.cancel_form_btn.clicked.connect(self._on_cancel_form)
        self.save_form_btn.clicked.connect(self._on_save_form)
        self.close_btn.clicked.connect(self.accept)
        self.account_list.itemSelectionChanged.connect(self._on_selection_changed)

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            #dialogTitle {
                font-size: 18px;
                font-weight: bold;
                color: #2c3e50;
                padding: 10px 0;
            }

            QLabel {
                color: #2c3e50;
                font-size: 14px;
                min-height: 28px;
            }

            QListWidget {
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                background-color: #ffffff;
                font-size: 14px;
            }

            QListWidget::item {
                padding: 8px 12px;
                border-bottom: 1px solid #f0f0f0;
            }

            QListWidget::item:selected {
                background-color: #3498db;
                color: #ffffff;
            }

            QLineEdit {
                padding: 6px 12px;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                font-size: 14px;
                background-color: #ffffff;
            }

            QLineEdit:focus {
                border-color: #3498db;
            }

            QPushButton {
                padding: 8px 16px;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                background-color: #ffffff;
                font-size: 14px;
                color: #2c3e50;
            }

            QPushButton:hover {
                background-color: #f5f5f5;
                border-color: #3498db;
            }

            #addAccountBtn {
                background-color: #3498db;
                color: #ffffff;
                border: none;
            }

            #addAccountBtn:hover {
                background-color: #2980b9;
            }

            #deleteAccountBtn {
                background-color: #e74c3c;
                color: #ffffff;
                border: none;
            }

            #deleteAccountBtn:hover {
                background-color: #c0392b;
            }

            #closeBtn {
                background-color: #3498db;
                color: #ffffff;
                border: none;
                font-weight: bold;
            }

            #closeBtn:hover {
                background-color: #2980b9;
            }

            #formWidget {
                background-color: #f8f9fa;
                border-radius: 8px;
                padding: 10px;
            }
        """)

    def _refresh_account_list(self) -> None:
        """Refresh the account list display."""
        self.account_list.clear()
        accounts = self.account_manager.get_all_accounts()
        for account in accounts:
            item = QListWidgetItem(account.get_display_name())
            item.setData(Qt.ItemDataRole.UserRole, account.id)
            self.account_list.addItem(item)

    def _on_selection_changed(self) -> None:
        """Handle selection change."""
        has_selection = len(self.account_list.selectedItems()) > 0
        self.edit_btn.setEnabled(has_selection)
        self.delete_btn.setEnabled(has_selection)
        if has_selection:
            self._selected_account_id = self.account_list.selectedItems()[0].data(Qt.ItemDataRole.UserRole)

    def _on_add_clicked(self) -> None:
        """Handle add button click."""
        self._editing_account_id = None
        self.phone_input.clear()
        self.password_input.clear()
        self.nickname_input.clear()
        self._show_form()

    def _on_edit_clicked(self) -> None:
        """Handle edit button click."""
        if not self._selected_account_id:
            return

        account = self.account_manager.get_account(self._selected_account_id)
        if account:
            self._editing_account_id = account.id
            self.phone_input.setText(account.phone)
            self.password_input.setText(account.password)
            self.nickname_input.setText(account.nickname)
            self._show_form()

    def _on_delete_clicked(self) -> None:
        """Handle delete button click."""
        if not self._selected_account_id:
            return

        account = self.account_manager.get_account(self._selected_account_id)
        if not account:
            return

        reply = QMessageBox.question(
            self,
            "确认删除",
            f"确定要删除账号 '{account.get_display_name()}' 吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            self.account_manager.delete_account(self._selected_account_id)
            self._refresh_account_list()
            self._selected_account_id = None
            self.edit_btn.setEnabled(False)
            self.delete_btn.setEnabled(False)

    def _on_cancel_form(self) -> None:
        """Handle cancel form button click."""
        self._hide_form()

    def _on_save_form(self) -> None:
        """Handle save form button click."""
        phone = self.phone_input.text().strip()
        password = self.password_input.text().strip()
        nickname = self.nickname_input.text().strip()

        if not phone:
            QMessageBox.warning(self, "提示", "请输入手机号")
            return

        if not password:
            QMessageBox.warning(self, "提示", "请输入密码")
            return

        if self._editing_account_id:
            # Update existing
            self.account_manager.update_account(
                self._editing_account_id,
                phone=phone,
                password=password,
                nickname=nickname
            )
        else:
            # Add new
            self.account_manager.add_account(phone, password, nickname)

        self._hide_form()
        self._refresh_account_list()

    def _show_form(self) -> None:
        """Show the form widget."""
        self.form_widget.setVisible(True)
        self.add_btn.setEnabled(False)
        self.edit_btn.setEnabled(False)
        self.delete_btn.setEnabled(False)

    def _hide_form(self) -> None:
        """Hide the form widget."""
        self.form_widget.setVisible(False)
        self.add_btn.setEnabled(True)
        # Re-enable buttons if selection exists
        has_selection = len(self.account_list.selectedItems()) > 0
        self.edit_btn.setEnabled(has_selection)
        self.delete_btn.setEnabled(has_selection)
```

- [ ] **Step 2: 验证对话框可以实例化**

```bash
cd D:\workspace\aiwriter-local\generations\autonomous_demo_project
python -c "
from PyQt6.QtWidgets import QApplication
import sys
app = QApplication(sys.argv)
from gui.dialogs.fanqie_account_dialog import FanqieAccountDialog
from services.fanqie_account_manager import FanqieAccountManager
import tempfile
tmpdir = tempfile.mkdtemp()
mgr = FanqieAccountManager(tmpdir)
dialog = FanqieAccountDialog(mgr)
print('Dialog created successfully')
"
```

预期：无错误输出

- [ ] **Step 3: 提交**

```bash
git add src/gui/dialogs/fanqie_account_dialog.py
git commit -m "feat: add FanqieAccountDialog for account management"
```

---

## Task 5: 重构 PublishingView，添加步骤导航框架

**Files:**
- Modify: `src/gui/views/publishing_view.py`

这是最大的任务，需要将现有的 PublishingView 重构为步骤导航模式。

- [ ] **Step 1: 备份现有文件**

```bash
cp src/gui/views/publishing_view.py src/gui/views/publishing_view.py.bak
```

- [ ] **Step 2: 重新设计 PublishingView 结构**

新的 PublishingView 将包含：
1. 步骤指示器（Step 1选择平台, Step 2选择作品, Step 3确认发布）
2. 各步骤的内容区域
3. 底部按钮（取消/上一步/下一步/发布）

核心代码结构：

```python
class PublishingView(QWidget):
    """发布中心 - 单页面引导式布局"""

    # 步骤定义
    STEPS = ["选择平台", "选择作品", "确认发布"]

    def __init__(self, settings: Settings, work_manager=None, fanqie_account_manager=None, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.work_manager = work_manager
        self.fanqie_account_manager = fanqie_account_manager
        self._current_step = 0  # 0=选择平台, 1=选择作品, 2=确认发布

        self._setup_ui()
        self._setup_connections()
        self._apply_styles()
        self._load_works()
        self._update_step_display()

    def _setup_ui(self) -> None:
        """设置UI组件"""
        # 步骤指示器
        self._setup_step_indicator()

        # 内容区域（堆叠Widget）
        self.content_stack = QStackedWidget()

        # Step 0: 平台选择
        self._setup_step_platform()

        # Step 1: 作品选择
        self._setup_step_work()

        # Step 2: 确认发布
        self._setup_step_publish()

        # 底部按钮
        self._setup_buttons()

    def _setup_step_indicator(self) -> None:
        """设置步骤指示器"""
        # 水平布局显示：○ 1选择平台 —— ○ 2选择作品 —— ○ 3确认发布
        pass

    def _setup_step_platform(self) -> None:
        """Step 0: 平台选择"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Platform combo
        platform_layout = QHBoxLayout()
        platform_label = QLabel("选择平台:")
        self.platform_combo = QComboBox()
        self.platform_combo.addItems(["番茄", "起点"])
        platform_layout.addWidget(platform_label)
        platform_layout.addWidget(self.platform_combo)
        platform_layout.addStretch()
        layout.addLayout(platform_layout)
        layout.addStretch()

        self.content_stack.addWidget(widget)

    def _setup_step_work(self) -> None:
        """Step 1: 作品选择"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Work combo
        work_layout = QHBoxLayout()
        work_label = QLabel("选择作品:")
        self.work_combo = QComboBox()
        self.work_combo.addItem("请选择作品...", "")
        work_layout.addWidget(work_label)
        work_layout.addWidget(self.work_combo)
        work_layout.addStretch()
        layout.addLayout(work_layout)

        # Work info display
        self.work_info_label = QLabel()
        self.work_info_label.setWordWrap(True)
        layout.addWidget(self.work_info_label)

        layout.addStretch()
        self.content_stack.addWidget(widget)

    def _setup_step_publish(self) -> None:
        """Step 2: 确认发布"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # 账号选择区域
        account_layout = QHBoxLayout()
        account_label = QLabel("番茄账号:")
        self.account_combo = QComboBox()
        self.account_combo.addItem("请选择账号...", "")
        account_layout.addWidget(account_label)
        account_layout.addWidget(self.account_combo)

        self.manage_account_btn = QPushButton("管理账号")
        account_layout.addWidget(self.manage_account_btn)
        account_layout.addStretch()
        layout.addLayout(account_layout)

        # 章节范围
        chapter_layout = QHBoxLayout()
        start_label = QLabel("起始章节:")
        self.start_chapter_spin = QSpinBox()
        self.start_chapter_spin.setMinimum(1)
        end_label = QLabel("结束章节:")
        self.end_chapter_spin = QSpinBox()
        self.end_chapter_spin.setMinimum(1)
        self.publish_all_btn = QPushButton("发布全部剩余")
        chapter_layout.addWidget(start_label)
        chapter_layout.addWidget(self.start_chapter_spin)
        chapter_layout.addWidget(end_label)
        chapter_layout.addWidget(self.end_chapter_spin)
        chapter_layout.addWidget(self.publish_all_btn)
        chapter_layout.addStretch()
        layout.addLayout(chapter_layout)

        # 发布选项
        options_group = QGroupBox("发布选项")
        options_layout = QVBoxLayout(options_group)

        self.original_radio = QRadioButton("按原始章节发布")
        self.original_radio.setChecked(True)
        self.restructure_radio = QRadioButton("按自定义字数重新划分章节")

        options_layout.addWidget(self.original_radio)
        options_layout.addWidget(self.restructure_radio)
        layout.addWidget(options_group)

        layout.addStretch()
        self.content_stack.addWidget(widget)

    def _setup_buttons(self) -> None:
        """设置底部按钮"""
        button_layout = QHBoxLayout()
        button_layout.addStretch()

        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.setObjectName("cancelBtn")
        button_layout.addWidget(self.cancel_btn)

        self.prev_btn = QPushButton("上一步")
        self.prev_btn.setObjectName("prevBtn")
        self.prev_btn.setVisible(False)
        button_layout.addWidget(self.prev_btn)

        self.next_btn = QPushButton("下一步")
        self.next_btn.setObjectName("nextBtn")
        button_layout.addWidget(self.next_btn)

        self.publish_btn = QPushButton("发布")
        self.publish_btn.setObjectName("publishBtn")
        self.publish_btn.setVisible(False)
        button_layout.addWidget(self.publish_btn)

        self.main_layout.addLayout(button_layout)

    def _setup_connections(self) -> None:
        """连接信号槽"""
        self.platform_combo.currentTextChanged.connect(self._on_platform_changed)
        self.work_combo.currentIndexChanged.connect(self._on_work_changed)
        self.manage_account_btn.clicked.connect(self._on_manage_accounts)
        self.cancel_btn.clicked.connect(self._on_cancel)
        self.prev_btn.clicked.connect(self._on_prev)
        self.next_btn.clicked.connect(self._on_next)
        self.publish_btn.clicked.connect(self._on_publish)
        self.publish_all_btn.clicked.connect(self._on_publish_all)

    def _on_platform_changed(self, platform: str) -> None:
        """处理平台选择变化"""
        self._current_platform = platform

    def _on_work_changed(self, index: int) -> None:
        """处理作品选择变化"""
        if index > 0:
            work_id = self.work_combo.itemData(index)
            self._current_work_id = work_id

    def _on_manage_accounts(self) -> None:
        """打开账号管理对话框"""
        from gui.dialogs.fanqie_account_dialog import FanqieAccountDialog
        dialog = FanqieAccountDialog(self.fanqie_account_manager, self)
        dialog.exec()
        self._refresh_account_list()

    def _refresh_account_list(self) -> None:
        """刷新账号列表"""
        self.account_combo.clear()
        self.account_combo.addItem("请选择账号...", "")
        for account in self.fanqie_account_manager.get_all_accounts():
            self.account_combo.addItem(account.get_display_name(), account.id)

    def _on_cancel(self) -> None:
        """取消并重置"""
        self._current_step = 0
        self._update_step_display()

    def _on_prev(self) -> None:
        """上一步"""
        if self._current_step > 0:
            self._current_step -= 1
            self._update_step_display()

    def _on_next(self) -> None:
        """下一步"""
        if self._current_step < len(self.STEPS) - 1:
            # 验证当前步骤
            if self._validate_current_step():
                self._current_step += 1
                self._update_step_display()

    def _validate_current_step(self) -> bool:
        """验证当前步骤的输入"""
        if self._current_step == 0:
            if not self.platform_combo.currentText():
                return False
        elif self._current_step == 1:
            if not self._current_work_id:
                return False
        return True

    def _update_step_display(self) -> None:
        """更新步骤显示"""
        # 更新步骤指示器
        for i, (_, name) in enumerate(self.STEPS):
            # Update step indicator styling
            pass

        # 更新内容区域
        self.content_stack.setCurrentIndex(self._current_step)

        # 更新按钮
        self.prev_btn.setVisible(self._current_step > 0)
        self.next_btn.setVisible(self._current_step < len(self.STEPS) - 1)
        self.publish_btn.setVisible(self._current_step == len(self.STEPS) - 1)

    def _on_publish(self) -> None:
        """处理发布按钮点击"""
        # TODO: 实现发布逻辑
        pass

    def _on_publish_all(self) -> None:
        """处理发布全部剩余按钮点击"""
        if self._current_work_id:
            work = self.work_manager.get_work(self._current_work_id)
            if work:
                # 设置结束章节为总章节数
                self.end_chapter_spin.setValue(work.chapter_count)
```

- [ ] **Step 3: 添加 QStackedWidget 导入**

在文件头部添加：
```python
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QComboBox, QGroupBox, QFormLayout, QPushButton,
    QSpinBox, QCheckBox, QTextEdit, QRadioButton, QButtonGroup,
    QMessageBox, QSizePolicy, QScrollArea, QStackedWidget
)
```

- [ ] **Step 4: 验证 UI 可以正常显示**

```bash
cd D:\workspace\aiwriter-local\generations\autonomous_demo_project
python -c "
from PyQt6.QtWidgets import QApplication
import sys
app = QApplication(sys.argv)
from gui.views.publishing_view import PublishingView
from config.settings import Settings
settings = Settings()
settings.storage_root = 'C:/temp/test_storage'
settings.works_dir = 'C:/temp/test_storage/works'
view = PublishingView(settings)
print('PublishingView created successfully')
"
```

预期：无错误输出

- [ ] **Step 5: 提交**

```bash
git add src/gui/views/publishing_view.py
git commit -m "refactor: restructure PublishingView with step navigation"
```

---

## Task 6: 在 MainWindow 中集成账号管理器

**Files:**
- Modify: `src/gui/main_window.py`

- [ ] **Step 1: 添加 FanqieAccountManager 初始化**

在 MainWindow.__init__ 中（约第96行 WorkManager 初始化后）添加：

```python
# Initialize fanqie account manager
from services.fanqie_account_manager import FanqieAccountManager
self.fanqie_account_manager = FanqieAccountManager(self.settings.storage_root)
```

- [ ] **Step 2: 传递 account_manager 给 PublishingView**

找到创建 PublishingView 的位置（约第24行导入和第97行初始化），修改为：

```python
# In imports (~line 24):
from gui.views.publishing_view import PublishingView

# In __init__ (~line 97), after work_manager init:
self.publishing_view = PublishingView(
    self.settings,
    work_manager=self.work_manager,
    fanqie_account_manager=self.fanqie_account_manager,
    parent=self
)
```

- [ ] **Step 3: 验证**

```bash
cd D:\workspace\aiwriter-local\generations\autonomous_demo_project
python -c "
from PyQt6.QtWidgets import QApplication
import sys
app = QApplication(sys.argv)
from gui.main_window import MainWindow
from config.settings import Settings
settings = Settings()
settings.storage_root = 'C:/temp/test_storage'
settings.works_dir = 'C:/temp/test_storage/works'
settings.templates_dir = 'C:/temp/test_storage/templates'
settings.is_configured = True
window = MainWindow(settings)
print('MainWindow with FanqieAccountManager created successfully')
"
```

预期：无错误输出

- [ ] **Step 4: 提交**

```bash
git add src/gui/main_window.py
git commit -m "feat: integrate FanqieAccountManager into MainWindow"
```

---

## 实现检查清单

完成所有任务后，验证以下功能：

- [ ] Work 模型包含 fanqie_book_id, fanqie_book_url, fanqie_book_title, fanqie_account_id, fanqie_last_published_chapter, fanqie_chapters, fanqie_publish_config 字段
- [ ] FanqieAccount 模型可以创建、序列化、反序列化
- [ ] FanqieAccountManager 可以增删改查账号，数据保存到 fanqie_accounts.json
- [ ] FanqieAccountDialog 可以显示账号列表、添加/编辑/删除账号
- [ ] PublishingView 显示步骤指示器（选择平台 > 选择作品 > 确认发布）
- [ ] PublishingView 各步骤内容正确显示
- [ ] PublishingView 底部按钮（上一步/下一步/发布）正确响应
- [ ] MainWindow 正确初始化 FanqieAccountManager 并传递给 PublishingView

---

**Plan complete.** Two execution options:

**1. Subagent-Driven (recommended)** - I dispatch a fresh subagent per task, review between tasks, fast iteration

**2. Inline Execution** - Execute tasks in this session using executing-plans, batch execution with checkpoints

**Which approach?**
