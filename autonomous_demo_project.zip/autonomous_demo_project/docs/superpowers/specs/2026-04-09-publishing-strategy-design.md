# 发布策略步骤设计方案

**日期**: 2026-04-09
**状态**: 已确认

## 一、步骤调整

**当前步骤流程**：
1. 选择平台 → 2. 选择作品 → 3. 发布范围 → 4. 选择账号 → 5. 汇总发布

**新增后步骤流程**：
1. 选择平台 → 2. 选择作品 → 3. 发布范围 → 4. 选择账号 → **5. 发布策略** → 6. 汇总发布

---

## 二、步骤5：发布策略（三个子阶段）

### 子阶段1：更新已发布章节元数据

**目的**：获取番茄平台已发布章节的元数据，保存到本地

**流程**：
1. 检查番茄书本是否存在
   - **如果书本不存在** → 创建新书（逻辑从汇总发布移到这里）
   - **如果书本存在** → 继续下一步
2. 调用番茄 API 获取所有已发布章节（分页遍历）
3. 遍历每一页，保存到 `chapters/chapter_{index}.json`
4. 同时更新 `work.fanqie_chapters` 列表
5. 更新 `work.fanqie_last_published_chapter`

**API 参考**：`fanqie_list_published_chapters.md`

**接口**：
```
GET https://fanqienovel.com/api/author/chapter/chapter_list/v1
```

**元数据存储位置**：`{work_dir}/chapters/chapter_{index}.json`

**字段**：完全复用番茄平台返回的章节元数据，样例：
```json
{
    "item_id": "7607374856908177945",
    "volume_id": "7605250541479808025",
    "index": 76,
    "title": "第76章 一个饺子让她浑身颤抖",
    "display_status": 1,
    "article_status": 2,
    "create_time": "1772070900",
    "word_number": 2136,
    "timer_time": "",
    ...
}
```

**界面显示**：
- 番茄已发布章节摘要（共 X 章，最后更新: XXXX）
- 章节列表（可折叠/展开）

---

### 子阶段2：章节范围对齐

**目的**：让用户选择本地和番茄平台要对齐的章节范围

**默认值**：
- 起始章节：`fanqie_last_published_chapter + 1`
- 结束章节：publish 目录最新章节

**用户可调整范围**：`[start, end]`

**章节处理逻辑**：
| 情况 | 处理方式 |
|-----|---------|
| 本地 3-5 章 vs 番茄已有 3-5 章 | 更新流程（调用 `fanqie_update_chapter_flow.md`） |
| 本地 6-10 章 vs 番茄只有 3-5 章 | 新章节发布流程（调用 `fanqie_publish_chapter_flow.md`） |

**界面显示**：
- 本地章节范围 vs 番茄已发布章节对比
- 将要更新的章节列表
- 将要新发布的章节列表

---

### 子阶段3：发布方式选择

**选项A：直接发布**
- 跳过定时设置
- 直接进入汇总发布

**选项B：定时发布**
- 每日发布章节数：`N` 章/天
- 开始日期：`YYYY-MM-DD`
- 时间范围：`HH:MM - HH:MM`（在范围内随机）

**发布时间表生成规则**：
1. 计算结束日期：总共 M 章，每日 N 章，需要 M/N 天
2. 每天生成 N 个随机时间点（在指定时间段内）
3. 按章节号排序：章节号大的发布时间 > 章节号小的时间
4. 确保所有时间都在当前时间之后

**界面显示**：
- 发布时间表（可修改单个时间点）
- 表格列：章节号 | 发布日期 | 发布时间 | 操作（修改）

---

## 三、数据流

```
番茄平台 API (fanqie_list_published_chapters.md)
    ↓
获取全量已发布章节列表（分页遍历）
    ↓
保存到 chapters/chapter_{index}.json
    ↓
更新 work.fanqie_chapters 列表
    ↓
更新 work.fanqie_last_published_chapter
    ↓
计算章节对齐范围
    ↓
生成发布时间表（如果选择定时发布）
    ↓
进入汇总发布
```

---

## 四、关键实现

| 功能 | 实现位置 | 参考文档 |
|-----|---------|---------|
| 获取番茄已发布章节列表 | `FanqieBookService.list_published_chapters()` | `fanqie_list_published_chapters.md` |
| 保存章节元数据到文件 | `WorkManager.save_chapter_metadata()` | 新增 |
| 读取章节元数据 | `WorkManager.load_chapter_metadata()` | 新增 |
| 创建新书（如需要） | `FanqieBookService.create_book()` | `fanqie_create_new_book_flow.md` |
| 章节对齐计算 | `PublishingView._calculate_chapter_range()` | 新增 |
| 发布时间表生成 | `PublishingView._generate_schedule_plan()` | 新增 |
| 发布新章节 | `FanqiePublisher.publish_chapter()` | `fanqie_publish_chapter_flow.md` |
| 更新已发布章节 | `FanqiePublisher.update_chapter()` | `fanqie_update_chapter_flow.md` |

---

## 五、文件变更

### 新增文件
- `docs/superpowers/specs/2026-04-09-publishing-strategy-design.md`（本文档）

### 修改文件
- `src/gui/views/publishing_view.py` - 新增步骤5的UI和逻辑
- `src/services/fanqie_book_service.py` - 新增 `list_published_chapters()` 方法
- `src/services/fanqie_publisher.py` - 新增 `update_chapter()` 方法
- `src/core/work_manager.py` - 新增章节元数据读写方法

---

## 六、实施顺序

1. **Phase 1**: `FanqieBookService.list_published_chapters()` - 获取番茄已发布章节
2. **Phase 2**: `WorkManager` 章节元数据读写方法
3. **Phase 3**: `PublishingView` 步骤5 UI（三个子阶段）
4. **Phase 4**: 章节对齐计算和发布时间表生成
5. **Phase 5**: `FanqiePublisher.update_chapter()` - 更新已发布章节
6. **Phase 6**: 集成测试和调试
