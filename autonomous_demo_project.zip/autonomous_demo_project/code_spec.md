# AI Writer 开发规范文档

## 1. 项目目录结构规范

### 1.1 整体目录结构

```
aiwriter-local/
├── src/                        # 源代码目录
│   ├── __init__.py
│   ├── main.py                 # 应用程序入口
│   ├── config/                 # 配置管理
│   ├── core/                   # 核心业务逻辑
│   ├── gui/                    # GUI 界面组件
│   ├── services/               # 服务层（AI 调用、文件处理等）
│   ├── models/                 # 数据模型
│   ├── utils/                  # 工具函数
│   └── resources/              # 资源文件
├── tests/                      # 测试代码
├── docs/                       # 文档
├── requirements.txt            # Python 依赖
├── setup.py                    # 安装脚本
└── README.md                   # 项目说明
```

### 1.2 前端 (GUI) 目录结构

由于本项目是 PyQt6 桌面应用，前后端不分离，`gui/` 目录承担前端职责：

```
src/gui/
├── __init__.py
├── main_window.py              # 主窗口
├── widgets/                    # 自定义控件组件
│   ├── __init__.py
│   ├── work_card.py            # 作品卡片组件
│   ├── flow_tree.py            # 流程树组件
│   ├── notification_bar.py     # 通知栏组件
│   └── text_editor.py          # 文本编辑器组件
├── views/                      # 视图页面
│   ├── __init__.py
│   ├── workspace_view.py       # 作品库视图
│   ├── work_detail_view.py     # 作品信息视图
│   ├── creation_view.py        # 创作管理视图
│   ├── publishing_view.py      # 发布中心视图
│   ├── template_view.py        # 提示词模板视图
│   └── settings_view.py        # 设置视图
├── dialogs/                    # 对话框
│   ├── __init__.py
│   ├── new_work_wizard.py      # 新建作品向导
│   ├── import_dialog.py        # 导入作品对话框
│   ├── volume_range_dialog.py  # 卷数范围选择
│   └── confirm_dialog.py       # 确认对话框
└── styles/                     # Qt 样式表
    ├── __init__.py
    └── main.qss                # 主样式表
```

**职责说明：**
- `widgets/`: 可复用的 UI 控件组件，独立于具体业务
- `views/`: 业务视图页面，对应导航菜单的各个页面
- `dialogs/`: 模态对话框和向导
- `styles/`: QSS 样式表文件

### 1.3 后端 (核心逻辑) 目录结构

```
src/core/
├── __init__.py
├── app.py                      # 应用主类
├── work_manager.py             # 作品管理器
├── creation_manager.py         # 创作流程管理器
├── template_engine.py          # 模板引擎
└── publishing_manager.py       # 发布管理器

src/services/
├── __init__.py
├── ai_service.py               # AI API 调用服务
├── file_service.py             # 文件操作服务
├── storage_service.py          # 存储服务
└── export_service.py           # 导出服务 (ZIP)

src/models/
├── __init__.py
├── work.py                     # 作品模型
├── volume.py                   # 分卷模型
├── chapter.py                  # 章节模型
├── template.py                 # 模板模型
└── config.py                   # 配置模型

src/config/
├── __init__.py
├── settings.py                 # 配置管理类
└── constants.py                # 常量定义

src/utils/
├── __init__.py
├── logger.py                   # 日志工具
├── helpers.py                  # 辅助函数
└── validators.py               # 验证器
```

**职责说明：**
- `core/`: 核心业务逻辑，管理器类
- `services/`: 外部服务调用（AI API、文件系统等）
- `models/`: 数据模型和数据结构
- `config/`: 配置管理和常量
- `utils/`: 通用工具函数

### 1.4 公共资源目录

```
src/resources/
├── __init__.py
├── icons/                      # 图标文件
│   ├── workspace.svg
│   ├── publishing.svg
│   ├── template.svg
│   └── settings.svg
├── images/                     # 图片资源
│   └── placeholders/           # 占位图
└── data/                       # 静态数据
    ├── categories.json         # 作品类别定义
    └── default_templates/      # 默认提示词模板
```

### 1.5 测试目录结构

```
tests/
├── __init__.py
├── conftest.py                 # pytest 配置和 fixtures
├── test_gui/                   # GUI 测试
│   ├── test_main_window.py
│   ├── test_workspace_view.py
│   └── test_dialogs.py
├── test_core/                  # 核心逻辑测试
│   ├── test_work_manager.py
│   ├── test_creation_manager.py
│   └── test_template_engine.py
├── test_services/              # 服务层测试
│   ├── test_ai_service.py
│   └── test_file_service.py
└── test_models/                # 模型测试
    ├── test_work.py
    └── test_chapter.py
```

---

## 2. 文件命名规范

### 2.1 Python 源文件命名

| 文件类型 | 命名规则 | 示例 |
|---------|---------|------|
| 模块文件 | snake_case | `work_manager.py`, `file_service.py` |
| 包初始化 | `__init__.py` | `__init__.py` |
| 主程序入口 | snake_case | `main.py`, `run.py` |
| 测试文件 | `test_` + snake_case | `test_work_manager.py` |
| 配置文件 | snake_case 或 kebab-case | `settings.py`, `config.json` |
| 样式文件 | snake_case | `main.qss`, `colors.py` |
| 资源数据 | snake_case | `categories.json` |

### 2.2 Qt 相关文件命名

```
# 样式表
main.qss                        # 主样式表
colors.qss                      # 颜色定义
widgets.qss                     # 控件样式

# UI 文件 (如使用 Qt Designer)
main_window.ui
workspace_view.ui
```

### 2.3 资源文件命名

```
# 图标
icon_workspace.svg
icon_publishing.svg
icon_settings.svg
ic_save.svg
ic_delete.svg

# 图片
placeholder_cover.png
loading_spinner.gif
```

---

## 3. 变量、方法命名规范

### 3.1 Python 命名规范

#### 3.1.1 变量和函数

```python
# 变量：snake_case，小写字母 + 下划线
work_title = "示例书名"
chapter_count = 100
is_published = False

# 函数：snake_case，动词 + 名词
def create_work(title: str, category: str) -> Work:
    pass

def save_work_to_file(work: Work, path: str) -> bool:
    pass

def generate_title_async(prompt: str) -> str:
    pass
```

#### 3.1.2 类和异常

```python
# 类：PascalCase（大驼峰）
class WorkManager:
    pass

class TemplateEngine:
    pass

class AIServiceError(Exception):
    """AI 服务异常"""
    pass

class StorageError(Exception):
    """存储异常"""
    pass
```

#### 3.1.3 常量

```python
# 模块级常量：UPPER_CASE
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
DEFAULT_ENCODING = "utf-8"
SUPPORTED_CATEGORIES = ["玄幻", "都市", "科幻", "武侠", "历史", "言情", "悬疑", "网游"]

# 类常量：UPPER_CASE
class Config:
    DEFAULT_PORT = 8080
    MAX_RETRY_COUNT = 3
```

#### 3.1.4 私有成员

```python
class WorkManager:
    def __init__(self):
        self._cache = {}          # 受保护成员（单下划线）
        self.__secret = None      # 私有成员（双下划线，名称修饰）

    def _internal_method(self):   # 内部方法
        pass
```

#### 3.1.5 类型注解

```python
from typing import Optional, List, Dict, Callable

# 函数参数和返回值使用类型注解
def get_work_by_id(work_id: str) -> Optional[Work]:
    pass

def get_all_works() -> List[Work]:
    pass

def on_work_changed(callback: Callable[[Work], None]) -> None:
    pass

# 类属性注解
class Chapter:
    title: str
    content: str
    word_count: int
```

### 3.2 PyQt 特定命名

#### 3.2.1 控件成员变量

```python
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # 控件成员：描述性名称 + 控件类型后缀
        self.btn_new_work = QPushButton("新建作品")
        self.txt_search = QLineEdit()
        self.lbl_title = QLabel("作品库")
        self.list_works = QListWidget()
        self.tree_flow = QTreeWidget()
        self.txt_editor = QTextEditor()
        self.bar_status = QStatusBar()

        # 或者使用 m_ 前缀（Qt 传统）
        # self.m_btn_new_work = QPushButton("新建作品")
```

#### 3.2.2 Slot 和 Signal

```python
from PyQt6.QtCore import pyqtSignal, pyqtSlot

class WorkManager(QObject):
    # Signal: 动词 + 名词，描述事件
    work_created = pyqtSignal(Work)
    work_deleted = pyqtSignal(str)  # work_id
    generation_progress = pyqtSignal(int, str)  # percentage, message

    @pyqtSlot()
    def on_btn_save_clicked(self):
        """Slot: on_ + 控件名 + _ + 事件"""
        pass

    @pyqtSlot(str)
    def on_txt_search_text_changed(self, text: str):
        pass
```

---

## 4. API 接口定义规范

### 4.1 外部 AI API 调用规范

本项目调用外部大模型 API（如 Anthropic Claude），需遵循以下规范：

#### 4.1.1 HTTP 客户端封装

```python
# src/services/ai_service.py
import httpx
from typing import AsyncIterator

class AIService:
    BASE_URL = "https://api.anthropic.com/v1"

    def __init__(self, api_key: str):
        self.api_key = api_key
        self.client = httpx.AsyncClient(
            base_url=self.BASE_URL,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01"
            },
            timeout=60.0
        )

    async def chat_stream(
        self,
        model: str,
        messages: List[Dict],
        system: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7
    ) -> AsyncIterator[str]:
        """流式对话"""
        pass
```

#### 4.1.2 请求/响应数据结构

```python
# 请求体（调用 Claude API）
{
    "model": "claude-sonnet-4-5-20250929",
    "messages": [
        {"role": "user", "content": "请生成一个玄幻小说的书名"}
    ],
    "system": "你是一个专业的小说创作助手",
    "max_tokens": 1000,
    "temperature": 0.7,
    "stream": true
}

# 流式响应（SSE）
# 解析响应流，逐字输出
async for chunk in response.aiter_text():
    yield chunk
```

#### 4.1.3 错误处理

```python
class AIServiceError(Exception):
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code

# 错误码映射
ERROR_MAPPING = {
    400: "请求参数错误",
    401: "API Key 无效",
    403: "权限不足",
    429: "请求频率超限",
    500: "服务端错误",
    503: "服务暂时不可用"
}
```

---

## 5. 本地存储规范

### 5.1 文件系统存储结构

```
{storage_root}/                    # 用户配置的存储根目录
├── works/                         # 作品目录
│   ├── {work_id_1}/               # 作品 1
│   │   ├── work_info.json         # 作品基本信息
│   │   ├── covers/                # 封面图片
│   │   │   └── cover.jpg
│   │   ├── volumes/               # 分卷数据
│   │   │   ├── volume_001.json
│   │   │   └── volume_002.json
│   │   └── chapters/              # 章节数据
│   │       ├── chapter_001.json
│   │       └── chapter_002.json
│   └── {work_id_2}/               # 作品 2
│       └── ...
├── templates/                     # 全局提示词模板
│   ├── basic_info.txt             # 基本信息模板
│   ├── worldbuilding.txt          # 世界观设定模板
│   ├── character.txt              # 人物设定模板
│   ├── volume_outline.txt         # 分卷大纲模板
│   └── chapter_content.txt        # 章节正文模板
├── logs/                          # 日志目录
│   ├── aiwriter_2026-03-11.log
│   └── aiwriter_2026-03-12.log
└── config.json                    # 应用配置
```

### 5.2 数据文件格式

#### 5.2.1 作品信息 (work_info.json)

```json
{
    "id": "work_20260311_001",
    "title": "示例书名",
    "author": "AI 作者",
    "category": "玄幻",
    "reference_works": ["斗破苍穹", "完美世界"],
    "creation_guide": "创作指导内容",
    "chapters_per_volume": 20,
    "words_per_chapter": 3000,
    "cover_url": "https://example.com/cover.jpg",
    "created_at": "2026-03-11T10:00:00",
    "updated_at": "2026-03-11T12:00:00",
    "status": "draft"
}
```

#### 5.2.2 分卷数据 (volume_001.json)

```json
{
    "volume_number": 1,
    "title": "第一卷 初入江湖",
    "outline": "卷纲内容...",
    "chapter_list": ["chapter_001", "chapter_002"],
    "characters": ["角色 1", "角色 2"],
    "created_at": "2026-03-11T10:00:00",
    "updated_at": "2026-03-11T12:00:00"
}
```

#### 5.2.3 章节数据 (chapter_001.json)

```json
{
    "chapter_number": 1,
    "volume_number": 1,
    "title": "第一章 开始",
    "outline": "章节大纲...",
    "content": "章节正文内容...",
    "word_count": 3000,
    "characters": ["角色 1", "角色 2"],
    "scenes": ["场景 1", "场景 2"],
    "status": "completed",
    "created_at": "2026-03-11T10:00:00",
    "updated_at": "2026-03-11T12:00:00"
}
```

#### 5.2.4 应用配置 (config.json)

```json
{
    "storage_root": "D:/AIWriter/Data",
    "works_dir": "D:/AIWriter/Data/works",
    "templates_dir": "D:/AIWriter/Data/templates",
    "logs_dir": "D:/AIWriter/Data/logs",
    "api_key": "sk-xxx",
    "default_model": "claude-sonnet-4-5-20250929",
    "theme": "light",
    "language": "zh-CN"
}
```

### 5.3 文件命名规则

```
# 作品目录：使用工作 ID（时间戳 + 序号）
work_20260311_001/
work_20260311_002/

# 分卷文件：volume_ + 三位数字序号
volume_001.json
volume_002.json

# 章节文件：chapter_ + 三位数字序号
chapter_001.json
chapter_002.json

# 封面图片：固定名称
cover.jpg
```

### 5.4 日志文件规范

```
# 日志文件名格式
aiwriter_{date}.log
aiwriter_2026-03-11.log

# 日志格式
{timestamp} | {level} | {module} | {message}
2026-03-11 10:00:00.123 | INFO | work_manager | 创建新作品：work_20260311_001
2026-03-11 10:00:01.456 | ERROR | ai_service | API 调用失败：429 Too Many Requests
```

---

## 6. 代码风格规范

### 6.1 Python 代码风格

遵循 PEP 8 规范，使用 Black 格式化：

```python
# 行宽限制
MAX_LINE_LENGTH = 100  # Black 默认 88，可根据项目调整

# 导入顺序
import sys  # 标准库
from typing import Optional

import httpx  # 第三方库
from PyQt6.QtWidgets import QMainWindow

from generations.autonomous_demo_project.src.core import WorkManager  # 本地导入


# 空行规范
# 类/函数定义前空两行
class WorkManager:
    """作品管理器"""

    def __init__(self):
        pass

    def create_work(self) -> Work:
        pass


# 同一类内方法空一行
def next_method(self):
    pass
```

### 6.2 文档字符串规范

```python
class WorkManager:
    """
    作品管理器

    负责作品的创建、加载、保存、删除等操作。
    管理作品在内存和文件系统之间的同步。

    Attributes:
        storage_path: 存储根目录路径
        cache: 作品缓存字典
    """

    def create_work(self, title: str, category: str) -> Work:
        """
        创建新作品

        Args:
            title: 作品标题
            category: 作品类别

        Returns:
            创建的 Work 对象

        Raises:
            WorkExistsError: 作品已存在时抛出
        """
        pass
```

### 6.3 类型注解规范

```python
from typing import Optional, List, Dict, Callable, Union

# 简单类型
def process_count(count: int) -> int:
    pass

def process_name(name: str) -> str:
    pass

def process_flag(enabled: bool) -> bool:
    pass

# 容器类型
def get_all_works() -> List[Work]:
    pass

def get_work_map() -> Dict[str, Work]:
    pass

def get_config(key: str) -> Optional[str]:
    pass

# 联合类型
def process_value(value: Union[str, int]) -> str:
    pass

# Callable 类型
def set_callback(func: Callable[[str], bool]) -> None:
    pass
```

---

## 7. Git 提交规范

### 7.1 提交信息格式

```
<type>(<scope>): <subject>

<body>

<footer>
```

### 7.2 Type 类型

| Type | 说明 |
|------|------|
| feat | 新功能 |
| fix | Bug 修复 |
| docs | 文档更新 |
| style | 代码格式（不影响功能） |
| refactor | 重构 |
| test | 测试相关 |
| chore | 构建/工具/配置 |

### 7.3 提交示例

```bash
# 新功能
git commit -m "feat(gui): 添加作品库视图基本框架"

# Bug 修复
git commit -m "fix(core): 修复作品保存时文件名冲突问题"

# 重构
git commit -m "refactor(services): 重构 AI 服务错误处理逻辑"

# 文档
git commit -m "docs: 更新 README 安装说明"
```

---

## 8. 注释规范

### 8.1 代码注释

```python
# 单行注释：# 后加空格
# 计算总字数
total_words = sum(chapter.word_count for chapter in chapters)

# 块注释：用于解释复杂逻辑
# 检查作品目录结构是否完整
# 需要验证以下文件/目录存在：
# - work_info.json
# - volumes/ 目录
# - chapters/ 目录
if not validate_work_structure(path):
    raise InvalidWorkStructureError(f"Invalid work structure: {path}")

# TODO 标记待办事项
# TODO: 添加缓存失效机制
# FIXME: 修复并发写入冲突
# XXX: 警告：此方法性能较差，待优化
```

### 8.2 魔法数字处理

```python
# 错误：魔法数字
if len(content) > 3000:
    pass

# 正确：使用具名常量
DEFAULT_WORDS_PER_CHAPTER = 3000

if len(content) > DEFAULT_WORDS_PER_CHAPTER:
    pass
```

---

## 9. 错误处理规范

### 9.1 自定义异常层次

```python
# src/utils/exceptions.py

class AIWriterError(Exception):
    """基础异常类"""
    pass

# 存储相关
class StorageError(AIWriterError):
    pass

class FileNotFoundError(StorageError):
    pass

class PermissionError(StorageError):
    pass

# AI 服务相关
class AIServiceError(AIWriterError):
    pass

class APIRateLimitError(AIServiceError):
    pass

class APIAuthError(AIServiceError):
    pass

# 业务逻辑相关
class WorkNotFoundError(AIWriterError):
    pass

class InvalidWorkStructureError(AIWriterError):
    pass

class TemplateRenderError(AIWriterError):
    pass
```

### 9.2 异常捕获和处理

```python
# 精确捕获特定异常
try:
    work = work_manager.load_work(work_id)
except WorkNotFoundError as e:
    show_error_dialog(f"作品不存在：{work_id}")
except StorageError as e:
    logger.error(f"存储错误：{e}")
    show_error_dialog("读取作品失败，请检查存储路径")
except Exception as e:
    logger.exception(f"未知错误：{e}")
    show_error_dialog("发生未知错误，请查看日志")
```

### 9.3 全局异常捕获

```python
# src/main.py
import sys
from PyQt6.QtWidgets import QApplication

def exception_handler(exc_type, exc_value, exc_traceback):
    """全局异常处理器"""
    logger.critical("未捕获的异常", exc_info=(exc_type, exc_value, exc_traceback))
    show_error_dialog(f"程序发生错误：{exc_value}")

sys.excepthook = exception_handler
```

---

## 10. 安全和隐私规范

### 10.1 API Key 存储

```python
# 配置文件中 API Key 应谨慎处理
# config.json 不应提交到版本控制

# .gitignore
config.json
*.key
.env
```

### 10.2 敏感数据保护

```python
# 日志中不记录敏感信息
# 错误：记录 API Key
logger.debug(f"使用 API Key: {api_key}")

# 正确：脱敏处理
logger.debug(f"使用 API Key: {mask_key(api_key)}")  # sk-**x123
```

---

## 附录：快速参考

### 命名速查表

| 项目 | 规则 | 示例 |
|------|------|------|
| 变量/函数 | snake_case | `work_title`, `create_work()` |
| 类 | PascalCase | `WorkManager`, `MainWindow` |
| 常量 | UPPER_CASE | `MAX_RETRY_COUNT` |
| 私有成员 | `_prefix` / `__prefix` | `_cache`, `__secret` |
| 模块文件 | snake_case | `work_manager.py` |
| 测试文件 | `test_` 前缀 | `test_work_manager.py` |

### 目录速查表

| 目录 | 用途 |
|------|------|
| `src/gui/widgets/` | 可复用 UI 控件 |
| `src/gui/views/` | 业务视图页面 |
| `src/gui/dialogs/` | 对话框 |
| `src/core/` | 核心业务逻辑 |
| `src/services/` | 外部服务调用 |
| `src/models/` | 数据模型 |
| `src/utils/` | 工具函数 |
| `tests/` | 测试代码 |
