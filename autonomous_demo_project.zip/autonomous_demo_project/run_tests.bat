@echo off
REM Run pytest-qt tests for AI Writer project
REM Usage: run_tests.bat [test_file] [options]

cd /d "%~dp0"

echo ========================================
echo AI Writer pytest-qt Test Runner
echo ========================================
echo.

REM Check if virtual environment exists
if exist ".venv\Scripts\activate.bat" (
    echo Activating virtual environment...
    call .venv\Scripts\activate.bat
) else (
    echo Virtual environment not found at .venv
    echo Creating virtual environment...
    python -m venv .venv
    call .venv\Scripts\activate.bat
    echo Installing dependencies...
    pip install pytest pytest-qt PyQt6
)

echo.

REM Check if pytest-qt is installed
pip show pytest-qt >nul 2>&1
if errorlevel 1 (
    echo Installing pytest-qt...
    pip install pytest-qt PyQt6
)

echo.
echo Running tests...
echo.

REM Default test file
if "%1"=="" (
    REM Run all tests
    pytest tests/test_*.py -v --tb=short %*
) else (
    REM Run specific test file
    pytest tests/%1 -v --tb=short %*
)

echo.
echo ========================================
echo Test run completed
echo ========================================

REM Deactivate virtual environment
deactivate 2>nul
