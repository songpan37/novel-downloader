import json

with open('feature_list.json', encoding='utf-8') as f:
    tests = json.load(f)

passing = [t for t in tests if t.get('passes', False)]
failing = [t for t in tests if not t.get('passes', False)]

print(f'Total tests: {len(tests)}')
print(f'Passing: {len(passing)}')
print(f'Failing: {len(failing)}')
print('\nFirst 15 failing tests:')
for t in failing[:15]:
    print(f"  #{t['id']}: {t['name']}")
