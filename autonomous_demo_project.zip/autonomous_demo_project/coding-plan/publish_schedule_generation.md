# 发布日程生成逻辑

## 概述

发布日程用于定时发布场景，用户设置每天发布章节数量和时间范围后，系统生成每天的具体发布时间点。

## 输入参数

| 参数 | 说明 | 示例 |
|------|------|------|
| start_time | 每天开始发布时间 | "21:00" |
| end_time | 每天结束发布时间 | "23:00" |
| start_date | 开始发布的日期 | "2026-04-12" |
| daily_count | 每天发布章节数 | 2 |
| start_chapter | 起始章节号 | 1 |
| end_chapter | 结束章节号 | 15 |

## 核心约束

1. **最早发布时间**：任何章节的发布时间必须 >= 当前时间 + 1小时
2. **每日上限**：每天最多发布 `daily_count` 章节
3. **时间范围**：发布时间必须在用户设定的 `start_time` 到 `end_time` 范围内

## 计算逻辑

### 1. 基本时间范围

每天的可发布时间范围是 `start_time` 到 `end_time`，例如 21:00 到 23:00 共 120 分钟。

### 2. 边界场景处理

#### Case 1：当前时间已超过今天的结束时间

如果 `当前时间 + 1小时 >= today_end`，今天跳过，从明天开始。

```
当前时间: 23:30
min_publish_time: 00:30 (明天)
today_end: 23:00
结果: 跳过今天，从明天开始发布
```

#### Case 2：当前时间早于今天的开始时间

如果 `min_publish_time <= today_start`，使用完整的时间范围。

```
当前时间: 20:00
min_publish_time: 21:00
today_start: 21:00
today_end: 23:00
结果: 可用范围 = 21:00 - 23:00
```

#### Case 3：当前时间在开始时间和结束时间之间

此时可用范围需要分段处理：
- 如果 `min_publish_time` 在 `today_start` 和 `today_end` 之间，可用范围是 `min_publish_time` 到 `min(today_end, tomorrow_0:00)`

```
当前时间: 22:00
min_publish_time: 23:00
today_start: 21:00
today_end: 23:00
tomorrow_start: 明天 00:00
结果: 可用范围 = 23:00 - 23:00 (只有1分钟，勉强可以发布1章)
```

注意：如果 `min_publish_time` 在 `today_end` 和 `tomorrow_0:00` 之间（即当前时间已超过结束时间但还没到午夜），可用范围会非常短甚至为0，此时跳过今天。

### 3. 每天章节分配

对于每天：

1. 计算当天可用的时间范围（分钟）
2. 计算当天需要发布的章节数：`min(daily_count, 剩余总章节数)`
3. 在可用范围内随机生成对应数量的时间点
4. 对时间点排序确保发布顺序正确

```python
# 示例
available_start_min = 21 * 60 + 0   # 1260
available_end_min = 23 * 60 + 0      # 1380
daily_count = 2

# 生成2个随机时间并排序
random_times = sorted([randint(1260, 1379), randint(1260, 1379)])
# 假设生成 [1284, 1341]
# 对应时间: 21:24, 22:21
```

### 4. 循环处理

```python
chapter_num = start_chapter
current_date = start_date

while chapter_num <= end_chapter:
    # 1. 计算当天可用范围
    # 2. 如果无可用范围，跳过当天

    # 3. 计算当天章节数
    chapters_today = min(daily_count, total_chapters - (chapter_num - start_chapter))

    # 4. 生成随机时间
    random_times = sorted([randint(avail_start_min, avail_end_min - 1) for _ in range(chapters_today)])

    # 5. 分配章节
    for j in range(chapters_today):
        分配 chapter_num 到 random_times[j]
        chapter_num += 1

    current_date += 1天
```

## 示例

### 输入
- 时间范围: 21:00 - 23:00 (120分钟)
- 每天章节数: 2
- 起始日期: 2026-04-12
- 章节范围: 1-15

### 输出
| 日期 | 章节 | 发布时间 |
|------|------|----------|
| 2026-04-12 | 1 | 21:14 |
| 2026-04-12 | 2 | 22:21 |
| 2026-04-13 | 3 | 21:03 |
| 2026-04-13 | 4 | 22:34 |
| 2026-04-14 | 5 | 21:31 |
| ... | ... | ... |

### 边界情况

1. **当前时间 23:30**（超过结束时间）:
   - min_publish_time = 明天 00:30
   - min_publish_time >= today_end (23:00)
   - 结果: 跳过今天，从明天开始

2. **当前时间 20:00**（早于开始时间）:
   - min_publish_time = 21:00
   - 可用范围: 21:00 - 23:00
   - 结果: 正常发布

3. **当前时间 22:00**:
   - min_publish_time = 23:00
   - 可用范围: 23:00 - 23:00
   - 结果: 只有1分钟，勉强发布1章

## 关键代码片段

```python
def _on_generate_schedule(self) -> None:
    now = datetime.now()
    min_publish_time = now + timedelta(hours=1)

    while chapter_num <= end_chapter:
        today_start = datetime.combine(current_date, start_dt.time())
        today_end = datetime.combine(current_date, end_dt.time())
        tomorrow_start = datetime.combine(current_date + timedelta(days=1), datetime.min.time())

        # Case 1: 已超过结束时间，跳过
        if min_publish_time >= today_end:
            current_date += timedelta(days=1)
            continue

        # Case 2 & 3: 计算可用范围
        available_start = min_publish_time if min_publish_time > today_start else today_start
        available_end = min(today_end, tomorrow_start)

        if available_start >= available_end:
            current_date += timedelta(days=1)
            continue

        # 生成随机时间
        chapters_today = min(daily_count, remaining_chapters)
        random_times = sorted([randint(avail_start_min, avail_end_min - 1)
                               for _ in range(chapters_today)])

        # 分配章节...
```

## 注意事项

1. 时间使用分钟表示，比较时需注意日期和时间的组合
2. `tomorrow_start` 是第二天 00:00，用于限制结束时间不超过午夜
3. 随机时间排序确保章节按时间顺序发布
4. 每次循环都需要重新计算 `min_publish_time`（因为是固定值，不是递减的）
