# 登录过程
进入登录页面：https://fanqienovel.com/main/writer/login -> 输入账号 -> 输入密码 -> 勾选协议 -> 点击登录 -> 等待用户完成验证码 -> 跳转到 https://fanqienovel.com/main/writer/home

可以从如下位置查看到登录的用户信息：
```html
<div class="muye-header-user ">
   <div class="slogin-user-avatar">
    <div class="slogin-user-avatar__info">
     <img src="https://p3-novel.byteimg.com/img/novel-static/51cdc818263941cb8985f97b486ddd11~tplv-obj.image" class="slogin-user-avatar__info__avatar" />
     <div class="slogin-user-avatar__info__name">
      我看到一只橘子
     </div>
     <div class="slogin-user-avatar__info__arrow-down"></div>
    </div>
   </div>
  </div> 
```  
  
# 创建新书过程

## 进入创建新书页面
https://fanqienovel.com/main/writer/create?enter_from=home

## 填写表单

### 书名
```html
<input maxlength="15" placeholder="请输入作品名称" class="arco-input arco-input-size-large arco-input-error" value="" aria-invalid="true">
```

### 男频女频

通过设置name="pindao"的radio值，选择男频和女频：
选择男频：
```html
<div class="arco-col arco-col--1 arco-form-item-wrapper">
   <div class="arco-form-item-control-wrapper">
    <div class="arco-form-item-control" id="radio">
     <div class="arco-form-item-control-children">
      <div class="arco-radio-group arco-radio-size-default arco-radio-mode-outline serial-radio-group" role="radiogroup">
       <label class="arco-radio arco-radio-checked serial-radio "><input type="radio" name="pindao" value="1" /><span class="arco-icon-hover arco-radio-icon-hover arco-icon-hover-disabled arco-radio-mask-wrapper">
         <div class="arco-radio-mask"></div></span><span class="arco-radio-text">男频</span></label>
       <label class="arco-radio serial-radio "><input type="radio" name="pindao" value="0" /><span class="arco-icon-hover arco-radio-icon-hover arco-radio-mask-wrapper">
         <div class="arco-radio-mask"></div></span><span class="arco-radio-text">女频</span></label>
      </div>
     </div>
    </div>
   </div>
  </div>  
```

选择女频：
```html
<div class="arco-col arco-col--1 arco-form-item-wrapper">
   <div class="arco-form-item-control-wrapper">
    <div class="arco-form-item-control" id="radio">
     <div class="arco-form-item-control-children">
      <div class="arco-radio-group arco-radio-size-default arco-radio-mode-outline serial-radio-group" role="radiogroup">
       <label class="arco-radio arco-radio-checked serial-radio "><input type="radio" name="pindao" value="0" /><span class="arco-icon-hover arco-radio-icon-hover arco-icon-hover-disabled arco-radio-mask-wrapper">
         <div class="arco-radio-mask"></div></span><span class="arco-radio-text">男频</span></label>
       <label class="arco-radio serial-radio "><input type="radio" name="pindao" value="1" /><span class="arco-icon-hover arco-radio-icon-hover arco-radio-mask-wrapper">
         <div class="arco-radio-mask"></div></span><span class="arco-radio-text">女频</span></label>
      </div>
     </div>
    </div>
   </div>
  </div>  
```

### 选择标签（通过直接修改页面的html来模拟标签选择）：

标签所在div：
```html
<div class="arco-col arco-col--1 arco-form-item-wrapper">
  <div class="arco-form-item-control-wrapper">
    <div class="arco-form-item-control" id="selectRow">
      <div class="arco-form-item-control-children">
        <div class="select-row">
          <span class="view-inner-wrap">
            <div class="select-view  ">
              <span style="color: rgb(164, 164, 164); font-size: 14px; margin-left: 12px;">请选择作品标签</span>
              <span class="tomato-down-arrow null"/>
            </div>
          </span>
        </div>
      </div>
    </div>
  </div>
</div>
```

选择标签后，.select-view 里面会用ul和li展示标签：
```html
<div class="arco-col arco-col--1 arco-form-item-wrapper">
  <div class="arco-form-item-control-wrapper">
    <div class="arco-form-item-control" id="selectRow">
      <div class="arco-form-item-control-children">
        <div class="select-row">
          <span class="view-inner-wrap">
            <div class="select-view  ">
              <ul class="select-view-ul">
                <li class="create-category-item font-2">
                  <span class="item-title">西方奇幻</span>
                  <span class="tomato-close item-del"/>
                </li>
                <li class="create-category-item font-2">
                  <span class="item-title">衍生</span>
                  <span class="tomato-close item-del"/>
                </li>
              </ul>
              <span class="tomato-down-arrow null"/>
            </div>
          </span>
        </div>
      </div>
    </div>
  </div>
</div>
```

标签一共有四个类别（主分类、主题、角色、情节），每个类别可以选择不同的标签：

#### 主分类（最多选择1个）
- 西方奇幻：偏西方世界背景下，包含魔法斗气奥术等奇幻元素的小说
- 东方仙侠：偏东方世界背景下，包含修仙修道修真等仙侠元素的小说
- 科幻末世：末世、丧尸、星际、机甲、未来科技等
- 男频衍生：影视剧男频同人小说
- 都市高武：都市架空,全民拥有修炼体系、灵气复苏等
- 悬疑灵异：男频探案、悬疑、恐怖、风水奇术等
- 悬疑脑洞：脑洞向的悬疑灵异、破案探险类，以及诡异复苏、惊悚游戏、规则怪谈等带有创意的悬疑新类型
- 抗战谍战：抗战时期的军事战争和间谍情报的男频小说
- 历史古代：以种田、朝堂、智谋、争霸、科举等为主要元素，行文严谨，兼顾历史真实与艺术创作规律的无金手指非系统历史文
- 历史脑洞：脑洞向历史，一般有金手指
- 都市种田：重生年代文、职场商战文、种田建设等都市文
- 都市脑洞：拥有金手指系统的男频都市脑洞奇想
- 都市日常：都市情感、现实生活等都市文
- 玄幻脑洞：脑洞向玄幻
- 战神赘婿：都市向战神，兵王文
- 动漫衍生：游戏、动漫等偏二次元向的同人作品
- 游戏体育：网游、竞技、体育及穿入游戏或世界游戏化
- 传统玄幻：废柴逆袭，强者重生等传统玄幻，高武世界，异世大陆文
- 都市修真：以修真为力量体系的都市文

#### 主题（最多选择2个）
- 衍生
- 仕途
- 综影视
- 天灾
- 第一人称
- 赛博朋克
- 第四天灾
- 规则怪谈
- 搞笑轻松
- 古代
- 悬疑
- 克苏鲁
- 都市异能
- 末日求生
- 灵气复苏
- 高武世界
- 异世大陆
- 东方玄幻
- 谍战
- 清朝
- 宋朝
- 断层
- 武将
- 国运
- 综漫
- 开局
- 架空
- 奇幻仙侠
- 都市
- 玄幻
- 历史
- 体育
- 武侠

#### 角色（最多选择2个）
- 多女主
- 赘婿
- 全能
- 大佬
- 大小姐
- 特工
- 游戏主播
- 神探
- 宫廷侯爵
- 皇帝
- 单女主
- 校花
- 无女主
- 女帝
- 特种兵
- 反派
- 神医
- 奶爸
- 学霸
- 天才
- 腹黑
- 扮猪吃虎

#### 情节（最多选择2个）
- 风水秘术
- 斩神衍生
- 十日衍生
- 西游衍生
- 公版衍生
- 红楼衍生
- 甄嬛衍生
- 如懿衍生
- 都市江湖
- 惊悚游戏
- 卡牌
- 山海经
- 捉鬼
- 剑修
- 废土
- 副本
- 黑科技
- 无脑爽
- 魂穿
- 高手下山
- 黑化
- 迪化
- 发家致富
- 无后宫
- 争霸
- 1v1
- 升级流
- 灵魂互换
- 科举
- 封神
- 四合院
- 电竞
- 双重生
- 乡村
- 同人
- 打脸
- 破案
- 囤物资
- 钓鱼
- 网游
- 奥特同人
- 求生
- 无敌
- 九叔
- 穿书
- 聊天群
- 大秦
- 龙珠
- 漫威
- 神奇宝贝
- 海贼
- 火影
- 职场
- 明朝
- 家庭
- 三国
- 末世
- 直播
- 无限流
- 诸天万界
- 大唐
- 宠物
- 外卖
- 星际
- 美食
- 剑道
- 盗墓
- 灵异
- 鉴宝
- 系统
- 神豪
- 重生
- 穿越
- 二次元
- 海岛
- 娱乐圈
- 空间
- 推理
- 洪荒

一共需要选择7个标签，填充到 div.select-view 里面的 ul.select-view-ul ，形成7个 li.create-category-item：
```html
<div class="select-view  ">
  <ul class="select-view-ul">
	<li class="create-category-item font-2">
	  <span class="item-title">西方奇幻</span>
	  <span class="tomato-close item-del"/>
	</li>
	<li class="create-category-item font-2">
	  <span class="item-title">衍生</span>
	  <span class="tomato-close item-del"/>
	</li>
  </ul>
  <span class="tomato-down-arrow null"/>
</div>
```

### 输入主角名

填写两个主角名称，每个名字不超过5个字：
```html
<input maxlength="5" placeholder="请输入主角名1" class="arco-input arco-input-size-large arco-input-error" value="" aria-invalid="true">
<input maxlength="5" placeholder="请输入主角名2" class="arco-input arco-input-size-large arco-input-error" value="" aria-invalid="true">
```

### 输入作品简介
在如下textarea里面输入作品简介：
```html
<div class="textarea-inner" id="descRow_input">
   <div class="arco-row arco-row-align-start arco-row-justify-start serial-row desc-input">
    <div class="pgc-input-hint ">
     <textarea minlength="50" class="arco-textarea serial-textarea" placeholder="请输入50-500字以内的作品简介，不可出现低俗、暴力、血腥等不符合法律法规的内容" style="resize: none; overflow: scroll; height: 100%; min-height: 100%; max-height: 100%;"></textarea>
     <div class="pgc-hint-text hint">
      <div class="hint__content">
       0/500
      </div>
     </div>
    </div>
   </div>
  </div>
```

## 点击创建

点击如下的立即创建按钮：
```html
<div class="arco-row arco-row-align-start arco-row-justify-end serial-row " style="margin-top: 10px; padding-bottom: 202px;">
  <button class="arco-btn arco-btn-secondary arco-btn-size-default arco-btn-shape-round serial-arco-btn" type="button" style="width: 90px; border: none; margin-right: 20px; padding: 0px;">
    <span>取消</span>
  </button>
  <button class="arco-btn arco-btn-primary arco-btn-size-default arco-btn-shape-round serial-arco-btn" type="button" style="padding: 0px;">
    <span>立即创建</span>
  </button>
</div>
```

点击创建按钮后：
监控这个请求： https://fanqienovel.com/api/author/book/create/v0/?xxxx

下面是成功响应请求：
```json
{
    "code": 0,
    "data": {
        "book_name": "我以凡躯斩仙1111",
        "book_id": "7626026655567318078",
        "status": 1,
        "thumb_uri": "novel-pic-r/65bac56f3205516eb2ae106ae8f16aa8",
        "abstract": "青石镇少年陆尘，被测出天生凡骨，经脉闭塞，灵根全无——在这个修炼为尊的世界，这意味着他终生无法凝聚灵气，注定被踩在尘埃里。族人嘲笑，师长叹息，连他自己都几乎认命。然而一次进山采药，他误入上古荒墓，得禁忌功法《逆凡诀》。此诀不以灵根修炼，而是以肉身为炉、意志为火、天劫为锤，将凡骨锻造成超越仙体的存在。从此，陆尘踏上逆天之路：每一次突破都要承受天道降下的雷劫，每一次变强都与天地法则正面对抗。宗门视他为异类，正道称他为逆贼，天劫一次比一次恐怖。但他从不低头——荒原上以凡人之躯接下元婴一剑，雷海中以血肉之身撞碎第九重天劫。从青石镇的废物少年，一步步走到九天之上。推开那扇无人敢碰的仙门，门后是天道。而他只问一句：你说凡人不可成仙，我偏要逆了这苍天！",
        "genre": 0,
        "gift_word": "",
        "authorize_type": 0,
        "sign_progress": 0,
        "creation_status": 1,
        "can_modify": true,
        "create_time": 1775572695,
        "gender": 1,
        "completion_status": 1,
        "category": null,
        "can_delete": true,
        "set_top": -2,
        "has_hide": -2,
        "roles": [
            "陆尘",
            "苏婉清"
        ],
        "editor_info": "",
        "has_activity": 0,
        "activity_id": 0,
        "activity_name": "",
        "activity_detail_url": "",
        "activity_icon_uri": "",
        "activity_description": "",
        "group_name": null,
        "security_status": 1,
        "group_category": null,
        "thumb_url_list": [
            {
                "size": "160x214",
                "main_url": "https://p0-reading-private.fanqienovel.com/novel-pic-r/65bac56f3205516eb2ae106ae8f16aa8~tplv-
resize:160:214.image?lk3s=8c91f0b0&policy=eyJ2bSI6MywidWlkIjoiMzI4MzU2MjgzOTQxNTY5OSJ9&x-orig-authkey=9789e59a7aff57c4619b
24f373478561&x-orig-expires=1778164695&x-orig-sign=z3xu3m0Nu7bBzeE0GwxvkYPwt5I%3D",
                "backup_url": "https://p0-reading-private.fanqienovel.com/novel-pic-r/65bac56f3205516eb2ae106ae8f16aa8~tpl
v-resize:160:214.image?lk3s=8c91f0b0&policy=eyJ2bSI6MywidWlkIjoiMzI4MzU2MjgzOTQxNTY5OSJ9&x-orig-authkey=9789e59a7aff57c461
9b24f373478561&x-orig-expires=1778164695&x-orig-sign=z3xu3m0Nu7bBzeE0GwxvkYPwt5I%3D"
            }
        ],
        "creation_audit_status": 0,
        "has_real_editor": false,
        "book_flight_alias_name": "",
        "referral_traffic_permission": 0,
        "referral_traffic_running_state": 0,
        "word_number": 0,
        "is_signing": false,
        "plagiarize_appeal_status": 0,
        "has_plagiarize_appeal_record": 0,
        "safe_reaudit_status": 0,
        "safe_reaudit_time": 0,
        "verify_status": 1,
        "in_attend_activity": 0,
        "check_write_extra_permission": false,
        "fail_chapter_records_group_by_problem": null,
        "copyright_plagiarism_info_group_by_problem": null
    },
    "log_id": "202604072238152752C8EED12B3D722202",
    "message": "success"
}
```
下面是失败响应请求：
```json
{
    "code": -2006,
    "data": null,
    "log_id": "20260407223636A3A6C4BC79980C5B62C9",
    "message": "该书名已存在"
}
```


## 重定向到书本页面
创建成功后，页面会重定向到书本页面，如下url：
https://fanqienovel.com/main/writer/book-info/7625274537797504062?type=1

其中 7625274537797504062 就是书本id
