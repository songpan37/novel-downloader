# 番茄更新已发布章节流程

## 进入章节编辑页面
新建一个page，url格式：
https://fanqienovel.com/main/writer/{书本id}/publish/{章节id}/?enter_from=modifychapter

样例：
https://fanqienovel.com/main/writer/7626727431100959768/publish/7626727468778422808/?enter_from=modifychapter

#### 输入章节号
在如下input里输入章节号：
```html
<div class="serial-editor-title-left none">
    <span>第</span>
        <span class="left-input">
            <input type="text" class="serial-input byte-input byte-input-size-default" value="">
        </span>
    <span>章</span>
</div>
```

#### 输入章节标题
在如下input里输入章标题：
```html
<div class="serial-editor-title-right">
    <div class="serial-editor-input-hint input">
        <input placeholder="请输入标题" class="serial-input serial-editor-input-hint-area byte-input byte-input-size-default" value="">
    </div>
</div>
```

#### 输入章节正文
在如下div中药键入章节正文。

未写入任何段落状态：
```html
<div contenteditable="true" translate="no" class="ProseMirror" spellcheck="false">
    <p>
        <span class="syl-placeholder ProseMirror-widget" style="cursor: text; text-indent: initial; pointer-events: none; -webkit-user-select: none; user-select: none; position: absolute;" ignoreel="true" contenteditable="false">请输入正文，或通过输入「空格」唤起AI写作小助手</span>
        <img class="ProseMirror-separator" alt="">
        <br class="ProseMirror-trailingBreak">
    </p>
</div>
```

写入段落状态：
```html
<div contenteditable="true" translate="no" class="ProseMirror" spellcheck="false">
    <p>青石镇广场上，搭起了一座三尺高的石台。</p>
    <p>台上放着一块人头大小的青灰色石头，表面光滑如镜，在春日的阳光下泛着幽幽冷光。那是测灵石，据说是仙门赐下的宝物，能测出一个人的灵根资质。</p>
    <p>台下人头攒动，全镇男女老少几乎都来了。</p>
    <p>陆尘排在队伍中间，手心全是汗。</p>
    <p>
        <br class="ProseMirror-trailingBreak">
    </p>
</div>
```
每个段落用<p>标签包裹，然后插入<div>里。


#### 确认发布时间前30分钟提交修改内容
检查是否有如下提示框，如果有则点击`我知道了`按钮进行确认。

```html
<div class="serial-modal byte-modal" style="width: 428px;">
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
    <div data-focus-lock-disabled="false">
        <div class="byte-modal-header">
            <div class="byte-modal-title">
                <span>
                    <svg class="byte-icon byte-icon-info-circle-fill" viewBox="0 0 1024 1024" width="1em" height="1em" fill="currentColor">
                        <path d="M512.435 0C229.428 0 0 229.173 0 511.926 0 794.7 229.428 1024 512.435 1024c282.944 0 512.393-229.322 512.393-512.074C1024.828 229.173 795.378 0 512.435 0zm42.906 762.191a42.927 42.927 0 01-85.876 0V477.592a42.949 42.949 0 0185.876 0v284.6zm0-441.752a42.906 42.906 0 01-42.906 42.906 42.885 42.885 0 01-42.97-42.906v-13.432c0-23.745 19.204-42.906 42.97-42.906 23.66 0 42.906 19.161 42.906 42.906v13.432z"></path>
                    </svg>提示
                </span>
            </div>
        </div>
        <div class="byte-modal-content" style="margin-left: 30px;">请在发布时间前30分钟提交修改内容，否则无法完成修改</div>
        <div class="byte-modal-footer">
            <button class="byte-btn byte-btn-primary byte-btn-size-default byte-btn-shape-square" type="button">
                <span>我知道了</span>
            </button>
        </div>
        <button tabindex="-1" class="byte-modal-close-icon">
            <svg class="byte-icon byte-icon-close" viewBox="0 0 1024 1024" width="1em" height="1em" fill="currentColor">
                <path d="M512 448l288-288c6.4-6.4 19.2-6.4 32 0l25.6 32c6.4 6.4 6.4 19.2 0 32l-288 281.6 288 288c6.4 6.4 6.4 19.2 0 32l-32 32c-6.4 6.4-19.2 6.4-32 0L512 569.6l-288 288c-6.4 6.4-19.2 6.4-32 0l-32-32c-6.4-6.4-6.4-19.2 0-32l288-288L160 224c-6.4-12.8-6.4-25.6 0-32l32-32c6.4-6.4 19.2-6.4 32 0l288 288z"></path>
                <path d="M512 448l288-288c6.4-6.4 19.2-6.4 32 0l25.6 32c6.4 6.4 6.4 19.2 0 32l-288 281.6 288 288c6.4 6.4 6.4 19.2 0 32l-32 32c-6.4 6.4-19.2 6.4-32 0L512 569.6l-288 288c-6.4 6.4-19.2 6.4-32 0l-32-32c-6.4-6.4-6.4-19.2 0-32l288-288L160 224c-6.4-12.8-6.4-25.6 0-32l32-32c6.4-6.4 19.2-6.4 32 0l288 288z"></path>
            </svg>
        </button>
    </div>
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
</div>
```
上面这个提示框可能有可能没有，在点击下一步之前，需要进行检查，如果有就点击确认，如果没有就跳过，进入后面的步骤。



#### 点击下一步
点击下一步按钮：
```html
<div class="publish-header">
    <div class="publish-header-right">
        <button class="arco-btn arco-btn-secondary arco-btn-size-default arco-btn-shape-square publish-button auto-editor-next btn-primary-variant" type="button">
            <span>下一步</span>
        </button>
    </div>
</div>
```

#### 检查是否有错别字
检查是否会弹出如下提示框，如果有，则点击提交。
```html
<div role="dialog" aria-modal="true" aria-labelledby="arco-dialog-5" class="arco-modal auto-editor-error-modal publish-modal-confirm global-confirm-modal zoomModal-appear-done zoomModal-enter-done" style="width: 428px;">
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
    <div data-focus-lock-disabled="false" tabindex="-1">
        <div class="arco-modal-header">
            <div class="arco-modal-title" id="arco-dialog-5">
                <span>发布提示</span>
            </div>
        </div>
        <div class="arco-modal-content">检测到你还有错别字未修改，是否确定提交？</div>
        <div class="arco-modal-footer">
            <button class="arco-btn arco-btn-secondary arco-btn-size-default arco-btn-shape-square" type="button">
                <span>取消</span>
            </button>
            <button class="arco-btn arco-btn-primary arco-btn-size-default arco-btn-shape-square" type="button">
                <span>提交</span>
            </button>
        </div>
        <span class="arco-icon-hover arco-modal-close-icon" tabindex="-1" role="button" aria-label="Close">
            <svg class="serial-icon serial-icon-close " width="1em" height="1em" viewBox="0 0 32 32" fill="currentColor"
                xmlns="http://www.w3.org/2000/svg">
                <path d="M5.29289 6.70711C4.90237 6.31658 4.90237 5.68342 5.29289 5.29289C5.68342 4.90237 6.31658 4.90237 6.70711 5.29289L16 14.5858L25.2929 5.29289C25.6834 4.90237 26.3166 4.90237 26.7071 5.29289C27.0976 5.68342 27.0976 6.31658 26.7071 6.70711L17.4142 16L26.7071 25.2929C27.0976 25.6834 27.0976 26.3166 26.7071 26.7071C26.3166 27.0976 25.6834 27.0976 25.2929 26.7071L16 17.4142L6.70711 26.7071C6.31658 27.0976 5.68342 27.0976 5.29289 26.7071C4.90237 26.3166 4.90237 25.6834 5.29289 25.2929L14.5858 16L5.29289 6.70711Z"></path>
            </svg>
        </span>
    </div>
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
</div>
```
注意，上述错别字提示框，可能有，可能没有。



#### 检查非章节内容使用作者有话说
检查是否会弹出如下提示框，如果有，则点击提交：
```html
<div role="dialog" aria-modal="true" class="arco-modal auto-editor-error-modal publish-modal-confirm global-confirm-modal zoomModal-appear-done zoomModal-enter-done" style="width: 428px;">
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
    <div data-focus-lock-disabled="false" tabindex="-1">
        <div class="arco-modal-content">非章节内容请使用“作者有话说”功能，章末附带无关内容可能会影响章节审核结果。是否确定提交？</div>
        <div class="arco-modal-footer">
            <button class="arco-btn arco-btn-secondary arco-btn-size-default arco-btn-shape-square" type="button">
                <span>取消</span>
            </button>
            <button class="arco-btn arco-btn-primary arco-btn-size-default arco-btn-shape-square" type="button">
                <span>提交</span>
            </button>
        </div>
        <span class="arco-icon-hover arco-modal-close-icon" tabindex="-1" role="button" aria-label="Close">
            <svg class="serial-icon serial-icon-close " width="1em" height="1em" viewBox="0 0 32 32" fill="currentColor"
                xmlns="http://www.w3.org/2000/svg">
                <path d="M5.29289 6.70711C4.90237 6.31658 4.90237 5.68342 5.29289 5.29289C5.68342 4.90237 6.31658 4.90237 6.70711 5.29289L16 14.5858L25.2929 5.29289C25.6834 4.90237 26.3166 4.90237 26.7071 5.29289C27.0976 5.68342 27.0976 6.31658 26.7071 6.70711L17.4142 16L26.7071 25.2929C27.0976 25.6834 27.0976 26.3166 26.7071 26.7071C26.3166 27.0976 25.6834 27.0976 25.2929 26.7071L16 17.4142L6.70711 26.7071C6.31658 27.0976 5.68342 27.0976 5.29289 26.7071C4.90237 26.3166 4.90237 25.6834 5.29289 25.2929L14.5858 16L5.29289 6.70711Z"></path>
            </svg>
        </span>
    </div>
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
</div>
```
注意，上述提示框，可能有，可能没有。



#### 检查是否进行内容风险检测
检查是否会存在如下提示框，如果有，则点击提交：
```html
<div role="dialog" aria-modal="true" aria-labelledby="arco-dialog-6" class="arco-modal undefined global-confirm-modal zoomModal-appear-done zoomModal-enter-done" style="transform-origin: 378px 188.4px;">
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
    <div data-focus-lock-disabled="false" tabindex="-1">
        <div class="arco-modal-header">
            <div class="arco-modal-title" id="arco-dialog-6">
                <span>是否进行内容风险检测？</span>
            </div>
        </div>
        <div class="arco-modal-content">开启后，小助手将为你标注当前章节可能存在的风险内容。请确认是否已完成当前章节编辑，需开启风险提示功能并消耗此功能使用次数？</div>
        <div class="arco-modal-footer">
            <button class="arco-btn arco-btn-secondary arco-btn-size-default arco-btn-shape-square" type="button">
                <span>取消</span>
            </button>
            <button class="arco-btn arco-btn-primary arco-btn-size-default arco-btn-shape-square" type="button">
                <span>确定</span>
            </button>
        </div>
        <span class="arco-icon-hover arco-modal-close-icon" tabindex="-1" role="button" aria-label="Close">
            <svg class="serial-icon serial-icon-close " width="1em" height="1em" viewBox="0 0 32 32" fill="currentColor"
                xmlns="http://www.w3.org/2000/svg">
                <path d="M5.29289 6.70711C4.90237 6.31658 4.90237 5.68342 5.29289 5.29289C5.68342 4.90237 6.31658 4.90237 6.70711 5.29289L16 14.5858L25.2929 5.29289C25.6834 4.90237 26.3166 4.90237 26.7071 5.29289C27.0976 5.68342 27.0976 6.31658 26.7071 6.70711L17.4142 16L26.7071 25.2929C27.0976 25.6834 27.0976 26.3166 26.7071 26.7071C26.3166 27.0976 25.6834 27.0976 25.2929 26.7071L16 17.4142L6.70711 26.7071C6.31658 27.0976 5.68342 27.0976 5.29289 26.7071C4.90237 26.3166 4.90237 25.6834 5.29289 25.2929L14.5858 16L5.29289 6.70711Z"></path>
            </svg>
        </span>
    </div>
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
</div>
```
注意，上述提示框，可能有，可能没有。


**注意**
上述的3个提示框 检查是否有错别字、检查非章节内容使用作者有话说、检查是否进行内容风险检测 都是可能有可能没有，因此，每个提示框的超时时间不要等待太久。
可以在一个循环里面，逐个检查上述3个提示框，如果有则进行点击，如果等待1秒超时，则进行下一个提示框检查，一直循环到下面的 发布设置 提示框出现，就结束循环。

#### 进行发布设置
检查是否有发布设置提示框出现：
```html
<div role="dialog" aria-modal="true" aria-labelledby="arco-dialog-3"
     class="arco-modal publish-confirm-container-new zoomModal-appear-done zoomModal-enter-done"
     style="transform-origin: 397px 234.6px;">
    <div class="arco-modal-header">
        <div class="arco-modal-title" id="arco-dialog-3">发布设置</div>
    </div>
</div>
```

#### 选择是否使用AI
点击下面的第二个label，选择否：
```html
<div class="card-content-line-control">
    <div class="arco-radio-group arco-radio-size-default arco-radio-mode-outline" role="radiogroup">
        <label class="arco-radio">
        <input type="radio" value="1">
            <span class="arco-icon-hover arco-radio-icon-hover arco-radio-mask-wrapper">
                <div class="arco-radio-mask"></div>
            </span>
            <span class="arco-radio-text">是</span>
        </label>
        <label class="arco-radio">
            <input type="radio" value="2">
                <span class="arco-icon-hover arco-radio-icon-hover arco-radio-mask-wrapper">
                    <div class="arco-radio-mask"></div>
                </span>
                <span class="arco-radio-text">否</span>
        </label>
    </div>
</div>
```

#### 点击确认发布
点击确认发布按钮：
```html
<div class="arco-modal-footer">
    <button class="arco-btn arco-btn-secondary arco-btn-size-default arco-btn-shape-square" type="button">
        <span>取消</span>
    </button>
    <button class="arco-btn arco-btn-primary arco-btn-size-default arco-btn-shape-square" type="button">
        <span>确认发布</span>
    </button>
</div>
```

#### 等待 publish 接口完成
接口url：
https://fanqienovel.com/api/author/publish_article/v0/?msToken=

成功响应样例：
```json
{
    "code": 0,
    "data": {
        "item_id": "7626727468778422808",
        "tips": ""
    },
    "log_id": "20260409200702BC9A31DE6465BC8AEC02",
    "message": "success"
}
```

如果请求失败了，需要进行3次重试，如果重试失败了，将错误信息展示在界面上。