# AI 创作流程完整文档（硬编码版本）

## 概述

本文档描述 AI 创作流程的**硬编码实现方案**。

**核心原则**：
1. 每个会话一个独立方法
2. 每个步骤一个独立方法
3. 不使用循环、递归或通用流程控制
4. 所有执行顺序在代码中明确写出

---

## 完整会话列表

假设用户选择创作第 1-2 卷，每卷 5 章，参考作品 2 部（作品 A、作品 B）：

| 序号 | 会话 ID | 会话名称 | 输入步骤数 | 输出步骤数 | 总步骤数 |
|------|---------|----------|-----------|-----------|---------|
| 1 | `basic_info` | 基本设定 | 5 | 6 | 11 |
| 2 | `reference_作品 A_1_10` | 拆书：作品 A | 5 | 1 | 6 |
| 3 | `reference_作品 B_1_10` | 拆书：作品 B | 5 | 1 | 6 |
| 4 | `pattern_analysis` | 创作公式 | 5 | 1 | 6 |
| 5 | `volume_1` | 第 1 卷 | 5 | 2 | 7 |
| 6 | `volume_2` | 第 2 卷 | 5 | 2 | 7 |
| 7 | `chapter_1` | 第 1 卷章节 | 7 | 10 | 17 |
| 8 | `chapter_2` | 第 2 卷章节 | 7 | 10 | 17 |
| 9 | `volume_summary_1` | 第 1 卷总结 | 5 | 2 | 7 |
| 10 | `volume_summary_2` | 第 2 卷总结 | 5 | 2 | 7 |

**总计**：10 个会话，55 个输入步骤，42 个输出步骤，共 97 个步骤

---

## 完整执行流程（硬编码）

```python
def _start_creation_flow(self) -> None:
    """
    开始创作流程 - 硬编码所有会话的执行顺序
    """
    # === 第 1 个会话：基本设定 ===
    self._execute_basic_info_session()

def _execute_basic_info_session(self) -> None:
    """
    会话 1：基本设定

    输入阶段（5 步）：
    1. 定义角色
    2. 定义任务
    3. 输入小说基本设定
    4. 输入前序剧情
    5. 输入已完成的信息

    输出阶段（6 步）：
    1. 文风设定
    2. 书名
    3. 故事梗概
    4. 时空设定
    5. 人物设定
    6. 封面图片
    """
    session_id = "basic_info"

    # --- 输入阶段（5 步，顺序执行）---
    self._basic_input_role(session_id)
    self._basic_input_task(session_id)
    self._basic_input_basic_setting(session_id)
    self._basic_input_previous_plot(session_id)
    self._basic_input_completed(session_id)

    # --- 输出阶段（6 步，顺序执行）---
    self._generate_style_setting(session_id)
    self._generate_book_title(session_id)
    self._generate_story_summary(session_id)
    self._generate_worldbuilding(session_id)
    self._generate_character_design(session_id)
    self._generate_cover_image(session_id)

    # --- 进入下一个会话 ---
    self._execute_reference_session_work_a()


def _execute_reference_session_work_a(self) -> None:
    """
    会话 2：拆书参考 - 作品 A（第 1-10 章）

    输入阶段（5 步）：
    1. 定义角色
    2. 定义任务
    3. 输入小说基本设定
    4. 输入前序剧情
    5. 输入已完成的信息

    输出阶段（1 步）：
    1. 拆书分析
    """
    session_id = "reference_work_a_1_10"

    # --- 输入阶段（5 步）---
    self._reference_input_role(session_id, "作品 A")
    self._reference_input_task(session_id, "作品 A", 1, 10)
    self._reference_input_basic_setting(session_id)
    self._reference_input_previous_plot(session_id)
    self._reference_input_completed(session_id)

    # --- 输出阶段（1 步）---
    self._generate_reference_analysis(session_id, "作品 A", 1, 10)

    # --- 进入下一个会话 ---
    self._execute_reference_session_work_b()


def _execute_reference_session_work_b(self) -> None:
    """
    会话 3：拆书参考 - 作品 B（第 1-10 章）
    """
    session_id = "reference_work_b_1_10"

    # --- 输入阶段（5 步）---
    self._reference_input_role(session_id, "作品 B")
    self._reference_input_task(session_id, "作品 B", 1, 10)
    self._reference_input_basic_setting(session_id)
    self._reference_input_previous_plot(session_id)
    self._reference_input_completed(session_id)

    # --- 输出阶段（1 步）---
    self._generate_reference_analysis(session_id, "作品 B", 1, 10)

    # --- 进入下一个会话 ---
    self._execute_pattern_analysis_session()


def _execute_pattern_analysis_session(self) -> None:
    """
    会话 4：创作公式

    输入阶段（5 步）：
    1. 定义角色
    2. 定义任务
    3. 输入小说基本设定
    4. 输入前序剧情
    5. 输入已完成的拆书分析

    输出阶段（1 步）：
    1. 创作公式分析
    """
    session_id = "pattern_analysis"

    # --- 输入阶段（5 步）---
    self._pattern_input_role(session_id)
    self._pattern_input_task(session_id, 1, 10)
    self._pattern_input_basic_setting(session_id)
    self._pattern_input_previous_plot(session_id)
    self._pattern_input_completed(session_id)  # 包含两个拆书分析结果

    # --- 输出阶段（1 步）---
    self._generate_pattern_analysis(session_id, 1, 10)

    # --- 进入下一个会话 ---
    self._execute_volume_1_session()


def _execute_volume_1_session(self) -> None:
    """
    会话 5：第 1 卷

    输入阶段（5 步）：
    1. 定义角色
    2. 定义任务
    3. 输入小说基本设定
    4. 输入前序剧情
    5. 输入已完成的信息

    输出阶段（2 步）：
    1. 分卷大纲
    2. 分卷人物
    """
    session_id = "volume_1"
    vol_num = 1

    # --- 输入阶段（5 步）---
    self._volume_input_role(session_id, vol_num)
    self._volume_input_task(session_id, vol_num)
    self._volume_input_basic_setting(session_id)
    self._volume_input_previous_plot(session_id, vol_num)  # 第 1 卷无前序剧情
    self._volume_input_completed(session_id, vol_num)

    # --- 输出阶段（2 步）---
    self._generate_volume_outline(session_id, vol_num)
    self._generate_volume_characters(session_id, vol_num)

    # --- 进入下一个会话 ---
    self._execute_volume_2_session()


def _execute_volume_2_session(self) -> None:
    """
    会话 6：第 2 卷
    """
    session_id = "volume_2"
    vol_num = 2

    # --- 输入阶段（5 步）---
    self._volume_input_role(session_id, vol_num)
    self._volume_input_task(session_id, vol_num)
    self._volume_input_basic_setting(session_id)
    self._volume_input_previous_plot(session_id, vol_num)  # 包含第 1 卷总结
    self._volume_input_completed(session_id, vol_num)

    # --- 输出阶段（2 步）---
    self._generate_volume_outline(session_id, vol_num)
    self._generate_volume_characters(session_id, vol_num)

    # --- 进入下一个会话 ---
    self._execute_chapter_1_session()


def _execute_chapter_1_session(self) -> None:
    """
    会话 7：第 1 卷章节（第 1-5 章）

    输入阶段（7 步）：
    1. 定义角色
    2. 定义任务
    3. 输入小说基本设定
    4. 输入前序剧情
    5. 输入分卷大纲和分卷人物
    6. 上一卷最后 3 章正文 (new_chat=False)
    7. 输入已完成的章节信息

    输出阶段（10 步）：
    第 1 章大纲 → 第 1 章正文 → 第 2 章大纲 → 第 2 章正文 → ... → 第 5 章正文
    """
    session_id = "chapter_1"
    vol_num = 1
    chapters_per_volume = 5

    # --- 输入阶段（7 步）---
    self._chapter_input_role(session_id, vol_num)
    self._chapter_input_task(session_id, vol_num, chapters_per_volume)
    self._chapter_input_basic_setting(session_id)
    self._chapter_input_previous_plot(session_id, vol_num)
    self._chapter_input_volume_info(session_id, vol_num)
    self._chapter_input_previous_3_chapters(vol_num, current_session=7, total_sessions=10)
    self._chapter_input_completed_info(session_id, vol_num)

    # --- 输出阶段（10 步：5 章 × 2）---
    # 第 1 章
    self._generate_chapter_outline(session_id, vol_num, 1)
    self._generate_chapter_content(session_id, vol_num, 1)
    # 第 2 章
    self._generate_chapter_outline(session_id, vol_num, 2)
    self._generate_chapter_content(session_id, vol_num, 2)
    # 第 3 章
    self._generate_chapter_outline(session_id, vol_num, 3)
    self._generate_chapter_content(session_id, vol_num, 3)
    # 第 4 章
    self._generate_chapter_outline(session_id, vol_num, 4)
    self._generate_chapter_content(session_id, vol_num, 4)
    # 第 5 章
    self._generate_chapter_outline(session_id, vol_num, 5)
    self._generate_chapter_content(session_id, vol_num, 5)

    # --- 进入下一个会话 ---
    self._execute_chapter_2_session()


def _execute_chapter_2_session(self) -> None:
    """
    会话 8：第 2 卷章节（第 1-5 章）

    输入阶段（7 步）：
    1. 定义角色
    2. 定义任务
    3. 输入小说基本设定
    4. 输入前序剧情
    5. 输入分卷大纲和分卷人物
    6. 上一卷最后 3 章正文 (new_chat=False)
    7. 输入已完成的章节信息

    输出阶段（10 步）：
    第 1 章大纲 → 第 1 章正文 → 第 2 章大纲 → 第 2 章正文 → ... → 第 5 章正文
    """
    session_id = "chapter_2"
    vol_num = 2
    chapters_per_volume = 5

    # --- 输入阶段（7 步）---
    self._chapter_input_role(session_id, vol_num)
    self._chapter_input_task(session_id, vol_num, chapters_per_volume)
    self._chapter_input_basic_setting(session_id)
    self._chapter_input_previous_plot(session_id, vol_num)  # 包含第 1 卷全部章节
    self._chapter_input_volume_info(session_id, vol_num)
    self._chapter_input_previous_3_chapters(vol_num, current_session=8, total_sessions=10)
    self._chapter_input_completed_info(session_id, vol_num)

    # --- 输出阶段（10 步）---
    self._generate_chapter_outline(session_id, vol_num, 1)
    self._generate_chapter_content(session_id, vol_num, 1)
    self._generate_chapter_outline(session_id, vol_num, 2)
    self._generate_chapter_content(session_id, vol_num, 2)
    self._generate_chapter_outline(session_id, vol_num, 3)
    self._generate_chapter_content(session_id, vol_num, 3)
    self._generate_chapter_outline(session_id, vol_num, 4)
    self._generate_chapter_content(session_id, vol_num, 4)
    self._generate_chapter_outline(session_id, vol_num, 5)
    self._generate_chapter_content(session_id, vol_num, 5)

    # --- 进入下一个会话 ---
    self._execute_volume_summary_1_session()


def _execute_volume_summary_1_session(self) -> None:
    """
    会话 9：第 1 卷总结

    输入阶段（5 步）：
    1. 定义角色
    2. 定义任务
    3. 输入小说基本设定
    4. 输入前序剧情
    5. 输入本卷所有章节正文

    输出阶段（2 步）：
    1. 剧情总结
    2. 人物总结
    """
    session_id = "volume_summary_1"
    vol_num = 1

    # --- 输入阶段（5 步）---
    self._summary_input_role(session_id, vol_num)
    self._summary_input_task(session_id, vol_num)
    self._summary_input_basic_setting(session_id)
    self._summary_input_previous_plot(session_id, vol_num)  # 无前序
    self._summary_input_completed(session_id, vol_num)  # 第 1 卷 5 章正文

    # --- 输出阶段（2 步）---
    self._generate_volume_plot_summary(session_id, vol_num)
    self._generate_volume_character_summary(session_id, vol_num)

    # --- 进入下一个会话 ---
    self._execute_volume_summary_2_session()


def _execute_volume_summary_2_session(self) -> None:
    """
    会话 10：第 2 卷总结
    """
    session_id = "volume_summary_2"
    vol_num = 2

    # --- 输入阶段（5 步）---
    self._summary_input_role(session_id, vol_num)
    self._summary_input_task(session_id, vol_num)
    self._summary_input_basic_setting(session_id)
    self._summary_input_previous_plot(session_id, vol_num)  # 包含第 1 卷总结
    self._summary_input_completed(session_id, vol_num)  # 第 2 卷 5 章正文

    # --- 输出阶段（2 步）---
    self._generate_volume_plot_summary(session_id, vol_num)
    self._generate_volume_character_summary(session_id, vol_num)

    # --- 创作完成 ---
    self._on_creation_completed()
```

---

## 输入步骤方法实现

### 基本设定会话的输入方法

```python
def _basic_input_role(self, session_id: str) -> None:
    """
    基本设定会话 - 步骤 1：定义角色

    发送给 AI 的内容：
    "你是一位专业的小说创作助手，擅长帮助作者完成小说的基本设定工作，
    包括文风分析、书名生成、故事梗概、世界观构建和人物设计。"
    """
    prompt = """你是一位专业的小说创作助手，擅长帮助作者完成小说的基本设定工作。

你的职责包括：
1. 分析并确定小说的文风设定
2. 生成吸引人的书名
3. 撰写故事梗概
4. 构建世界观和时空背景
5. 设计主要人物

请准备好协助作者完成这些基本设定工作。"""

    self._send_input_message(session_id, "basic_input_role", prompt)


def _basic_input_task(self, session_id: str) -> None:
    """
    基本设定会话 - 步骤 2：定义任务
    """
    novel_name = self.creation_task.work_data.get("novel_name", "未命名小说")
    novel_type = self.creation_task.work_data.get("novel_type", "未指定类型")

    prompt = f"""你的任务是帮助作者完成小说《{novel_name}》的基本设定。

小说类型：{novel_type}

请按照以下步骤完成基本设定：
1. 分析并确定文风设定
2. 生成 3-5 个备选书名
3. 撰写 300-500 字的故事梗概
4. 构建详细的世界观和时空背景
5. 设计主要人物（主角、配角、反派等）

请准备好开始工作。"""

    self._send_input_message(session_id, "basic_input_task", prompt)


def _basic_input_basic_setting(self, session_id: str) -> None:
    """
    基本设定会话 - 步骤 3：输入小说基本设定
    """
    work_data = self.creation_task.work_data

    sections = []

    if work_data.get("novel_type"):
        sections.append(f"小说类型：{work_data['novel_type']}")

    if work_data.get("novel_name"):
        sections.append(f"小说名称：{work_data['novel_name']}")

    if work_data.get("author_name"):
        sections.append(f"作者名：{work_data['author_name']}")

    if work_data.get("novel_content_sample"):
        sections.append(f"小说文本样例：\n{work_data['novel_content_sample']}")

    prompt = "\n\n".join([
        "=== 小说基本设定 ===",
        "",
        "\n".join(sections),
        "",
        "请仔细阅读以上基本设定信息，这是后续创作的基础。"
    ])

    self._send_input_message(session_id, "basic_input_basic_setting", prompt)


def _basic_input_previous_plot(self, session_id: str) -> None:
    """
    基本设定会话 - 步骤 4：输入前序剧情

    基本设定是第一个会话，没有前序剧情。
    """
    prompt = """=== 前序剧情 ===

这是故事的开始，没有前序剧情。
请基于基本设定开始创作。"""

    self._send_input_message(session_id, "basic_input_previous_plot", prompt)


def _basic_input_completed(self, session_id: str) -> None:
    """
    基本设定会话 - 步骤 5：输入已完成的信息

    基本设定是第一个会话，没有已完成的内容。
    """
    prompt = """=== 本次任务已完成的内容 ===

暂无已完成的内容。
这是基本设定会话的第一个步骤，后续将依次完成：
1. 文风设定
2. 书名生成
3. 故事梗概
4. 时空设定
5. 人物设定
6. 封面图片设计

请准备好开始工作。"""

    self._send_input_message(session_id, "basic_input_completed", prompt)
```

---

### 创作参考会话的输入方法

```python
def _reference_input_role(self, session_id: str, work_name: str) -> None:
    """
    创作参考会话 - 步骤 1：定义角色

    角色：文学分析师
    """
    prompt = f"""你是一位专业的文学分析师，擅长深入拆解优秀作品的写作技巧和叙事结构。

你的任务是分析参考作品《{work_name}》，提取其创作模式和技巧。

请准备好进行详细的文学分析。"""

    self._send_input_message(session_id, "reference_input_role", prompt)


def _reference_input_task(self, session_id: str, work_name: str,
                           start_chapter: int, end_chapter: int) -> None:
    """
    创作参考会话 - 步骤 2：定义任务
    """
    prompt = f"""你的任务是拆解分析参考作品《{work_name}》的第{start_chapter}-{end_chapter}章。

分析重点包括：
1. 每章的核心情节和冲突设计
2. 人物出场和塑造手法
3. 场景描写和氛围营造
4. 对话设计和节奏控制
5. 悬念设置和伏笔埋设
6. 章节结尾的钩子设计

请准备好开始分析。"""

    self._send_input_message(session_id, "reference_input_task", prompt)


def _reference_input_basic_setting(self, session_id: str) -> None:
    """
    创作参考会话 - 步骤 3：输入小说基本设定
    """
    # 复用基本设定的输入
    self._basic_input_basic_setting(session_id)


def _reference_input_previous_plot(self, session_id: str) -> None:
    """
    创作参考会话 - 步骤 4：输入前序剧情
    """
    # 参考会话不需要前序剧情
    prompt = """=== 前序剧情 ===

这是创作参考分析阶段，不需要前序剧情。
请专注于参考作品的分析。"""

    self._send_input_message(session_id, "reference_input_previous_plot", prompt)


def _reference_input_completed(self, session_id: str) -> None:
    """
    创作参考会话 - 步骤 5：输入已完成的信息
    """
    # 参考会话没有前置输出步骤
    prompt = """=== 本次任务已完成的内容 ===

暂无已完成的内容。
请开始对参考作品的拆解分析。"""

    self._send_input_message(session_id, "reference_input_completed", prompt)
```

---

### 创作公式会话的输入方法

```python
def _pattern_input_role(self, session_id: str) -> None:
    """
    创作公式会话 - 步骤 1：定义角色

    角色：创作模式分析专家
    """
    prompt = """你是一位专业的创作模式分析专家，擅长从多部优秀作品中提取共通的创作公式和技巧。

你的任务是综合分析多部参考作品的拆解分析结果，提取可复用的创作公式。

请准备好进行模式分析。"""

    self._send_input_message(session_id, "pattern_input_role", prompt)


def _pattern_input_task(self, session_id: str, start_chapter: int,
                         end_chapter: int) -> None:
    """
    创作公式会话 - 步骤 2：定义任务
    """
    prompt = f"""你的任务是综合分析多部参考作品的拆解分析结果，提取适用于第{start_chapter}-{end_chapter}章的创作公式。

分析重点包括：
1. 开篇 Hook 的设计模式
2. 节奏控制规律（多少字一个小高潮，多少字一个大高潮）
3. 人物引入的节奏和手法
4. 冲突升级的模式
5. 伏笔埋设的技巧
6. 章节结尾钩子的设计公式

请基于以下拆书分析结果进行综合提炼。"""

    self._send_input_message(session_id, "pattern_input_task", prompt)


def _pattern_input_basic_setting(self, session_id: str) -> None:
    """
    创作公式会话 - 步骤 3：输入小说基本设定
    """
    self._basic_input_basic_setting(session_id)


def _pattern_input_previous_plot(self, session_id: str) -> None:
    """
    创作公式会话 - 步骤 4：输入前序剧情
    """
    prompt = """=== 前序剧情 ===

创作公式阶段不需要前序剧情。
请专注于从拆书分析中提取创作公式。"""

    self._send_input_message(session_id, "pattern_input_previous_plot", prompt)


def _pattern_input_completed(self, session_id: str) -> None:
    """
    创作公式会话 - 步骤 5：输入已完成的信息

    包含所有拆书分析的结果
    """
    completed_steps = self.session_manager.get_completed_steps()

    sections = []

    # 收集所有拆书分析结果
    for step_id, content in completed_steps.items():
        if step_id.startswith("reference_") and content:
            work_name = step_id.replace("reference_", "").split("_")[0]
            sections.append(f"=== 《{work_name}》拆书分析 ===\n{content}")

    prompt = "\n\n".join([
        "=== 已完成的拆书分析 ===",
        "",
        "\n\n".join(sections) if sections else "暂无拆书分析结果",
        "",
        "请综合以上分析结果，提取创作公式。"
    ])

    self._send_input_message(session_id, "pattern_input_completed", prompt)
```

---

### 分卷会话的输入方法

```python
def _volume_input_role(self, session_id: str, vol_num: int) -> None:
    """
    分卷会话 - 步骤 1：定义角色

    角色：大纲规划师
    """
    prompt = f"""你是一位专业的小说大纲规划师，擅长规划整卷的故事结构和人物发展。

你的任务是为第{vol_num}卷创作详细的大纲和人物设定。

请准备好进行大纲规划。"""

    self._send_input_message(session_id, "volume_input_role", prompt)


def _volume_input_task(self, session_id: str, vol_num: int) -> None:
    """
    分卷会话 - 步骤 2：定义任务
    """
    prompt = f"""你的任务是为第{vol_num}卷创作以下内容：

1. 分卷大纲
   - 本卷主题和核心冲突
   - 本卷主要情节线（起承转合）
   - 每章的核心事件概要
   - 本卷高潮和结局设计

2. 分卷人物
   - 本卷出场人物列表
   - 每人的人物弧光
   - 人物关系变化
   - 新角色设定

请准备好开始创作。"""

    self._send_input_message(session_id, "volume_input_task", prompt)


def _volume_input_basic_setting(self, session_id: str) -> None:
    """
    分卷会话 - 步骤 3：输入小说基本设定
    """
    self._basic_input_basic_setting(session_id)


def _volume_input_previous_plot(self, session_id: str, vol_num: int) -> None:
    """
    分卷会话 - 步骤 4：输入前序剧情

    收集前 3 卷的剧情总结
    """
    completed_steps = self.session_manager.get_completed_steps()

    sections = []

    # 收集前 3 卷的剧情总结
    for i in range(vol_num - 3, vol_num):
        if i < 1:
            continue
        key = f"volume_{i}_summary_plot"
        if key in completed_steps and completed_steps[key]:
            sections.append(f"=== 第{i}卷 剧情总结 ===\n{completed_steps[key]}")

    if not sections:
        prompt = """=== 前序剧情 ===

这是第 1 卷，没有前序剧情。
请基于基本设定开始创作分卷大纲。"""
    else:
        prompt = "\n\n".join([
            "=== 前序剧情（前 3 卷总结）===",
            "",
            "\n\n".join(sections),
            "",
            "请仔细阅读以上前序剧情，确保故事连贯性。"
        ])

    self._send_input_message(session_id, "volume_input_previous_plot", prompt)


def _volume_input_completed(self, session_id: str, vol_num: int) -> None:
    """
    分卷会话 - 步骤 5：输入已完成的信息

    包含当前卷内已完成的步骤（如有）
    """
    # 分卷会话只有 2 个输出步骤，按顺序执行
    # 当执行此方法时，还没有完成任何输出步骤
    prompt = """=== 本次任务已完成的内容 ===

暂无已完成的内容。
本会话将依次完成：
1. 分卷大纲
2. 分卷人物

请准备好开始创作。"""

    self._send_input_message(session_id, "volume_input_completed", prompt)
```

---

### 章节会话的输入方法

```python
def _chapter_input_role(self, session_id: str, vol_num: int) -> None:
    """
    章节会话 - 步骤 1：定义角色

    角色：章节创作助手
    """
    prompt = f"""你是一位专业的小说章节创作助手，擅长根据大纲创作具体的章节内容。

你的任务是为第{vol_num}卷创作章节大纲和正文。

请准备好进行章节创作。"""

    self._send_input_message(session_id, "chapter_input_role", prompt)


def _chapter_input_task(self, session_id: str, vol_num: int,
                         chapters_per_volume: int) -> None:
    """
    章节会话 - 步骤 2：定义任务
    """
    prompt = f"""你的任务是为第{vol_num}卷创作第 1-{chapters_per_volume}章的内容。

对于每一章，你需要完成：
1. 章节大纲（200-300 字）
   - 本章核心事件
   - 出场人物
   - 场景设定
   - 情节发展

2. 章节正文（2000-3000 字）
   - 符合大纲要求
   - 保持文风一致
   - 情节连贯
   - 结尾设置钩子

请准备好开始创作。"""

    self._send_input_message(session_id, "chapter_input_task", prompt)


def _chapter_input_basic_setting(self, session_id: str) -> None:
    """
    章节会话 - 步骤 3：输入小说基本设定
    """
    self._basic_input_basic_setting(session_id)


def _chapter_input_previous_plot(self, session_id: str, vol_num: int) -> None:
    """
    章节会话 - 步骤 4：输入前序剧情

    包含：
    - 前 3 卷的剧情总结
    - 本卷已完成章节的剧情
    """
    completed_steps = self.session_manager.get_completed_steps()

    sections = []

    # 收集前 3 卷的剧情总结
    for i in range(max(1, vol_num - 3), vol_num):
        key = f"volume_{i}_summary_plot"
        if key in completed_steps and completed_steps[key]:
            sections.append(f"=== 第{i}卷 剧情总结 ===\n{completed_steps[key]}")

    # 收集本卷已完成章节的剧情（如有）
    for step_id, content in completed_steps.items():
        if step_id.startswith(f"chapter_{vol_num}_") and step_id.endswith("_content") and content:
            chapter_num = step_id.split("_")[2]
            sections.append(f"=== 第{vol_num}卷 第{chapter_num}章 正文（已完成） ===\n{content[:500]}...")

    if not sections:
        prompt = """=== 前序剧情 ===

这是第 1 卷第 1 章，没有前序剧情。
请基于分卷大纲开始创作。"""
    else:
        prompt = "\n\n".join([
            "=== 前序剧情 ===",
            "",
            "\n\n".join(sections),
            "",
            "请仔细阅读以上前序剧情，确保故事连贯性。"
        ])

    self._send_input_message(session_id, "chapter_input_previous_plot", prompt)


def _chapter_input_volume_info(self, session_id: str, vol_num: int) -> None:
    """
    章节会话 - 步骤 5：输入分卷大纲和分卷人物
    """
    completed_steps = self.session_manager.get_completed_steps()

    sections = []

    # 收集本卷大纲
    outline_key = f"volume_{vol_num}"
    if outline_key in completed_steps and completed_steps[outline_key]:
        sections.append(f"=== 第{vol_num}卷 大纲 ===\n{completed_steps[outline_key]}")

    # 收集本卷人物
    char_key = f"volume_{vol_num}_characters"
    if char_key in completed_steps and completed_steps[char_key]:
        sections.append(f"=== 第{vol_num}卷 人物 ===\n{completed_steps[char_key]}")

    prompt = "\n\n".join([
        "=== 分卷信息 ===",
        "",
        "\n\n".join(sections) if sections else "暂无分卷信息",
        "",
        "请仔细阅读以上分卷大纲和人物设定，作为章节创作的依据。"
    ])

    self._send_input_message(session_id, "chapter_input_volume_info", prompt)


def _chapter_input_previous_3_chapters(self, session_id: str, vol_num: int) -> None:
    """
    章节会话 - 步骤 6：上一卷最后 3 章正文内容 (new_chat=False)

    用于保持剧情连贯性，确保本卷第 1 章紧接着上一卷最后一章的剧情继续发展。

    读取上一卷最后 3 章的正文内容：
    - 第{vol_num-1}卷 第{chapters_per_volume-2}章
    - 第{vol_num-1}卷 第{chapters_per_volume-1}章
    - 第{vol_num-1}卷 第{chapters_per_volume}章

    如果是第一卷或上一卷正文尚未创作，则发送无内容的提示词。

    执行顺序：
    1. 读取上一卷最后 3 章正文内容（从磁盘文件）
    2. 拼接成上下文格式
    3. 发送给 AI（new_chat=False，保持同一会话）
    4. 回调到 _chapter_input_completed_info 继续下一步
    """
    work_id = self.main_window.creating_work_id
    steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

    # 获取上一卷最后 3 章正文内容
    previous_vol = vol_num - 1
    previous_3_chapters = []

    if previous_vol >= 1:
        # 读取上一卷最后 3 章正文内容
        start_chap = max(1, self.main_window._creation_chapters_per_volume - 2)
        for chap in range(start_chap, self.main_window._creation_chapters_per_volume + 1):
            content_file = f"{steps_dir}/chapter_{previous_vol}_{chap}_content.txt"
            content = self._read_file_safe(content_file)
            if content:
                previous_3_chapters.append(f"=== 第{previous_vol}卷 第{chap}章 正文 ===\n{content}")

    if not previous_3_chapters:
        prompt = """【上下文输入 - 上一卷最后 3 章正文】

没有上一卷的正文内容可供参考（可能是第一卷，或上一卷正文尚未创作）。
将从本卷第 1 章开始创作，请确保与前序剧情保持连贯。

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已了解。"""
    else:
        prompt = f"""【上下文输入 - 上一卷最后 3 章正文】

以下是上一卷最后 3 章的正文内容，请仔细阅读，确保本卷创作与上一卷结尾保持剧情连贯：

{'\n\n'.join(previous_3_chapters)}

【重要提示】
- 请仔细阅读并理解以上内容的剧情发展、人物对话、场景描写
- 本卷第 1 章需要紧接着上一卷最后一章的剧情继续创作，**不能有割裂感**
- **一定不要重复**上一卷结尾已经写过的剧情内容
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**

请确认你已理解上一卷结尾的剧情。"""

    self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话][上一卷最后 3 章正文 (6/7)][STEP_INPUT]: 发送输入提示词")
    self._send_context_input_with_callback(prompt, False,
        lambda: self._chapter_input_completed_info(session_id, vol_num))


def _chapter_input_completed_info(self, session_id: str, vol_num: int) -> None:
    """
    章节会话 - 步骤 7：输入已完成章节信息 (new_chat=False)

    包含本会话内已完成的章节大纲和正文

    执行顺序：
    1. 收集本卷已完成的章节大纲和正文
    2. 拼接成上下文格式
    3. 发送给 AI（new_chat=False，保持同一会话）
    4. 回调到 _chapter_start_output_phase 开始输出阶段
    """
    # 章节会话中，前面的章节可能已经完成
    completed_steps = self.session_manager.get_completed_steps()

    sections = []

    # 收集本卷已完成的章节（只收集本会话中已完成的）
    # 注意：这里只需要收集已经完成的章节，用于上下文连贯
    for i in range(1, 6):  # 假设每卷最多 5 章
        content_key = f"chapter_{vol_num}_{i}_content"
        outline_key = f"chapter_{vol_num}_{i}_outline"

        if content_key in completed_steps and completed_steps[content_key]:
            sections.append(f"=== 第{vol_num}卷 第{i}章（已完成） ===\n{completed_steps[content_key][:300]}...")

    if not sections:
        prompt = """=== 本次任务已完成的章节 ===

暂无已完成的章节。
本会话将依次创作第 1-5 章的大纲和正文。

请准备好开始创作第 1 章。"""
    else:
        prompt = "\n\n".join([
            "=== 本次任务已完成的章节 ===",
            "",
            "\n\n".join(sections),
            "",
            "请仔细阅读以上已完成的章节，确保故事连贯性和文风一致性。"
        ])

    self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话][已完成章节信息 (7/7)][STEP_INPUT]: 发送输入提示词")
    self._send_context_input_with_callback(prompt, False,
        lambda: self._chapter_start_output_phase(session_id, vol_num))
```

---

### 分卷总结会话的输入方法

```python
def _summary_input_role(self, session_id: str, vol_num: int) -> None:
    """
    分卷总结会话 - 步骤 1：定义角色

    角色：剧情总结助手
    """
    prompt = f"""你是一位专业的剧情总结助手，擅长对已完成的卷册进行剧情和人物梳理。

你的任务是对第{vol_num}卷进行剧情总结和人物状态梳理。

请准备好进行总结。"""

    self._send_input_message(session_id, "summary_input_role", prompt)


def _summary_input_task(self, session_id: str, vol_num: int) -> None:
    """
    分卷总结会话 - 步骤 2：定义任务
    """
    prompt = f"""你的任务是对第{vol_num}卷进行以下总结：

1. 剧情总结
   - 本卷核心事件梳理
   - 情节发展脉络
   - 重要转折点
   - 伏笔和悬念整理

2. 人物总结
   - 本卷出场人物状态
   - 人物关系变化
   - 人物成长弧光
   - 下卷人物发展预期

请准备好开始总结。"""

    self._send_input_message(session_id, "summary_input_task", prompt)


def _summary_input_basic_setting(self, session_id: str) -> None:
    """
    分卷总结会话 - 步骤 3：输入小说基本设定
    """
    self._basic_input_basic_setting(session_id)


def _summary_input_previous_plot(self, session_id: str, vol_num: int) -> None:
    """
    分卷总结会话 - 步骤 4：输入前序剧情

    收集前 3 卷的总结
    """
    completed_steps = self.session_manager.get_completed_steps()

    sections = []

    for i in range(max(1, vol_num - 3), vol_num):
        key = f"volume_{i}_summary_plot"
        if key in completed_steps and completed_steps[key]:
            sections.append(f"=== 第{i}卷 剧情总结 ===\n{completed_steps[key]}")

    if not sections:
        prompt = """=== 前序剧情总结 ===

这是第 1 卷总结，没有前序剧情总结。
请基于本卷内容进行总结。"""
    else:
        prompt = "\n\n".join([
            "=== 前序剧情总结（前 3 卷）===",
            "",
            "\n\n".join(sections),
            "",
            "请仔细阅读以上前序剧情总结，确保总结的连贯性。"
        ])

    self._send_input_message(session_id, "summary_input_previous_plot", prompt)


def _summary_input_completed(self, session_id: str, vol_num: int) -> None:
    """
    分卷总结会话 - 步骤 5：输入已完成的信息

    包含本卷所有章节正文
    """
    completed_steps = self.session_manager.get_completed_steps()

    sections = []

    # 收集本卷所有章节正文
    for i in range(1, 6):  # 假设每卷最多 5 章
        content_key = f"chapter_{vol_num}_{i}_content"
        if content_key in completed_steps and completed_steps[content_key]:
            sections.append(f"=== 第{vol_num}卷 第{i}章 正文 ===\n{completed_steps[content_key]}")

    prompt = "\n\n".join([
        "=== 第{vol_num}卷 所有章节正文 ===".format(vol_num=vol_num),
        "",
        "\n\n".join(sections) if sections else "暂无章节正文",
        "",
        "请仔细阅读以上所有章节正文，进行剧情和人物总结。"
    ])

    self._send_input_message(session_id, "summary_input_completed", prompt)
```

---

## 输出步骤方法实现

### 通用输出方法

```python
def _generate_step(self, session_id: str, step_id: str, step_name: str,
                   template_category: str) -> None:
    """
    通用步骤生成方法

    流程：
    1. 获取模板
    2. 构建上下文（收集占位符值）
    3. 渲染模板
    4. 调用 AI 服务
    5. 保存内容
    6. 更新 UI
    7. 通知完成
    """
    # 1. 获取模板
    template = self.template_service.get_template(template_category)

    # 2. 构建上下文
    context = self._build_step_context(step_id)

    # 3. 渲染模板
    rendered_prompt, missing = template.render_with_defaults(context, keep_missing=False)

    # 4. 调用 AI 服务（使用持久化浏览器服务）
    if hasattr(self, '_persistent_browser_service') and self._persistent_browser_service:
        ai_service = self._persistent_browser_service
    else:
        ai_service = self._create_api_service()

    # 5. 保存内容并回调
    def on_complete(content: str, success: bool):
        if success and content:
            self._save_step_content(step_id, content)
            self._save_rendered_prompt(step_id, rendered_prompt)
            self.creation_view.update_step_content(step_id, content)
            self.creation_view.set_step_status(step_id, "completed")
            self.session_manager.complete_step(step_id, content)

            # 通知下一步
            self._on_step_completed(step_id, content, success)
        else:
            self.creation_view.set_step_status(step_id, "skipped")
            self._on_step_completed(step_id, "", False)

    # 6. 开始生成
    self.creation_view.start_content_stream(step_id)
    ai_service.generate_stream(rendered_prompt, callback=on_complete)
```

---

### 基本设定会话的输出方法

```python
def _generate_style_setting(self, session_id: str) -> None:
    """
    基本设定会话 - 输出步骤 1：文风设定
    """
    self._generate_step(session_id, "style_setting", "文风设定", "文风设定")


def _generate_book_title(self, session_id: str) -> None:
    """
    基本设定会话 - 输出步骤 2：书名
    """
    self._generate_step(session_id, "book_title", "书名", "书名")


def _generate_story_summary(self, session_id: str) -> None:
    """
    基本设定会话 - 输出步骤 3：故事梗概
    """
    self._generate_step(session_id, "story_summary", "故事梗概", "故事梗概")


def _generate_worldbuilding(self, session_id: str) -> None:
    """
    基本设定会话 - 输出步骤 4：时空设定
    """
    self._generate_step(session_id, "worldbuilding", "时空设定", "时空设定")


def _generate_character_design(self, session_id: str) -> None:
    """
    基本设定会话 - 输出步骤 5：人物设定
    """
    self._generate_step(session_id, "character_design", "人物设定", "人物设定")


def _generate_cover_image(self, session_id: str) -> None:
    """
    基本设定会话 - 输出步骤 6：封面图片
    """
    # 封面图片可能使用不同的服务
    self._generate_step(session_id, "cover_image", "封面图片", "封面图片")
```

---

### 创作参考会话的输出方法

```python
def _generate_reference_analysis(self, session_id: str, work_name: str,
                                  start_chapter: int, end_chapter: int) -> None:
    """
    创作参考会话 - 输出步骤 1：拆书分析
    """
    step_id = f"reference_{work_name}_{start_chapter}_{end_chapter}"
    step_name = f"{work_name} ({start_chapter}-{end_chapter}章 拆书)"
    self._generate_step(session_id, step_id, step_name, "拆书参考")
```

---

### 创作公式会话的输出方法

```python
def _generate_pattern_analysis(self, session_id: str, start_chapter: int,
                                end_chapter: int) -> None:
    """
    创作公式会话 - 输出步骤 1：创作公式分析
    """
    step_id = f"pattern_{start_chapter}_{end_chapter}"
    step_name = f"创作公式 ({start_chapter}-{end_chapter}章)"
    self._generate_step(session_id, step_id, step_name, "创作公式")
```

---

### 分卷会话的输出方法

```python
def _generate_volume_outline(self, session_id: str, vol_num: int) -> None:
    """
    分卷会话 - 输出步骤 1：分卷大纲
    """
    step_id = f"volume_{vol_num}"
    step_name = f"第{vol_num}卷 分卷大纲"
    self._generate_step(session_id, step_id, step_name, "分卷大纲")


def _generate_volume_characters(self, session_id: str, vol_num: int) -> None:
    """
    分卷会话 - 输出步骤 2：分卷人物
    """
    step_id = f"volume_{vol_num}_characters"
    step_name = f"第{vol_num}卷 分卷人物"
    self._generate_step(session_id, step_id, step_name, "分卷人物")
```

---

### 章节会话的输出方法

```python
def _generate_chapter_outline(self, session_id: str, vol_num: int,
                               chapter_num: int) -> None:
    """
    章节会话 - 输出步骤：章节大纲
    """
    step_id = f"chapter_{vol_num}_{chapter_num}_outline"
    step_name = f"第{vol_num}卷 第{chapter_num}章 大纲"
    self._generate_step(session_id, step_id, step_name, "章节大纲")


def _generate_chapter_content(self, session_id: str, vol_num: int,
                               chapter_num: int) -> None:
    """
    章节会话 - 输出步骤：章节正文
    """
    step_id = f"chapter_{vol_num}_{chapter_num}_content"
    step_name = f"第{vol_num}卷 第{chapter_num}章 正文"
    self._generate_step(session_id, step_id, step_name, "章节正文")
```

---

### 分卷总结会话的输出方法

```python
def _generate_volume_plot_summary(self, session_id: str, vol_num: int) -> None:
    """
    分卷总结会话 - 输出步骤 1：剧情总结
    """
    step_id = f"volume_{vol_num}_summary_plot"
    step_name = f"第{vol_num}卷 剧情总结"
    self._generate_step(session_id, step_id, step_name, "分卷剧情总结")


def _generate_volume_character_summary(self, session_id: str, vol_num: int) -> None:
    """
    分卷总结会话 - 输出步骤 2：人物总结
    """
    step_id = f"volume_{vol_num}_summary_character"
    step_name = f"第{vol_num}卷 人物总结"
    self._generate_step(session_id, step_id, step_name, "分卷人物总结")
```

---

## 步骤级别文件检查设计

### 核心原则

**每个步骤在执行前都检查自己的文件是否存在：**
1. 输出步骤执行前检查对应的磁盘文件
2. 若文件存在且内容非空，则跳过该步骤，直接回调下一步
3. 若文件不存在或内容为空，则执行 AI 生成
4. 不依赖任何内存状态变量判断步骤完成状态

### 检查逻辑

```python
def _execute_output_step_with_callback(self, step_id: str, step_name: str, file_path: str,
                                        prompt: str, new_chat: bool, next_method) -> None:
    """执行输出步骤前检查文件是否存在"""

    # 步骤 1: 检查文件是否已存在
    if os.path.exists(file_path):
        content = self._read_file_safe(file_path)
        if content and len(content.strip()) > 0:
            # 文件存在且内容非空，跳过
            self.logger.info(f"[STEP_LOADED] {step_name}: 从磁盘加载完成 - {len(content)}字")
            self.logger.info(f"[STEP_SKIPPED] {step_name}: 已存在，跳过")
            next_method()  # 直接回调下一步
            return

    # 步骤 2: 文件不存在或内容为空，执行 AI 生成
    self.logger.info(f"[STEP_GENERATING] {step_name}: AI 生成中...")
    # ... AI 生成逻辑
```

### 日志输出示例

```
[基本设定会话 (1/4)] [文风设定 (1/6)] [STEP_CHECK]: 检查文件 steps/style_setting.txt - 不存在
[基本设定会话 (1/4)] [文风设定 (1/6)] [STEP_GENERATING]: AI 生成中...
[基本设定会话 (1/4)] [文风设定 (1/6)] [STEP_INPUT]: 输入提示词:
    ---
    你是一位专业的小说创作者...
    ---
[基本设定会话 (1/4)] [文风设定 (1/6)] [STEP_OUTPUT]: AI 生成完成 (156 字)
    ---
    本文采用第三人称全知视角叙述...
    ---
[基本设定会话 (1/4)] [文风设定 (1/6)] [STEP_SAVED]: 已保存到 steps/style_setting.txt

[基本设定会话 (1/4)] [书名 (2/6)] [STEP_CHECK]: 检查文件 steps/book_title.txt - 已存在 (12 字)
[基本设定会话 (1/4)] [书名 (2/6)] [STEP_LOADED]: 从磁盘加载完成
[基本设定会话 (1/4)] [书名 (2/6)] [STEP_SKIPPED]: 已存在，跳过
```

### 好处

| 好处 | 说明 |
|------|------|
| **最小粒度检查** | 每个步骤独立检查，不依赖会话级别的状态判断 |
| **自动跳过已完成** | 文件存在即跳过，无需手动标记 |
| **支持断点续作** | 任意步骤完成后停止，下次从第一个未完成步骤继续 |
| **无状态管理** | 不依赖内存变量，所有状态由磁盘文件决定 |
| **日志清晰** | 每个步骤的执行/跳过状态都有日志记录 |

---

## 步骤完成回调

```python
def _on_step_completed(self, step_id: str, content: str, success: bool) -> None:
    """
    步骤完成回调

    由于所有步骤都是硬编码顺序执行，不需要在这里处理下一步
    每一步完成后，调用栈会自动继续执行下一步
    """
    self.logger.info(f"[STEP_COMPLETED] {step_id}: success={success}")

    # 不需要查找下一步，硬编码的流程会在调用栈中自动继续
    # 只需要更新状态即可
```

---

## 步骤上下文构建

```python
def _build_step_context(self, step_id: str) -> Dict[str, str]:
    """
    构建步骤的上下文（占位符值）

    硬编码每个步骤可以使用的占位符
    """
    completed_steps = self.session_manager.get_completed_steps()
    context = {}

    # === 基本信息类占位符 ===
    if self.creation_task.work_data.get("novel_type"):
        context["novel_type"] = self.creation_task.work_data["novel_type"]

    if self.creation_task.work_data.get("novel_name"):
        context["novel_name"] = self.creation_task.work_data["novel_name"]

    if self.creation_task.work_data.get("author_name"):
        context["author_name"] = self.creation_task.work_data["author_name"]

    # 从已完成步骤中收集占位符
    if "style_setting" in completed_steps:
        context["literary_style"] = completed_steps["style_setting"]

    if "story_summary" in completed_steps:
        context["story_summary"] = completed_steps["story_summary"]

    if "worldbuilding" in completed_steps:
        context["worldbuilding"] = completed_steps["worldbuilding"]
        context["power_system"] = completed_steps["worldbuilding"]  # 力量体系在世界观中

    if "character_design" in completed_steps:
        context["characters"] = completed_steps["character_design"]

    if "book_title" in completed_steps:
        context["book_title"] = completed_steps["book_title"]

    # === 拆书参考占位符 ===
    for step_key, content in completed_steps.items():
        if step_key.startswith("reference_"):
            context[f"book_reference_{step_key}"] = content

    # === 创作公式占位符 ===
    if "pattern_analysis" in completed_steps:
        context["pattern_analysis"] = completed_steps["pattern_analysis"]

    # === 分卷相关占位符 ===
    # 动态收集已完成的分卷大纲和人物
    for step_key, content in completed_steps.items():
        if step_key.startswith("volume_") and not step_key.endswith("_characters"):
            if not step_key.endswith("_summary_plot") and not step_key.endswith("_summary_character"):
                context[f"volume_outline_{step_key}"] = content
        if step_key.endswith("_characters"):
            if not step_key.endswith("_summary_character"):
                context[f"volume_characters_{step_key}"] = content

    # === 章节相关占位符 ===
    for step_key, content in completed_steps.items():
        if step_key.endswith("_outline"):
            context[f"chapter_outline_{step_key}"] = content
        if step_key.endswith("_content"):
            context[f"chapter_content_{step_key}"] = content

    # === 分卷总结占位符 ===
    for step_key, content in completed_steps.items():
        if step_key.endswith("_summary_plot"):
            context[f"volume_plot_summary_{step_key}"] = content
        if step_key.endswith("_summary_character"):
            context[f"volume_character_summary_{step_key}"] = content

    return context
```

---

## 总结

**硬编码方案的核心优势**：

| 优势 | 说明 |
|------|------|
| **流程清晰** | 每个会话、每个步骤都在代码中明确写出 |
| **易于调试** | 出问题时可以直接定位到具体方法 |
| **无竞态条件** | 没有异步回调链，不会重复执行 |
| **易于修改** | 修改某个步骤只需改对应的方法 |
| **类型安全** | 每个方法的参数明确，IDE 可以提示 |

**代码结构**：
- 10 个会话方法（每个会话一个）
- 30+ 个输入方法（每个输入类型一个）
- 15+ 个输出方法（每个输出类型一个）
- 1 个通用 `_generate_step()` 方法
- 1 个通用 `_build_step_context()` 方法

**总计约 60 个方法**，但每个方法都很简单，职责单一。
