# 番茄创建新章节流程

## 定时发布时间生成规则

### 用户输入参数

| 参数 | 说明 | 示例 |
|------|------|------|
| start_date | 开始发布日期 | 2026-04-11 |
| start_time | 每日开始时间 | 21:00 |
| end_time | 每日结束时间 | 23:00 |
| daily_count | 每天发布章节数 | 2 |
| start_chapter | 起始章节号 | 1 |
| end_chapter | 结束章节号 | 10 |

### 核心约束

1. **发布时间必须比当前时间晚1小时以上**
   - 计算 `min_publish_time = now + timedelta(hours=1)`
   - 如果计算的发布时间早于此时间，自动顺延到满足条件的时间

2. **每天发布章节数限制**
   - 当 `chapters_today >= daily_count` 时，自动切换到下一天
   - 重置当天计数，重新开始

3. **时间范围限制**
   - 如果计算的时间超过 `end_time`，自动切换到下一天
   - 从下一天的 `start_time` 开始重新计算

4. **保证先后顺序**
   - 大章节时间一定在后面
   - 通过 `current_publish_time` 递增实现

### 生成算法

```
interval = (end_time - start_time) / daily_count  # 每日时间间隔
min_interval = interval / 2  # 最小间隔

current_publish_time = start_date + start_time
chapters_today = 0

for each chapter:
    if chapters_today >= daily_count:
        current_day += 1
        chapters_today = 0
        current_publish_time = current_day + start_time + random(0, interval)

    random_offset = random(0, interval)
    publish_time = current_publish_time + random_offset

    if publish_time > end_time of current day:
        current_day += 1
        chapters_today = 0
        publish_time = current_day + start_time + random(0, interval)

    if publish_time < min_publish_time:
        publish_time = min_publish_time + random(0, 10)

    chapters_today += 1
    current_publish_time = publish_time + min_interval + random(0, interval)
```

### 随机性保证

- 每个章节的实际发布时间 = 基础时间 + `random(0, interval)` 分钟
- 不再是均匀的整点分布，而是任意分钟
- 但仍然保证大章节时间在后面（因为 `current_publish_time` 每次迭代都增加）

### 示例

**输入：**
- start_date = 2026-04-11
- start_time = 21:00
- end_time = 23:00
- daily_count = 2
- 章节范围：1-10（共10章）

**生成结果（示例）：**
```
2026-04-11 21:23 - 第1章
2026-04-11 22:45 - 第2章
2026-04-12 21:15 - 第3章
2026-04-12 22:38 - 第4章
2026-04-13 21:05 - 第5章
...
```

### 代码位置

`src/gui/views/publishing_view.py` - `_on_generate_schedule()` 方法

---

## 创建新章节页面
新建一个page，url格式：
https://fanqienovel.com/main/writer/{书本id}/publish/?enter_from=newchapter

样例：
https://fanqienovel.com/main/writer/7605250539030318105/publish/?enter_from=newchapter

#### 输入章节号
在如下input里输入章节号：
```html
<div class="serial-editor-title-left none">
    <span>第</span>
        <span class="left-input">
            <input type="text" class="serial-input byte-input byte-input-size-default" value="">
        </span>
    <span>章</span>
</div>
```

#### 输入章节标题
在如下input里输入章标题：
```html
<div class="serial-editor-title-right">
    <div class="serial-editor-input-hint input">
        <input placeholder="请输入标题" class="serial-input serial-editor-input-hint-area byte-input byte-input-size-default" value="">
    </div>
</div>
```

#### 输入章节正文
在如下div中药键入章节正文。

未写入任何段落状态：
```html
<div contenteditable="true" translate="no" class="ProseMirror" spellcheck="false">
    <p>
        <span class="syl-placeholder ProseMirror-widget" style="cursor: text; text-indent: initial; pointer-events: none; -webkit-user-select: none; user-select: none; position: absolute;" ignoreel="true" contenteditable="false">请输入正文，或通过输入「空格」唤起AI写作小助手</span>
        <img class="ProseMirror-separator" alt="">
        <br class="ProseMirror-trailingBreak">
    </p>
</div>
```

写入段落状态：
```html
<div contenteditable="true" translate="no" class="ProseMirror" spellcheck="false">
    <p>青石镇广场上，搭起了一座三尺高的石台。</p>
    <p>台上放着一块人头大小的青灰色石头，表面光滑如镜，在春日的阳光下泛着幽幽冷光。那是测灵石，据说是仙门赐下的宝物，能测出一个人的灵根资质。</p>
    <p>台下人头攒动，全镇男女老少几乎都来了。</p>
    <p>陆尘排在队伍中间，手心全是汗。</p>
    <p>
        <br class="ProseMirror-trailingBreak">
    </p>
</div>
```
每个段落用<p>标签包裹，然后插入<div>里。


#### 点击下一步
点击下一步按钮：
```html
<div class="publish-header">
    <div class="publish-header-right">
        <button class="arco-btn arco-btn-secondary arco-btn-size-default arco-btn-shape-square publish-button auto-editor-next btn-primary-variant" type="button">
            <span>下一步</span>
        </button>
    </div>
</div>
```

#### 检查是否有错别字
检查是否会弹出如下提示框，如果有，则点击提交。
```html
<div role="dialog" aria-modal="true" aria-labelledby="arco-dialog-5" class="arco-modal auto-editor-error-modal publish-modal-confirm global-confirm-modal zoomModal-appear-done zoomModal-enter-done" style="width: 428px;">
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
    <div data-focus-lock-disabled="false" tabindex="-1">
        <div class="arco-modal-header">
            <div class="arco-modal-title" id="arco-dialog-5">
                <span>发布提示</span>
            </div>
        </div>
        <div class="arco-modal-content">检测到你还有错别字未修改，是否确定提交？</div>
        <div class="arco-modal-footer">
            <button class="arco-btn arco-btn-secondary arco-btn-size-default arco-btn-shape-square" type="button">
                <span>取消</span>
            </button>
            <button class="arco-btn arco-btn-primary arco-btn-size-default arco-btn-shape-square" type="button">
                <span>提交</span>
            </button>
        </div>
        <span class="arco-icon-hover arco-modal-close-icon" tabindex="-1" role="button" aria-label="Close">
            <svg class="serial-icon serial-icon-close " width="1em" height="1em" viewBox="0 0 32 32" fill="currentColor"
                xmlns="http://www.w3.org/2000/svg">
                <path d="M5.29289 6.70711C4.90237 6.31658 4.90237 5.68342 5.29289 5.29289C5.68342 4.90237 6.31658 4.90237 6.70711 5.29289L16 14.5858L25.2929 5.29289C25.6834 4.90237 26.3166 4.90237 26.7071 5.29289C27.0976 5.68342 27.0976 6.31658 26.7071 6.70711L17.4142 16L26.7071 25.2929C27.0976 25.6834 27.0976 26.3166 26.7071 26.7071C26.3166 27.0976 25.6834 27.0976 25.2929 26.7071L16 17.4142L6.70711 26.7071C6.31658 27.0976 5.68342 27.0976 5.29289 26.7071C4.90237 26.3166 4.90237 25.6834 5.29289 25.2929L14.5858 16L5.29289 6.70711Z"></path>
            </svg>
        </span>
    </div>
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
</div>
```
注意，上述错别字提示框，可能有，可能没有。



#### 检查非章节内容使用作者有话说
检查是否会弹出如下提示框，如果有，则点击提交：
```html
<div role="dialog" aria-modal="true" class="arco-modal auto-editor-error-modal publish-modal-confirm global-confirm-modal zoomModal-appear-done zoomModal-enter-done" style="width: 428px;">
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
    <div data-focus-lock-disabled="false" tabindex="-1">
        <div class="arco-modal-content">非章节内容请使用“作者有话说”功能，章末附带无关内容可能会影响章节审核结果。是否确定提交？</div>
        <div class="arco-modal-footer">
            <button class="arco-btn arco-btn-secondary arco-btn-size-default arco-btn-shape-square" type="button">
                <span>取消</span>
            </button>
            <button class="arco-btn arco-btn-primary arco-btn-size-default arco-btn-shape-square" type="button">
                <span>提交</span>
            </button>
        </div>
        <span class="arco-icon-hover arco-modal-close-icon" tabindex="-1" role="button" aria-label="Close">
            <svg class="serial-icon serial-icon-close " width="1em" height="1em" viewBox="0 0 32 32" fill="currentColor"
                xmlns="http://www.w3.org/2000/svg">
                <path d="M5.29289 6.70711C4.90237 6.31658 4.90237 5.68342 5.29289 5.29289C5.68342 4.90237 6.31658 4.90237 6.70711 5.29289L16 14.5858L25.2929 5.29289C25.6834 4.90237 26.3166 4.90237 26.7071 5.29289C27.0976 5.68342 27.0976 6.31658 26.7071 6.70711L17.4142 16L26.7071 25.2929C27.0976 25.6834 27.0976 26.3166 26.7071 26.7071C26.3166 27.0976 25.6834 27.0976 25.2929 26.7071L16 17.4142L6.70711 26.7071C6.31658 27.0976 5.68342 27.0976 5.29289 26.7071C4.90237 26.3166 4.90237 25.6834 5.29289 25.2929L14.5858 16L5.29289 6.70711Z"></path>
            </svg>
        </span>
    </div>
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
</div>
```
注意，上述提示框，可能有，可能没有。



#### 检查是否进行内容风险检测
检查是否会存在如下提示框，如果有，则点击提交：
```html
<div role="dialog" aria-modal="true" aria-labelledby="arco-dialog-6" class="arco-modal undefined global-confirm-modal zoomModal-appear-done zoomModal-enter-done" style="transform-origin: 378px 188.4px;">
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
    <div data-focus-lock-disabled="false" tabindex="-1">
        <div class="arco-modal-header">
            <div class="arco-modal-title" id="arco-dialog-6">
                <span>是否进行内容风险检测？</span>
            </div>
        </div>
        <div class="arco-modal-content">开启后，小助手将为你标注当前章节可能存在的风险内容。请确认是否已完成当前章节编辑，需开启风险提示功能并消耗此功能使用次数？</div>
        <div class="arco-modal-footer">
            <button class="arco-btn arco-btn-secondary arco-btn-size-default arco-btn-shape-square" type="button">
                <span>取消</span>
            </button>
            <button class="arco-btn arco-btn-primary arco-btn-size-default arco-btn-shape-square" type="button">
                <span>确定</span>
            </button>
        </div>
        <span class="arco-icon-hover arco-modal-close-icon" tabindex="-1" role="button" aria-label="Close">
            <svg class="serial-icon serial-icon-close " width="1em" height="1em" viewBox="0 0 32 32" fill="currentColor"
                xmlns="http://www.w3.org/2000/svg">
                <path d="M5.29289 6.70711C4.90237 6.31658 4.90237 5.68342 5.29289 5.29289C5.68342 4.90237 6.31658 4.90237 6.70711 5.29289L16 14.5858L25.2929 5.29289C25.6834 4.90237 26.3166 4.90237 26.7071 5.29289C27.0976 5.68342 27.0976 6.31658 26.7071 6.70711L17.4142 16L26.7071 25.2929C27.0976 25.6834 27.0976 26.3166 26.7071 26.7071C26.3166 27.0976 25.6834 27.0976 25.2929 26.7071L16 17.4142L6.70711 26.7071C6.31658 27.0976 5.68342 27.0976 5.29289 26.7071C4.90237 26.3166 4.90237 25.6834 5.29289 25.2929L14.5858 16L5.29289 6.70711Z"></path>
            </svg>
        </span>
    </div>
    <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
</div>
```
注意，上述提示框，可能有，可能没有。


**注意**
上述的3个提示框 检查是否有错别字、检查非章节内容使用作者有话说、检查是否进行内容风险检测 都是可能有可能没有，因此，每个提示框的超时时间不要等待太久。
可以在一个循环里面，逐个检查上述3个提示框，如果有则进行点击，如果等待1秒超时，则进行下一个提示框检查，一直循环到下面的 发布设置 提示框出现，就结束循环。

#### 进行发布设置
检查是否有发布设置提示框出现：
```html
<div role="dialog" aria-modal="true" aria-labelledby="arco-dialog-4" class="arco-modal publish-confirm-container-new zoomModal-appear-done zoomModal-enter-done">
    <div class="arco-modal-header">
        <div class="arco-modal-title" id="arco-dialog-4">发布设置</div>
    </div>
    <div class="arco-modal-content">
        <div>
            <div class="publish-confirm-card">
                <div class="arco-alert arco-alert-info publish-confirm-audit-alert" role="alert">
                    <div class="arco-alert-icon-wrapper">
                        <svg class="serial-icon serial-icon-info-circle-fill " width="1em" height="1em" viewBox="0 0 32 32" fill="currentColor"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M16 29C23.1797 29 29 23.1797 29 16C29 8.8203 23.1797 3 16 3C8.8203 3 3 8.8203 3 16C3 23.1797 8.8203 29 16 29ZM18 10C18 11.1046 17.1046 12 16 12C14.8954 12 14 11.1046 14 10C14 8.89543 14.8954 8 16 8C17.1046 8 18 8.89543 18 10ZM13 24V22H14.5V16H13V14H17.5V22H19V24H13Z"></path>
                        </svg>
                    </div>
                    <div class="arco-alert-content-wrapper">
                        <div class="arco-alert-content">番茄审核工作时间是7:00-24:00，夜间发文会卡在审核中状态（无法修改和删除章节）直至次日早上7-9点，建议您在工作时间发布章节。</div>
                    </div>
                </div>
                <div class="card-content-line">
                    <div class="card-content-line-label">分卷</div>
                    <div class="card-content-line-control">第一卷：默认</div>
                </div>
                <div class="card-content-line">
                    <div class="card-content-line-label">章节</div>
                    <div class="card-content-line-control">
                        <span>第81章 凡骨</span>
                    </div>
                </div>
                <div class="card-content-line">
                    <div class="card-content-line-label">上次提交</div>
                    <div class="card-content-line-control">
                        <span>第一卷
                            <span style="margin-left: 12px;">第45章 暗室惊闻天机阁在找我</span>
                        </span>
                    </div>
                </div>
                <div class="card-content-line">
                    <div class="card-content-line-label">
                        <span class="serial-flex-center">是否使用AI 
                            <svg class="serial-icon serial-icon-general_info " width="1em" height="1em" viewBox="0 0 32 32" fill="currentColor"
                                xmlns="http://www.w3.org/2000/svg" style="cursor: pointer;">
                                <path d="M16 14C16.5523 14 17 14.4477 17 15V21C17 21.5523 16.5523 22 16 22 15.4477 22 15 21.5523 15 21V15C15 14.4477 15.4477 14 16 14zM16 12C16.8284 12 17.5 11.3284 17.5 10.5 17.5 9.67157 16.8284 9 16 9 15.1716 9 14.5 9.67157 14.5 10.5 14.5 11.3284 15.1716 12 16 12z"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M3 16C3 8.8203 8.8203 3 16 3C23.1797 3 29 8.8203 29 16C29 23.1797 23.1797 29 16 29C8.8203 29 3 23.1797 3 16ZM16 5C9.92487 5 5 9.92487 5 16C5 22.0751 9.92487 27 16 27C22.0751 27 27 22.0751 27 16C27 9.92487 22.0751 5 16 5Z"></path>
                            </svg>
                        </span>
                    </div>
                    <div class="card-content-line-control">
                        <div class="arco-radio-group arco-radio-size-default arco-radio-mode-outline" role="radiogroup">
                            <label class="arco-radio">
                                <input type="radio" value="1">
                                    <span class="arco-icon-hover arco-radio-icon-hover arco-radio-mask-wrapper">
                                        <div class="arco-radio-mask"></div>
                                    </span>
                                    <span class="arco-radio-text">是</span>
                                </label>
                                <label class="arco-radio">
                                    <input type="radio" value="2">
                                        <span class="arco-icon-hover arco-radio-icon-hover arco-radio-mask-wrapper">
                                            <div class="arco-radio-mask"></div>
                                        </span>
                                        <span class="arco-radio-text">否</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="publish-confirm-card">
                        <div class="card-content-line">
                            <div class="card-content-line-label">定时发布
                                <svg class="serial-icon serial-icon-general_info " width="1em" height="1em" viewBox="0 0 32 32" fill="currentColor"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M16 14C16.5523 14 17 14.4477 17 15V21C17 21.5523 16.5523 22 16 22 15.4477 22 15 21.5523 15 21V15C15 14.4477 15.4477 14 16 14zM16 12C16.8284 12 17.5 11.3284 17.5 10.5 17.5 9.67157 16.8284 9 16 9 15.1716 9 14.5 9.67157 14.5 10.5 14.5 11.3284 15.1716 12 16 12z"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M3 16C3 8.8203 8.8203 3 16 3C23.1797 3 29 8.8203 29 16C29 23.1797 23.1797 29 16 29C8.8203 29 3 23.1797 3 16ZM16 5C9.92487 5 5 9.92487 5 16C5 22.0751 9.92487 27 16 27C22.0751 27 27 22.0751 27 16C27 9.92487 22.0751 5 16 5Z"></path>
                                </svg>
                            </div>
                            <div class="card-content-line-control">
                                <div>
                                    <button role="switch" aria-checked="false" class="arco-switch arco-switch-type-circle" type="button">
                                        <div class="arco-switch-dot"></div>
                                    </button>
                                    <div class="publish-confirm-timed-help">关闭定时发布后，章节在通过审核后会立即发布</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="arco-modal-footer">
                <button class="arco-btn arco-btn-secondary arco-btn-size-default arco-btn-shape-square" type="button">
                    <span>取消</span>
                </button>
                <button class="arco-btn arco-btn-primary arco-btn-size-default arco-btn-shape-square" type="button">
                    <span>确认发布</span>
                </button>
            </div>
            <span class="arco-icon-hover arco-modal-close-icon" tabindex="-1" role="button" aria-label="Close">
                <svg class="serial-icon serial-icon-close " width="1em" height="1em" viewBox="0 0 32 32" fill="currentColor"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M5.29289 6.70711C4.90237 6.31658 4.90237 5.68342 5.29289 5.29289C5.68342 4.90237 6.31658 4.90237 6.70711 5.29289L16 14.5858L25.2929 5.29289C25.6834 4.90237 26.3166 4.90237 26.7071 5.29289C27.0976 5.68342 27.0976 6.31658 26.7071 6.70711L17.4142 16L26.7071 25.2929C27.0976 25.6834 27.0976 26.3166 26.7071 26.7071C26.3166 27.0976 25.6834 27.0976 25.2929 26.7071L16 17.4142L6.70711 26.7071C6.31658 27.0976 5.68342 27.0976 5.29289 26.7071C4.90237 26.3166 4.90237 25.6834 5.29289 25.2929L14.5858 16L5.29289 6.70711Z"></path>
                </svg>
            </span>
        </div>
```

#### 选择是否使用AI
点击下面的第二个label，选择否：
```html
<div class="card-content-line-control">
    <div class="arco-radio-group arco-radio-size-default arco-radio-mode-outline" role="radiogroup">
        <label class="arco-radio">
        <input type="radio" value="1">
            <span class="arco-icon-hover arco-radio-icon-hover arco-radio-mask-wrapper">
                <div class="arco-radio-mask"></div>
            </span>
            <span class="arco-radio-text">是</span>
        </label>
        <label class="arco-radio">
            <input type="radio" value="2">
                <span class="arco-icon-hover arco-radio-icon-hover arco-radio-mask-wrapper">
                    <div class="arco-radio-mask"></div>
                </span>
                <span class="arco-radio-text">否</span>
        </label>
    </div>
</div>
```

#### 选择定时发布
如果用户选择了定时发布，才需要走如下流程，如果没有选择定时发布，则直接到下一步点击发布按钮。
如果用户选择了定时发布，还需要校验是否传入了发布日期和发布时间，如果没有，则返回错误。

点击下面的button，选择定时发布：
```html
<div class="publish-confirm-card">
    <div class="card-content-line">
        <div class="card-content-line-label">定时发布
            <svg class="serial-icon serial-icon-general_info " width="1em" height="1em" viewBox="0 0 32 32" fill="currentColor"
                xmlns="http://www.w3.org/2000/svg">
                <path d="M16 14C16.5523 14 17 14.4477 17 15V21C17 21.5523 16.5523 22 16 22 15.4477 22 15 21.5523 15 21V15C15 14.4477 15.4477 14 16 14zM16 12C16.8284 12 17.5 11.3284 17.5 10.5 17.5 9.67157 16.8284 9 16 9 15.1716 9 14.5 9.67157 14.5 10.5 14.5 11.3284 15.1716 12 16 12z"></path>
                <path fill-rule="evenodd" clip-rule="evenodd" d="M3 16C3 8.8203 8.8203 3 16 3C23.1797 3 29 8.8203 29 16C29 23.1797 23.1797 29 16 29C8.8203 29 3 23.1797 3 16ZM16 5C9.92487 5 5 9.92487 5 16C5 22.0751 9.92487 27 16 27C22.0751 27 27 22.0751 27 16C27 9.92487 22.0751 5 16 5Z"></path>
            </svg>
        </div>
        <div class="card-content-line-control">
            <div>
                <button role="switch" aria-checked="false" class="arco-switch arco-switch-type-circle" type="button">
                    <div class="arco-switch-dot"></div>
                </button>
                <div class="publish-confirm-timed-help">关闭定时发布后，章节在通过审核后会立即发布</div>
            </div>
        </div>
    </div>
</div>
```

**选择发布日期**
为如下input设置发布日期值（格式：yyyy-MM-dd）：
```html
<div class="arco-picker-input"><input placeholder="请选择日期" class="arco-picker-start-time" value="2026-04-09"></div>
```

**选择发布时间**
为如下input设置发布时间值（格式：HH:SS）：
```html
<div class="arco-picker-input"><input placeholder="请选择时间" class="arco-picker-start-time" value="06:16"></div>
```

#### 点击确认发布
点击确认发布按钮：
```html
<div class="arco-modal-footer">
    <button class="arco-btn arco-btn-secondary arco-btn-size-default arco-btn-shape-square" type="button">
        <span>取消</span>
    </button>
    <button class="arco-btn arco-btn-primary arco-btn-size-default arco-btn-shape-square" type="button">
        <span>确认发布</span>
    </button>
</div>
```

#### 等待 publish 接口完成
接口url：
https://fanqienovel.com/api/author/publish_article/v0/?msToken=

成功响应样例：
```json
{
    "code": 0,
    "data": {
        "item_id": "7626727468778422808",
        "tips": ""
    },
    "log_id": "20260409200702BC9A31DE6465BC8AEC02",
    "message": "success"
}
```

如果请求失败了，需要进行3次重试，如果重试失败了，将错误信息展示在界面上。