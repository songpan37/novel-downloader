# 发布队列 UI 修改方案

## 一、现状梳理

### 1.1 第3步当前结构

```
第3步: 发布范围
├── 章节发布状态 (GroupBox)
│   ├── 发布目录: X 章         # publish目录中的章节文件数
│   ├── 番茄已发布: X 章      # 从番茄平台获取的已发布章节数
│   ├── 将新发布: X 章        # 将要新发布的章节数
│   └── 将更新: X 章          # 将要更新的章节数
│
├── 发布章节范围 (GroupBox)
│   ├── 从第 [输入框] 章 到 第 [输入框] 章
│   ├── [按steps目录最新章节设置] 按钮
│   └── 标签: "范围内共 X 章，其中更新 X 章，发布新章节 X 章"
│
├── 章节划分方式 (GroupBox)
│   ├── ○ 按原始章节     ○ 按自定义字数重新划分
│   │                    ├── [字数输入框] 字/章
│   │                    └── [开始重新划分章节] 按钮
│   └── 提示文字
│
└── 预览标签
```

### 1.2 关键数据流

| 数据 | 来源 | 用途 |
|------|------|------|
| steps目录章节数 | steps/chapter_*_content.txt 文件数 | 原始章节总数 |
| publish目录章节数 | publish/第*章 *.txt 文件数 | 待发布队列 |
| 番茄已发布章节数 | 从番茄平台API获取 | 已有发布记录 |
| 已进入发布队列的章节数 | **需要新增持久化存储** | 下次进入时显示 |

### 1.3 章节划分流程

**按原始章节发布时：**
- 读取 steps/chapter_*_content.txt 文件
- 复制到 publish/第*章 *.txt
- 不涉及章节重划分

**按自定义字数重新划分时：**
- 读取 steps/chapter_*_content.txt 文件内容
- 按指定字数拆分成新章节
- 生成新标题
- 保存到 publish/第*章 *.txt
- 完成后 `_restructure_complete = True`

---

## 二、用户需求理解

### 2.1 名称修改

| 当前位置 | 原名称 | 新名称 |
|----------|--------|--------|
| 第3步大标题 | 发布范围 | **发布队列** |
| 章节状态GroupBox | 章节发布状态 | **发布队列状态** |
| 番茄已发布标签 | 番茄已发布 | **已进入发布队列** |
| 范围标签 | 将发布第x章到第y章 | **待进入发布队列的章节：x-y章** |
| 设置按钮 | 按steps目录最新章节设置 | **选择全部章节** |

### 2.2 数据定义修改

**"已进入发布队列的章节数" 新定义：**
- 指从 steps 目录转换到 publish 目录的章节数
- 不是番茄平台的已发布章节数
- 每次章节划分完成后需要更新记录

**需要移除的标签：**
- "将新发布" - 不再需要
- "将更新" - 不再需要

**新增 Work 模型字段：**
```python
# 在 Work 模型中添加
steps_to_publish_converted_count: int = 0  # steps已转换到publish的章节数
```

### 2.3 章节划分完成后的记录逻辑

每次章节划分完成后，需要：
1. 计算 steps 目录下已完成转换的原始章节数（即 end_chapter_input 的值）
2. 将其保存到 Work 模型的 `steps_to_publish_converted_count` 字段
3. 下次进入发布界面时，从这里读取并显示

**示例：**
- steps 目录已有 30 章原始内容
- 用户选择"按原始章节"发布 1-30 章
- 点击下一步，30 章全部转换到 publish 目录
- 保存 `steps_to_publish_converted_count = 30`

下次进入：
- 本地总章节：30（steps目录）
- 已进入发布队列：30（从Work模型读取）
- 待进入发布队列：0（如果全部已转换）

---

## 三、UI 修改方案

### 3.1 第3步标题修改

```python
# 步骤名称数组
steps = ["选择平台", "选择作品", "发布队列", "选择账号", "发布策略", "汇总发布"]
```

### 3.2 "发布队列状态" GroupBox 修改

**修改前：**
```
发布目录: X 章
番茄已发布: X 章
将新发布: X 章
将更新: X 章
```

**修改后：**
```
本地总章节: X 章              # steps目录的原始章节数
已进入发布队列: X 章          # 从Work模型读取的已转换数
待进入发布队列: X 章          # 计算值 = 本地总章节 - 已进入发布队列
```

### 3.3 "发布队列范围" GroupBox 修改

**布局保持不变，仅修改文案：**

```
发布队列范围

从第 [输入框] 章 到 第 [输入框] 章
[选择全部章节] 按钮

标签: "待进入发布队列的章节：x-y章"
```

### 3.4 "章节划分方式" GroupBox 修改

逻辑不变，仅在划分完成后添加记录逻辑。

### 3.5 下一步按钮行为修改

**修改前：**
- 必须先完成章节划分（点击"开始重新划分章节"）
- 才能点击下一步

**修改后：**
- 可以直接点击下一步（不强制要求先划分）
- 如果选择"按原始章节"发布，点击下一步时：
  1. 执行章节转换（steps → publish）
  2. 记录 `steps_to_publish_converted_count = end_chapter`
- 如果选择"按自定义字数重新划分"且已完成（`_restructure_complete = True`）：
  1. 记录 `steps_to_publish_converted_count = end_chapter`
  2. 执行发布

---

## 四、Work 模型修改

### 4.1 新增字段

在 `src/models/work.py` 的 `Work` 类中添加：

```python
@dataclass
class Work:
    # ... existing fields ...

    # Publishing queue tracking (新增)
    steps_to_publish_converted_count: int = 0  # steps已转换到publish的章节数
```

### 4.2 持久化

`to_dict()` 和 `from_dict()` 方法需要处理新字段。

---

## 五、代码修改点

### 5.1 publishing_view.py

| 位置 | 修改内容 |
|------|----------|
| 步骤名称数组 | "发布范围" → "发布队列" |
| `_update_strategy_range_status()` | 修改标签名称和计算逻辑 |
| `_update_strategy_range_preview()` | 修改预览标签文案 |
| `stage2_group` | QGroupBox标题 "发布范围" → "发布队列范围" |
| `stage2_fanqie_label` | 更名为 `stage2_in_queue_label`，文字改为"已进入发布队列" |
| `stage2_local_label` | 更名为 `stage2_total_label`，文字改为"本地总章节" |
| 移除 `stage2_new_label` 和 `stage2_update_label` | 不再显示 |
| 添加新标签 `stage2_pending_label` | 显示"待进入发布队列" |
| 按钮文字 | "按steps目录最新章节设置" → "选择全部章节" |
| `_on_start_next_step()` | 下一步时记录 `steps_to_publish_converted_count` |
| `_run_restructure()` | 重划分完成后记录 `steps_to_publish_converted_count` |

### 5.2 work_manager.py

| 位置 | 修改内容 |
|------|----------|
| 无需修改 | 已有 `update_work()` 方法可更新 Work 模型 |

---

## 六、状态显示逻辑

### 6.1 `_update_strategy_range_status()` 新逻辑

```python
def _update_strategy_range_status(self) -> None:
    # steps目录总章节数
    steps_count = self._get_steps_chapter_count()

    # 从Work模型读取已转换数（新增）
    work = self.work_manager.get_work(self._current_work_id)
    converted_count = getattr(work, 'steps_to_publish_converted_count', 0)

    # 计算待转换数
    pending_count = max(0, steps_count - converted_count)

    self.stage2_total_label.setText(f"本地总章节: {steps_count} 章")
    self.stage2_in_queue_label.setText(f"已进入发布队列: {converted_count} 章")
    self.stage2_pending_label.setText(f"待进入发布队列: {pending_count} 章")
```

### 6.2 下一步按钮启用条件

```python
def _validate_current_step(self) -> None:
    # ... step 1, 2 validation ...

    if self.current_step == 2:  # Step 3
        # 检查是否有可发布的章节
        if pending_count > 0 or converted_count > 0:
            self.next_btn.setEnabled(True)
        else:
            self.next_btn.setEnabled(False)
```

---

## 七、记录时机

### 7.1 按原始章节发布时

点击"下一步"触发 `_on_start_next_step()`：
```python
# 在执行 steps → publish 转换后
work = self.work_manager.get_work(self._current_work_id)
work.steps_to_publish_converted_count = int(self.end_chapter_input.text())
self.work_manager.update_work(work)
```

### 7.2 按自定义字数重新划分时

`_run_restructure()` 完成并生成标题后：
```python
# 在 _on_restructure_complete 回调中
work = self.work_manager.get_work(self._current_work_id)
work.steps_to_publish_converted_count = int(self.end_chapter_input.text())
self.work_manager.update_work(work)
```

---

## 八、汇总页面修改

汇总页面（第6步）中也需要同步修改相关标签文案：

| 原文案 | 新文案 |
|--------|--------|
| 发布范围 | 发布队列 |
| 番茄已发布 | 已进入发布队列 |
| 待新发布 | 待进入发布队列 |

