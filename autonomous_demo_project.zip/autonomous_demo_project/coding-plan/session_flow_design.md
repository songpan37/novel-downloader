# AI Writer 会话执行流程设计

## 概述

本文档描述 AI Writer 创作流程的完整会话执行流程。采用**硬编码流程 + 动态参数**的设计：

- **硬编码**：每个会话类型的输入/输出步骤顺序固定
- **动态参数**：卷号 `vol_num` 作为参数传入，支持任意卷（1-3 卷、4-9 卷等）
- **new_chat 规则**：每个会话的**第 1 个输入步骤** `new_chat=True`，其余所有步骤 `new_chat=False`
- **顺序执行**：所有会话按固定顺序依次执行，前一个会话完全结束后才开始下一个会话
- **无状态管理**：不使用 SessionManager 或 session_id，直接在 `_on_start_creation` 中按顺序调用各会话方法

---

## 会话类型总览

```
创作流程
│
├── basic_info (基本设定会话)
│   ├── style_setting (文风设定)
│   ├── book_title (书名)
│   ├── story_summary (故事梗概)
│   ├── worldbuilding (时空设定)
│   ├── character_design (人物设定)
│   └── cover_image (封面图片)
│
├── creation_reference (创作参考会话)
│   ├── reference_{work_name_1}_{start_ch}_{end_ch} (拆书参考 1)
│   ├── reference_{work_name_2}_{start_ch}_{end_ch} (拆书参考 2)
│   ├── ... (每个参考作品一个步骤)
│   └── pattern_{start_ch}_{end_ch} (创作公式)
│
├── volume_{vol_num} (分卷信息会话，每卷一个)
│   ├── volume_{vol_num} (分卷大纲)
│   └── volume_{vol_num}_characters (分卷人物)
│
└── chapter_{vol_num} (章节信息会话，每卷一个)
    ├── chapter_{vol_num}_1_outline (第 1 章大纲)
    ├── chapter_{vol_num}_1_content (第 1 章正文)
    ├── chapter_{vol_num}_2_outline (第 2 章大纲)
    ├── chapter_{vol_num}_2_content (第 2 章正文)
    ├── ... (循环至该卷最后一章)
    ├── chapter_{vol_num}_N_content (最后一章正文)
    │
    ├── [同一会话内，章节完成后直接进行]
    ├── volume_{vol_num}_summary_plot (剧情总结)
    └── volume_{vol_num}_summary_character (人物总结)
```

**说明：**
- `creation_reference` 会话包含所有拆书参考步骤（每个参考作品一个）和创作公式步骤
- `chapter_{vol_num}` 会话包含该卷所有章节的大纲和正文步骤，**章节全部完成后，在同一会话内继续进行分卷总结**（剧情总结 + 人物总结）
- 分卷总结不是独立会话，而是章节信息会话的输出阶段的一部分
- **所有会话按顺序依次执行，前一个会话完全结束后才开始下一个会话**

---

## 完整执行流程树

```
_on_start_creation()
│
├─→ 获取用户选择的卷数范围 (start_volume, end_volume)
│
├─→ _execute_basic_info_session()
│   │
│   ├─ 输入阶段 (6 步，仅第 1 步 new_chat=True)
│   │   ├─→ _basic_input_define_role()
│   │   ├─→ _basic_input_define_task()
│   │   ├─→ _basic_input_basic_settings()
│   │   ├─→ _basic_input_previous_plot()
│   │   ├─→ _basic_input_character_design()
│   │   └─→ _basic_input_completed_info()
│   │
│   ├─ 输出阶段 (6 步，全部 new_chat=False)
│   │   ├─→ _basic_generate_style_setting()
│   │   ├─→ _basic_generate_book_title()
│   │   ├─→ _basic_generate_story_summary()
│   │   ├─→ _basic_generate_worldbuilding()
│   │   ├─→ _basic_generate_character_design()
│   │   └─→ _basic_generate_cover_image()
│   │
│   └─→ _basic_session_complete()
│       └─→ _execute_creation_reference_session()
│
├─→ _execute_creation_reference_session()
│   │
│   ├─ 输入阶段 (6 步，仅第 1 步 new_chat=True)
│   │   ├─→ _reference_input_define_role()
│   │   ├─→ _reference_input_define_task()
│   │   ├─→ _reference_input_basic_settings()
│   │   ├─→ _reference_input_previous_plot()
│   │   ├─→ _reference_input_character_design()
│   │   └─→ _reference_input_completed_info()
│   │
│   ├─ 输出阶段 (多个步骤，全部 new_chat=False)
│   │   │
│   │   ├─ 拆书参考步骤 (每个参考作品一个)
│   │   │   ├─→ _reference_analyze_work(work_name_1)
│   │   │   ├─→ _reference_analyze_work(work_name_2)
│   │   │   └─→ ... (遍历所有参考作品)
│   │   │
│   │   └─ 创作公式步骤
│   │       └─→ _reference_generate_pattern()
│   │
│   └─→ _reference_session_complete()
│       └─→ for vol_num in range(start_volume, end_volume + 1):
│               _execute_volume_session(vol_num)
│
├─→ for vol_num in range(start_volume, end_volume + 1):
│   │
│   └─→ _execute_volume_session(vol_num)
│       │
│       ├─ 输入阶段 (6 步，仅第 1 步 new_chat=True)
│       │   ├─→ _volume_input_define_role(vol_num)  [new_chat=True]
│       │   │   └─ send_context_input(prompt, new_chat=True)
│       │   │       → callback: _volume_input_define_task
│       │   │
│       │   ├─→ _volume_input_define_task(vol_num)  [new_chat=False]
│       │   │   └─ send_context_input(prompt, new_chat=False)
│       │   │       → callback: _volume_input_basic_settings
│       │   │
│       │   ├─→ _volume_input_basic_settings(vol_num)  [new_chat=False]
│       │   │   └─ send_context_input(prompt, new_chat=False)
│       │   │       → callback: _volume_input_previous_plot
│       │   │
│       │   ├─→ _volume_input_previous_plot(vol_num)  [new_chat=False]
│       │   │   └─ send_context_input(prompt, new_chat=False)
│       │   │       → callback: _volume_input_character_design
│       │   │
│       │   ├─→ _volume_input_character_design(vol_num)  [new_chat=False]
│       │   │   └─ send_context_input(prompt, new_chat=False)
│       │   │       → callback: _volume_input_completed_info
│       │   │
│       │   └─→ _volume_input_completed_info(vol_num)  [new_chat=False]
│       │       └─ send_context_input(prompt, new_chat=False)
│       │           → callback: _volume_start_output_phase
│       │
│       ├─ 输出阶段 (2 步，全部 new_chat=False)
│       │   │
│       │   ├─→ _volume_generate_outline(vol_num)  [new_chat=False]
│       │   │   └─ execute_output_step(step, new_chat=False)
│       │   │       → callback: _volume_generate_characters
│       │   │
│       │   └─→ _volume_generate_characters(vol_num)  [new_chat=False]
│       │       └─ execute_output_step(step, new_chat=False)
│       │           → callback: _volume_session_complete
│       │
│       └─→ _volume_session_complete(vol_num)
│           └─→ [循环继续下一卷 或 进入章节创作]
│
└─→ for vol_num in range(start_volume, end_volume + 1):
    │
    └─→ _execute_chapter_session(vol_num)
        │
        ├─ 输入阶段 (6 步，仅第 1 步 new_chat=True)
        │   ├─→ _chapter_input_define_role(vol_num)  [new_chat=True]
        │   │   └─ send_context_input(prompt, new_chat=True)
        │   │       → callback: _chapter_input_define_task
        │   │
        │   ├─→ _chapter_input_define_task(vol_num)  [new_chat=False]
        │   │   └─ send_context_input(prompt, new_chat=False)
        │   │       → callback: _chapter_input_basic_settings
        │   │
        │   ├─→ _chapter_input_basic_settings(vol_num)  [new_chat=False]
        │   │   └─ send_context_input(prompt, new_chat=False)
        │   │       → callback: _chapter_input_previous_plot
        │   │
        │   ├─→ _chapter_input_previous_plot(vol_num)  [new_chat=False]
        │   │   └─ send_context_input(prompt, new_chat=False)
        │   │       → callback: _chapter_input_volume_info
        │   │
        │   ├─→ _chapter_input_volume_info(vol_num)  [new_chat=False]
        │   │   └─ send_context_input(prompt, new_chat=False)
        │   │       → callback: _chapter_input_completed_info
        │   │
        │   └─→ _chapter_input_completed_info(vol_num)  [new_chat=False]
        │       └─ send_context_input(prompt, new_chat=False)
        │           → callback: _chapter_start_output_phase
        │
        ├─ 输出阶段 - 章节创作 (2×N 步，全部 new_chat=False)
        │   │
        │   └─→ _chapter_generate_all_chapters(vol_num)
        │       │
        │       ├─ for chapter_num in 1..chapters_per_volume:
        │       │   │
        │       │   ├─→ _chapter_generate_single_chapter_outline(vol_num, chapter_num)
        │       │   │   └─ execute_output_step(step, new_chat=False)
        │       │   │       → callback: _chapter_generate_single_chapter_content(vol_num, chapter_num)
        │       │   │
        │       │   └─→ _chapter_generate_single_chapter_content(vol_num, chapter_num)
        │       │       └─ execute_output_step(step, new_chat=False)
        │       │           → callback: 下一章 或 _chapter_generate_volume_summary_plot
        │       │
        │       └─→ [所有章节完成后，同一会话内继续分卷总结]
        │
        ├─ 输出阶段 - 分卷总结 (2 步，全部 new_chat=False)
        │   │
        │   ├─→ _chapter_generate_volume_summary_plot(vol_num)  [new_chat=False]
        │   │   └─ execute_output_step(step, new_chat=False)
        │   │       → callback: _chapter_generate_volume_summary_character
        │   │
        │   └─→ _chapter_generate_volume_summary_character(vol_num)  [new_chat=False]
        │       └─ execute_output_step(step, new_chat=False)
        │           → callback: _chapter_session_complete
        │
        └─→ _chapter_session_complete(vol_num)
            └─→ [循环继续下一卷 或 调用_on_creation_completed]
```

---

## 方法清单

### 会话执行方法（4 个）

| 方法名 | 参数 | 说明 |
|--------|------|------|
| `_execute_basic_info_session()` | 无 | 基本设定会话 |
| `_execute_creation_reference_session()` | 无 | 创作参考会话（拆书 + 公式） |
| `_execute_volume_session(vol_num)` | vol_num | 分卷信息会话 |
| `_execute_chapter_session(vol_num)` | vol_num | 章节信息会话（包含章节创作 + 分卷总结） |

---

### 输入步骤方法（18 个）

#### 基本设定会话输入（6 个）
| 方法名 | new_chat | 说明 |
|--------|----------|------|
| `_basic_input_define_role()` | True | 定义角色 |
| `_basic_input_define_task()` | False | 定义任务 |
| `_basic_input_basic_settings()` | False | 小说基本设定 |
| `_basic_input_previous_plot()` | False | 前序剧情 |
| `_basic_input_character_design()` | False | 人物设定 |
| `_basic_input_completed_info()` | False | 已完成信息 |

#### 创作参考会话输入（6 个）
| 方法名 | new_chat | 说明 |
|--------|----------|------|
| `_reference_input_define_role()` | True | 定义角色 |
| `_reference_input_define_task()` | False | 定义任务 |
| `_reference_input_basic_settings()` | False | 小说基本设定 |
| `_reference_input_previous_plot()` | False | 前序剧情 |
| `_reference_input_character_design()` | False | 人物设定 |
| `_reference_input_completed_info()` | False | 已完成信息 |

#### 分卷信息会话输入（6 个）
| 方法名 | 参数 | new_chat | 说明 |
|--------|------|----------|------|
| `_volume_input_define_role(vol_num)` | vol_num | True | 定义角色 |
| `_volume_input_define_task(vol_num)` | vol_num | False | 定义任务 |
| `_volume_input_basic_settings(vol_num)` | vol_num | False | 小说基本设定 |
| `_volume_input_previous_plot(vol_num)` | vol_num | False | 前序剧情 |
| `_volume_input_character_design(vol_num)` | vol_num | False | 人物设定 |
| `_volume_input_completed_info(vol_num)` | vol_num | False | 已完成分卷信息 |

#### 章节信息会话输入（6 个）
| 方法名 | 参数 | new_chat | 说明 |
|--------|------|----------|------|
| `_chapter_input_define_role(vol_num)` | vol_num | True | 定义角色 |
| `_chapter_input_define_task(vol_num)` | vol_num | False | 定义任务 |
| `_chapter_input_basic_settings(vol_num)` | vol_num | False | 小说基本设定 |
| `_chapter_input_previous_plot(vol_num)` | vol_num | False | 前序剧情 |
| `_chapter_input_volume_info(vol_num)` | vol_num | False | 分卷大纲和人物 |
| `_chapter_input_completed_info(vol_num)` | vol_num | False | 已完成章节信息 |

---

### 输出步骤方法（15 个）

#### 基本设定会话输出（6 个）
| 方法名 | new_chat | 说明 |
|--------|----------|------|
| `_basic_generate_style_setting()` | False | 生成文风设定 |
| `_basic_generate_book_title()` | False | 生成书名 |
| `_basic_generate_story_summary()` | False | 生成故事梗概 |
| `_basic_generate_worldbuilding()` | False | 生成时空设定 |
| `_basic_generate_character_design()` | False | 生成人物设定 |
| `_basic_generate_cover_image()` | False | 生成封面图片 |

#### 创作参考会话输出（2 个）
| 方法名 | 参数 | new_chat | 说明 |
|--------|------|----------|------|
| `_reference_analyze_work(work_name)` | work_name | False | 分析参考作品（拆书） |
| `_reference_generate_pattern()` | 无 | False | 生成创作公式 |

#### 分卷信息会话输出（3 个）
| 方法名 | 参数 | new_chat | 说明 |
|--------|------|----------|------|
| `_volume_start_output_phase(vol_num)` | vol_num | - | 输出阶段入口 |
| `_volume_generate_outline(vol_num)` | vol_num | False | 生成**分卷大纲** |
| `_volume_generate_characters(vol_num)` | vol_num | False | 生成**分卷人物** |

#### 章节信息会话输出（6 个）
| 方法名 | 参数 | new_chat | 说明 |
|--------|------|----------|------|
| `_chapter_start_output_phase(vol_num)` | vol_num | - | 输出阶段入口 |
| `_chapter_generate_all_chapters(vol_num)` | vol_num | - | 生成所有章节（循环入口） |
| `_chapter_generate_single_chapter_outline(vol_num, chapter_num)` | vol_num, chapter_num | False | 生成单章大纲 |
| `_chapter_generate_single_chapter_content(vol_num, chapter_num)` | vol_num, chapter_num | False | 生成单章正文 |
| `_chapter_generate_volume_summary_plot(vol_num)` | vol_num | False | 生成**剧情总结** |
| `_chapter_generate_volume_summary_character(vol_num)` | vol_num | False | 生成**人物总结** |

---

### 会话完成方法（4 个）

| 方法名 | 参数 | 说明 |
|--------|------|------|
| `_basic_session_complete()` | 无 | 基本设定会话完成 |
| `_reference_session_complete()` | 无 | 创作参考会话完成 |
| `_volume_session_complete(vol_num)` | vol_num | 分卷信息会话完成 |
| `_chapter_session_complete(vol_num)` | vol_num | 章节信息会话完成（包含分卷总结） |

---

### 辅助方法（6 个）

| 方法名 | 参数 | 说明 |
|--------|------|------|
| `_send_context_input(prompt, new_chat, next_method)` | prompt, new_chat, next_method | 发送上下文输入 |
| `_execute_output_step(step_info, new_chat, next_method)` | step_info, new_chat, next_method | 执行输出步骤 |
| `_build_volume_input_prompt(vol_num, input_type)` | vol_num, input_type | 构建分卷输入提示词 |
| `_build_chapter_input_prompt(vol_num, input_type)` | vol_num, input_type | 构建章节输入提示词 |
| `_create_persistent_browser()` | 无 | 创建持久浏览器 |
| `_close_persistent_browser()` | 无 | 关闭浏览器 |

---

## new_chat 规则总结

```
┌─────────────────────────────────────────────────────────┐
│  每个会话 (Session) 的 new_chat 规则                      │
│                                                         │
│  ├─ 输入阶段 (Input Phase)                               │
│  │   │                                                   │
│  │   ├─ 第 1 步  ───────────────→ new_chat=True         │
│  │   │           (点击"开启新对话"按钮)                  │
│  │   │                                                   │
│  │   └─ 第 2-6 步 ──────────────→ new_chat=False        │
│  │               (在同一聊天中继续)                      │
│  │                                                       │
│  └─ 输出阶段 (Output Phase)                              │
│      │                                                   │
│      └─ 所有输出步骤 ─────────────→ new_chat=False      │
│                  (在同一聊天中生成所有输出)               │
│                                                         │
│  会话完成后 → 下一个会话方法                              │
│  下一个会话的第 1 步 new_chat=True (开始新会话)             │
└─────────────────────────────────────────────────────────┘
```

---

## 步骤与磁盘文件映射

### 输出步骤文件映射规则

**每个输出步骤对应 `steps/` 目录下的一个文件，一一对应：**

| 输出步骤 | 磁盘文件路径 |
|----------|-------------|
| `_basic_generate_style_setting()` | `steps/style_setting.txt` |
| `_basic_generate_book_title()` | `steps/book_title.txt` |
| `_basic_generate_story_summary()` | `steps/story_summary.txt` |
| `_basic_generate_worldbuilding()` | `steps/worldbuilding.txt` |
| `_basic_generate_character_design()` | `steps/character_design.txt` |
| `_basic_generate_cover_image()` | `steps/cover_image.txt` |
| `_reference_analyze_work(work_name)` | `steps/reference_{work_name}_{start_ch}_{end_ch}.txt` |
| `_reference_generate_pattern()` | `steps/pattern_{start_ch}_{end_ch}.txt` |
| `_volume_generate_outline(vol_num)` | `steps/volume_{vol_num}.txt` |
| `_volume_generate_characters(vol_num)` | `steps/volume_{vol_num}_characters.txt` |
| `_chapter_generate_single_chapter_outline(vol_num, chapter_num)` | `chapters/chapter_{vol_num:03d}_{chapter_num:03d}.json` (outline 字段) |
| `_chapter_generate_single_chapter_content(vol_num, chapter_num)` | `chapters/chapter_{vol_num:03d}_{chapter_num:03d}.json` (content 字段) |
| `_chapter_generate_volume_summary_plot(vol_num)` | `steps/volume_{vol_num}_summary_plot.txt` |
| `_chapter_generate_volume_summary_character(vol_num)` | `steps/volume_{vol_num}_summary_character.txt` |

### 步骤完成状态判断

```python
def is_step_completed(step_file_path: str) -> bool:
    """
    判断步骤是否已完成。

    判断条件：
    1. 文件存在
    2. 文件内容不为空

    Returns:
        True if 文件存在 AND 内容不为空，否则 False
    """
    if not os.path.exists(step_file_path):
        return False

    content = read_file(step_file_path, encoding='utf-8')
    return content is not None and len(content.strip()) > 0
```

### 步骤完成状态判断

**核心原则：步骤级别的细粒度检查**

1. 每个步骤执行前都检查自己的文件
2. 文件存在且内容非空 = 已完成，跳过
3. 文件不存在或内容为空 = 未完成，执行 AI 生成
4. 不依赖会话级别的状态判断（如 all_completed 等）

```python
def is_step_completed(step_file_path: str) -> bool:
    """
    判断步骤是否已完成。

    判断条件：
    1. 文件存在
    2. 文件内容不为空

    Returns:
        True if 文件存在 AND 内容不为空，否则 False
    """
    if not os.path.exists(step_file_path):
        return False

    content = read_file(step_file_path, encoding='utf-8')
    return content is not None and len(content.strip()) > 0
```

### 跳过已完成步骤逻辑

**每个输出步骤执行前的检查流程：**

```python
# 每个输出步骤执行前检查
def _execute_output_step_with_callback(self, step_id, step_name, file_path, prompt, next_method):
    # 步骤 1: 检查文件是否已存在
    if os.path.exists(file_path):
        content = self._read_file_safe(file_path)
        if content and len(content.strip()) > 0:
            # 文件存在且内容非空，跳过
            self.logger.info(f"[STEP_LOADED] {step_name}: 从磁盘加载完成 - {len(content)}字")
            self.logger.info(f"[STEP_SKIPPED] {step_name}: 已存在，跳过")
            next_method()  # 直接回调下一步
            return

    # 步骤 2: 文件不存在或内容为空，执行 AI 生成
    self.logger.info(f"[STEP_GENERATING] {step_name}: AI 生成中...")
    self.logger.info(f"[STEP_INPUT] {step_name}: 输入提示词:")
    self.logger.info(f"    ---")
    for line in prompt.split('\n')[:10]:
        self.logger.info(f"    {line}")
    # ... 显示前 10 行提示词
    self.logger.info(f"    ---")

    # AI 生成逻辑
    # ...

    # 步骤 3: 保存内容
    self._write_file_safe(file_path, content)
    self.logger.info(f"[STEP_SAVED] {step_name}: 已保存到 {file_path}")

    # 步骤 4: 回调下一步
    next_method()
```

**设计要点：**
- 不要在会话级别做 `all_completed` 判断
- 每个步骤都是最小粒度的检查单元
- 流程自动走到第一个未完成的步骤就进行生成
- 已完成的步骤自动跳过，不重复生成

---

## 日志格式设计

### 日志级别

| 级别 | 用途 | 示例 |
|------|------|------|
| `INFO` | 正常流程节点 | 步骤开始、步骤完成、会话切换 |
| `WARNING` | 可恢复的异常 | 文件不存在、内容为空 |
| `ERROR` | 不可恢复的错误 | AI 调用失败、文件写入失败 |
| `DEBUG` | 详细调试信息 | 提示词内容、AI 响应内容 |

### 日志标签分类

| 标签 | 用途 | 说明 |
|------|------|------|
| `[CREATION_START]` | 创作开始 | `_on_start_creation` 调用 |
| `[SESSION_START]` | 会话开始 | 每个会话方法调用时 |
| `[SESSION_COMPLETE]` | 会话完成 | 会话所有步骤完成后 |
| `[STEP_CHECK]` | 步骤检查 | 检查步骤文件是否存在 |
| `[STEP_LOADED]` | 步骤加载 | 从磁盘加载已完成的步骤 |
| `[STEP_SKIPPED]` | 步骤跳过 | 跳过已完成的步骤 |
| `[STEP_INPUT]` | 步骤输入 | 显示当前步骤的输入提示词 |
| `[STEP_GENERATING]` | 步骤生成 | AI 生成中 |
| `[STEP_OUTPUT]` | 步骤输出 | AI 生成的内容 |
| `[STEP_SAVED]` | 步骤保存 | 内容保存到磁盘文件 |
| `[CREATION_COMPLETE]` | 创作完成 | `_on_creation_completed` 调用 |

### 日志输出规则

**核心原则**：看到日志就知道：
1. 当前在执行哪个步骤
2. 步骤的输入是什么
3. 步骤的输出是什么
4. 已完成了哪些步骤
5. 还有哪些步骤待完成

**日志格式规范**：
```
[会话进度] [步骤进度] 标签：内容
```

**会话进度格式**：`[会话名称 (当前会话/总会话)]`
**步骤进度格式**：`[步骤名称 (当前步骤/总步骤)]`

**示例**：
```
[基本设定会话 (1/4)] [文风设定 (1/6)] [STEP_GENERATING]: AI 生成中...
[分卷信息会话 (3/4)] [分卷大纲 (1/2)] [STEP_SAVED]: 已保存到 steps/volume_1.txt
```

**输出格式**：
- 会话层级：无缩进，显示会话进度
- 步骤层级：2 个空格缩进，显示步骤进度
- 输入/输出内容：4 个空格缩进，用 `---` 包裹

### 日志格式示例

```
==================== 创作流程启动 ====================

[CREATION_START] 开始创作流程
  作品 ID: work_001
  卷数范围：1-3
  每卷章节数：5
  总步骤数：36

[基本设定会话 (1/4)] [文风设定 (1/6)] [STEP_CHECK]: 检查文件 steps/style_setting.txt - 不存在
[基本设定会话 (1/4)] [文风设定 (1/6)] [STEP_GENERATING]: AI 生成中...
[基本设定会话 (1/4)] [文风设定 (1/6)] [STEP_INPUT]: 输入提示词:
    ---
    你是一位专业的小说创作者...
    小说类型：玄幻
    请分析以下小说的语言风格...
    ---
[基本设定会话 (1/4)] [文风设定 (1/6)] [STEP_OUTPUT]: AI 生成完成 (156 字)
    ---
    本文采用第三人称全知视角叙述...
    语言风格特点：
    1. 修辞手法：大量使用比喻、夸张...
    ---
[基本设定会话 (1/4)] [文风设定 (1/6)] [STEP_SAVED]: 已保存到 steps/style_setting.txt
[基本设定会话 (1/4)] [书名 (2/6)] [STEP_CHECK]: 检查文件 steps/book_title.txt - 不存在
[基本设定会话 (1/4)] [书名 (2/6)] [STEP_GENERATING]: AI 生成中...
[基本设定会话 (1/4)] [书名 (2/6)] [STEP_INPUT]: 输入提示词:
    ---
    根据以下设定生成书名：
    小说类型：玄幻
    故事梗概：{story_summary}
    ---
[基本设定会话 (1/4)] [书名 (2/6)] [STEP_OUTPUT]: AI 生成完成 (12 字)
    ---
    《九霄神帝》
    ---
[基本设定会话 (1/4)] [书名 (2/6)] [STEP_SAVED]: 已保存到 steps/book_title.txt
...
[基本设定会话 (1/4)] [封面图片 (6/6)] [STEP_CHECK]: 检查文件 steps/cover_image.txt - 已存在 (320 字)
[基本设定会话 (1/4)] [封面图片 (6/6)] [STEP_LOADED]: 从磁盘加载完成
[基本设定会话 (1/4)] [封面图片 (6/6)] [STEP_SKIPPED]: 已存在，跳过
[基本设定会话 (1/4)] [SESSION_COMPLETE]: 会话完成 - 6/6 步骤 (5 新生成，1 已存在)

[创作参考会话 (2/4)] [拆书参考 (1/3)] [STEP_CHECK]: 检查文件 steps/reference_斗破苍穹_1_15.txt - 不存在
[创作参考会话 (2/4)] [拆书参考 (1/3)] [STEP_GENERATING]: AI 生成中...
[创作参考会话 (2/4)] [拆书参考 (1/3)] [STEP_INPUT]: 输入提示词:
    ---
    请分析《斗破苍穹》第 1-15 章的创作模式...
    ---
[创作参考会话 (2/4)] [拆书参考 (1/3)] [STEP_OUTPUT]: AI 生成完成 (2150 字)
    ---
    【作品信息】
    作品名：斗破苍穹
    分析范围：第 1-15 章
    ...
    ---
[创作参考会话 (2/4)] [拆书参考 (1/3)] [STEP_SAVED]: 已保存到 steps/reference_斗破苍穹_1_15.txt
...
[创作参考会话 (2/4)] [SESSION_COMPLETE]: 会话完成 - 3/3 步骤 (3 新生成，0 已存在)

[分卷信息会话 (3/4)] 开始处理卷 1-3 (共 3 卷)

  [第 1 卷分卷信息 (3/4)] [分卷大纲 (1/2)] [STEP_CHECK]: 检查文件 steps/volume_1.txt - 不存在
  [第 1 卷分卷信息 (3/4)] [分卷大纲 (1/2)] [STEP_GENERATING]: AI 生成中...
  [第 1 卷分卷信息 (3/4)] [分卷大纲 (1/2)] [STEP_INPUT]: 输入提示词:
      ---
      请为第 1 卷生成详细大纲...
      小说类型：玄幻
      书名：《九霄神帝》
      故事梗概：{story_summary}
      时空设定：{worldbuilding}
      人物设定：{character_design}
      创作公式：{pattern_analysis}
      ---
  [第 1 卷分卷信息 (3/4)] [分卷大纲 (1/2)] [STEP_OUTPUT]: AI 生成完成 (890 字)
      ---
      第 1 卷：青云宗少年

      【核心目标】
      主角林动从青云宗外门弟子...

      【章节安排】
      第 1 章 - 第 5 章：外门试炼...
      ---
  [第 1 卷分卷信息 (3/4)] [分卷大纲 (1/2)] [STEP_SAVED]: 已保存到 steps/volume_1.txt
  [第 1 卷分卷信息 (3/4)] [分卷人物 (2/2)] [STEP_CHECK]: 检查文件 steps/volume_1_characters.txt - 不存在
  [第 1 卷分卷信息 (3/4)] [分卷人物 (2/2)] [STEP_GENERATING]: AI 生成中...
  [第 1 卷分卷信息 (3/4)] [分卷人物 (2/2)] [STEP_INPUT]: 输入提示词:
      ---
      请为第 1 卷生成出场人物设定...
      ---
  [第 1 卷分卷信息 (3/4)] [分卷人物 (2/2)] [STEP_OUTPUT]: AI 生成完成 (450 字)
      ---
      【主要人物】
      林动：男主角，青云宗外门弟子...
      萧薰儿：女主角，神秘身份...
      ---
  [第 1 卷分卷信息 (3/4)] [分卷人物 (2/2)] [STEP_SAVED]: 已保存到 steps/volume_1_characters.txt
  [第 1 卷分卷信息 (3/4)] [SESSION_COMPLETE]: 会话完成 - 2/2 步骤 (2 新生成，0 已存在)

  [第 2 卷分卷信息 (3/4)] [分卷大纲 (1/2)] [STEP_CHECK]: 检查文件 steps/volume_2.txt - 已存在 (920 字)
  [第 2 卷分卷信息 (3/4)] [分卷大纲 (1/2)] [STEP_LOADED]: 从磁盘加载完成
  [第 2 卷分卷信息 (3/4)] [分卷大纲 (1/2)] [STEP_SKIPPED]: 已存在，跳过
  [第 2 卷分卷信息 (3/4)] [分卷人物 (2/2)] [STEP_CHECK]: 检查文件 steps/volume_2_characters.txt - 已存在 (480 字)
  [第 2 卷分卷信息 (3/4)] [分卷人物 (2/2)] [STEP_LOADED]: 从磁盘加载完成
  [第 2 卷分卷信息 (3/4)] [分卷人物 (2/2)] [STEP_SKIPPED]: 已存在，跳过
  [第 2 卷分卷信息 (3/4)] [SESSION_COMPLETE]: 会话完成 - 2/2 步骤 (0 新生成，2 已存在)

  [第 3 卷分卷信息 (3/4)] ...
  [第 3 卷分卷信息 (3/4)] [SESSION_COMPLETE]: 会话完成 - 2/2 步骤 (2 新生成，0 已存在)

[分卷信息会话 (3/4)] [SESSION_COMPLETE]: 会话完成 - 3 卷已处理

[章节信息会话 (4/4)] [SESSION_START]: 开始处理卷 1-3 (共 3 卷)

  [第 1 卷章节 + 总结 (4/4)] [第 1 章大纲 (1/12)] [STEP_CHECK]: 检查文件 chapters/chapter_001_001.json (outline) - 不存在
  [第 1 卷章节 + 总结 (4/4)] [第 1 章大纲 (1/12)] [STEP_GENERATING]: AI 生成中...
  [第 1 卷章节 + 总结 (4/4)] [第 1 章大纲 (1/12)] [STEP_INPUT]: 输入提示词:
      ---
      请生成第 1 章大纲...
      卷号：1
      章号：1
      分卷大纲：{volume_outline}
      ---
  [第 1 卷章节 + 总结 (4/4)] [第 1 章大纲 (1/12)] [STEP_OUTPUT]: AI 生成完成 (180 字)
      ---
      第 1 章：陨落的天才

      【核心事件】
      林动在家族测试中展现天赋...

      【出场人物】
      林动、林琅天、族长...
      ---
  [第 1 卷章节 + 总结 (4/4)] [第 1 章大纲 (1/12)] [STEP_SAVED]: 已保存到 chapters/chapter_001_001.json
  [第 1 卷章节 + 总结 (4/4)] [第 1 章正文 (2/12)] [STEP_CHECK]: 检查文件 chapters/chapter_001_001.json (content) - 不存在
  [第 1 卷章节 + 总结 (4/4)] [第 1 章正文 (2/12)] [STEP_GENERATING]: AI 生成中...
  [第 1 卷章节 + 总结 (4/4)] [第 1 章正文 (2/12)] [STEP_INPUT]: 输入提示词:
      ---
      请生成第 1 章正文...
      章节大纲：{chapter_outline}
      字数要求：3000 字
      ---
  [第 1 卷章节 + 总结 (4/4)] [第 1 章正文 (2/12)] [STEP_OUTPUT]: AI 生成完成 (3200 字)
      ---
      第一章 陨落的天才

      清晨，青云宗外门...
      ---
  [第 1 卷章节 + 总结 (4/4)] [第 1 章正文 (2/12)] [STEP_SAVED]: 已保存到 chapters/chapter_001_001.json
  ...
  [第 1 卷章节 + 总结 (4/4)] [剧情总结 (11/12)] [STEP_CHECK]: 检查文件 steps/volume_1_summary_plot.txt - 不存在
  [第 1 卷章节 + 总结 (4/4)] [剧情总结 (11/12)] [STEP_GENERATING]: AI 生成中...
  [第 1 卷章节 + 总结 (4/4)] [剧情总结 (11/12)] [STEP_INPUT]: 输入提示词:
      ---
      请总结第 1 卷的剧情...
      本卷所有章节：{volume_all_chapters_content}
      ---
  [第 1 卷章节 + 总结 (4/4)] [剧情总结 (11/12)] [STEP_OUTPUT]: AI 生成完成 (560 字)
      ---
      【第 1 卷 剧情总结】

      主线剧情：
      林动从青云宗外门弟子起步...
      ---
  [第 1 卷章节 + 总结 (4/4)] [剧情总结 (11/12)] [STEP_SAVED]: 已保存到 steps/volume_1_summary_plot.txt
  [第 1 卷章节 + 总结 (4/4)] [人物总结 (12/12)] [STEP_CHECK]: 检查文件 steps/volume_1_summary_character.txt - 不存在
  [第 1 卷章节 + 总结 (4/4)] [人物总结 (12/12)] [STEP_GENERATING]: AI 生成中...
  [第 1 卷章节 + 总结 (4/4)] [人物总结 (12/12)] [STEP_OUTPUT]: AI 生成完成 (320 字)
      ---
      【第 1 卷 人物状态】

      林动：
      - 初始状态：外门弟子...
      - 结束状态：内门核心...
      ---
  [第 1 卷章节 + 总结 (4/4)] [人物总结 (12/12)] [STEP_SAVED]: 已保存到 steps/volume_1_summary_character.txt
  [第 1 卷章节 + 总结 (4/4)] [SESSION_COMPLETE]: 会话完成 - 12/12 步骤 (12 新生成，0 已存在)

  [第 2 卷章节 + 总结 (4/4)] ...
  [第 2 卷章节 + 总结 (4/4)] [SESSION_COMPLETE]: 会话完成 - 12/12 步骤 (12 新生成，0 已存在)

  [第 3 卷章节 + 总结 (4/4)] ...
  [第 3 卷章节 + 总结 (4/4)] [SESSION_COMPLETE]: 会话完成 - 12/12 步骤 (12 新生成，0 已存在)

[章节信息会话 (4/4)] [SESSION_COMPLETE]: 会话完成 - 3 卷已处理

[CREATION_COMPLETE] 创作流程完成

==================== 创作流程结束 ====================
```

---

## 设计原则

1. **顺序执行**：会话按固定顺序依次执行，在 `_on_start_creation` 中直接按顺序调用
2. **流程硬编码**：每种会话类型的步骤顺序固定，不依赖状态变量
3. **参数动态化**：`vol_num` 和 `chapter_num` 作为参数传入，支持任意卷/章
4. **回调链驱动**：每个方法完成后回调下一个方法，形成链式调用
5. **new_chat 固化**：每个方法的 `new_chat` 值在方法内硬编码，不动态计算
6. **无状态追踪**：
   - 不使用 `_current_step_index`、`_current_input_index` 等状态变量
   - 不使用 `SessionManager` 管理会话状态
   - 不使用 `session_id`、`step_id` 等 ID 参数
   - 每个步骤方法通过闭包回调直接调用下一个方法
   - 步骤完成状态由磁盘文件决定（文件存在且内容非空 = 已完成）

---

## 会话执行顺序

```
_on_start_creation() 中执行顺序:

[1] _execute_basic_info_session()
    ↓ 完成后
[2] _execute_creation_reference_session()
    ↓ 完成后
[3] for vol_num in range(start_volume, end_volume + 1):
        _execute_volume_session(vol_num)
    ↓ 所有卷完成后
[4] for vol_num in range(start_volume, end_volume + 1):
        _execute_chapter_session(vol_num)
    ↓ 所有卷完成后
[END] _on_creation_completed()
```

**关键机制：**
- **没有 `_start_next_session` 调度器**，直接在 `_on_start_creation` 中按顺序调用
- **没有 `SessionManager`**，步骤完成状态由磁盘文件映射到 UI
- **每个会话是独立的带参数方法**，如 `_execute_volume_session(vol_num)`
- **循环处理卷**：在 `_on_start_creation` 中用 `for` 循环遍历用户选择的卷数范围
- **回调链驱动**：每个会话方法内部通过回调链依次执行步骤
- **没有并行执行**，所有会话严格按顺序依次执行
- **章节会话包含两部分**：章节创作（所有章的大纲 + 正文） + 分卷总结（剧情总结 + 人物总结），在同一会话内完成
