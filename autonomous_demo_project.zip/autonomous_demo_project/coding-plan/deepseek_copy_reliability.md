# DeepSeek 拷贝可靠性改进方案

## 背景问题

1. **拷贝不稳定**：拷贝按钮点击后，可能由于网络或页面渲染问题，导致剪贴板为空或内容错乱
2. **提示词与结果不对应**：在连续生成场景下，可能出现提示词发送失败，但拷贝到了上一次生成结果的情况

## 重试策略

### A. 拷贝结果重试（结果剪贴板为空）

1. 点击拷贝按钮之前，先清空剪贴板 `pyperclip.copy("")`
2. 点击拷贝按钮后，等待1秒
3. 检查剪贴板内容是否不为空
4. 如果为空，重试点击拷贝按钮（最多3次）
5. 3次都失败才报错

### B. 提示词验证失败重试（提示词不匹配）

1. 生成完成后，点击**倒数第二个**拷贝按钮，获取刚发送的提示词
2. 比对：剪贴板内容 == message
3. 如果不一致，说明提示词发送失败，需要**重新发送提示词并等待生成完成**
4. 重试发送提示词（最多3次）
5. 3次都失败才报错

---

## 完整流程

```
发送提示词(message):
1. 清空剪贴板
2. 填充输入框并发送提示词(message)
3. 等待生成完成
4. 检查页面错误（服务器繁忙、频率限制）

验证并获取结果:
5. 获取所有拷贝按钮数量
   ├─ < 2个 → 重试发送提示词（跳回步骤1，最多3次）
   └─ >= 2个 → 继续

6. 点击"倒数第二个"拷贝按钮 → 获取刚发送的提示词
7. 比对：剪贴板内容 == message
   ├─ 不一致 → 重试发送提示词（跳回步骤1，最多3次）
   └─ 一致 → 继续（提示词发送正确）

8. 清空剪贴板
9. 点击"最后一个"拷贝按钮 → 获取最新生成结果
10. 检查剪贴板是否为空
    ├─ 为空 → 重试点击（最多3次，跳回步骤8）
    └─ 不为空 → 返回结果
```

---

## 重试循环说明

| 场景 | 重试动作 | 最大次数 |
|------|----------|----------|
| 拷贝按钮数量 < 2 | 重新发送提示词，重新等待生成完成 | 3次 |
| 提示词验证失败 | 重新发送提示词，重新等待生成完成 | 3次 |
| 结果拷贝为空 | 重新点击拷贝按钮 | 3次 |

**注意**：
- 重试设置了最大次数，避免无限循环
- 内层循环（拷贝按钮点击）失败不会触发外层重发循环

## 涉及方法

| 方法 | 改动内容 |
|------|----------|
| `_deepseek_complete` | 修改为外层重试循环，调用新增方法 |
| `_click_copy_button_with_retry` (新增) | 封装拷贝按钮点击逻辑，支持重试验证 |
| `_resend_and_wait` (新增) | 封装重新发送提示词并等待生成的逻辑 |

---

## 代码修改方案

### 1. 新增方法 `_click_copy_button_with_retry`

```python
def _click_copy_button_with_retry(self, button, max_retries=3) -> str:
    """点击拷贝按钮并验证剪贴板内容，重试机制

    Args:
        button: Playwright locator 对象
        max_retries: 最大重试次数

    Returns:
        剪贴板内容

    Raises:
        Exception: 重试max_retries次后仍为空
    """
    import pyperclip

    for attempt in range(max_retries):
        # 1. 清空剪贴板
        pyperclip.copy("")

        # 2. 点击按钮
        try:
            button.scroll_into_view_if_needed(timeout=10000)
            button.click(timeout=10000)
        except Exception as click_err:
            self.logger.warning(f"[deepseek] 点击拷贝按钮失败 (attempt {attempt+1}/{max_retries}): {click_err}")
            if attempt < max_retries - 1:
                time.sleep(2)
                continue
            else:
                raise Exception(f"点击拷贝按钮失败: {click_err}")

        # 3. 等待内容写入剪贴板
        time.sleep(1)

        # 4. 获取内容
        content = pyperclip.paste()

        if content and len(content.strip()) > 0:
            self.logger.info(f"[deepseek] 拷贝成功，内容长度: {len(content)}")
            return content

        self.logger.warning(f"[deepseek] 剪贴板为空 (attempt {attempt+1}/{max_retries})")

        if attempt < max_retries - 1:
            time.sleep(2)

    raise Exception("拷贝失败，剪贴板始终为空")
```

---

### 2. 新增方法 `_resend_and_wait`

```python
def _resend_and_wait(self, message: str, wait_timeout: float = 120.0, pause_check_fn=None) -> None:
    """重新发送提示词并等待生成完成

    Args:
        message: 提示词内容
        wait_timeout: 等待超时时间
        pause_check_fn: 可选的中断检查函数

    Raises:
        Exception: 发送或等待失败
    """
    self.logger.info(f"[deepseek] 重新发送提示词，长度: {len(message)}")

    # 找到输入框
    chat_input = self.page.locator('textarea.ds-scroll-area')
    chat_input.click()
    chat_input.fill(message)

    # 点击发送
    chat_input.press('Enter')
    self.logger.info("[deepseek] 提示词已重新发送")

    # 等待生成完成
    self._wait_for_generation_complete(wait_timeout, pause_check_fn)
    self.logger.info("[deepseek] 重新生成完成")

    # 等待内容渲染
    self.page.wait_for_timeout(500)

    # 检查页面错误
    self._check_page_errors()
```

---

### 3. 修改 `_deepseek_complete` 的拷贝逻辑

**核心结构**：外层重试循环（最多3次），用于提示词验证失败或按钮数量不足时重发

```python
def _deepseek_complete(self, message: str, new_chat: bool, dial_cnt: int, wait_timeout: float, session_mode: str = "multi_turn", pause_check_fn=None) -> str:
    """DeepSeek 完整对话流程（带重试逻辑）"""

    import pyperclip

    try:
        # ========== 外层重试循环：提示词验证失败或按钮不足时重发 ==========
        for verify_retry in range(3):
            self.logger.info(f"[deepseek] ========== 开始第{verify_retry + 1}/3次生成 ==========")

            # --- 发送提示词 ---
            if verify_retry == 0:
                # 首次发送
                # ... [原有发送逻辑不变] ...
            else:
                # 重新发送
                self._resend_and_wait(message, wait_timeout, pause_check_fn)

            # --- 查找拷贝按钮 ---
            all_buttons = self._find_copy_buttons()
            self.logger.info(f"[deepseek] 找到 {len(all_buttons)} 个拷贝按钮")

            if len(all_buttons) < 2:
                # 按钮数量不足，重试发送提示词
                self.logger.warning(f"[deepseek] 拷贝按钮数量不足: {len(all_buttons)}个，需要至少2个")
                if verify_retry < 2:
                    continue  # 继续下一次外层循环
                else:
                    raise Exception(f"拷贝按钮数量异常，只有{len(all_buttons)}个，已重试3次")

            # --- 1. 点击倒数第二个，获取刚发送的提示词 ---
            self.logger.info("[deepseek] 点击倒数第二个拷贝按钮验证提示词")
            second_last = all_buttons[-2]
            prev_prompt = self._click_copy_button_with_retry(second_last)

            # --- 2. 验证提示词是否一致 ---
            if prev_prompt != message:
                self.logger.warning(f"[deepseek] 提示词验证失败 (attempt {verify_retry + 1}/3)")
                self.logger.warning(f"[deepseek] 期望: {message[:100]}...")
                self.logger.warning(f"[deepseek] 实际: {prev_prompt[:100]}...")
                if verify_retry < 2:
                    continue  # 继续下一次外层循环，重新发送
                else:
                    raise Exception("提示词验证失败，已重试3次")

            self.logger.info("[deepseek] 提示词验证通过")

            # --- 3. 点击最后一个，获取生成结果 ---
            self.logger.info("[deepseek] 点击最后一个拷贝按钮获取结果")
            last_button = all_buttons[-1]
            message_text = self._click_copy_button_with_retry(last_button)

            self.logger.info(f"[deepseek] ========== 生成完成，内容长度: {len(message_text)} ==========")
            break  # 成功，跳出外层循环

        return message_text

    except Exception as e:
        self.logger.error(f"[deepseek] 生成失败: {e}")
        raise
```

---

## 日志规范

所有关键步骤都需要清晰日志：

```
[deepseek] ========== 开始第1/3次生成 ==========
[deepseek] 发送提示词，长度: 1234
[deepseek] 等待生成完成...
[deepseek] 生成完成，开始验证
[deepseek] 找到 2 个拷贝按钮
[deepseek] 点击倒数第二个拷贝按钮验证提示词
[deepseek] 拷贝成功，内容长度: 1234
[deepseek] 提示词验证通过
[deepseek] 点击最后一个拷贝按钮获取结果
[deepseek] 拷贝成功，内容长度: 5678
[deepseek] ========== 生成完成，内容长度: 5678 ==========

[deepseek] ========== 开始第2/3次生成 ==========
[deepseek] 重新发送提示词，长度: 1234
[deepseek] 提示词已重新发送
[deepseek] 等待生成完成...
[deepseek] 重新生成完成
[deepseek] 找到 2 个拷贝按钮
[deepseek] 提示词验证通过
[deepseek] 拷贝成功
[deepseek] ========== 生成完成 ==========
```

## 影响范围

| 方法 | 修改类型 | 影响 |
|------|----------|------|
| `_deepseek_complete` | 修改 | 仅影响 DeepSeek |
| `_click_copy_button_with_retry` | 新增 | 仅 DeepSeek 使用 |
| `_resend_and_wait` | 新增 | 仅 DeepSeek 使用 |
| `send_message` | 无修改 | 路由逻辑不变 |
| `_doubao_complete` | 无修改 | 豆包完全不受影响 |
