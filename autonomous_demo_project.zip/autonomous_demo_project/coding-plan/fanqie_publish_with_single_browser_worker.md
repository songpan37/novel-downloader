# 单浏览器实例任务队列架构设计

## 一、原始需求

用户要求在整个番茄小说发布流程中，只创建一个 Playwright 浏览器实例，具体要求：

1. **单一浏览器实例**：整个发布流程只使用一个 Playwright 浏览器实例
2. **独立线程运行**：浏览器在单独的工作线程中运行
3. **无限循环任务处理**：工作线程启动后进入无限循环，不断从任务队列读取新任务
4. **任务抽象**：所有浏览器操作都抽象成任务，包括：
   - 登录番茄账号
   - 创建新书
   - 获取已发布章节信息
   - 更新已有章节内容
   - 发布新章节
5. **生产者-消费者模式**：主流程不直接操作浏览器，而是向任务队列提交任务，然后轮询等待任务完成
6. **只登录一次**：整个流程只进行一次番茄平台登录

## 二、核心架构

### 2.1 线程模型

```
┌─────────────────────────────────────────────────────────────────┐
│                         主线程 (GUI)                             │
│  - 监听用户操作                                                   │
│  - 向 FanqieWorker 提交任务                                       │
│  - 等待任务完成                                                   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ submit_task()
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    FanqieWorker 线程                              │
│  - 启动 Playwright 浏览器                                          │
│  - 维护任务队列                                                   │
│  - 无限循环处理任务                                               │
│  - 任务执行完通知主线程                                            │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ 创建/复用 Page
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Playwright Browser 实例                        │
│  - 只创建一个 Browser 实例                                         │
│  - 创建多个 Context (当前实现复用同一个 Context)                     │
│  - 创建多个 Page (每个任务创建新 Page，登录任务除外)                  │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 任务类型定义

```python
class FanqieTaskType(Enum):
    LOGIN = "login"                      # 登录账号
    CREATE_BOOK = "create_book"          # 创建新书
    GET_PUBLISHED_CHAPTERS = "get_published_chapters"  # 获取已发布章节
    PUBLISH_CHAPTER = "publish_chapter"  # 发布新章节
    UPDATE_CHAPTER = "update_chapter"    # 更新已有章节
    CLOSE = "close"                      # 关闭浏览器
```

### 2.3 Page 管理策略

| 任务类型 | Page 管理 | 原因 |
|---------|---------|------|
| LOGIN | 创建新 Page，**不关闭** | 登录后保持页面状态，用于后续任务验证 |
| CREATE_BOOK | 创建新 Page，用完后关闭 | 不需要保持状态 |
| GET_PUBLISHED_CHAPTERS | 创建新 Page，用完后关闭 | 只读操作 |
| PUBLISH_CHAPTER | 创建新 Page，用完后关闭 | 每个章节独立操作 |
| UPDATE_CHAPTER | 创建新 Page，用完后关闭 | 每个章节独立操作 |

## 三、核心组件

### 3.1 FanqieWorker

负责管理浏览器生命周期和任务调度。

**主要属性：**
```python
class FanqieWorker:
    _thread: threading.Thread           # 工作线程
    _stop_event: threading.Event         # 停止事件
    _task_queue: list                   # 任务队列
    _queue_lock: threading.Lock          # 队列锁

    _publisher: FanqiePublisher         # 浏览器发布器
    _logged_in: bool                    # 登录状态
    _account_info: dict                 # 账号信息
    _current_book_id: str               # 当前书籍ID
    _current_book_name: str             # 当前书籍名称
```

**核心方法：**
- `start()`: 启动工作线程
- `stop()`: 停止工作线程
- `submit_task(task_type, params, timeout)`: 提交任务并等待结果
- `_run()`: 线程主循环

### 3.2 FanqiePublisher

封装 Playwright 浏览器操作，提供浏览器启动、页面导航、发布章节等功能。

**新增方法：**
```python
def create_new_page(self):
    """在现有浏览器 Context 中创建新 Page"""
    if not self.browser or not self.context:
        return None
    return self.context.new_page()
```

## 四、任务执行流程

### 4.1 登录任务 (LOGIN)

```
1. 主线程调用 submit_task(LOGIN, {phone, password})
2. Worker 创建 FanqiePublisher (如果不存在)
3. Worker 设置账号密码
4. Worker 调用 publisher.connect():
   - 启动 Playwright
   - 启动 Chrome 浏览器
   - 创建 Context
   - 创建 Page
   - 导航到登录页面
   - 执行登录流程 (填手机号、密码、勾选协议、点击登录)
   - 等待页面跳转到作家后台
5. 设置 _logged_in = True
6. 返回登录成功 (Page 保持打开状态)
```

**关键代码：**
```python
def _do_login(self, task):
    self._publisher.phone_number = phone
    self._publisher.password = password
    success = self._publisher.connect()  # 创建 browser/context/page，登录，不关闭
    if success:
        self._logged_in = True
```

### 4.2 获取已发布章节 (GET_PUBLISHED_CHAPTERS)

```
1. 主线程调用 submit_task(GET_PUBLISHED_CHAPTERS, {book_id})
2. 检查 _logged_in 状态
3. 创建新 Page: new_page = publisher.create_new_page()
4. 临时替换 publisher.page = new_page (保持 API 兼容)
5. 导航到章节管理页面，使用 expect_response 捕获 API 数据
6. 解析章节列表
7. 关闭 new_page
8. 恢复 original_page
9. 返回章节列表
```

**关键代码：**
```python
def _do_get_published_chapters(self, task):
    page = self._publisher.create_new_page()  # 创建新 Page
    original_page = self._publisher.page
    self._publisher.page = page

    try:
        # 导航并获取章节数据
        with page.expect_response("**/api/author/chapter/chapter_list/**") as resp:
            page.goto(chapter_url)
        # 解析响应...
    finally:
        self._publisher.page = original_page
        page.close()  # 关闭任务 Page
```

### 4.3 发布新章节 (PUBLISH_CHAPTER)

流程与获取章节类似，只是操作不同：
1. 创建新 Page
2. 调用 `publisher.publish_chapter()` 发布章节
3. 关闭 Page

## 五、伪代码实现

### 5.1 Worker 主循环

```python
def _run(self):
    """工作线程主循环"""
    while not self._stop_event.is_set():
        # 1. 从队列获取任务
        task = None
        with self._queue_lock:
            if self._task_queue:
                task = self._task_queue.pop(0)

        # 2. 无任务则休眠
        if task is None:
            time.sleep(0.1)
            continue

        # 3. 处理停止命令
        if task.task_type == FanqieTaskType.CLOSE:
            self._cleanup()
            task.completed = True
            task.finished_event.set()
            break

        # 4. 执行任务
        try:
            self._process_task(task)
        except Exception as e:
            task.error = str(e)

        # 5. 标记完成并通知
        task.completed = True
        task.finished_event.set()

def _process_task(self, task):
    """根据任务类型分发执行"""
    if task.task_type == FanqieTaskType.LOGIN:
        self._do_login(task)
    elif task.task_type == FanqieTaskType.CREATE_BOOK:
        self._do_create_book(task)
    elif task.task_type == FanqieTaskType.GET_PUBLISHED_CHAPTERS:
        self._do_get_published_chapters(task)
    elif task.task_type == FanqieTaskType.PUBLISH_CHAPTER:
        self._do_publish_chapter(task)
    elif task.task_type == FanqieTaskType.UPDATE_CHAPTER:
        self._do_update_chapter(task)
```

### 5.2 任务提交与等待

```python
def submit_task(self, task_type, params=None, timeout=300):
    """提交任务给工作线程并等待结果"""
    task = FanqieTask(
        task_id=str(uuid.uuid4()),
        task_type=task_type,
        params=params or {}
    )

    # 加入队列
    with self._queue_lock:
        self._task_queue.append(task)

    # 等待任务完成
    completed = task.finished_event.wait(timeout=timeout)

    if not completed:
        return (False, f"Task {task_type.value} timed out")

    if task.error:
        return (False, task.error)

    return (True, task.result)
```

### 5.3 主流程使用示例

```python
# 主线程使用方式

# 1. 登录
worker.start()
success, result = worker.submit_task(
    FanqieTaskType.LOGIN,
    {'phone': '13800138000', 'password': 'xxx'}
)

# 2. 获取已发布章节
success, result = worker.submit_task(
    FanqieTaskType.GET_PUBLISHED_CHAPTERS,
    {'book_id': '123456'}
)
chapters = result.get('chapters', [])

# 3. 发布多个章节
for i, chapter_num in enumerate(range(1, 11)):
    success, result = worker.submit_task(
        FanqieTaskType.PUBLISH_CHAPTER,
        {
            'chapter_number': chapter_num,
            'chapter_title': f'第{chapter_num}章',
            'chapter_content': '章节内容...'
        }
    )

# 4. 关闭
worker.stop()
```

## 六、关键设计决策

### 6.1 为什么每个任务创建新 Page？

- **隔离性**：每个任务在独立页面执行，避免页面状态污染
- **并发**：虽然任务串行执行，但页面隔离确保操作独立性
- **稳定性**：某个任务失败不会影响其他任务或登录状态

### 6.2 为什么登录后不关闭 Page？

- **复用 Context**：登录创建的 Context 包含 cookies，是后续请求的凭证
- **状态保持**：Page 保持在作家后台，后续任务可以直接使用

### 6.3 为什么使用 expect_response 而不是 DOM 解析？

- **准确性**：API 返回的 JSON 数据比页面 DOM 更可靠
- **完整性**：DOM 可能随前端框架变化，而 API 数据结构更稳定
- **性能**：JSON 解析比遍历 DOM 更快

## 七、文件结构

```
src/
├── services/
│   ├── fanqie_publisher.py    # 浏览器发布器核心实现
│   ├── fanqie_book_service.py # 书籍服务（创建书等操作）
│   └── fanqie_worker.py       # 任务队列工作器 [修改]
└── gui/
    └── views/
        └── publishing_view.py  # 发布视图，使用 Worker [修改]
```

## 八、注意事项

1. **Greenlet 上下文问题**：`expect_response` 是异步 API，在跨绿色线程调用时会出错。解决方案是确保在正确的线程/页面上下文中调用。

2. **Page 替换机制**：`FanqiePublisher` 内部大量使用 `self.page`，通过临时替换 `self.page` 可以复用现有代码，不需要大规模重构。

3. **线程安全**：任务队列使用 `threading.Lock` 保护，确保主线程和工作线程安全交互。
