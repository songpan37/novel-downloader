# 全量获取番茄作品已发布章节列表

## 步骤1：进入章节管理页面
url格式：
https://fanqienovel.com/main/writer/chapter-manage/{书本id}&{书名}?type=1
url样例：
https://fanqienovel.com/main/writer/chapter-manage/7605250539030318105&%E6%9C%AB%E4%B8%96%E7%81%BE%E5%8F%98%EF%BC%9A%E6%88%91%E7%9A%84%E8%9A%81%E5%B7%A2%E6%97%A0%E9%99%90%E5%8D%87%E7%BA%A7?type=1

## 步骤2：遍历所有章节分页
章节分页导航如下：
```html
<div class="arco-pagination arco-pagination-size-default">
    <ul class="arco-pagination-list">
        <li class="arco-pagination-item arco-pagination-item-prev arco-pagination-item-disabled" tabindex="-1" aria-label="上一页">
            <svg fill="none" stroke="currentColor" stroke-width="4" viewBox="0 0 48 48" aria-hidden="true" focusable="false" class="arco-icon arco-icon-left">
                <path d="M32 8.4 16.444 23.956 32 39.513"></path>
            </svg>
        </li>
        <li class="arco-pagination-item arco-pagination-item-active" tabindex="0" aria-label="第 1 页" aria-current="true">1</li>
        <li class="arco-pagination-item" tabindex="0" aria-label="第 2 页">2</li>
        <li class="arco-pagination-item" tabindex="0" aria-label="第 3 页">3</li>
        <li class="arco-pagination-item" tabindex="0" aria-label="第 4 页">4</li>
        <li class="arco-pagination-item" tabindex="0" aria-label="第 5 页">5</li>
        <li class="arco-pagination-item" tabindex="0" aria-label="第 6 页">6</li>
        <li class="arco-pagination-item" tabindex="0" aria-label="第 7 页">7</li>
        <li class="arco-pagination-item arco-pagination-item-next" tabindex="0" aria-label="下一页">
            <svg fill="none" stroke="currentColor" stroke-width="4" viewBox="0 0 48 48" aria-hidden="true" focusable="false" class="arco-icon arco-icon-right">
                <path d="m16 39.513 15.556-15.557L16 8.4"></path>
            </svg>
        </li>
    </ul>
</div>
```
需要注意，如果章节数小于15章，是是不会有上述分页导航的，所以不要死板得去等这个分页导航。


进入页面后，默认在第1页，点击下一页按钮，直到最后一页。
达到最后一页时，分页导航变为如下格式，下一页多了arco-pagination-item-disabled类型：
```html
<div class="arco-pagination arco-pagination-size-default">
    <ul class="arco-pagination-list">
        <li class="arco-pagination-item arco-pagination-item-prev" tabindex="0" aria-label="上一页">
            <svg fill="none" stroke="currentColor" stroke-width="4" viewBox="0 0 48 48" aria-hidden="true" focusable="false" class="arco-icon arco-icon-left">
                <path d="M32 8.4 16.444 23.956 32 39.513"></path>
            </svg>
        </li>
        <li class="arco-pagination-item" tabindex="0" aria-label="第 1 页">1</li>
        <li class="arco-pagination-item" tabindex="0" aria-label="第 2 页">2</li>
        <li class="arco-pagination-item" tabindex="0" aria-label="第 3 页">3</li>
        <li class="arco-pagination-item" tabindex="0" aria-label="第 4 页">4</li>
        <li class="arco-pagination-item" tabindex="0" aria-label="第 5 页">5</li>
        <li class="arco-pagination-item" tabindex="0" aria-label="第 6 页">6</li>
        <li class="arco-pagination-item arco-pagination-item-active" tabindex="0" aria-label="第 7 页" aria-current="true">7</li>
        <li class="arco-pagination-item arco-pagination-item-next arco-pagination-item-disabled" tabindex="-1" aria-label="下一页">
            <svg fill="none" stroke="currentColor" stroke-width="4" viewBox="0 0 48 48" aria-hidden="true" focusable="false" class="arco-icon arco-icon-right">
                <path d="m16 39.513 15.556-15.557L16 8.4"></path>
            </svg>
        </li>
    </ul>
</div>
```

从进入页面，以及每次点击下一页都会有如下请求：
GET https://fanqienovel.com/api/author/chapter/chapter_list/v1?aid=2503&app_name=muye_novel&book_id=7605250539030318105&page_index=1&page_count=15&status=0&must_have_correction_feedback=0&need_correction_feedback_num=1&sort=&volume_id=7605250541479808025&msToken=HezKFdpDWiKC5Pe5FmXzqmJJdouk_Z0NQT8qUy3Co0eBT1OOP51bq2hnil8LbtBKT--SQCOjDprGkhm8K8glq8ZAIFeUqgw7Iyo87Nd14DZkOaVPrTDPmMkR73pz7G_5x1Rh3yutIN4B1VfHdsoMYaFLDslxTT9mw5X6Fog3T_MB&a_bogus=Qj0fhzyEQNmRepCG8Kk8eUPU8o2ANBSyvaT2RxkSyxPyPHFYacBDYOtrbxugJ7KtERpRwo9HAdzAODdcu84w1qCkwmkkSYTSds%2FcIX0ohqwvYz7QDqgQeuzFqwMOWYiN-Q2tiCyRlsMnZEclVNIEAd3Gt5FH-YmpWqZnpMT9nDCU3sgTVodAe3LAGhE%3D

该请求返回当前页的章节列表信息，如下是样例：
```json
{
    "code": 0,
    "data": {
        "total_count": 91,
        "total_fail_count": 0,
        "book_genre": 0,
        "item_list": [
            {
                "item_id": "7607374856908177945",
                "volume_id": "7605250541479808025",
                "index": 76,
                "title": "第76章 一个饺子让她浑身颤抖",
                "recommend_title": "",
                "recommend_editable": 0,
                "display_status": 1,
                "is_title_recommend": 0,
                "recommend_count_limit": 0,
                "recommend_count": 0,
                "article_status": 2,
                "recommend_status": 0,
                "create_time": "1772070900",
                "need_pay": 0,
                "price": 0,
                "word_number": 2136,
                "timer_time": "",
                "can_delete": 2,
                "mp_highlight_stage": 0,
                "sell_product_chapter": 0,
                "cant_modify_reason": "断更作品恢复连载后可修改",
                "correction_feedback_num": 0,
                "author_speak_audit_block": false,
                "timer_chapter_preview": null
            }
        ],
        "book_status": 1,
        "creation_status": 1,
        "book_write_extra_permission": 0,
        "book_extra_word_number": 0
    },
    "log_id": "202604081220213B0FAABB4A3E02BC5588",
    "message": "success"
}
```

将章节信息持久化下来，保存在本地章节元数据里（作品目录下的 chapters 目录）。