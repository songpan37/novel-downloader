# 番茄发布和更新章节流程

## 一、发布前准备

### 1.1 发布目录结构

用户配置的本地 publish 目录下的文件命名格式：
```
第{x}章 {章节标题}.txt
```

示例：
```
第1章 天还没亮，陆尘就醒了.txt
第2章 逆意燃血，凡人不屈.txt
第3章 夜行·百炼山.txt
第10章 离别青石镇.txt
第11章 绝杀铁背狼.txt
```

### 1.2 发布范围选择

用户在 UI 上选择要发布的章节范围（如 1-3 章），系统需要：

1. 扫描 publish 目录
2. 筛选出文件名符合 `第{x}章 {标题}.txt` 格式的文件
3. 解析文件名获取章节号（x）和章节标题
4. 读取文件内容作为章节正文

### 1.3 发布 vs 更新 判断

系统需要判断每个章节是**新发布**还是**更新已有**：

1. 调用 `GET_PUBLISHED_CHAPTERS` 获取番茄平台上已有的章节列表
2. 平台章节列表包含 `(chapter_id, chapter_number, chapter_title)`
3. 对于用户选择的每个本地章节：
   - 如果平台已有相同章节号 → **更新已有章节**
   - 如果平台没有该章节号 → **新发布章节**

---

## 二、新发布章节流程

URL：`https://fanqienovel.com/main/writer/{book_id}/publish/?enter_from=newchapter`

### 2.1 导航到新章节页面

```
https://fanqienovel.com/main/writer/{book_id}/publish/?enter_from=newchapter
```

### 2.2 填写章节信息

#### 输入章节号

在 `div.serial-editor-title-left span.left-input input` 中输入章节号（纯数字）：

```html
<div class="serial-editor-title-left none">
    <span>第</span>
    <span class="left-input">
        <input type="text" class="serial-input byte-input byte-input-size-default" value="">
    </span>
    <span>章</span>
</div>
```

#### 输入章节标题

在 `div.serial-editor-input-hint input[placeholder="请输入标题"]` 中输入标题：

```html
<div class="serial-editor-title-right">
    <div class="serial-editor-input-hint input">
        <input placeholder="请输入标题" class="serial-input serial-editor-input-hint-area..." value="">
    </div>
</div>
```

#### 输入章节正文

在 `div.ProseMirror[contenteditable="true"]` 中输入正文：

```html
<div contenteditable="true" translate="no" class="ProseMirror" spellcheck="false">
    <p>第一段内容...</p>
    <p>第二段内容...</p>
    <p>第三段内容...</p>
</div>
```

**注意**：每个段落用 `<p>` 标签包裹，填充时需要将文本按段落分割后用 `<p>` 包裹。

### 2.3 点击下一步

点击 `button span:has-text("下一步")`：

```html
<div class="publish-header-right">
    <button class="arco-btn arco-btn-secondary... publish-button auto-editor-next btn-primary-variant">
        <span>下一步</span>
    </button>
</div>
```

### 2.4 处理弹窗

点击下一步后可能弹出以下提示框，需要依次检查并处理：

#### 错别字提示

```html
<div role="dialog" aria-modal="true">
    <div class="arco-modal-content">检测到你还有错别字未修改，是否确定提交？</div>
    <div class="arco-modal-footer">
        <button><span>取消</span></button>
        <button><span>提交</span></button>  <!-- 点击提交 -->
    </div>
</div>
```

#### 作者有话说提示

```html
<div role="dialog" aria-modal="true">
    <div class="arco-modal-content">非章节内容请使用"作者有话说"功能...</div>
    <div class="arco-modal-footer">
        <button><span>取消</span></button>
        <button><span>提交</span></button>  <!-- 点击提交 -->
    </div>
</div>
```

#### 内容风险检测提示

```html
<div role="dialog" aria-modal="true" aria-labelledby="arco-dialog-6">
    <div class="arco-modal-header">
        <span>是否进行内容风险检测？</span>
    </div>
    <div class="arco-modal-content">开启后，小助手将为你标注当前章节可能存在的风险内容...</div>
    <div class="arco-modal-footer">
        <button><span>取消</span></button>
        <button><span>确定</span></button>  <!-- 点击确定 -->
    </div>
</div>
```

**处理方式**：每个弹窗最多等待 1 秒超时，如果出现则点击对应按钮，然后继续检查下一个弹窗。直到「发布设置」弹窗出现。

### 2.5 发布设置

#### 选择是否使用 AI

在「发布设置」弹窗中，选择「否」：

```html
<div class="arco-radio-group">
    <label>
        <input type="radio" value="1">  <!-- 第一个：是 -->
        <span class="arco-radio-text">是</span>
    </label>
    <label>
        <input type="radio" value="2">  <!-- 第二个：否，点击这个 -->
        <span class="arco-radio-text">否</span>
    </label>
</div>
```

#### 定时发布（可选）

如果用户配置了定时发布：
1. 点击开关启用定时发布
2. 设置发布日期（格式：`yyyy-MM-dd`）
3. 设置发布时间（格式：`HH:mm`）

如果用户未配置定时发布，保持关闭状态。

#### 点击确认发布

```html
<div class="arco-modal-footer">
    <button><span>取消</span></button>
    <button class="arco-btn-primary"><span>确认发布</span></button>
</div>
```

### 2.6 等待发布完成

监控接口响应：
```
POST https://fanqienovel.com/api/author/publish_article/v0/
```

成功响应：
```json
{
    "code": 0,
    "data": {
        "item_id": "7626727468778422808",
        "tips": ""
    },
    "message": "success"
}
```

**注意**：如果请求失败，重试最多 3 次。

---

## 三、更新已有章节流程

URL：`https://fanqienovel.com/main/writer/{book_id}/publish/?enter_from=editchapter&chapter_id={chapter_id}`

### 3.1 与新发布的区别

1. URL 包含 `chapter_id` 参数
2. 进入页面后，表单会预填充已有内容
3. 用户修改后点击「确认修改」而非「确认发布」

---

## 四、代码实现要点

### 4.1 文件名解析

```python
import re

def parse_chapter_file(filename):
    """从文件名解析章节号和标题"""
    # 文件名格式：第{num}章 {title}.txt
    match = re.match(r'^第(\d+)章\s+(.+)\.txt$', filename)
    if match:
        chapter_num = int(match.group(1))
        chapter_title = match.group(2)
        return chapter_num, chapter_title
    return None, None
```

### 4.2 正文填充为 HTML

```python
def content_to_prose_mirror_html(text):
    """将纯文本内容转换为 ProseMirror 格式的 HTML"""
    paragraphs = text.split('\n\n')  # 按双换行分割段落
    html_parts = []
    for p in paragraphs:
        p = p.strip()
        if p:
            html_parts.append(f'<p>{p}</p>')
    return ''.join(html_parts)
```

### 4.3 发布流程选择

```python
def should_update_or_publish(local_chapter_num, published_chapters):
    """判断是更新还是新发布"""
    for pub_ch in published_chapters:
        if pub_ch['chapter_number'] == local_chapter_num:
            return 'update', pub_ch['chapter_id']
    return 'publish', None
```

---

## 五、任务队列集成

发布和更新章节都通过 `FanqieWorker` 的任务队列执行：

| 任务类型 | 说明 | Page 管理 |
|---------|------|----------|
| `LOGIN` | 登录账号 | 创建 Page，登录后不关闭 |
| `GET_PUBLISHED_CHAPTERS` | 获取平台已发布章节 | 创建新 Page，执行后关闭 |
| `PUBLISH_CHAPTER` | 发布新章节 | 创建新 Page，执行后关闭 |
| `UPDATE_CHAPTER` | 更新已有章节 | 创建新 Page，执行后关闭 |
