# 批量创作流程设计方案

## 需求背景

当前创作流程每次只能处理用户选择的一段卷范围，完成后需要用户再次手动触发。期望增加批次控制功能，让用户可以选择每批大小，系统自动分批循环执行。

## 需求描述

用户选择创作卷范围（如 1-15 卷）和每批大小（如 3 卷），系统自动分批处理：
- 第1批：1-3 卷
- 第2批：4-6 卷
- 第3批：7-9 卷
- 第4批：10-12 卷
- 第5批：13-15 卷

每批完成后自动开始下一批，无需用户干预。所有批次完成后通知用户。

## 当前流程分析

### 关键文件

| 文件 | 职责 |
|------|------|
| `src/gui/main_window.py` | 外层控制逻辑 - UI 事件、对话框协调 |
| `src/gui/dialogs/volume_range_dialog.py` | 卷范围选择 UI |
| `src/gui/session_executor.py` | 内层创作逻辑 - AI 会话执行 |

### 当前调用链

```
用户点击"开始创作"
    ↓
_on_start_creation(work_id)
    ↓
_show_volume_range_dialog(work_id) → 弹出 VolumeRangeDialog
    ↓
用户选择 起始卷, 结束卷 → 点击"确认开始"
    ↓
_on_volume_range_confirmed(work_id, start_volume, end_volume)
    ↓
_start_ai_generation_flow(work_id, start_volume, end_volume, api_key)
    ↓
SessionExecutor.execute_session() → 递归执行所有会话
    ↓
全部完成后 → _on_creation_completed() → 通知用户
```

### 关键方法

| 方法 | 位置 | 作用 |
|------|------|------|
| `_show_volume_range_dialog()` | main_window.py:1478 | 显示卷范围对话框 |
| `_on_volume_range_confirmed()` | main_window.py:1740 | 处理用户确认，启动创作 |
| `_start_ai_generation_flow()` | main_window.py:1831 | 创建 AI 服务，启动会话执行器 |
| `_on_creation_completed()` | main_window.py:1933 | 创作完成回调 |
| `VolumeRangeDialog` | volume_range_dialog.py | 卷范围选择对话框 UI |

### SessionExecutor 内部循环机制

SessionExecutor 使用递归回调链处理卷：

```python
def _execute_volume_sessions_loop(current_session, total_sessions, vol_num):
    if vol_num > self.main_window._creation_end_volume:
        # 所有卷完成 → 进入章节会话
        self._execute_chapter_sessions_loop(...)
        return
    # 处理当前卷...
    self._execute_volume_session(vol_num, ...)
```

完成所有卷和章节后，最终调用 `main_window._on_creation_completed()`。

## 修改方案

### 修改文件清单

| 文件 | 修改内容 |
|------|---------|
| `src/gui/dialogs/volume_range_dialog.py` | 添加 batch_size 输入控件 |
| `src/gui/main_window.py` | 添加批次控制逻辑 |

---

### 修改 1: VolumeRangeDialog

**文件**: `src/gui/dialogs/volume_range_dialog.py`

#### 1.1 修改信号定义（第 24 行）

```python
# 修改前
range_confirmed = pyqtSignal(int, int)  # start_volume, end_volume

# 修改后
range_confirmed = pyqtSignal(int, int, int)  # start_volume, end_volume, batch_size
```

#### 1.2 添加 batch_size UI 控件

在 `_setup_end_volume_section()` 之后添加新方法：

```python
def _setup_batch_size_section(self, parent_layout):
    """设置每批大小输入区域"""
    section_layout = QHBoxLayout()
    section_layout.setSpacing(15)

    label = QLabel("每批卷数:")
    label.setObjectName("inputLabel")
    label.setFixedWidth(80)
    section_layout.addWidget(label)

    self.batch_size_input = QSpinBox()
    self.batch_size_input.setObjectName("volumeInput")
    self.batch_size_input.setRange(1, 20)
    self.batch_size_input.setValue(3)
    self.batch_size_input.setMinimumHeight(40)
    section_layout.addWidget(self.batch_size_input)

    hint_label = QLabel("(每批处理的卷数)")
    hint_label.setObjectName("hintLabel")
    section_layout.addWidget(hint_label)
    section_layout.addStretch()

    parent_layout.addLayout(section_layout)
```

#### 1.3 修改 `_setup_ui()` 方法

在 `form_layout.addStretch()` 之前添加：
```python
self._setup_batch_size_section(form_layout)
```

#### 1.4 修改 `_on_confirm()` 方法

```python
def _on_confirm(self) -> None:
    """处理确认按钮点击"""
    if self._validate():
        start = self.start_volume_input.value()
        end = self.end_volume_input.value()
        batch_size = self.batch_size_input.value()
        self.range_confirmed.emit(start, end, batch_size)
        self.accept()
```

---

### 修改 2: MainWindow

**文件**: `src/gui/main_window.py`

#### 2.1 添加实例变量

在类初始化或合适位置添加：
```python
self._creation_overall_start_volume = 1   # 用户选择的原始起始卷
self._creation_overall_end_volume = 3    # 用户选择的原始结束卷
self._creation_batch_size = 3            # 每批大小
self._creation_current_batch_start = 1    # 当前批次起始卷
self._creation_current_batch_end = 3      # 当前批次结束卷
```

#### 2.2 修改 `_show_volume_range_dialog()` 方法（第 1478 行）

对话框确认信号连接需要修改：
```python
# 修改前
dialog.range_confirmed.connect(lambda start, end: self._on_volume_range_confirmed(work_id, start, end))

# 修改后
dialog.range_confirmed.connect(lambda start, end, bs: self._on_volume_range_confirmed(work_id, start, end, bs))
```

#### 2.3 修改 `_on_volume_range_confirmed()` 方法（第 1740 行）

```python
def _on_volume_range_confirmed(
    self,
    work_id: str,
    start_volume: int,
    end_volume: int,
    batch_size: int = 3  # 新增参数
) -> None:
    """
    处理卷范围确认。启动实际 AI 生成流程。

    Args:
        work_id: 作品 ID
        start_volume: 起始卷号
        end_volume: 结束卷号
        batch_size: 每批大小（默认3）
    """
    try:
        self.logger.info(f"[CREATION] Volume range confirmed: work={work_id}, volumes={start_volume}-{end_volume}, batch_size={batch_size}")

        # 保存整体范围和批次大小
        self._creation_overall_start_volume = start_volume
        self._creation_overall_end_volume = end_volume
        self._creation_batch_size = batch_size

        # 计算第一批范围
        batch_start = start_volume
        batch_end = min(start_volume + batch_size - 1, end_volume)
        self._creation_current_batch_start = batch_start
        self._creation_current_batch_end = batch_end

        # ... 以下原有逻辑不变，但传入的是第一批范围 ...

        # 更新消息显示
        if batch_end < end_volume:
            self.notification_bar.show_message(
                f"开始创作：第{batch_start}-{batch_end}卷 (共{start_volume}-{end_volume}卷，分{batch_size}批)",
                'info',
                0
            )
        else:
            self.notification_bar.show_message(
                f"开始创作：第{batch_start}-{batch_end}卷",
                'info',
                0
            )

        # ... 后续逻辑不变 ...

        # 启动第一批生成
        self._start_ai_generation_flow(work_id, batch_start, batch_end, ai_settings.api_key)

    except Exception as e:
        # ... 错误处理不变 ...
```

#### 2.4 修改 `_on_creation_completed()` 方法（第 1933 行）

```python
def _on_creation_completed(self) -> None:
    """
    创作完成回调。检查是否还有下一批需要处理。
    """
    current_end = self._creation_current_batch_end
    overall_end = self._creation_overall_end_volume
    batch_size = self._creation_batch_size
    overall_start = self._creation_overall_start_volume

    # 计算下一批起始卷
    next_batch_start = current_end + 1

    if next_batch_start <= overall_end:
        # 还有下一批需要处理
        next_batch_end = min(next_batch_start + batch_size - 1, overall_end)
        self._creation_current_batch_start = next_batch_start
        self._creation_current_batch_end = next_batch_end

        self.logger.info(f"[CREATION_BATCH] Starting next batch: volumes {next_batch_start}-{next_batch_end}")

        # 显示进度消息
        total_batches = (overall_end - overall_start) // batch_size + 1
        current_batch = (next_batch_start - overall_start) // batch_size + 1
        self.notification_bar.show_message(
            f"继续创作：第{next_batch_start}-{next_batch_end}卷 (第{current_batch}批，共约{total_batches}批)",
            'info',
            0
        )

        # 自动开始下一批
        self._start_ai_generation_flow(
            self.creating_work_id,
            next_batch_start,
            next_batch_end,
            self.settings.ai_settings.api_key
        )
        return

    # 所有批次都完成了
    self.logger.info(f"[CREATION_COMPLETE] 所有创作流程完成 - 卷 {overall_start}-{overall_end}，分批处理结束")

    # ... 后续原有逻辑（清理状态、通知用户等）...
```

---

## 流程图（修改后）

```
用户选择: 1-15卷, 每批3卷
     ↓
_on_volume_range_confirmed(1, 15, 3)
     ↓
保存: overall_start=1, overall_end=15, batch_size=3
     ↓
计算第一批: batch_start=1, batch_end=min(1+3-1, 15)=3
     ↓
_start_ai_generation_flow(1, 3) → SessionExecutor 处理
     ↓
完成 → _on_creation_completed()
     ↓
next_batch_start = 3 + 1 = 4 ≤ 15 → YES
     ↓
计算第二批: batch_start=4, batch_end=min(4+3-1, 15)=6
     ↓
_start_ai_generation_flow(4, 6) → SessionExecutor 处理
     ↓
... (重复直到所有卷完成)
     ↓
完成 → _on_creation_completed()
     ↓
next_batch_start = 16 ≤ 15 → NO
     ↓
显示"创作完成"通知，清理状态
```

---

## 伪代码实现

### VolumeRangeDialog 修改

```python
class VolumeRangeDialog(QDialog):
    # 信号修改
    range_confirmed = pyqtSignal(int, int, int)  # 新增 batch_size

    def _setup_ui(self):
        # ... 原有 UI ...
        self._setup_batch_size_section(form_layout)  # 新增

    def _setup_batch_size_section(self, parent_layout):
        # 添加每批大小输入框
        self.batch_size_input = QSpinBox()
        self.batch_size_input.setRange(1, 20)
        self.batch_size_input.setValue(3)

    def _on_confirm(self):
        if self._validate():
            start = self.start_volume_input.value()
            end = self.end_volume_input.value()
            batch_size = self.batch_size_input.value()
            self.range_confirmed.emit(start, end, batch_size)  # 发送 batch_size
            self.accept()
```

### MainWindow 修改

```python
class MainWindow:
    def __init__(self):
        # 新增实例变量
        self._creation_overall_start_volume = 1
        self._creation_overall_end_volume = 3
        self._creation_batch_size = 3
        self._creation_current_batch_start = 1
        self._creation_current_batch_end = 3

    def _show_volume_range_dialog(self, work_id):
        dialog = VolumeRangeDialog(self, max_volumes=100)
        # 信号连接添加 batch_size 参数
        dialog.range_confirmed.connect(
            lambda start, end, bs: self._on_volume_range_confirmed(work_id, start, end, bs)
        )
        dialog.exec()

    def _on_volume_range_confirmed(self, work_id, start, end, batch_size=3):
        # 保存参数
        self._creation_overall_start_volume = start
        self._creation_overall_end_volume = end
        self._creation_batch_size = batch_size

        # 计算第一批
        batch_start = start
        batch_end = min(start + batch_size - 1, end)
        self._creation_current_batch_start = batch_start
        self._creation_current_batch_end = batch_end

        # 显示进度
        msg = f"开始创作：第{batch_start}-{batch_end}卷"
        if batch_end < end:
            msg += f" (共{start}-{end}卷，分{batch_size}批)"
        self.notification_bar.show_message(msg, 'info', 0)

        # 启动第一批
        self._start_ai_generation_flow(work_id, batch_start, batch_end, api_key)

    def _on_creation_completed(self):
        # 检查是否还有下一批
        next_start = self._creation_current_batch_end + 1
        overall_end = self._creation_overall_end_volume

        if next_start <= overall_end:
            # 有下一批，继续
            batch_end = min(next_start + self._creation_batch_size - 1, overall_end)
            self._creation_current_batch_start = next_start
            self._creation_current_batch_end = batch_end

            self.notification_bar.show_message(
                f"继续创作：第{next_start}-{batch_end}卷",
                'info', 0
            )

            self._start_ai_generation_flow(
                self.creating_work_id,
                next_start,
                batch_end,
                self.settings.ai_settings.api_key
            )
        else:
            # 所有批次完成
            self.logger.info(f"[CREATION_COMPLETE] 全部完成")
            # ... 原有清理和通知逻辑 ...
```

---

## 向后兼容性

- 默认 batch_size = 3，保证现有用户体验不变
- 如果用户选择 1-3 卷且 batch_size=3，效果与之前完全一致
- 已完成验证的卷会被 SessionExecutor 内部跳过，不影响断点续传

## 测试验证

1. **基本流程**: 选择 1-9 卷，每批 3 卷，应分 3 批完成
2. **边界情况**: 选择 1-1 卷，每批 3 卷，应直接开始并完成
3. **断点续传**: 如果某批次中断，已完成的卷会被跳过
4. **UI 显示**: 每批开始时消息应正确显示当前进度
