# 创作流程步骤提示词结构详解

## 概述

本文档描述每个步骤的**完整提示词**结构。

**完整提示词** = 有价值的上下文信息（按依赖顺序拼接）+ 该步骤的输出模板

---

## 基本设定会话

### 1. 文风设定

```
# 任务：生成小说语言风格设定报告

## 小说基本设定

小说类型：{novel_type}

创作指导：{creation_guide}

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

小说语言风格设定报告
小说类型：{novel_type}
文风类别：{literary_style_category}

【文风类别解读】
风格定义：[详细描述]
典型代表作品：[列举 2-3 部]
读者预期：[描述]

【叙事视角与节奏】
视角选择：[建议]
节奏控制：[建议]
时间处理：[建议]

【句式与语法特征】
句子长度：[建议]
句式结构：[建议]
段落特征：[建议]

【词汇与修辞选择】
词汇等级：[建议]
常用意象：[列举]
修辞手法：[建议]

【对话与人物语言】
对话风格：[建议]
方言与口音：[建议]
内心独白：[建议]

【风格一致性要求】
禁止出现：[明确列出不应出现的风格特征]

【重要】请直接输出文风设定内容，不需要额外的解释或说明。
```

---

### 2. 故事梗概

```
# 任务：生成小说故事梗概

## 小说基本设定

小说类型：{novel_type}

创作指导：{creation_guide}

## 已完成设定

文风设定：
{style_setting}

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

## 故事梗概要求
1. 主线清晰：明确主角的核心目标和动机
2. 冲突明确：设置主要矛盾和冲突
3. 结构完整：包含起承转合，有明确的结局方向
4. 字数要求：500-1000 字

## 格式要求
- 使用纯文本格式，不要使用 markdown
- 以"《书名》故事梗概"作为开头
- 分段描述：开头，发展、高潮、结局

【重要】请直接输出故事梗概内容，不需要额外的解释或说明。
```

---

### 3. 时空设定

```
# 任务：生成小说时空设定报告

## 小说基本设定

小说类型：{novel_type}

创作指导：{creation_guide}

## 已完成设定

文风设定：
{style_setting}

故事梗概：
{story_summary}

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

## 时空设定要求
1. 世界观构建：仙界/凡界/异界等
2. 力量体系：修炼等级、魔法体系等
3. 社会结构：宗门、家族、国家等
4. 地理环境：山川河流城池等

【重要】请直接输出时空设定内容，不需要额外的解释或说明。
```

---

### 4. 人物设定

```
# 任务：生成小说人物设定报告

## 小说基本设定

小说类型：{novel_type}

创作指导：{creation_guide}

## 已完成设定

文风设定：
{style_setting}

故事梗概：
{story_summary}

时空设定：
{worldbuilding}

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

## 人物设定要求
1. 主角设定：外貌、性格、背景、目标
2. 配角设定：主角相关的重要NPC
3. 反派设定：主要冲突来源
4. 人物关系：角色之间的关联

【重要】请直接输出人物设定内容，不需要额外的解释或说明。
```

---

### 5. 书名

```
# 任务：生成小说书名

## 小说基本设定

小说类型：{novel_type}

## 已完成设定

文风设定：
{style_setting}

故事梗概：
{story_summary}

时空设定：
{worldbuilding}

人物设定：
{character_design}

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

## 书名要求
1. 简洁有力：2-6个字
2. 吸引眼球：有记忆点
3. 类型匹配：符合小说风格
4. 避免重复：不要与知名作品重名

【重要】请直接输出书名内容，不需要额外的解释或说明。
```

---

### 6. 封面图片

```
# 任务：生成小说封面图片描述

## 小说基本设定

小说类型：{novel_type}

## 已完成设定

文风设定：
{style_setting}

故事梗概：
{story_summary}

时空设定：
{worldbuilding}

人物设定：
{character_design}

书名：
{book_title}

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

## 封面要求
1. 主体：主角或关键场景
2. 风格：与文风设定匹配
3. 色彩：冷色调/暖色调
4. 文字：书名放置位置

【重要】请直接输出封面描述内容，不需要额外的解释或说明。
```

---

## 创作参考会话

### 7. 拆书参考（每个参考作品一个）

```
# 任务：分析参考作品第{start_chapter}-{end_chapter}章的创作规律

## 参考作品信息

作品名称：{work_name}

## 参考作品正文内容

{reference_novel_content}

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

## 参考作品信息
作品名称：{work_name}
分析范围：第{start_chapter}-{end_chapter}章

## 分析内容

### 开篇模式分析
【开篇Hook】
- 具体写法：[描述]
- 效果评估：[分析]

【前情铺垫】
- 方式：[描述]
- 有效性：[评估]

### 节奏控制分析
【小高潮设置】
- 位置：[章节百分之几]
- 频率：[多少字一个]

【大高潮设置】
- 位置：[章节百分之几]
- 频率：[多少字一个]

### 人物塑造分析
【主角出场】
- 时机：[第几章]
- 方式：[如何介绍]

【配角互动】
- 模式：[描述]

### 伏笔与悬念
【伏笔设置】
- 类型：[明线/暗线]
- 埋设位置：[具体位置]
- 回收位置：[预期回收位置]

【悬念设置】
- 类型：[章节末/章节中]
- 具体例子：[引用]

### 章节结尾钩子
【结尾类型】
- 分类：[冲突型/疑问型/事件型等]
- 具体写法：[描述]

【效果评估】
- 吸引力：[评估]
- 可模仿性：[评估]

### 创作公式总结
【可复用的公式】
1. [公式1]
2. [公式2]
3. [公式3]

【注意事项】
- [列出创作时需要注意的点]

【重要】请直接输出拆书分析内容，不需要额外的解释或说明。
```

---

### 8. 创作公式

```
# 任务：基于拆书分析结果，总结创作公式

## 参考作品分析结果

{reference_1_analysis}

{reference_2_analysis}

（如果有更多参考作品，继续列出...）

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

## 创作公式要求
请综合以上拆书分析结果，总结适用于当前小说创作的公式：

### 开篇公式
【标准开篇模式】
- Hook设置：[具体公式]
- 前情铺垫：[公式]

### 节奏公式
【小高潮公式】
- 触发条件：[条件]
- 节奏：[多少字一次]
- 强度递增：[方式]

【大高潮公式】
- 触发条件：[条件]
- 节奏：[多少字一次]
- 收尾方式：[方式]

### 人物公式
【主角塑造】
- 出场公式：[公式]
- 成长公式：[公式]

【配角出场】
- 引出方式：[公式]
- 互动模式：[公式]

### 伏笔公式
【明线伏笔】
- 埋设位置：[公式]
- 回收时机：[公式]

【暗线伏笔】
- 埋设方式：[公式]
- 回收方式：[公式]

### 结尾公式
【章节结尾】
- 类型：[分类]
- 公式：[具体写法]

【卷末结尾】
- 类型：[分类]
- 公式：[具体写法]

【重要】请直接输出创作公式内容，不需要额外的解释或说明。
```

---

## 分卷信息会话

### 9. 分卷大纲

```
# 任务：生成第{vol_num}卷的详细分卷大纲

## 小说基本设定

小说类型：{novel_type}

## 已完成设定

故事梗概：
{story_summary}

时空设定：
{worldbuilding}

人物设定：
{character_design}

创作公式：
{pattern_analysis}

## 前序卷剧情总结（最多前3卷）

=== 第{vol_num-1}卷 剧情总结 ===
{volume_{vol_num-1}_summary_plot}

=== 第{vol_num-1}卷 人物总结 ===
{volume_{vol_num-1}_summary_character}

=== 第{vol_num-2}卷 剧情总结 ===
{volume_{vol_num-2}_summary_plot}

=== 第{vol_num-2}卷 人物总结 ===
{volume_{vol_num-2}_summary_character}

=== 第{vol_num-3}卷 剧情总结 ===
{volume_{vol_num-3}_summary_plot}

=== 第{vol_num-3}卷 人物总结 ===
{volume_{vol_num-3}_summary_character}

（如果不足3卷，则只列出实际存在的前序卷）

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

# 第{vol_num}卷 分卷大纲

## 本卷概述
【字数】：建议 {words_per_volume} 字
【主要情节线】：1-2条核心情节线

## 前序卷剧情回顾
[简要回顾前序卷的核心剧情发展]

## 章节安排
### 第1章
【章节主题】：
【核心事件】：
【出场人物】：
【情节发展】：
### 第2章
...

## 本卷高潮
【高潮设计】：
【高潮位置】：（第几章）

## 本卷结局
【结局类型】：
【结局内容】：

## 与下卷衔接
【伏笔埋设】：
【下卷预期】：

【重要】请直接输出分卷大纲内容，不需要额外的解释或说明。
```

---

### 10. 分卷人物

```
# 任务：生成第{vol_num}卷的分卷人物设定

## 小说基本设定

小说类型：{novel_type}

## 已完成设定

故事梗概：
{story_summary}

时空设定：
{worldbuilding}

人物设定：
{character_design}

创作公式：
{pattern_analysis}

## 前序卷剧情和人物总结（最多前3卷）

=== 第{vol_num-1}卷 剧情总结 ===
{volume_{vol_num-1}_summary_plot}

=== 第{vol_num-1}卷 人物总结 ===
{volume_{vol_num-1}_summary_character}

=== 第{vol_num-2}卷 剧情总结 ===
{volume_{vol_num-2}_summary_plot}

=== 第{vol_num-2}卷 人物总结 ===
{volume_{vol_num-2}_summary_character}

=== 第{vol_num-3}卷 剧情总结 ===
{volume_{vol_num-3}_summary_plot}

=== 第{vol_num-3}卷 人物总结 ===
{volume_{vol_num-3}_summary_character}

（如果不足3卷，则只列出实际存在的）

## 本卷大纲

{volume_outline}

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

# 第{vol_num}卷 人物设定

## 本卷新增人物
【人物1】
- 身份：
- 外貌：
- 性格：
- 背景：
- 在本卷中的作用：

## 本卷人物状态变化
【人物A】
- 前序状态：
- 本卷变化：
- 变化原因：

## 人物关系
【关系1】：人物A <-> 人物B
【关系描述】：

【重要】请直接输出分卷人物内容，不需要额外的解释或说明。
```

---

## 章节信息会话

### 11. 章节大纲

```
# 任务：生成第{vol_num}卷第{chap_num}章的章节大纲

## 小说基本设定

小说类型：{novel_type}

## 已完成设定

故事梗概：
{story_summary}

时空设定：
{worldbuilding}

人物设定：
{character_design}

创作公式：
{pattern_analysis}

## 前序卷剧情和人物总结（最多前3卷）

=== 第{vol_num-1}卷 剧情总结 ===
{volume_{vol_num-1}_summary_plot}

=== 第{vol_num-1}卷 人物总结 ===
{volume_{vol_num-1}_summary_character}

=== 第{vol_num-2}卷 剧情总结 ===
{volume_{vol_num-2}_summary_plot}

=== 第{vol_num-2}卷 人物总结 ===
{volume_{vol_num-2}_summary_character}

=== 第{vol_num-3}卷 剧情总结 ===
{volume_{vol_num-3}_summary_plot}

=== 第{vol_num-3}卷 人物总结 ===
{volume_{vol_num-3}_summary_character}

（如果不足3卷，则只列出实际存在的）

## 本卷分卷大纲和人物

=== 第{vol_num}卷 分卷大纲 ===
{volume_outline}

=== 第{vol_num}卷 分卷人物 ===
{volume_characters}

## 前序章节信息

=== 第{vol_num}卷 第{chap_num-1}章 章节大纲 ===
{chapter_{vol_num}_{chap_num-1}_outline}

=== 第{vol_num}卷 第{chap_num-1}章 章节正文 ===
{chapter_{vol_num}_{chap_num-1}_content}

（只列出前1章，不需要更多）

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

# 章节细纲 - 第{vol_num}卷 第{chap_num}章

## 基本信息
- 章节号：第{chap_num}章
- 章节名：[为本章拟定一个有吸引力的名称]
- 核心功能：[从以下选择 - 引入主角/建立目标/升级能力/结识盟友/树立敌人/情感发展/铺垫伏笔/小型高潮/过渡衔接]
- 时间/地点：[明确的时间段和地点]

## 本章目标（主角）
[主角在本章的主要人物要实现的直接、具体的目标]

## 情绪基调
[例如：绝望与错愕交织 → 冰冷的急迫感]

## 本章出场人物
- [人物 1]：[在本章的作用]
- [人物 2]：[在本章的作用]
- ...

## 场景序列与情节推演

### 场景 1：[场景名]
- 开端：[场景如何开始，初始状态]
- 发展与冲突：[情节如何推进，遇到什么冲突]
- 转折/结果：[如何转折，最终结果是什么]
- 关键细节/风格提示：[必须包含的具体动作、对话、内心独白或环境细节]

### 场景 2：[场景名]
- 开端：[...]
- 发展与冲突：[...]
- 转折/结果：[...]
- 关键细节/风格提示：[...]

（继续其他场景）

## 伏笔与后续关联
- 本章埋下的伏笔：[明确列出]
- 与后续章节的关联：[预期在哪个章节呼应]

## 爽点设计
- 爽点位置：[第几个场景]
- 爽点类型：[打脸/碾压/反转/揭示等]
- 设计方式：[如何设计这个爽点]

## 剧情连贯性要求
- 本章开头必须紧接着前序章节的结尾剧情继续发展
- 一定不要重复前序章节已经写过的剧情内容
- 保持人物性格、关系状态、剧情节奏的连贯性
- 确保场景转换自然，不能有割裂感

【重要】请直接输出章节大纲内容，不需要额外的解释或说明。
```

---

### 12. 章节正文

```
# 任务：生成第{vol_num}卷第{chap_num}章的章节正文

## 小说基本设定

小说类型：{novel_type}

## 已完成设定

故事梗概：
{story_summary}

时空设定：
{worldbuilding}

人物设定：
{character_design}

创作公式：
{pattern_analysis}

## 前序卷剧情和人物总结（最多前3卷）

=== 第{vol_num-1}卷 剧情总结 ===
{volume_{vol_num-1}_summary_plot}

=== 第{vol_num-1}卷 人物总结 ===
{volume_{vol_num-1}_summary_character}

=== 第{vol_num-2}卷 剧情总结 ===
{volume_{vol_num-2}_summary_plot}

=== 第{vol_num-2}卷 人物总结 ===
{volume_{vol_num-2}_summary_character}

=== 第{vol_num-3}卷 剧情总结 ===
{volume_{vol_num-3}_summary_plot}

=== 第{vol_num-3}卷 人物总结 ===
{volume_{vol_num-3}_summary_character}

（如果不足3卷，则只列出实际存在的）

## 本卷分卷大纲和人物

=== 第{vol_num}卷 分卷大纲 ===
{volume_outline}

=== 第{vol_num}卷 分卷人物 ===
{volume_characters}

## 前序章节信息

=== 第{vol_num}卷 第{chap_num-1}章 章节大纲 ===
{chapter_{vol_num}_{chap_num-1}_outline}

=== 第{vol_num}卷 第{chap_num-1}章 章节正文 ===
{chapter_{vol_num}_{chap_num-1}_content}

（只列出前1章，不需要更多）

## 本章章节大纲

{chapter_outline}

## 格式要求

请严格按照以下要求创作（使用纯文本格式，不要使用 markdown 格式）：

## 核心创作要求
1. 严格遵循章节细纲为唯一剧情框架
2. 每个场景下的"关键细节/风格提示"是必须展开的刚性要求
3. 不得偏离、省略或更改核心事件与逻辑
4. 章节正文字数在 2000 字以上
5. 不要用多余的环境描写、修辞手法等来凑字数
6. 保持节奏紧凑，避免注水

## 创作技巧
1. 开篇钩子：第一段必须抓住读者注意力，可以用动作、对话、悬念或强烈情绪开场
2. 场景转换：场景之间过渡自然，用空行或时间/地点提示语区分场景
3. 对话写作：对话要符合人物身份和性格，避免冗长的说教式对话，用对话推动剧情或展现人物关系
4. 动作描写：动作场面要干净利落，用短句增强节奏感，突出关键动作的细节

## 剧情连贯性要求
- 依照前序章节的正文内容，接着往下生成
- 本章开头必须紧接着前序章节的结尾剧情继续发展
- 一定不要重复前序章节已经写过的剧情内容
- 保持人物性格、关系状态、剧情节奏的连贯性
- 确保场景转换自然，不能有割裂感

## 输出要求
- 只输出创作正文
- 正文结束后无需总结
- 不要在章节开头加上章节名

【重要】请直接输出章节正文内容，不需要额外的解释或说明。
```

---

### 13. 章节标题

```
# 任务：生成第{vol_num}卷第{chap_num}章的章节标题

## 本章章节正文

{chapter_content}

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

## 章节标题要求
1. 简洁有力：4-8个字
2. 吸引眼球：有记忆点或悬念
3. 符合文风：与小说整体风格一致
4. 不要与已有章节标题重复

【重要】请直接输出章节标题内容，不需要额外的解释或说明。
```

---

### 14. 剧情总结

```
# 任务：生成第{vol_num}卷的剧情总结

## 小说基本设定

小说类型：{novel_type}

## 已完成设定

故事梗概：
{story_summary}

时空设定：
{worldbuilding}

人物设定：
{character_design}

创作公式：
{pattern_analysis}

## 前序卷剧情和人物总结（最多前3卷）

=== 第{vol_num-1}卷 剧情总结 ===
{volume_{vol_num-1}_summary_plot}

=== 第{vol_num-1}卷 人物总结 ===
{volume_{vol_num-1}_summary_character}

=== 第{vol_num-2}卷 剧情总结 ===
{volume_{vol_num-2}_summary_plot}

=== 第{vol_num-2}卷 人物总结 ===
{volume_{vol_num-2}_summary_character}

=== 第{vol_num-3}卷 剧情总结 ===
{volume_{vol_num-3}_summary_plot}

=== 第{vol_num-3}卷 人物总结 ===
{volume_{vol_num-3}_summary_character}

（如果不足3卷，则只列出实际存在的）

## 本卷分卷大纲和人物

=== 第{vol_num}卷 分卷大纲 ===
{volume_outline}

=== 第{vol_num}卷 分卷人物 ===
{volume_characters}

## 本卷所有章节

=== 第{vol_num}卷 第1章 大纲 ===
{chapter_{vol_num}_1_outline}

=== 第{vol_num}卷 第1章 正文 ===
{chapter_{vol_num}_1_content}

=== 第{vol_num}卷 第2章 大纲 ===
{chapter_{vol_num}_2_outline}

=== 第{vol_num}卷 第2章 正文 ===
{chapter_{vol_num}_2_content}

（如果有更多章节，继续列出...）

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

# 第{vol_num}卷 剧情总结

## 主线剧情
[按时间顺序梳理本卷的核心事件]

## 重要转折
[列出本卷中1-3个重要转折点]

## 伏笔与悬念
[整理本卷埋下的伏笔和悬念]

## 与下卷关联
[本卷结尾与下卷开头的衔接点]

【重要】请直接输出剧情总结内容，不需要额外的解释或说明。
```

---

### 15. 人物总结

```
# 任务：生成第{vol_num}卷的人物状态总结

## 小说基本设定

小说类型：{novel_type}

## 已完成设定

故事梗概：
{story_summary}

时空设定：
{worldbuilding}

人物设定：
{character_design}

创作公式：
{pattern_analysis}

## 前序卷剧情和人物总结（最多前3卷）

=== 第{vol_num-1}卷 剧情总结 ===
{volume_{vol_num-1}_summary_plot}

=== 第{vol_num-1}卷 人物总结 ===
{volume_{vol_num-1}_summary_character}

=== 第{vol_num-2}卷 剧情总结 ===
{volume_{vol_num-2}_summary_plot}

=== 第{vol_num-2}卷 人物总结 ===
{volume_{vol_num-2}_summary_character}

=== 第{vol_num-3}卷 剧情总结 ===
{volume_{vol_num-3}_summary_plot}

=== 第{vol_num-3}卷 人物总结 ===
{volume_{vol_num-3}_summary_character}

（如果不足3卷，则只列出实际存在的）

## 本卷分卷大纲和人物

=== 第{vol_num}卷 分卷大纲 ===
{volume_outline}

=== 第{vol_num}卷 分卷人物 ===
{volume_characters}

## 本卷所有章节

=== 第{vol_num}卷 第1章 大纲 ===
{chapter_{vol_num}_1_outline}

=== 第{vol_num}卷 第1章 正文 ===
{chapter_{vol_num}_1_content}

=== 第{vol_num}卷 第2章 大纲 ===
{chapter_{vol_num}_2_outline}

=== 第{vol_num}卷 第2章 正文 ===
{chapter_{vol_num}_2_content}

（如果有更多章节，继续列出...）

## 格式要求

请严格按照以下格式输出（使用纯文本格式，不要使用 markdown 格式）：

# 第{vol_num}卷 人物状态总结

## 人物状态变化
【人物1】
- 初始状态：[本卷开始时的状态]
- 结束状态：[本卷结束时的状态]
- 变化原因：[导致变化的核心事件]

## 人物关系变化
【关系1】：人物A <-> 人物B
- 变化前：[之前的关系状态]
- 变化后：[当前的关系状态]
- 变化原因：[导致变化的事件]

## 下卷预期
[基于本卷人物状态，预期下卷的发展方向]

【重要】请直接输出人物总结内容，不需要额外的解释或说明。
```

---

## 步骤提示词速查表

| 步骤ID | 上下文信息 |
|--------|----------|
| 文风设定 | novel_type, creation_guide |
| 故事梗概 | novel_type, creation_guide, style_setting |
| 时空设定 | novel_type, creation_guide, style_setting, story_summary |
| 人物设定 | novel_type, creation_guide, style_setting, story_summary, worldbuilding |
| 书名 | novel_type, style_setting, story_summary, worldbuilding, character_design |
| 封面图片 | novel_type, style_setting, story_summary, worldbuilding, character_design, book_title |
| 拆书参考 | work_name, reference_novel_content |
| 创作公式 | all_reference_analyses |
| 分卷大纲 | novel_type, story_summary, worldbuilding, character_design, pattern_analysis, previous_3_volumes_summaries |
| 分卷人物 | novel_type, story_summary, worldbuilding, character_design, pattern_analysis, previous_3_volumes_summaries, volume_outline |
| 章节大纲 | novel_type, story_summary, worldbuilding, character_design, pattern_analysis, previous_3_volumes_summaries, volume_outline, volume_characters, previous_1_chapter |
| 章节正文 | novel_type, story_summary, worldbuilding, character_design, pattern_analysis, previous_3_volumes_summaries, volume_outline, volume_characters, previous_1_chapter, chapter_outline |
| 章节标题 | chapter_content |
| 剧情总结 | novel_type, story_summary, worldbuilding, character_design, pattern_analysis, previous_3_volumes_summaries, volume_outline, volume_characters, all_chapters |
| 人物总结 | novel_type, story_summary, worldbuilding, character_design, pattern_analysis, previous_3_volumes_summaries, volume_outline, volume_characters, all_chapters |

---

## 占位符说明

| 占位符 | 含义 | 来源 |
|--------|------|------|
| `{novel_type}` | 小说类型 | work_data |
| `{creation_guide}` | 创作指导 | work_data |
| `{style_setting}` | 文风设定 | steps/style_setting.txt |
| `{story_summary}` | 故事梗概 | steps/story_summary.txt |
| `{worldbuilding}` | 时空设定 | steps/worldbuilding.txt |
| `{character_design}` | 人物设定 | steps/character_design.txt |
| `{book_title}` | 书名 | steps/book_title.txt |
| `{pattern_analysis}` | 创作公式 | steps/pattern_*.txt |
| `{work_name}` | 参考作品名称 | 从参考作品文件名提取 |
| `{reference_novel_content}` | 参考作品正文 | 从参考作品文件加载 |
| `{reference_N_analysis}` | 参考作品拆书结果 | steps/reference_*.txt |
| `{volume_N_summary_plot}` | 第N卷剧情总结 | steps/volume_N_summary_plot.txt |
| `{volume_N_summary_character}` | 第N卷人物总结 | steps/volume_N_summary_character.txt |
| `{volume_outline}` | 本卷分卷大纲 | steps/volume_N.txt |
| `{volume_characters}` | 本卷分卷人物 | steps/volume_N_characters.txt |
| `{chapter_N_M_outline}` | 第N卷第M章大纲 | steps/chapter_N_M_outline.txt |
| `{chapter_N_M_content}` | 第N卷第M章正文 | steps/chapter_N_M_content.txt |

---

# 代码修改方案

## 需求概述

### "提示词"按钮
- 检查 `steps/{step_id}_prompt.txt` 是否存在
- 存在 → 直接加载并显示
- 不存在 → 实时生成完整提示词并显示（**不自动保存**）
- 用户可手动点"保存"保存到steps目录

### "重新生成"按钮
- 检查 `steps/{step_id}_prompt.txt` 是否存在
- 存在 → 直接使用
- 不存在 → 实时生成完整提示词，**保存到steps目录**，然后使用
- 发送提示词到DeepSeek，获取结果，替换原步骤文件

---

## 文件修改清单

| 文件 | 修改内容 |
|------|----------|
| `src/gui/main_window.py` | 新增方法，修改按钮逻辑 |
| `src/gui/views/creation_view.py` | 无需修改 |
| `src/gui/dialogs/template_edit_dialog.py` | 无需修改 |

---

## 核心方法

### 1. `_generate_complete_prompt(work_id, step_id) -> str`

生成某个步骤的完整提示词。

```python
def _generate_complete_prompt(self, work_id: str, step_id: str) -> str:
    """
    生成某个步骤的完整提示词。
    
    完整提示词 = 有价值的上下文信息 + 输出模板
    
    Args:
        work_id: 作品ID
        step_id: 步骤ID
        
    Returns:
        完整的提示词字符串
    """
    # 1. 确定步骤类型
    step_type = self._get_step_type(step_id)
    
    # 2. 加载上下文信息
    context = self._load_step_context(work_id, step_id, step_type)
    
    # 3. 拼接上下文信息部分
    context_section = self._build_context_section(step_type, context)
    
    # 4. 加载输出模板
    output_template = self._get_output_template(step_id, step_type)
    
    # 5. 拼接完整提示词
    return context_section + "\n\n" + output_template
```

---

### 2. `_get_step_type(step_id) -> str`

判断步骤类型。

```python
def _get_step_type(self, step_id: str) -> str:
    """
    判断步骤类型。
    
    Returns:
        步骤类型：'basic', 'reference', 'pattern', 'volume', 'chapter', 'chapter_title', 'summary_plot', 'summary_character'
    """
    if step_id in ['style_setting', 'book_title', 'story_summary', 'worldbuilding', 'character_design', 'cover_image']:
        return 'basic'
    elif step_id.startswith('reference_'):
        return 'reference'
    elif step_id.startswith('pattern_'):
        return 'pattern'
    elif step_id.startswith('volume_') and '_summary' not in step_id and '_characters' not in step_id:
        return 'volume'
    elif step_id.startswith('volume_') and '_characters' in step_id:
        return 'volume_characters'
    elif step_id.startswith('chapter_') and '_title' in step_id:
        return 'chapter_title'
    elif step_id.startswith('chapter_') and '_outline' in step_id:
        return 'chapter_outline'
    elif step_id.startswith('chapter_') and '_content' in step_id:
        return 'chapter_content'
    elif '_summary_plot' in step_id:
        return 'summary_plot'
    elif '_summary_character' in step_id:
        return 'summary_character'
    return 'unknown'
```

---

### 3. `_load_step_context(work_id, step_id, step_type) -> dict`

根据步骤类型，加载所需的上下文信息。

```python
def _load_step_context(self, work_id: str, step_id: str, step_type: str) -> dict:
    """
    加载步骤所需的上下文信息。
    
    Returns:
        上下文字典
    """
    context = {}
    steps_dir = f"{self.settings.works_dir}/{work_id}/steps"
    
    # === 基本设定 ===
    # novel_type, creation_guide - 来自 work_data
    work_data = self.work_manager.get_work(work_id).to_dict() if self.work_manager.get_work(work_id) else {}
    context['novel_type'] = work_data.get('novel_type', '')
    context['creation_guide'] = work_data.get('creation_guide', '')
    
    # === 基础设定步骤内容 ===
    if step_type != 'reference' and step_type != 'pattern':
        # style_setting
        context['style_setting'] = self._read_file_safe(f"{steps_dir}/style_setting.txt")
        
        # story_summary
        if step_type not in ['basic_style_setting']:
            context['story_summary'] = self._read_file_safe(f"{steps_dir}/story_summary.txt")
        
        # worldbuilding
        if step_type not in ['basic_style_setting', 'basic_story_summary']:
            context['worldbuilding'] = self._read_file_safe(f"{steps_dir}/worldbuilding.txt")
        
        # character_design
        if step_type not in ['basic_style_setting', 'basic_story_summary', 'basic_worldbuilding']:
            context['character_design'] = self._read_file_safe(f"{steps_dir}/character_design.txt")
        
        # book_title
        if step_type == 'cover_image':
            context['book_title'] = self._read_file_safe(f"{steps_dir}/book_title.txt")
    
    # === 拆书参考 ===
    if step_type == 'reference':
        # 从 step_id 解析 work_name, start_chapter, end_chapter
        # reference_{work_name}_{start}_{end}
        parts = step_id.split('_')
        # TODO: 解析参考作品信息
        context['work_name'] = 'TODO'  # 需要从step_id解析
        context['reference_novel_content'] = 'TODO'  # 需要从参考作品文件加载
    
    # === 创作公式 ===
    if step_type == 'pattern':
        # 加载所有参考作品的分析结果
        context['all_reference_analyses'] = 'TODO'  # 需要收集所有 reference_* 文件内容
    
    # === 分卷信息 ===
    if step_type in ['volume', 'volume_characters', 'chapter_outline', 'chapter_content', 'chapter_title', 'summary_plot', 'summary_character']:
        # 加载创作公式
        pattern_file = self._find_pattern_file(steps_dir)
        if pattern_file:
            context['pattern_analysis'] = self._read_file_safe(f"{steps_dir}/{pattern_file}")
        
        # 加载前3卷的总结
        vol_num = self._parse_volume_number(step_id)
        for prev_vol in range(max(1, vol_num - 3), vol_num):
            context[f'volume_{prev_vol}_summary_plot'] = self._read_file_safe(f"{steps_dir}/volume_{prev_vol}_summary_plot.txt")
            context[f'volume_{prev_vol}_summary_character'] = self._read_file_safe(f"{steps_dir}/volume_{prev_vol}_summary_character.txt")
        
        # 加载本卷大纲和人物
        if step_type != 'volume':
            context['volume_outline'] = self._read_file_safe(f"{steps_dir}/volume_{vol_num}.txt")
            context['volume_characters'] = self._read_file_safe(f"{steps_dir}/volume_{vol_num}_characters.txt")
    
    # === 章节信息 ===
    if step_type in ['chapter_outline', 'chapter_content', 'chapter_title']:
        chap_num = self._parse_chapter_number(step_id)
        vol_num = self._parse_volume_number(step_id)
        
        # 加载前1章的内容
        if chap_num > 1:
            prev_chap = chap_num - 1
            context['previous_chapter_outline'] = self._read_file_safe(f"{steps_dir}/chapter_{vol_num}_{prev_chap}_outline.txt")
            context['previous_chapter_content'] = self._read_file_safe(f"{steps_dir}/chapter_{vol_num}_{prev_chap}_content.txt")
        
        # 加载本章节大纲（仅章节正文需要）
        if step_type == 'chapter_content':
            context['chapter_outline'] = self._read_file_safe(f"{steps_dir}/chapter_{vol_num}_{chap_num}_outline.txt")
        
        # 加载本章节正文（仅章节标题需要）
        if step_type == 'chapter_title':
            context['chapter_content'] = self._read_file_safe(f"{steps_dir}/chapter_{vol_num}_{chap_num}_content.txt")
    
    # === 总结步骤 ===
    if step_type in ['summary_plot', 'summary_character']:
        vol_num = self._parse_volume_number(step_id)
        # 加载本卷所有章节
        context['all_chapters'] = self._load_all_chapters_content(steps_dir, vol_num)
    
    return context
```

---

### 4. `_build_context_section(step_type: str, context: dict) -> str`

根据步骤类型，拼接上下文信息部分。

```python
def _build_context_section(self, step_type: str, context: dict) -> str:
    """
    拼接上下文信息部分。
    """
    lines = []
    
    # === 基本设定会话 ===
    if step_type == 'basic_style_setting':
        lines.append("# 任务：生成小说语言风格设定报告")
        lines.append("")
        lines.append("## 小说基本设定")
        lines.append("")
        lines.append(f"小说类型：{context.get('novel_type', '')}")
        if context.get('creation_guide'):
            lines.append(f"创作指导：{context.get('creation_guide', '')}")
        return '\n'.join(lines)
    
    if step_type == 'basic_story_summary':
        lines.append("# 任务：生成小说故事梗概")
        lines.append("")
        lines.append("## 小说基本设定")
        lines.append(f"小说类型：{context.get('novel_type', '')}")
        if context.get('creation_guide'):
            lines.append(f"创作指导：{context.get('creation_guide', '')}")
        lines.append("")
        lines.append("## 已完成设定")
        lines.append("")
        lines.append("文风设定：")
        lines.append(context.get('style_setting', ''))
        return '\n'.join(lines)
    
    # ... 其他步骤类型类似
    
    # === 章节标题（最简，只有一段）===
    if step_type == 'chapter_title':
        lines.append("# 任务：生成第{vol_num}卷第{chap_num}章的章节标题")
        lines.append("")
        lines.append("## 本章章节正文")
        lines.append("")
        lines.append(context.get('chapter_content', ''))
        return '\n'.join(lines)
    
    return '\n'.join(lines)
```

---

### 5. `_get_output_template(step_id: str, step_type: str) -> str`

获取步骤的输出模板。

```python
def _get_output_template(self, step_id: str, step_type: str) -> str:
    """
    获取步骤的输出模板。
    
    Returns:
        输出模板字符串
    """
    from models.template import get_default_template
    
    # 模板类别映射
    template_map = {
        'basic_style_setting': '文风设定',
        'basic_story_summary': '故事梗概',
        'basic_worldbuilding': '时空设定',
        'basic_character_design': '人物设定',
        'basic_book_title': '书名',
        'basic_cover_image': '封面图片',
        'reference': '拆书参考',
        'pattern': '创作公式',
        'volume': '分卷大纲',
        'volume_characters': '分卷人物',
        'chapter_outline': '章节大纲',
        'chapter_content': '章节正文',
        'chapter_title': '章节标题',
        'summary_plot': '剧情总结',
        'summary_character': '人物总结',
    }
    
    category = template_map.get(step_type)
    if not category:
        return ""
    
    template = get_default_template(category, self._get_templates_dir())
    return template.content if template else ""
```

---

## 按钮逻辑修改

### "提示词"按钮 (`_on_template_button_clicked`)

```python
def _on_template_button_clicked(self) -> None:
    """Handle template button click - show template edit dialog."""
    if not hasattr(self, '_current_action_step_id') or not self.current_work_id:
        return
    
    step_id = self._current_action_step_id
    work_id = self.current_work_id
    
    # 检查 steps/{step_id}_prompt.txt 是否存在
    prompt_file = self._get_prompt_file_path(work_id, step_id)
    
    if os.path.exists(prompt_file):
        # 存在：直接加载
        with open(prompt_file, 'r', encoding='utf-8') as f:
            prompt_content = f.read()
    else:
        # 不存在：实时生成
        prompt_content = self._generate_complete_prompt(work_id, step_id)
        # 注意：不自动保存，只显示
    
    # 发射信号显示对话框
    self.template_edit_requested.emit(work_id, step_id, self._current_action_step_name, prompt_content)
```

### "重新生成"按钮 (`_start_regeneration`)

```python
def _start_regeneration(self, work_id: str, step_id: str) -> None:
    """Start regeneration process for a step."""
    self.logger.info(f"[REGENERATE] Starting regeneration for step: {step_id}")
    
    # 检查 steps/{step_id}_prompt.txt 是否存在
    prompt_file = self._get_prompt_file_path(work_id, step_id)
    
    if os.path.exists(prompt_file):
        # 存在：直接加载
        with open(prompt_file, 'r', encoding='utf-8') as f:
            prompt = f.read()
    else:
        # 不存在：实时生成并保存
        prompt = self._generate_complete_prompt(work_id, step_id)
        
        # 保存到 steps/{step_id}_prompt.txt
        os.makedirs(os.path.dirname(prompt_file), exist_ok=True)
        with open(prompt_file, 'w', encoding='utf-8') as f:
            f.write(prompt)
        self.logger.info(f"[REGENERATE] Saved prompt to {prompt_file}")
    
    # 继续执行重新生成逻辑...
    self._start_independent_regeneration(work_id, step_id, step_name, prompt)
```

---

## 辅助方法

### `_get_prompt_file_path(work_id, step_id) -> str`

```python
def _get_prompt_file_path(self, work_id: str, step_id: str) -> str:
    """获取步骤提示词文件路径。"""
    steps_dir = f"{self.settings.works_dir}/{work_id}/steps"
    return f"{steps_dir}/{step_id}_prompt.txt"
```

### `_read_file_safe(file_path: str) -> str`

```python
def _read_file_safe(self, file_path: str) -> str:
    """安全读取文件，不存在则返回空字符串。"""
    try:
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
    except Exception as e:
        self.logger.warning(f"[FILE_READ] Failed to read {file_path}: {e}")
    return ""
```

### `_find_pattern_file(steps_dir: str) -> str`

```python
def _find_pattern_file(self, steps_dir: str) -> str:
    """查找创作公式文件。"""
    import glob
    pattern_files = glob.glob(f"{steps_dir}/pattern_*.txt")
    return os.path.basename(pattern_files[0]) if pattern_files else ""
```

### `_parse_volume_number(step_id: str) -> int`

```python
def _parse_volume_number(self, step_id: str) -> int:
    """从step_id解析卷号。"""
    # volume_1 -> 1
    # volume_1_characters -> 1
    # chapter_1_3_outline -> 1
    # volume_1_summary_plot -> 1
    match = re.search(r'volume_(\d+)', step_id)
    if match:
        return int(match.group(1))
    match = re.search(r'chapter_(\d+)_(\d+)', step_id)
    if match:
        return int(match.group(1))
    return 1
```

### `_parse_chapter_number(step_id: str) -> int`

```python
def _parse_chapter_number(self, step_id: str) -> int:
    """从step_id解析章号。"""
    # chapter_1_3_outline -> 3
    match = re.search(r'chapter_\d+_(\d+)', step_id)
    if match:
        return int(match.group(1))
    return 1
```

---

## 修改位置汇总

| 方法 | 位置 | 修改类型 |
|------|------|----------|
| `_generate_complete_prompt` | `main_window.py` | 新增 |
| `_get_step_type` | `main_window.py` | 新增 |
| `_load_step_context` | `main_window.py` | 新增 |
| `_build_context_section` | `main_window.py` | 新增 |
| `_get_output_template` | `main_window.py` | 新增 |
| `_get_prompt_file_path` | `main_window.py` | 新增 |
| `_read_file_safe` | `main_window.py` | 新增 |
| `_find_pattern_file` | `main_window.py` | 新增 |
| `_parse_volume_number` | `main_window.py` | 新增 |
| `_parse_chapter_number` | `main_window.py` | 新增 |
| `_on_template_button_clicked` | `main_window.py` | 修改 |
| `_start_regeneration` | `main_window.py` | 修改 |
| `template_edit_requested` | `creation_view.py` 信号 | 修改（增加参数） |

---

## 注意事项

1. **模板解析**：需要使用 `models.template.get_default_template` 方法获取模板
2. **文件路径**：提示词文件命名格式为 `{step_id}_prompt.txt`
3. **章节标题**：是唯一只需要章节正文内容的步骤
4. **前序卷**：最多追溯前3卷的内容
5. **前序章节**：只需要前1章的内容
