#!/usr/bin/env python
"""
Setup script for pytest-qt test environment.

Installs required dependencies and verifies the test environment.

Usage:
    python setup_tests.py
"""
import subprocess
import sys
import os


def install_package(package):
    """Install a package using pip."""
    print(f"Installing {package}...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])


def check_environment():
    """Check if required packages are installed."""
    required_packages = {
        'pytest': 'pytest',
        'pytestqt': 'pytest-qt',
        'PyQt6': 'PyQt6',
    }

    missing = []
    installed = {}

    for import_name, package_name in required_packages.items():
        try:
            __import__(import_name)
            installed[package_name] = True
            print(f"  [OK] {package_name} is installed")
        except ImportError:
            installed[package_name] = False
            missing.append(package_name)
            print(f"  [MISSING] {package_name}")

    return missing, installed


def main():
    """Main setup function."""
    print("=" * 60)
    print("AI Writer Test Environment Setup")
    print("=" * 60)
    print()

    # Check current environment
    print("Checking installed packages...")
    missing, installed = check_environment()

    if missing:
        print()
        print(f"Missing packages: {', '.join(missing)}")
        print("Installing missing packages...")
        print()

        for package in missing:
            try:
                install_package(package)
            except subprocess.CalledProcessError as e:
                print(f"Failed to install {package}: {e}")
                return 1

        print()
        print("Verifying installation...")
        missing, installed = check_environment()

        if missing:
            print()
            print("ERROR: Failed to install some packages")
            return 1

    print()
    print("=" * 60)
    print("Test environment setup complete!")
    print("=" * 60)
    print()
    print("You can now run tests using:")
    print("  pytest tests/ -v")
    print()
    print("Or run a specific test:")
    print("  pytest tests/test_001_application_launch.py -v")
    print()

    return 0


if __name__ == "__main__":
    sys.exit(main())
