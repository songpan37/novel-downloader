"""
Template model for AI Writer application.

Defines the data structure for prompt templates used in AI generation.
Updated to support the 13-step creative workflow.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, List, Optional


# Default template categories for the AI Writer workflow
DEFAULT_TEMPLATE_CATEGORIES = [
    "文风设定",
    "书名",
    "故事梗概",
    "时空设定",
    "人物设定",
    "封面图片",
    "拆书参考",
    "创作公式",
    "分卷大纲",
    "分卷人物",
    "章节大纲",
    "章节正文",
    "剧情总结",
    "人物总结",
]


# Available placeholders that can be used in templates
# Only includes placeholders actually used in template files
AVAILABLE_PLACEHOLDERS = {
    "novel_type": {
        "name": "小说类型",
        "description": "小说的类型分类（如玄幻、都市、科幻等）",
        "category": "基本信息"
    },
    "novel_name": {
        "name": "小说名称",
        "description": "小说的名称",
        "category": "基本信息"
    },
    "literary_style_category": {
        "name": "文风类别",
        "description": "用户选择的文风类别（如轻松幽默、热血爽文、暗黑压抑等）",
        "category": "基本信息"
    },
    "vol_num": {
        "name": "卷号",
        "description": "当前分卷的卷号",
        "category": "分卷信息"
    },
    "start_chapter": {
        "name": "起始章节号",
        "description": "分析或创作的起始章节号",
        "category": "章节信息"
    },
    "end_chapter": {
        "name": "结束章节号",
        "description": "分析或创作的结束章节号",
        "category": "章节信息"
    },
    "chapter_num": {
        "name": "章节号",
        "description": "当前章节的序号",
        "category": "章节信息"
    },
    "novel_number": {
        "name": "样本数量",
        "description": "参考小说的数量",
        "category": "基本信息"
    },
    "reference_works": {
        "name": "参考作品列表",
        "description": "参考小说的名称列表",
        "category": "基本信息"
    },
}


@dataclass
class Template:
    """
    Represents a prompt template for AI generation.

    Attributes:
        category: Template category name
        content: The template content with optional placeholders
        created_at: Creation timestamp
        updated_at: Last update timestamp
        is_custom: Whether this is a user-customized template
        version: Template version number
    """
    category: str = ""
    content: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    is_custom: bool = False
    version: int = 1

    def to_dict(self) -> Dict[str, Any]:
        """Convert template to dictionary for JSON serialization."""
        return {
            "category": self.category,
            "content": self.content,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "is_custom": self.is_custom,
            "version": self.version
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Template':
        """Create Template instance from dictionary."""
        template = cls()
        for key, value in data.items():
            if hasattr(template, key):
                setattr(template, key, value)
        return template

    def update_timestamp(self) -> None:
        """Update the updated_at timestamp."""
        self.updated_at = datetime.now().isoformat()

    def get_placeholders(self) -> List[str]:
        """
        Extract all placeholders from template content.

        Returns:
            List of placeholder names found in content
        """
        import re
        pattern = r'\{(\w+)\}'
        return re.findall(pattern, self.content)

    def validate_placeholders(self) -> tuple[bool, List[str]]:
        """
        Validate all placeholders in template.

        Returns:
            Tuple of (is_valid, list of invalid placeholder names)
        """
        placeholders = self.get_placeholders()
        invalid = []
        for ph in placeholders:
            if ph not in AVAILABLE_PLACEHOLDERS:
                invalid.append(ph)
        return len(invalid) == 0, invalid

    def render(self, context: Dict[str, str]) -> str:
        """
        Render template with provided context values.

        Args:
            context: Dictionary mapping placeholder names to values

        Returns:
            Rendered template content
        """
        result = self.content
        for key, value in context.items():
            # Convert non-string values to string
            if value is None:
                str_value = ""
            elif isinstance(value, (list, tuple)):
                str_value = ", ".join(str(v) for v in value) if value else ""
            elif isinstance(value, dict):
                str_value = str(value)
            else:
                str_value = str(value)
            result = result.replace(f"{{{key}}}", str_value)
        return result

    def render_with_defaults(self, context: Dict[str, str], keep_missing: bool = True) -> tuple[str, List[str]]:
        """
        Render template with provided context, handling missing placeholders.

        Args:
            context: Dictionary mapping placeholder names to values
            keep_missing: If True, keep missing placeholders as-is; if False, replace with empty string

        Returns:
            Tuple of (rendered content, list of missing placeholder names)
        """
        import re
        result = self.content
        missing = []

        # Find all placeholders
        placeholders = re.findall(r'\{(\w+)\}', self.content)

        for ph in set(placeholders):
            if ph in context and context[ph] is not None:
                result = result.replace(f"{{{ph}}}", context[ph])
            else:
                missing.append(ph)
                if not keep_missing:
                    result = result.replace(f"{{{ph}}}", "")

        return result, missing


def get_default_template(category: str, templates_dir: Optional[str] = None) -> Template:
    """
    Get template content for a category.
    First tries to load from templates/ directory, falls back to prompts/ directory.

    Args:
        category: Template category name (e.g., "文风设定", "创作公式")
        templates_dir: Optional templates directory path

    Returns:
        Template with content from templates or defaults
    """
    import os

    # File name is the category name with .pmpt extension
    file_name = f"{category}.pmpt"

    # First try to load from templates/ directory
    if templates_dir:
        template_file = os.path.join(templates_dir, file_name)
        if os.path.exists(template_file):
            with open(template_file, 'r', encoding='utf-8') as f:
                content = f.read()
            return Template(category=category, content=content, is_custom=True)

    # Fall back to prompts/ directory
    script_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    prompt_file = os.path.join(script_dir, "prompts", file_name)

    if os.path.exists(prompt_file):
        with open(prompt_file, 'r', encoding='utf-8') as f:
            content = f.read()
        return Template(category=category, content=content, is_custom=False)

    return Template(category=category, content="", is_custom=False)


def get_all_default_templates() -> Dict[str, Template]:
    """
    Get all default templates.

    Returns:
        Dictionary mapping category to Template
    """
    return {cat: get_default_template(cat) for cat in DEFAULT_TEMPLATE_CATEGORIES}
