"""
Fanqie Account model for AI Writer application.

Represents a 番茄小说 writer account with credentials.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Dict, Any


@dataclass
class FanqieAccount:
    """
    Represents a 番茄小说 writer account.

    Attributes:
        id: Unique identifier (format: fanqie_YYYYMMDD_XXX)
        phone: Full phone number
        password: Account password
        nickname: User-defined nickname/remark
        created_at: Creation timestamp
    """
    id: str = ""
    phone: str = ""
    password: str = ""
    nickname: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def __post_init__(self) -> None:
        """Generate ID if not provided."""
        if not self.id:
            import random
            timestamp = datetime.now().strftime("%Y%m%d")
            suffix = f"{random.randint(1, 999):03d}"
            self.id = f"fanqie_{timestamp}_{suffix}"

    def get_display_name(self) -> str:
        """
        Get display name for the account.

        Returns:
            Nickname if set, otherwise masked phone number (138****1234)
        """
        if self.nickname:
            return f"{self.nickname} ({self._masked_phone()})"
        return self._masked_phone()

    def _masked_phone(self) -> str:
        """
        Get masked phone number.

        Returns:
            Masked phone like 138****1234
        """
        if len(self.phone) >= 11:
            return f"{self.phone[:3]}****{self.phone[-4:]}"
        return self.phone

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "phone": self.phone,
            "password": self.password,
            "nickname": self.nickname,
            "created_at": self.created_at
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FanqieAccount':
        """Create instance from dictionary."""
        account = cls()
        for key, value in data.items():
            if hasattr(account, key):
                setattr(account, key, value)
        return account

    @staticmethod
    def validate_id(account_id: str) -> bool:
        """Validate account ID format (fanqie_YYYYMMDD_XXX)."""
        import re
        pattern = r'^fanqie_\d{8}_\d{3}$'
        return bool(re.match(pattern, account_id))
