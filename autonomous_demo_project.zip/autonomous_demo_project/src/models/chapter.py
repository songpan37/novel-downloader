"""
Chapter model for AI Writer application.

Defines the data structure for a chapter in a novel work,
including content, outline, characters, scenes, and metadata.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Dict, Any, Optional


@dataclass
class Chapter:
    """
    Represents a chapter (章节) in a novel work.

    A chapter contains the full content, outline, character list,
    scene list, and metadata about the chapter.

    Attributes:
        chapter_number: The chapter number (1-indexed)
        volume_number: The volume number this chapter belongs to
        title: Chapter title
        outline: Chapter outline/summary
        content: Full chapter content
        word_count: Number of words in the chapter
        characters: List of character names appearing in this chapter
        scenes: List of scene descriptions
        status: Chapter status (draft, completed, etc.)
        created_at: Creation timestamp
        updated_at: Last update timestamp
    """
    chapter_number: int = 0
    volume_number: int = 0
    title: str = ""
    outline: str = ""
    content: str = ""
    word_count: int = 0
    characters: List[str] = field(default_factory=list)
    scenes: List[str] = field(default_factory=list)
    status: str = "draft"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert chapter to dictionary for JSON serialization.

        Returns:
            Dictionary containing all chapter data
        """
        return {
            "chapter_number": self.chapter_number,
            "volume_number": self.volume_number,
            "title": self.title,
            "outline": self.outline,
            "content": self.content,
            "word_count": self.word_count,
            "characters": self.characters,
            "scenes": self.scenes,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Chapter':
        """
        Create Chapter instance from dictionary.

        Args:
            data: Dictionary containing chapter data

        Returns:
            New Chapter instance
        """
        chapter = cls()
        for key, value in data.items():
            if hasattr(chapter, key):
                setattr(chapter, key, value)
        return chapter

    def update_timestamp(self) -> None:
        """Update the updated_at timestamp."""
        self.updated_at = datetime.now().isoformat()

    def update_word_count(self) -> None:
        """Update the word count based on current content."""
        self.word_count = len(self.content)
        self.update_timestamp()

    def add_character(self, character_name: str) -> None:
        """
        Add a character name to the character list.

        Args:
            character_name: The character name to add
        """
        if character_name not in self.characters:
            self.characters.append(character_name)
            self.update_timestamp()

    def remove_character(self, character_name: str) -> bool:
        """
        Remove a character name from the character list.

        Args:
            character_name: The character name to remove

        Returns:
            True if character was removed, False if not found
        """
        if character_name in self.characters:
            self.characters.remove(character_name)
            self.update_timestamp()
            return True
        return False

    def add_scene(self, scene_description: str) -> None:
        """
        Add a scene description to the scene list.

        Args:
            scene_description: The scene description to add
        """
        if scene_description not in self.scenes:
            self.scenes.append(scene_description)
            self.update_timestamp()

    def remove_scene(self, scene_description: str) -> bool:
        """
        Remove a scene description from the scene list.

        Args:
            scene_description: The scene description to remove

        Returns:
            True if scene was removed, False if not found
        """
        if scene_description in self.scenes:
            self.scenes.remove(scene_description)
            self.update_timestamp()
            return True
        return False

    def get_display_title(self) -> str:
        """
        Get display title for the chapter.

        Returns:
            Formatted title with chapter number
        """
        if self.title:
            return f"第 {self.volume_number} 卷 第 {self.chapter_number} 章 {self.title}"
        return f"第 {self.volume_number} 卷 第 {self.chapter_number} 章"

    def get_chapter_file_name(self) -> str:
        """
        Get the standard file name for this chapter.

        Note: This is for reference only. Chapter files are now stored
        as TXT files in the steps/ directory with format:
        - chapter_{vol}_{chap}_outline.txt
        - chapter_{vol}_{chap}_content.txt

        Returns:
            Legacy file name format in format chapter_XXX.json
        """
        return f"chapter_{self.chapter_number:03d}.json"

    def is_completed(self) -> bool:
        """
        Check if the chapter is completed.

        Returns:
            True if status is 'completed'
        """
        return self.status == "completed"

    def mark_completed(self) -> None:
        """Mark the chapter as completed."""
        self.status = "completed"
        self.update_timestamp()

    def mark_draft(self) -> None:
        """Mark the chapter as draft."""
        self.status = "draft"
        self.update_timestamp()

    def get_scene_count(self) -> int:
        """
        Get the number of scenes in this chapter.

        Returns:
            Number of scenes
        """
        return len(self.scenes)

    def get_character_count(self) -> int:
        """
        Get the number of characters in this chapter.

        Returns:
            Number of characters
        """
        return len(self.characters)
