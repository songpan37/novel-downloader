"""
Volume model for AI Writer application.

Defines the data structure for a volume in a novel work,
including outline, chapter references, and metadata.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Dict, Any, Optional


@dataclass
class Volume:
    """
    Represents a volume (卷) in a novel work.

    A volume contains an outline, a list of chapter references,
    and metadata about the volume.

    Attributes:
        volume_number: The volume number (1-indexed)
        title: Volume title
        outline: Volume outline/summary
        chapter_list: List of chapter IDs in this volume
        characters: List of character names appearing in this volume
        created_at: Creation timestamp
        updated_at: Last update timestamp
    """
    volume_number: int = 0
    title: str = ""
    outline: str = ""
    chapter_list: List[str] = field(default_factory=list)
    characters: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert volume to dictionary for JSON serialization.

        Returns:
            Dictionary containing all volume data
        """
        return {
            "volume_number": self.volume_number,
            "title": self.title,
            "outline": self.outline,
            "chapter_list": self.chapter_list,
            "characters": self.characters,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Volume':
        """
        Create Volume instance from dictionary.

        Args:
            data: Dictionary containing volume data

        Returns:
            New Volume instance
        """
        volume = cls()
        for key, value in data.items():
            if hasattr(volume, key):
                setattr(volume, key, value)
        return volume

    def update_timestamp(self) -> None:
        """Update the updated_at timestamp."""
        self.updated_at = datetime.now().isoformat()

    def add_chapter(self, chapter_id: str) -> None:
        """
        Add a chapter ID to the chapter list.

        Args:
            chapter_id: The chapter ID to add
        """
        if chapter_id not in self.chapter_list:
            self.chapter_list.append(chapter_id)
            self.update_timestamp()

    def remove_chapter(self, chapter_id: str) -> bool:
        """
        Remove a chapter ID from the chapter list.

        Args:
            chapter_id: The chapter ID to remove

        Returns:
            True if chapter was removed, False if not found
        """
        if chapter_id in self.chapter_list:
            self.chapter_list.remove(chapter_id)
            self.update_timestamp()
            return True
        return False

    def get_chapter_count(self) -> int:
        """
        Get the number of chapters in this volume.

        Returns:
            Number of chapters
        """
        return len(self.chapter_list)

    def get_display_title(self) -> str:
        """
        Get display title for the volume.

        Returns:
            Formatted title with volume number
        """
        if self.title:
            return f"第 {self.volume_number} 卷 {self.title}"
        return f"第 {self.volume_number} 卷"

    def add_character(self, character_name: str) -> None:
        """
        Add a character name to the character list.

        Args:
            character_name: The character name to add
        """
        if character_name not in self.characters:
            self.characters.append(character_name)
            self.update_timestamp()

    def get_volume_file_name(self) -> str:
        """
        Get the standard file name for this volume.

        Note: This is for reference only. Volume files are now stored
        as TXT files in the steps/ directory with format:
        - volume_{vol_num}.txt (分卷大纲)
        - volume_{vol_num}_characters.txt (分卷人物)

        Returns:
            Legacy file name format in format volume_XXX.json
        """
        return f"volume_{self.volume_number:03d}.json"
