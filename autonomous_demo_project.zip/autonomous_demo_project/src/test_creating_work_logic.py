"""
Test creating work logic.

Tests the following scenarios:
1. A work clicks "Start Creation" - memory records currently creating work
2. Work library lists works, compares with memory recorded work, shows badge if creating
3. Click "Creating" menu - checks memory for creating work, shows creation view or empty state
4. Click work card - checks memory, disables/grays other works, changes A work button to "View Creation"
5. Complete step - checks if creating work was deleted (means paused)
6. Click pause - modifies creating work state in memory, doesn't delete
7. A paused, click B start - clears A from memory, adds B as creating
"""

import unittest
from unittest.mock import MagicMock, patch
import sys
import os

# Add src to path
sys.path.insert(0, os.path.dirname(__file__))


class TestCreatingWorkLogic(unittest.TestCase):
    """Test creating work state management."""

    def setUp(self):
        """Set up test fixtures."""
        # Mock settings
        self.mock_settings = MagicMock()
        self.mock_settings.works_dir = "/tmp/test_works"
        self.mock_settings.templates_dir = "/tmp/test_templates"

        # Import main window
        with patch('gui.main_window.WorkManager'):
            with patch('gui.main_window.TemplateService'):
                from gui.main_window import MainWindow
                self.MainWindow = MainWindow

    def test_01_start_creation_records_work(self):
        """Test 1: Starting creation records work in memory."""
        print("\n=== Test 1: Start creation records work ===")

        with patch.object(self.MainWindow, '__init__', return_value=None):
            window = self.MainWindow()
            window.creating_work_id = None
            window.creating_work_data = None
            window.creating_work_state = "not_started"

            # Simulate starting creation for work A
            work_id_a = "work_a_123"
            work_data_a = {"id": work_id_a, "title": "Test Work A"}

            window.creating_work_id = work_id_a
            window.creating_work_data = work_data_a
            window.creating_work_state = "in_progress"

            # Verify state
            self.assertEqual(window.creating_work_id, work_id_a)
            self.assertEqual(window.creating_work_data, work_data_a)
            self.assertEqual(window.creating_work_state, "in_progress")
            print(f"  Work A ({work_id_a}) recorded as creating")

    def test_02_workspace_shows_badge(self):
        """Test 2: Workspace shows badge for creating work."""
        print("\n=== Test 2: Workspace shows badge ===")

        with patch.object(self.MainWindow, '__init__', return_value=None):
            window = self.MainWindow()
            window.creating_work_id = "work_a_123"
            window.creating_work_state = "in_progress"

            # Mock workspace view
            window.workspace_view = MagicMock()

            # Update views
            window.workspace_view.update_creating_work(window.creating_work_id)

            # Verify badge update called with correct work_id
            window.workspace_view.update_creating_work.assert_called_once_with("work_a_123")
            print("  Badge shown for work_a_123")

    def test_03_navigation_shows_creation_view(self):
        """Test 3: Navigation to 'Creating' shows creation view if work exists."""
        print("\n=== Test 3: Navigation shows creation view ===")

        with patch.object(self.MainWindow, '__init__', return_value=None):
            window = self.MainWindow()
            window.creating_work_id = "work_a_123"
            window.creating_work_state = "in_progress"

            # Mock creation view
            window.creation_view = MagicMock()
            window.creation_view.current_work_id = None

            # Mock work manager
            window.work_manager = MagicMock()
            work_data = {"id": "work_a_123", "title": "Test Work A"}
            window.work_manager.get_work.return_value.to_dict.return_value = work_data

            # Simulate checking if work should be loaded
            if window.creating_work_id:
                if window.creation_view.current_work_id != window.creating_work_id:
                    # Would load work
                    print(f"  Would load work {window.creating_work_id} into creation view")
                # Would show creation content
                print("  Would show creation content")

            self.assertIsNotNone(window.creating_work_id)
            print("  Creation view shown for existing work")

    def test_04_work_card_button_states(self):
        """Test 4: Work card button states based on creating work."""
        print("\n=== Test 4: Work card button states ===")

        # Simulate work A being created
        creating_work_id = "work_a_123"
        work_a_id = "work_a_123"
        work_b_id = "work_b_456"

        # Check A (same work)
        if creating_work_id == work_a_id:
            print(f"  Work A ({work_a_id}): Button should show 'View Creation'")
            # In code: btn.setText("查看创作"), btn.setEnabled(True), btn.setStyleSheet(blue)

        # Check B (different work)
        if creating_work_id and creating_work_id != work_b_id:
            print(f"  Work B ({work_b_id}): Button should be gray/disabled")
            # In code: btn.setEnabled(False), btn.setStyleSheet(gray)

        self.assertEqual(creating_work_id, work_a_id)
        print("  Button states correct")

    def test_05_pause_keeps_work_in_memory(self):
        """Test 5: Pause keeps work in memory with paused state."""
        print("\n=== Test 5: Pause keeps work in memory ===")

        with patch.object(self.MainWindow, '__init__', return_value=None):
            window = self.MainWindow()
            window.creating_work_id = "work_a_123"
            window.creating_work_data = {"id": "work_a_123", "title": "Test Work A"}
            window.creating_work_state = "in_progress"

            # Simulate pause
            window.creating_work_state = "paused"

            # Verify work is still in memory
            self.assertEqual(window.creating_work_id, "work_a_123")
            self.assertEqual(window.creating_work_state, "paused")
            print(f"  Work A paused, state={window.creating_work_state}")
            print("  Work still in memory for potential resume")

    def test_06_switch_work_clears_old_work(self):
        """Test 6: Starting B work when A is paused clears A."""
        print("\n=== Test 6: Switch work clears old work ===")

        with patch.object(self.MainWindow, '__init__', return_value=None):
            window = self.MainWindow()

            # Start with A paused
            window.creating_work_id = "work_a_123"
            window.creating_work_data = {"id": "work_a_123", "title": "Test Work A"}
            window.creating_work_state = "paused"

            print(f"  Initial: creating_work_id={window.creating_work_id}, state={window.creating_work_state}")

            # Start B work
            work_b_id = "work_b_456"
            work_b_data = {"id": work_b_id, "title": "Test Work B"}

            # Logic from _on_start_creation:
            if window.creating_work_id and window.creating_work_id != work_b_id:
                print(f"  Switching from {window.creating_work_id} to {work_b_id}")

            # Record new work
            window.creating_work_id = work_b_id
            window.creating_work_data = work_b_data
            window.creating_work_state = "not_started"

            print(f"  After switch: creating_work_id={window.creating_work_id}, state={window.creating_work_state}")

            # Verify A is cleared and B is recorded
            self.assertEqual(window.creating_work_id, work_b_id)
            self.assertEqual(window.creating_work_data, work_b_data)
            print("  Old work A cleared, new work B recorded")

    def test_07_complete_clears_work(self):
        """Test 7: Completion clears creating work."""
        print("\n=== Test 7: Completion clears work ===")

        with patch.object(self.MainWindow, '__init__', return_value=None):
            window = self.MainWindow()
            window.creating_work_id = "work_a_123"
            window.creating_work_data = {"id": "work_a_123", "title": "Test Work A"}
            window.creating_work_state = "in_progress"

            # Simulate completion
            window.creating_work_id = None
            window.creating_work_data = None
            window.creating_work_state = "not_started"

            # Verify cleared
            self.assertIsNone(window.creating_work_id)
            self.assertIsNone(window.creating_work_data)
            self.assertEqual(window.creating_work_state, "not_started")
            print("  Creating work cleared after completion")

    def test_08_pause_clears_badge_resume_restores(self):
        """Test 8: Pause clears badge, resume restores state and continues generation."""
        print("\n=== Test 8: Pause clears badge, resume restores ===")

        with patch.object(self.MainWindow, '__init__', return_value=None):
            window = self.MainWindow()

            # Initial state: Work A being created
            work_id_a = "work_a_123"
            work_data_a = {"id": work_id_a, "title": "Test Work A"}
            window.creating_work_id = work_id_a
            window.creating_work_data = work_data_a
            window.creating_work_state = "in_progress"

            # Mock generation state (simulating mid-generation)
            window._generation_state = {
                'work_id': work_id_a,
                'work_data': work_data_a,
                'current_step_index': 3,  # Mid-generation
                'steps': [('step1', 'Step 1', 'template'),
                          ('step2', 'Step 2', 'template'),
                          ('step3', 'Step 3', 'template'),
                          ('step4', 'Step 4', 'template')]
            }

            print(f"  Initial: creating_work_id={window.creating_work_id}, generation_step={window._generation_state['current_step_index']}")

            # Simulate pause: clears creating_work_id (badge removed)
            # This is what _on_creation_paused does now
            window.creating_work_id = None
            window.creating_work_data = None
            window.creating_work_state = "not_started"
            # But _generation_state is preserved!

            print(f"  After pause: creating_work_id={window.creating_work_id}, badge_cleared=True")
            print(f"  Generation state preserved: step={window._generation_state['current_step_index']}")

            # Verify badge is cleared
            self.assertIsNone(window.creating_work_id)

            # Simulate resume: _on_creation_resumed is called
            # It should restore creating_work_id and call _generate_next_step
            window.creating_work_id = work_id_a
            window.creating_work_data = work_data_a
            window.creating_work_state = "in_progress"

            # Verify generation state is still there
            self.assertEqual(window._generation_state['current_step_index'], 3)
            print(f"  After resume: creating_work_id={window.creating_work_id}, can_continue=True")
            print("  Resume will call _generate_next_step() to continue from step 3")


class TestCreatingWorkStateEnum(unittest.TestCase):
    """Test creating work state values."""

    def test_state_values(self):
        """Test that states are valid."""
        print("\n=== Test State Values ===")

        valid_states = ["not_started", "in_progress", "paused"]

        for state in valid_states:
            print(f"  Valid state: {state}")

        # Test invalid state
        invalid_state = "unknown"
        self.assertNotIn(invalid_state, valid_states)
        print(f"  Invalid state '{invalid_state}' correctly rejected")


def run_tests():
    """Run all tests and print results."""
    print("=" * 60)
    print("Creating Work Logic Tests")
    print("=" * 60)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestCreatingWorkLogic)
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestCreatingWorkStateEnum))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print("\n" + "=" * 60)
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print("=" * 60)

    return len(result.failures) == 0 and len(result.errors) == 0


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
