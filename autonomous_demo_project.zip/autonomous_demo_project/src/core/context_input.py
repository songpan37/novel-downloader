"""
上下文输入管理器 - 管理 AI 创作时的上下文输入

负责:
- 确定每个步骤需要的上下文
- 构建包含上下文的提示词
"""
from typing import List, Dict, Any, Optional
from core.creation_task import CreationTask, SessionInfo, StepInfo


class ContextInputManager:
    """
    上下文输入管理器

    管理 AI 创作时的上下文输入，包括：
    - 确定每个步骤需要的上下文步骤
    - 构建包含上下文的提示词
    """

    # 步骤类型映射到所需上下文
    # 使用通配符模式匹配步骤 ID
    CONTEXT_REQUIREMENTS = {
        # 基本设定步骤不需要上下文（使用模板）
        'style_setting': [],
        'book_title': ['story_summary', 'worldbuilding', 'character_design'],
        'story_summary': ['style_setting'],
        'worldbuilding': ['style_setting', 'story_summary'],
        'character_design': ['style_setting', 'story_summary'],
        'cover_image': ['book_title', 'story_summary'],

        # 拆书参考不需要上下文（直接使用参考作品）
        'reference_*': [],

        # 创作公式需要拆书参考作为上下文
        'pattern_*': ['reference_*'],

        # 分卷大纲需要基本信息和创作参考
        'volume_*': ['style_setting', 'story_summary'],
        'volume_*_characters': ['volume_*', 'character_design'],

        # 章节需要分卷信息
        'chapter_*_*_outline': ['volume_*', 'volume_*_characters'],
        'chapter_*_*_content': ['chapter_*_*_outline'],

        # 分卷总结需要本卷所有章节
        'volume_*_summary_plot': ['chapter_*_*_content'],
        'volume_*_summary_character': ['volume_*_summary_plot', 'volume_*_characters'],
    }

    @staticmethod
    def get_required_context_for_step(
        step_id: str,
        completed_steps: Dict[str, str]
    ) -> List[str]:
        """
        获取步骤所需的上下文步骤 ID 列表

        Args:
            step_id: 步骤 ID
            completed_steps: 已完成步骤的映射 {step_id: content}

        Returns:
            需要的上下文步骤 ID 列表
        """
        # 查找匹配的规则
        required = []
        for pattern, context_list in ContextInputManager.CONTEXT_REQUIREMENTS.items():
            if ContextInputManager._match_step_pattern(step_id, pattern):
                required = context_list
                break

        # 过滤出已完成的上下文
        available_context = []
        for ctx_pattern in required:
            # 如果上下文模式包含通配符，尝试从 step_id 中提取信息来精确匹配
            if '*' in ctx_pattern:
                # 尝试用 step_id 中的部分来替换通配符
                matched = ContextInputManager._match_context_from_step_id(
                    step_id, ctx_pattern, completed_steps
                )
                available_context.extend(matched)
            else:
                # 直接匹配
                if ctx_pattern in completed_steps:
                    available_context.append(ctx_pattern)

        # 调试日志
        import logging
        logger = logging.getLogger('context_input')
        logger.debug(f"[CONTEXT_MATCH] step_id={step_id}, required={required}, available={available_context}, completed_keys={list(completed_steps.keys())[:10]}...")

        return available_context

    @staticmethod
    def _match_context_from_step_id(
        step_id: str,
        ctx_pattern: str,
        completed_steps: Dict[str, str]
    ) -> List[str]:
        """
        根据步骤 ID 匹配上下文步骤

        例如：
        - step_id = 'chapter_1_1_outline', ctx_pattern = 'volume_*' → 匹配 'volume_1'
        - step_id = 'chapter_1_1_outline', ctx_pattern = 'volume_*_characters' → 匹配 'volume_1_characters'

        Args:
            step_id: 当前步骤 ID
            ctx_pattern: 上下文模式
            completed_steps: 已完成步骤

        Returns:
            匹配的上下文步骤 ID 列表
        """
        matched = []

        # 从 step_id 中提取卷号和章节号
        parts = step_id.split('_')
        vol_num = None
        chapter_num = None

        if step_id.startswith('chapter_') and len(parts) >= 3:
            try:
                vol_num = int(parts[1])
                chapter_num = int(parts[2])
            except ValueError:
                pass
        elif step_id.startswith('volume_') and len(parts) >= 2:
            try:
                vol_num = int(parts[1])
            except ValueError:
                pass
        elif '_summary_' in step_id:
            # 分卷总结步骤，如 volume_1_summary_plot
            for i, part in enumerate(parts):
                if part == 'summary' and i > 0:
                    prefix = parts[i-1]
                    if prefix.startswith('volume_'):
                        try:
                            vol_num = int(prefix.replace('volume_', ''))
                        except ValueError:
                            pass
                    break

        # 调试日志
        import logging
        logger = logging.getLogger('context_input')
        logger.debug(f"[MATCH_CONTEXT] step_id={step_id}, vol_num={vol_num}, ctx_pattern={ctx_pattern}")

        if vol_num is not None:
            # 根据卷号精确匹配
            if ctx_pattern == 'volume_*':
                target = f'volume_{vol_num}'
                if target in completed_steps:
                    matched.append(target)
            elif ctx_pattern == 'volume_*_characters':
                target = f'volume_{vol_num}_characters'
                if target in completed_steps:
                    matched.append(target)
            elif ctx_pattern == 'chapter_*_*_outline':
                # 如果是章节正文步骤，只匹配同一章节的大纲
                if chapter_num is not None and step_id.endswith('_content'):
                    target = f'chapter_{vol_num}_{chapter_num}_outline'
                    if target in completed_steps:
                        matched.append(target)
                else:
                    # 否则匹配同一卷的所有章节大纲（用于分卷总结等）
                    for completed_id in completed_steps:
                        if completed_id.startswith(f'chapter_{vol_num}_') and completed_id.endswith('_outline'):
                            matched.append(completed_id)
            elif ctx_pattern == 'chapter_*_*_content':
                # 分卷总结需要整卷的所有章节正文
                for completed_id in completed_steps:
                    if completed_id.startswith(f'chapter_{vol_num}_') and completed_id.endswith('_content'):
                        matched.append(completed_id)
            elif ctx_pattern == 'reference_*':
                # 匹配所有拆书参考
                for completed_id in completed_steps:
                    if completed_id.startswith('reference_'):
                        matched.append(completed_id)
            elif ctx_pattern == 'pattern_*':
                # 匹配创作公式
                for completed_id in completed_steps:
                    if completed_id.startswith('pattern_'):
                        matched.append(completed_id)
        else:
            # 无法提取卷号，使用通配符匹配所有
            for completed_id in completed_steps:
                if ContextInputManager._match_step_pattern(completed_id, ctx_pattern):
                    matched.append(completed_id)

        # 调试日志：显示匹配结果
        import logging
        logger = logging.getLogger('context_input')
        logger.debug(f"[MATCH_CONTEXT_RESULT] step_id={step_id}, ctx_pattern={ctx_pattern}, matched={matched}, completed_keys={list(completed_steps.keys())[:5]}...")

        return matched

    @staticmethod
    def _match_step_pattern(step_id: str, pattern: str) -> bool:
        """
        匹配步骤 ID 到通配符模式

        Args:
            step_id: 步骤 ID
            pattern: 模式字符串（可包含*通配符）

        Returns:
            True 如果匹配
        """
        import fnmatch
        return fnmatch.fnmatch(step_id, pattern)

    @staticmethod
    def build_context_prompt(
        step_id: str,
        completed_steps: Dict[str, str]
    ) -> str:
        """
        构建包含上下文的提示词

        Args:
            step_id: 步骤 ID
            completed_steps: 已完成步骤的映射

        Returns:
            包含上下文的提示词字符串
        """
        context_ids = ContextInputManager.get_required_context_for_step(step_id, completed_steps)

        context_sections = []
        for ctx_id in context_ids:
            content = completed_steps.get(ctx_id, "")
            if content:
                # 根据上下文类型添加适当的标题
                section_title = ContextInputManager._get_context_title(ctx_id)
                context_sections.append(f"=== {section_title} ===\n{content}")

        if context_sections:
            return "\n\n".join([
                "<context>",
                "以下是相关的上下文信息：",
                "",
                "\n\n".join(context_sections),
                "",
                "</context>"
            ])

        return ""

    @staticmethod
    def _get_context_title(step_id: str) -> str:
        """
        根据步骤 ID 生成上下文标题

        Args:
            step_id: 步骤 ID

        Returns:
            可读的标题字符串
        """
        title_map = {
            'style_setting': '文风设定',
            'book_title': '书名',
            'story_summary': '故事梗概',
            'worldbuilding': '时空设定',
            'character_design': '人物设定',
            'cover_image': '封面图片',
            'volume_*': '分卷大纲',
            'volume_*_characters': '分卷人物',
            'chapter_*_*_outline': '章节大纲',
            'chapter_*_*_content': '章节正文',
            'reference_*': '拆书参考',
            'pattern_*': '创作公式',
            'volume_*_summary_plot': '剧情总结',
            'volume_*_summary_character': '人物总结',
        }

        for pattern, title in title_map.items():
            if ContextInputManager._match_step_pattern(step_id, pattern):
                return f"{title} ({step_id})"

        return step_id

    @staticmethod
    def get_context_for_session(
        session_id: str,
        creation_task: CreationTask
    ) -> Dict[str, str]:
        """
        获取会话执行所需的全部上下文

        Args:
            session_id: 会话 ID
            creation_task: 创作任务对象

        Returns:
            {step_id: content} 上下文字典
        """
        completed = {}

        # 收集所有已完成的步骤作为上下文
        for session in creation_task.sessions:
            if session.session_id == session_id:
                continue  # 跳过当前会话
            for step in session.steps:
                if step.status == "completed" and step.content:
                    completed[step.step_id] = step.content

        return completed

    @staticmethod
    def get_ai_output_step_for_session(session_id: str) -> Optional[str]:
        """
        获取会话中需要 AI 输出的步骤 ID

        通常每个会话只有一个 AI 输出步骤。

        Args:
            session_id: 会话 ID

        Returns:
            AI 输出步骤 ID 或 None
        """
        # 基本设定会话：所有步骤都是 AI 输出
        if session_id == "basic_info":
            return "style_setting"  # 第一个步骤

        # 创作参考会话：拆书和创作公式都是 AI 输出
        if session_id.startswith("reference_"):
            return session_id.replace("reference_", "reference_")

        if session_id == "pattern_analysis":
            return "pattern_*"

        # 分卷信息会话：分卷大纲和分卷人物都是 AI 输出
        if session_id.startswith("volume_") and not session_id.startswith("volume_summary"):
            return f"{session_id}"  # 分卷大纲

        # 章节信息会话：章节大纲和正文都是 AI 输出
        if session_id.startswith("chapter_"):
            return f"{session_id}_outline"  # 章节大纲

        # 分卷总结会话：剧情总结是 AI 输出
        if session_id.startswith("volume_summary_"):
            return f"{session_id}_plot"

        return None
