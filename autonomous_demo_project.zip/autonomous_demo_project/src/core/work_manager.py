"""
Work Manager for AI Writer application.

Handles all work-related operations including creation, loading,
saving, updating, and deletion of works.
"""
import json
import os
import shutil
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime

from models.work import Work
from config.settings import Settings
from utils.logger import get_logger, setup_logger
from utils.exceptions import (
    StorageError,
    WorkNotFoundError,
    WorkExistsError,
    CorruptedJSONError,
    ConcurrentAccessError,
    FileLockError,
)
from utils.file_lock import WorkLockManager, FileLock


class WorkManagerError(Exception):
    """Base exception for WorkManager operations."""
    pass


class WorkNotFoundError(WorkManagerError):
    """Raised when a work is not found."""
    pass


class WorkExistsError(WorkManagerError):
    """Raised when attempting to create a work that already exists."""
    pass


class StorageError(WorkManagerError):
    """Raised when storage operations fail."""
    pass


class WorkManager:
    """
    Manager for work operations.

    Handles CRUD operations for works, managing the file system
    structure for work storage.

    File Structure:
        {works_dir}/
            {work_id}/
                work_info.json    - Work metadata
                covers/           - Cover images
                steps/            - All step output files (TXT format)
    """

    def __init__(self, settings: Settings):
        """
        Initialize the work manager.

        Args:
            settings: Application settings with storage paths
        """
        self.settings = settings
        self.logger = get_logger()
        # Initialize logger if not already set up
        if self.logger is None:
            self.logger = setup_logger()
        self._works_cache: Dict[str, Work] = {}
        # Initialize work lock manager for concurrent access handling
        self._lock_manager = WorkLockManager(self.works_dir)
        # Track active locks per work (for this process)
        self._active_locks: Dict[str, FileLock] = {}
        self._load_all_works()

    @property
    def works_dir(self) -> str:
        """Get the works directory path."""
        return self.settings.works_dir

    def _ensure_works_dir(self) -> None:
        """Ensure works directory exists."""
        if not self.works_dir:
            raise StorageError("Works directory not configured")
        os.makedirs(self.works_dir, exist_ok=True)

    def _get_next_sequential_number(self) -> int:
        """
        Get the next sequential number for today's works.

        Scans existing works to find the highest sequence number
        for works created today, and returns the next number.

        Returns:
            Next sequential number (1-999)

        Raises:
            StorageError: If unable to determine next number
        """
        today = datetime.now().strftime('%Y%m%d')
        today_prefix = f"work_{today}_"

        max_sequence = 0

        try:
            self._ensure_works_dir()
            for entry in os.listdir(self.works_dir):
                if entry.startswith(today_prefix) and Work.validate_work_id(entry):
                    parsed = Work.parse_work_id(entry)
                    if parsed:
                        max_sequence = max(max_sequence, parsed['sequence'])
        except Exception as e:
            self.logger.error(f"Failed to determine next sequence number: {e}")
            raise StorageError(f"Failed to determine next sequence number: {e}")

        if max_sequence >= 999:
            raise StorageError("Maximum number of works per day (999) reached")

        return max_sequence + 1

    def _get_work_dir(self, work_id: str) -> str:
        """
        Get the directory path for a specific work.

        Args:
            work_id: Work identifier

        Returns:
            Full path to work directory
        """
        return os.path.join(self.works_dir, work_id)

    def _get_work_info_path(self, work_id: str) -> str:
        """
        Get the path to work info JSON file.

        Args:
            work_id: Work identifier

        Returns:
            Full path to work_info.json
        """
        return os.path.join(self._get_work_dir(work_id), "work_info.json")

    def _get_backup_path(self, file_path: str) -> str:
        """
        Get the backup path for a given file.

        Backup files are named with .backup extension before the original extension.
        E.g., work_info.json -> work_info.json.backup

        Args:
            file_path: Original file path

        Returns:
            Backup file path
        """
        return f"{file_path}.backup"

    def _extract_work_id_from_path(self, file_path: str) -> Optional[str]:
        """
        Extract work ID from a file path.

        Args:
            file_path: Path to a file within a work directory

        Returns:
            Work ID if found, None otherwise
        """
        # Expected path format: {works_dir}/{work_id}/.../{filename}
        try:
            path = Path(file_path)
            # Find the works directory in the path
            parts = path.parts
            for i, part in enumerate(parts):
                if part == 'works' and i + 1 < len(parts):
                    return parts[i + 1]
        except Exception:
            pass
        return None

    def _create_backup(self, file_path: str) -> bool:
        """
        Create a backup of a file before overwriting it.

        Args:
            file_path: Path to file to backup

        Returns:
            True if backup created successfully, False if file doesn't exist
        """
        if not os.path.exists(file_path):
            return False

        backup_path = self._get_backup_path(file_path)
        try:
            shutil.copy2(file_path, backup_path)
            self.logger.debug(f"Created backup: {backup_path}")
            return True
        except (IOError, OSError) as e:
            self.logger.error(f"Failed to create backup for {file_path}: {e}")
            return False

    def _backup_exists(self, file_path: str) -> bool:
        """
        Check if a backup file exists for the given file.

        Args:
            file_path: Original file path

        Returns:
            True if backup exists, False otherwise
        """
        backup_path = self._get_backup_path(file_path)
        return os.path.exists(backup_path)

    def _restore_from_backup(self, file_path: str) -> bool:
        """
        Restore a file from its backup.

        Args:
            file_path: Path to file to restore

        Returns:
            True if restore successful, False otherwise
        """
        backup_path = self._get_backup_path(file_path)
        if not os.path.exists(backup_path):
            self.logger.error(f"No backup available for {file_path}")
            return False

        try:
            shutil.copy2(backup_path, file_path)
            self.logger.info(f"Restored {file_path} from backup")
            return True
        except (IOError, OSError) as e:
            self.logger.error(f"Failed to restore from backup: {e}")
            return False

    def _load_all_works(self) -> None:
        """Load all works from disk into cache."""
        self._ensure_works_dir()
        self._works_cache.clear()

        try:
            for entry in os.listdir(self.works_dir):
                work_dir = os.path.join(self.works_dir, entry)
                if os.path.isdir(work_dir):
                    work_info_path = os.path.join(work_dir, "work_info.json")
                    if os.path.exists(work_info_path):
                        try:
                            work = self._load_work_from_file(work_info_path)
                            if work:
                                self._works_cache[work.id] = work
                        except CorruptedJSONError as e:
                            # Log corrupted file but continue loading other works
                            self.logger.error(f"Skipping corrupted work: {e.file_path}")

            self.logger.info(f"Loaded {len(self._works_cache)} works")

        except Exception as e:
            self.logger.error(f"Failed to load works: {e}")
            raise StorageError(f"Failed to load works: {e}")

    def _load_work_from_file(self, path: str, attempt_recovery: bool = True) -> Optional[Work]:
        """
        Load a work from its info file.

        Args:
            path: Path to work_info.json
            attempt_recovery: Whether to attempt recovery from backup if corrupted

        Returns:
            Work instance or None if loading fails

        Raises:
            CorruptedJSONError: If JSON is corrupted and recovery fails or is disabled
        """
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            work = Work.from_dict(data)

            # Count volumes and chapters
            work_dir = os.path.dirname(path)
            work.volume_count = self._count_volumes(work_dir)
            work.chapter_count = self._count_chapters(work_dir)
            work.word_count = self._calculate_total_words(work_dir)

            return work

        except json.JSONDecodeError as e:
            self.logger.error(f"Corrupted JSON file: {path} - {e}")
            backup_available = self._backup_exists(path)

            if attempt_recovery and backup_available:
                self.logger.info(f"Attempting to restore {path} from backup")
                if self._restore_from_backup(path):
                    # Retry loading after restore
                    try:
                        return self._load_work_from_file(path, attempt_recovery=False)
                    except Exception as retry_error:
                        self.logger.error(f"Recovery failed: {retry_error}")

            # Raise exception with recovery info
            raise CorruptedJSONError(
                file_path=path,
                parse_error=e,
                backup_available=backup_available
            )
        except IOError as e:
            self.logger.error(f"Failed to load work from {path}: {e}")
            return None

    def _count_volumes(self, work_dir: str) -> int:
        """
        Count volume files in work directory.

        Volume files are stored in steps/ directory as:
        - volume_{vol_num}.txt
        - volume_{vol_num}_characters.txt

        Args:
            work_dir: Work directory path

        Returns:
            Number of unique volume files (counting only volume_{vol_num}.txt)
        """
        steps_dir = os.path.join(work_dir, "steps")
        if not os.path.exists(steps_dir):
            return 0

        # Count unique volume numbers (volume_X.txt files)
        import re
        volume_pattern = re.compile(r'^volume_(\d+)\.txt$')
        volume_nums = set()
        for filename in os.listdir(steps_dir):
            match = volume_pattern.match(filename)
            if match:
                volume_nums.add(int(match.group(1)))
        return len(volume_nums)

    def _count_chapters(self, work_dir: str) -> int:
        """
        Count chapter files in work directory.

        Chapter files are stored in steps/ directory as:
        - chapter_{vol}_{chap}_outline.txt
        - chapter_{vol}_{chap}_content.txt

        Args:
            work_dir: Work directory path

        Returns:
            Number of unique chapter files (counting outline files only)
        """
        steps_dir = os.path.join(work_dir, "steps")
        if not os.path.exists(steps_dir):
            return 0

        # Count unique chapter numbers (chapter_X_Y_outline.txt files)
        import re
        chapter_pattern = re.compile(r'^chapter_(\d+)_(\d+)_outline\.txt$')
        chapters = set()
        for filename in os.listdir(steps_dir):
            match = chapter_pattern.match(filename)
            if match:
                vol_num = int(match.group(1))
                chap_num = int(match.group(2))
                chapters.add((vol_num, chap_num))
        return len(chapters)

    def _calculate_total_words(self, work_dir: str) -> int:
        """
        Calculate total word count from all chapter content files.

        Chapter content files are stored in steps/ directory as:
        - chapter_{vol}_{chap}_content.txt

        Args:
            work_dir: Work directory path

        Returns:
            Total word count
        """
        steps_dir = os.path.join(work_dir, "steps")
        if not os.path.exists(steps_dir):
            return 0

        total = 0
        for filename in os.listdir(steps_dir):
            if filename.endswith('_content.txt') and filename.startswith('chapter_'):
                content_path = os.path.join(steps_dir, filename)
                try:
                    with open(content_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        total += len(content)
                except IOError:
                    pass
        return total

    def create_work(self, work_data: Dict[str, Any]) -> Work:
        """
        Create a new work.

        Args:
            work_data: Dictionary containing work creation parameters:
                - category: Work category
                - reference_works: List of reference works
                - creation_guide: User guidance
                - literary_style_category: Literary style category
                - chapters_per_volume: Chapters per volume
                - words_per_chapter: Words per chapter

        Returns:
            Created Work instance

        Raises:
            StorageError: If storage operations fail
        """
        self._ensure_works_dir()

        # Generate work ID with sequential numbering
        today = datetime.now().strftime('%Y%m%d')
        sequence_number = self._get_next_sequential_number()
        work_id = Work.generate_work_id(today, sequence_number)

        # Create work instance with generated ID
        work = Work(
            id=work_id,
            title=work_data.get('title', ''),
            category=work_data.get('category', ''),
            reference_works=work_data.get('reference_works', []),
            creation_guide=work_data.get('creation_guide', ''),
            literary_style_category=work_data.get('literary_style_category', ''),
            chapters_per_volume=work_data.get('chapters_per_volume', 20),
            words_per_chapter=work_data.get('words_per_chapter', 3000)
        )

        # Create work directory
        work_dir = self._get_work_dir(work.id)
        try:
            os.makedirs(work_dir, exist_ok=True)
            os.makedirs(os.path.join(work_dir, 'covers'), exist_ok=True)
            os.makedirs(os.path.join(work_dir, 'volumes'), exist_ok=True)
            os.makedirs(os.path.join(work_dir, 'chapters'), exist_ok=True)

            # Save work info
            self._save_work_info(work)

            # Add to cache
            self._works_cache[work.id] = work

            self.logger.info(f"Created new work: {work.id}")
            return work

        except OSError as e:
            self.logger.error(f"Failed to create work directory: {e}")
            # Clean up partial creation
            if os.path.exists(work_dir):
                shutil.rmtree(work_dir)
            raise StorageError(f"Failed to create work: {e}")

    def _save_work_info(self, work: Work, force: bool = False) -> None:
        """
        Save work info to JSON file.

        Creates a backup of the existing file before overwriting.
        Uses file locking to prevent concurrent access.

        Args:
            work: Work instance to save
            force: If True, bypass lock check (use with caution)

        Raises:
            ConcurrentAccessError: If work is locked by another process
            FileLockError: If lock operations fail
        """
        work.update_timestamp()
        work_path = self._get_work_info_path(work.id)

        # Check if work is locked by another process (unless force=True)
        if not force and self._lock_manager.is_work_locked(work.id):
            lock_info = self._lock_manager.get_lock_info(work.id)
            raise ConcurrentAccessError(work.id, lock_info)

        # Acquire lock for this save operation
        lock = self._lock_manager.acquire_lock(work.id, timeout=5.0, blocking=True)
        if lock is None:
            raise FileLockError(
                work_path,
                reason="无法获取文件锁，可能正被其他进程编辑",
                message=f"保存失败：作品 {work.id} 正被编辑中"
            )

        try:
            # Create backup if file exists
            if os.path.exists(work_path):
                self._create_backup(work_path)

            with open(work_path, 'w', encoding='utf-8') as f:
                json.dump(work.to_dict(), f, indent=4, ensure_ascii=False)

            self.logger.debug(f"Saved work info: {work_path}")

        finally:
            # Always release the lock
            lock.release()
            if work.id in self._active_locks:
                del self._active_locks[work.id]

    def get_work(self, work_id: str) -> Optional[Work]:
        """
        Get a work by ID.

        Args:
            work_id: Work identifier

        Returns:
            Work instance or None if not found
        """
        if work_id in self._works_cache:
            return self._works_cache[work_id]

        # Try to load from disk
        work_info_path = self._get_work_info_path(work_id)
        if os.path.exists(work_info_path):
            work = self._load_work_from_file(work_info_path)
            if work:
                self._works_cache[work_id] = work
                return work

        return None

    def reload_work(self, work_id: str) -> Optional[Work]:
        """
        Reload a work from disk, bypassing cache.

        Args:
            work_id: Work identifier

        Returns:
            Work instance or None if not found
        """
        work_info_path = self._get_work_info_path(work_id)
        if not os.path.exists(work_info_path):
            return None

        work = self._load_work_from_file(work_info_path)
        if work:
            self._works_cache[work_id] = work
        return work

    def reload(self) -> None:
        """
        Reload all works from disk, bypassing cache.
        Call this after settings change to refresh work list.
        """
        self._load_all_works()

    def get_all_works(self) -> List[Work]:
        """
        Get all works.

        Returns:
            List of all Work instances
        """
        # Refresh from disk to ensure latest data
        self._load_all_works()
        return list(self._works_cache.values())

    def update_work(self, work: Work) -> Work:
        """
        Update an existing work.

        Args:
            work: Work instance with updated data

        Returns:
            Updated Work instance

        Raises:
            WorkNotFoundError: If work doesn't exist
        """
        if work.id not in self._works_cache:
            raise WorkNotFoundError(f"Work not found: {work.id}")

        self._save_work_info(work)
        self._works_cache[work.id] = work

        self.logger.info(f"Updated work: {work.id}")
        return work

    def delete_work(self, work_id: str) -> bool:
        """
        Delete a work.

        Args:
            work_id: Work identifier

        Returns:
            True if deleted successfully

        Raises:
            WorkNotFoundError: If work doesn't exist
        """
        if work_id not in self._works_cache:
            raise WorkNotFoundError(f"Work not found: {work_id}")

        work_dir = self._get_work_dir(work_id)

        try:
            shutil.rmtree(work_dir)
            del self._works_cache[work_id]
            self.logger.info(f"Deleted work: {work_id}")
            return True

        except OSError as e:
            self.logger.error(f"Failed to delete work: {e}")
            raise StorageError(f"Failed to delete work: {e}")

    def search_works(self, query: str) -> List[Work]:
        """
        Search works by title or category.

        Args:
            query: Search query string

        Returns:
            List of matching Work instances
        """
        query = query.lower()
        results = []

        for work in self.get_all_works():
            if (query in work.title.lower() or
                query in work.category.lower() or
                query in work.creation_guide.lower()):
                results.append(work)

        return results

    def refresh_work_stats(self, work: Work) -> Work:
        """
        Refresh work statistics (chapter count, word count).

        Args:
            work: Work instance to refresh

        Returns:
            Updated Work instance
        """
        work_dir = self._get_work_dir(work.id)
        work.volume_count = self._count_volumes(work_dir)
        work.chapter_count = self._count_chapters(work_dir)
        work.word_count = self._calculate_total_words(work_dir)
        return work

    def import_work_from_zip(self, zip_path: str) -> Work:
        """
        Import a work from a ZIP file.

        Args:
            zip_path: Path to the ZIP file

        Returns:
            Imported Work instance

        Raises:
            StorageError: If import operations fail
        """
        import zipfile

        if not os.path.exists(zip_path):
            raise StorageError(f"ZIP file not found: {zip_path}")

        if not zip_path.lower().endswith('.zip'):
            raise StorageError("Invalid ZIP file")

        self._ensure_works_dir()

        try:
            # Extract ZIP to temp directory
            temp_dir = os.path.join(self.works_dir, "_temp_import")
            os.makedirs(temp_dir, exist_ok=True)

            with zipfile.ZipFile(zip_path, 'r') as zip_file:
                zip_file.extractall(temp_dir)

            # Find work_info.json in extracted contents
            work_info_path = None
            for root, dirs, files in os.walk(temp_dir):
                if 'work_info.json' in files:
                    work_info_path = os.path.join(root, 'work_info.json')
                    break

            if not work_info_path:
                raise StorageError("Invalid work package: work_info.json not found")

            # Load work info to get work ID
            with open(work_info_path, 'r', encoding='utf-8') as f:
                work_data = json.load(f)

            work_id = work_data.get('id')
            if not work_id:
                raise StorageError("Invalid work package: missing work ID")

            # Move extracted files to proper location
            source_dir = os.path.dirname(work_info_path)
            target_dir = self._get_work_dir(work_id)

            if os.path.exists(target_dir):
                raise WorkExistsError(f"Work already exists: {work_id}")

            # Move files from temp to target
            shutil.move(source_dir, target_dir)

            # Clean up temp directory
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)

            # Load work into cache
            work = self._load_work_from_file(self._get_work_info_path(work_id))
            if work:
                self._works_cache[work_id] = work
                self.logger.info(f"Imported work from ZIP: {work_id}")
                return work

            raise StorageError("Failed to load imported work")

        except zipfile.BadZipFile as e:
            raise StorageError(f"Invalid ZIP file: {e}")
        except Exception as e:
            self.logger.error(f"Failed to import work from ZIP: {e}")
            raise StorageError(f"Failed to import work: {e}")

    def import_work_from_directory(self, source_dir: str) -> Work:
        """
        Import a work from an existing directory.

        Args:
            source_dir: Path to the source work directory

        Returns:
            Imported Work instance

        Raises:
            StorageError: If import operations fail
        """
        if not os.path.exists(source_dir):
            raise StorageError(f"Source directory not found: {source_dir}")

        if not os.path.isdir(source_dir):
            raise StorageError("Source is not a directory")

        # Find work_info.json in source directory
        work_info_path = os.path.join(source_dir, 'work_info.json')
        if not os.path.exists(work_info_path):
            raise StorageError("Invalid work directory: work_info.json not found")

        # Load work info to get work ID
        with open(work_info_path, 'r', encoding='utf-8') as f:
            work_data = json.load(f)

        work_id = work_data.get('id')
        if not work_id:
            raise StorageError("Invalid work directory: missing work ID")

        # Check if work already exists
        target_dir = self._get_work_dir(work_id)
        if os.path.exists(target_dir):
            raise WorkExistsError(f"Work already exists: {work_id}")

        self._ensure_works_dir()

        try:
            # Copy directory to target location
            shutil.copytree(source_dir, target_dir)

            # Load work into cache
            work = self._load_work_from_file(self._get_work_info_path(work_id))
            if work:
                self._works_cache[work_id] = work
                self.logger.info(f"Imported work from directory: {work_id}")
                return work

            raise StorageError("Failed to load imported work")

        except Exception as e:
            self.logger.error(f"Failed to import work from directory: {e}")
            raise StorageError(f"Failed to import work: {e}")

    def export_work_to_zip(self, work_id: str, dest_path: str) -> bool:
        """
        Export a work to a ZIP file.

        Args:
            work_id: Work identifier
            dest_path: Destination path for the ZIP file

        Returns:
            True if exported successfully

        Raises:
            WorkNotFoundError: If work doesn't exist
            StorageError: If export operations fail
        """
        if work_id not in self._works_cache:
            raise WorkNotFoundError(f"Work not found: {work_id}")

        work_dir = self._get_work_dir(work_id)
        if not os.path.exists(work_dir):
            raise StorageError(f"Work directory not found: {work_dir}")

        try:
            import zipfile

            # Ensure destination directory exists
            dest_dir = os.path.dirname(dest_path)
            if dest_dir and not os.path.exists(dest_dir):
                os.makedirs(dest_dir, exist_ok=True)

            # Create ZIP file
            with zipfile.ZipFile(dest_path, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                for root, dirs, files in os.walk(work_dir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, work_dir)
                        zip_file.write(file_path, arcname)

            self.logger.info(f"Exported work {work_id} to {dest_path}")
            return True

        except Exception as e:
            self.logger.error(f"Failed to export work: {e}")
            raise StorageError(f"Failed to export work: {e}")

    def save_step_content(
        self,
        work_id: str,
        step_id: str,
        content: str
    ) -> bool:
        """
        Save content for a specific step to individual txt file.

        Each step is stored in a separate txt file in the steps/ subdirectory.
        Filename is the step_id (e.g., volume_1.txt, story_summary.txt)
        File exists = step completed

        Args:
            work_id: Work identifier
            step_id: Step identifier (e.g., 'book_title', 'story_summary', 'worldbuilding')
            content: Content to save

        Returns:
            True if saved successfully

        Raises:
            WorkNotFoundError: If work doesn't exist
            StorageError: If save operations fail
        """
        if work_id not in self._works_cache:
            # Try to load from disk
            work_info_path = self._get_work_info_path(work_id)
            if not os.path.exists(work_info_path):
                raise WorkNotFoundError(f"Work not found: {work_id}")
            work = self._load_work_from_file(work_info_path)
            if work:
                self._works_cache[work_id] = work
            else:
                raise WorkNotFoundError(f"Work not found: {work_id}")

        # Get work directory
        work_dir = self._get_work_dir(work_id)

        # Create steps directory
        steps_dir = os.path.join(work_dir, "steps")
        os.makedirs(steps_dir, exist_ok=True)

        # Save to txt file (filename = step_id.txt)
        step_file = os.path.join(steps_dir, f"{step_id}.txt")

        try:
            with open(step_file, 'w', encoding='utf-8') as f:
                f.write(content)

            self.logger.info(f"Saved step {step_id} to {step_file}")
            return True

        except Exception as e:
            self.logger.error(f"Failed to save step {step_id}: {e}")
            raise StorageError(f"Failed to save step content: {e}")

    def load_step_content(
        self,
        work_id: str,
        step_id: str
    ) -> Optional[str]:
        """
        Load content for a specific step from txt file.

        File exists = step completed
        Filename: {step_id}.txt

        Args:
            work_id: Work identifier
            step_id: Step identifier (e.g., 'book_title', 'story_summary')

        Returns:
            Content string or None if not found

        Raises:
            WorkNotFoundError: If work doesn't exist
        """
        if work_id not in self._works_cache:
            # Try to load from disk
            work_info_path = self._get_work_info_path(work_id)
            if not os.path.exists(work_info_path):
                raise WorkNotFoundError(f"Work not found: {work_id}")
            work = self._load_work_from_file(work_info_path)
            if work:
                self._works_cache[work_id] = work
            else:
                raise WorkNotFoundError(f"Work not found: {work_id}")

        # Get work directory
        work_dir = self._get_work_dir(work_id)

        # Try to load from steps directory (.txt file)
        steps_dir = os.path.join(work_dir, "steps")
        step_file = os.path.join(steps_dir, f"{step_id}.txt")

        if os.path.exists(step_file):
            try:
                with open(step_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                self.logger.info(f"Loaded step {step_id} from {step_file}: {len(content)} chars")
                return content
            except Exception as e:
                self.logger.error(f"Failed to load step {step_id}: {e}")
                return None

        # Also check work_info.json for backward compatibility
        # Only for book_title (title) and cover_image (cover_url)
        # Other AI-generated content is no longer stored in work_info.json
        self.logger.info(f"Step file not found, trying work_info.json for {step_id}")
        work = self._works_cache.get(work_id)
        if work:
            field_map = {
                'book_title': 'title',
                'cover_image': 'cover_url',
            }
            field = field_map.get(step_id)
            if field:
                content = getattr(work, field, "")
                if content:
                    self.logger.info(f"Loaded {step_id} from work_info.json (backward compat)")
                    return content

        return None

    def _save_basic_info_content(
        self,
        work_id: str,
        step_id: str,
        content: str
    ) -> bool:
        """
        Save basic info content to work_info.json.

        Note: Only book_title and cover_image are saved to work_info.json.
              Other AI-generated content (story_summary, worldbuilding, character_design,
              reference_analysis, pattern_analysis) is stored in steps/ directory files only.

        Args:
            work_id: Work identifier
            step_id: One of 'book_title', 'cover_image'
            content: Content to save

        Returns:
            True if saved successfully
        """
        work = self._works_cache.get(work_id)
        if not work:
            raise WorkNotFoundError(f"Work not found: {work_id}")

        # Map step_id to work attribute
        # Note: Only metadata fields are saved to work_info.json
        # AI-generated content (story_summary, worldbuilding, character_design, etc.)
        # is stored in steps/ directory files only
        field_map = {
            'book_title': 'title',
            'cover_image': 'cover_url',
        }

        field_name = field_map.get(step_id)
        if field_name:
            setattr(work, field_name, content)
            self._save_work_info(work)
            self.logger.info(f"Saved {step_id} for work {work_id}")
            return True

        return False

    def save_cover_image(
        self,
        work_id: str,
        image_data: bytes,
        filename: str = "cover.jpg"
    ) -> str:
        """
        Save cover image file to the covers subdirectory.

        Args:
            work_id: Work identifier
            image_data: Image data as bytes
            filename: Filename for the cover image (default: cover.jpg)

        Returns:
            Full path to the saved cover image

        Raises:
            WorkNotFoundError: If work doesn't exist
            StorageError: If save operations fail
        """
        if work_id not in self._works_cache:
            # Try to load from disk
            work_info_path = self._get_work_info_path(work_id)
            if not os.path.exists(work_info_path):
                raise WorkNotFoundError(f"Work not found: {work_id}")
            work = self._load_work_from_file(work_info_path)
            if work:
                self._works_cache[work_id] = work
            else:
                raise WorkNotFoundError(f"Work not found: {work_id}")

        # Ensure covers directory exists
        work_dir = self._get_work_dir(work_id)
        covers_dir = os.path.join(work_dir, 'covers')
        os.makedirs(covers_dir, exist_ok=True)

        # Save image file
        cover_path = os.path.join(covers_dir, filename)
        try:
            with open(cover_path, 'wb') as f:
                f.write(image_data)

            # Update work cover_url to point to the saved file
            work = self._works_cache[work_id]
            work.cover_url = cover_path
            self._save_work_info(work)

            self.logger.info(f"Saved cover image for work {work_id} at {cover_path}")
            return cover_path

        except IOError as e:
            self.logger.error(f"Failed to save cover image: {e}")
            raise StorageError(f"Failed to save cover image: {e}")

    def get_cover_image_path(self, work_id: str, filename: str = "cover.jpg") -> Optional[str]:
        """
        Get the path to a cover image file.

        Args:
            work_id: Work identifier
            filename: Filename of the cover image (default: cover.jpg)

        Returns:
            Full path to the cover image, or None if not found
        """
        work_dir = self._get_work_dir(work_id)
        cover_path = os.path.join(work_dir, 'covers', filename)

        if os.path.exists(cover_path):
            return cover_path
        return None

    def get_covers_directory(self, work_id: str) -> str:
        """
        Get the covers directory path for a work.

        Args:
            work_id: Work identifier

        Returns:
            Full path to the covers directory
        """
        work_dir = self._get_work_dir(work_id)
        return os.path.join(work_dir, 'covers')

    def save_work_template(
        self,
        work_id: str,
        template_name: str,
        content: str
    ) -> str:
        """
        Save a work-specific template.

        Templates are stored in the work's templates/ subdirectory,
        allowing each work to have its own customized templates.

        Args:
            work_id: Work identifier
            template_name: Name of the template (e.g., 'chapter_content.txt')
            content: Template content to save

        Returns:
            Full path to the saved template file

        Raises:
            StorageError: If unable to save template
            WorkNotFoundError: If work doesn't exist
        """
        if work_id not in self._works_cache:
            # Try to load from disk
            work_info_path = self._get_work_info_path(work_id)
            if not os.path.exists(work_info_path):
                raise WorkNotFoundError(f"Work not found: {work_id}")
            work = self._load_work_from_file(work_info_path)
            if work:
                self._works_cache[work_id] = work
            else:
                raise WorkNotFoundError(f"Work not found: {work_id}")

        # Ensure templates directory exists
        work_dir = self._get_work_dir(work_id)
        templates_dir = os.path.join(work_dir, 'templates')
        os.makedirs(templates_dir, exist_ok=True)

        # Save template file
        template_path = os.path.join(templates_dir, template_name)
        try:
            with open(template_path, 'w', encoding='utf-8') as f:
                f.write(content)

            self.logger.info(
                f"Saved work template for work {work_id} at {template_path}"
            )
            return template_path

        except IOError as e:
            self.logger.error(f"Failed to save work template: {e}")
            raise StorageError(f"Failed to save work template: {e}")

    def get_work_template(self, work_id: str, template_name: str) -> Optional[str]:
        """
        Get the content of a work-specific template.

        Args:
            work_id: Work identifier
            template_name: Name of the template file

        Returns:
            Template content as string, or None if template doesn't exist

        Raises:
            StorageError: If unable to read template
        """
        work_dir = self._get_work_dir(work_id)
        template_path = os.path.join(work_dir, 'templates', template_name)

        if not os.path.exists(template_path):
            return None

        try:
            with open(template_path, 'r', encoding='utf-8') as f:
                content = f.read()

            self.logger.debug(
                f"Loaded work template for work {work_id} from {template_path}"
            )
            return content

        except IOError as e:
            self.logger.error(f"Failed to load work template: {e}")
            raise StorageError(f"Failed to load work template: {e}")

    def get_templates_directory(self, work_id: str) -> str:
        """
        Get the templates directory path for a work.

        Args:
            work_id: Work identifier

        Returns:
            Full path to the templates directory
        """
        work_dir = self._get_work_dir(work_id)
        return os.path.join(work_dir, 'templates')

    def list_work_templates(self, work_id: str) -> List[str]:
        """
        List all templates available for a work.

        Args:
            work_id: Work identifier

        Returns:
            List of template filenames
        """
        templates_dir = self.get_templates_directory(work_id)

        if not os.path.exists(templates_dir):
            return []

        try:
            templates = [
                f for f in os.listdir(templates_dir)
                if os.path.isfile(os.path.join(templates_dir, f))
            ]
            return templates

        except IOError as e:
            self.logger.error(f"Failed to list work templates: {e}")
            return []

    def _save_volume_content(
        self,
        work_id: str,
        step_id: str,
        content: str,
        check_lock: bool = True
    ) -> bool:
        """
        Save volume outline content to TXT file in steps/ directory.

        Volume files are stored as:
        - volume_{vol_num}.txt (分卷大纲)
        - volume_{vol_num}_characters.txt (分卷人物)

        Args:
            work_id: Work identifier
            step_id: Volume step ID (e.g., 'volume_1', 'volume_1_characters')
            content: Content to save
            check_lock: Whether to check for concurrent access lock

        Returns:
            True if saved successfully

        Raises:
            ConcurrentAccessError: If work is locked by another process and check_lock=True
        """
        # Parse volume number from step_id
        # Format: volume_{vol_num} or volume_{vol_num}_{field}
        parts = step_id.split('_')
        if len(parts) < 2:
            return False

        try:
            vol_num = int(parts[1])
        except (ValueError, IndexError):
            return False

        # Get field name
        field_name = parts[2] if len(parts) > 2 else ''

        # Check for concurrent access if requested
        if check_lock and self._lock_manager.is_work_locked(work_id):
            lock_info = self._lock_manager.get_lock_info(work_id)
            raise ConcurrentAccessError(work_id, lock_info)

        # Ensure steps directory exists
        work_dir = self._get_work_dir(work_id)
        steps_dir = os.path.join(work_dir, 'steps')
        os.makedirs(steps_dir, exist_ok=True)

        # Save to TXT file
        if field_name == 'characters':
            volume_file = os.path.join(steps_dir, f'volume_{vol_num}_characters.txt')
        else:
            volume_file = os.path.join(steps_dir, f'volume_{vol_num}.txt')

        # Create backup if file exists
        if os.path.exists(volume_file):
            self._create_backup(volume_file)

        # Save volume content
        with open(volume_file, 'w', encoding='utf-8') as f:
            f.write(content)

        self.logger.info(f"Saved {step_id} for work {work_id} to {volume_file}")
        return True

    def _save_chapter_content(
        self,
        work_id: str,
        step_id: str,
        content: str,
        check_lock: bool = True
    ) -> bool:
        """
        Save chapter content to TXT file in steps/ directory.

        Chapter files are stored as:
        - chapter_{vol_num}_{chapter_num}_outline.txt
        - chapter_{vol_num}_{chapter_num}_content.txt

        Args:
            work_id: Work identifier
            step_id: Chapter step ID (e.g., 'chapter_1_1_outline', 'chapter_1_1_content')
            content: Content to save
            check_lock: Whether to check for concurrent access lock

        Returns:
            True if saved successfully

        Raises:
            ConcurrentAccessError: If work is locked by another process and check_lock=True
        """
        # Parse chapter info from step_id
        # Format: chapter_{vol_num}_{chapter_num}_{field}
        parts = step_id.split('_')
        if len(parts) < 3:
            return False

        try:
            vol_num = int(parts[1])
            chapter_num = int(parts[2])
        except (ValueError, IndexError):
            return False

        # Get field name (outline or content)
        field_name = parts[3] if len(parts) > 3 else 'content'
        if field_name not in ('outline', 'content'):
            field_name = 'content'

        # Check for concurrent access if requested
        if check_lock and self._lock_manager.is_work_locked(work_id):
            lock_info = self._lock_manager.get_lock_info(work_id)
            raise ConcurrentAccessError(work_id, lock_info)

        # Ensure steps directory exists
        work_dir = self._get_work_dir(work_id)
        steps_dir = os.path.join(work_dir, 'steps')
        os.makedirs(steps_dir, exist_ok=True)

        # Save to TXT file
        chapter_file = os.path.join(steps_dir, f'chapter_{vol_num}_{chapter_num}_{field_name}.txt')

        # Create backup if file exists
        if os.path.exists(chapter_file):
            self._create_backup(chapter_file)

        # Save chapter content
        with open(chapter_file, 'w', encoding='utf-8') as f:
            f.write(content)

        self.logger.info(f"Saved {step_id} for work {work_id} to {chapter_file}")
        return True

    def update_last_published_chapter(
        self,
        work_id: str,
        chapter_number: int
    ) -> bool:
        """
        Update the last published chapter for a work.

        This is called after successfully publishing chapters to track
        which chapter was last published, so the next publish session
        can default to the next chapter.

        Args:
            work_id: Work identifier
            chapter_number: The chapter number that was last published

        Returns:
            True if updated successfully

        Raises:
            WorkNotFoundError: If work doesn't exist
        """
        if work_id not in self._works_cache:
            # Try to load from disk
            work_info_path = self._get_work_info_path(work_id)
            if not os.path.exists(work_info_path):
                raise WorkNotFoundError(f"Work not found: {work_id}")
            work = self._load_work_from_file(work_info_path)
            if work:
                self._works_cache[work_id] = work
            else:
                raise WorkNotFoundError(f"Work not found: {work_id}")

        work = self._works_cache[work_id]

        # Only update if the new chapter is greater than current
        if chapter_number > work.last_published_chapter:
            work.last_published_chapter = chapter_number
            self._save_work_info(work)
            self.logger.info(
                f"Updated last_published_chapter to {chapter_number} for work {work_id}"
            )
            return True

        return False

    def check_file_corruption(self, file_path: str) -> Dict[str, Any]:
        """
        Check if a JSON file is corrupted.

        Args:
            file_path: Path to JSON file to check

        Returns:
            Dictionary with corruption status:
            - is_corrupted: bool
            - error: str or None
            - backup_available: bool
            - suggestion: str or None
        """
        result = {
            'is_corrupted': False,
            'error': None,
            'backup_available': False,
            'suggestion': None
        }

        if not os.path.exists(file_path):
            result['is_corrupted'] = True
            result['error'] = '文件不存在'
            return result

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                json.load(f)
            return result  # Not corrupted
        except json.JSONDecodeError as e:
            result['is_corrupted'] = True
            result['error'] = f'JSON 格式错误：{str(e)}'
            result['backup_available'] = self._backup_exists(file_path)
            result['suggestion'] = '可尝试从备份文件恢复' if result['backup_available'] else '需要手动修复或重新创建文件'
            return result
        except IOError as e:
            result['is_corrupted'] = True
            result['error'] = f'读取失败：{str(e)}'
            return result

    def recover_from_backup(self, file_path: str) -> Dict[str, Any]:
        """
        Attempt to recover a file from its backup.

        Args:
            file_path: Path to file to recover

        Returns:
            Dictionary with recovery status:
            - success: bool
            - error: str or None
            - message: str
        """
        result = {
            'success': False,
            'error': None,
            'message': ''
        }

        if not self._backup_exists(file_path):
            result['error'] = '备份文件不存在'
            result['message'] = '无法恢复：没有可用的备份文件'
            return result

        if self._restore_from_backup(file_path):
            # Invalidate cache for the restored work so it will be reloaded from disk
            work_id = self._extract_work_id_from_path(file_path)
            if work_id and work_id in self._works_cache:
                del self._works_cache[work_id]
                self.logger.info(f"Invalidated cache for work {work_id} after restore")

            result['success'] = True
            result['message'] = '已成功从备份恢复'
            return result
        else:
            result['error'] = '恢复失败'
            result['message'] = '从备份恢复失败，请查看日志获取详细信息'
            return result

    def get_backup_info(self, file_path: str) -> Dict[str, Any]:
        """
        Get information about a file's backup.

        Args:
            file_path: Path to original file

        Returns:
            Dictionary with backup information:
            - exists: bool
            - backup_path: str or None
            - size: int or None
            - modified_time: str or None
        """
        result = {
            'exists': False,
            'backup_path': None,
            'size': None,
            'modified_time': None
        }

        backup_path = self._get_backup_path(file_path)
        if os.path.exists(backup_path):
            stat = os.stat(backup_path)
            result['exists'] = True
            result['backup_path'] = backup_path
            result['size'] = stat.st_size
            from datetime import datetime
            result['modified_time'] = datetime.fromtimestamp(stat.st_mtime).isoformat()

        return result

    # ========================================================================
    # Concurrent Access Control Methods
    # ========================================================================

    def acquire_work_lock(self, work_id: str, timeout: float = 5.0,
                          blocking: bool = True) -> bool:
        """
        Acquire an exclusive lock on a work for editing.

        This should be called before starting an editing session on a work.
        The lock prevents other processes/users from modifying the same work
        concurrently.

        Args:
            work_id: The work ID to lock
            timeout: Maximum time to wait for lock (seconds)
            blocking: Whether to wait for lock or fail immediately

        Returns:
            True if lock acquired, False otherwise

        Raises:
            WorkNotFoundError: If work doesn't exist
        """
        # Verify work exists
        if work_id not in self._works_cache:
            work_info_path = self._get_work_info_path(work_id)
            if not os.path.exists(work_info_path):
                raise WorkNotFoundError(f"Work not found: {work_id}")

        # Check if already locked by this process
        if work_id in self._active_locks:
            self.logger.debug(f"Work {work_id} already locked by this process")
            return True

        # Check if locked by another process
        if self._lock_manager.is_work_locked(work_id):
            lock_info = self._lock_manager.get_lock_info(work_id)
            raise ConcurrentAccessError(work_id, lock_info)

        # Acquire lock
        lock = self._lock_manager.acquire_lock(work_id, timeout=timeout,
                                                blocking=blocking)
        if lock:
            self._active_locks[work_id] = lock
            self.logger.info(f"Acquired lock for work {work_id}")
            return True

        return False

    def release_work_lock(self, work_id: str) -> bool:
        """
        Release a lock on a work.

        This should be called when finishing an editing session.

        Args:
            work_id: The work ID to unlock

        Returns:
            True if lock released, False if no lock was held
        """
        if work_id not in self._active_locks:
            self.logger.debug(f"No active lock for work {work_id}")
            return False

        lock = self._active_locks[work_id]
        lock.release()
        del self._active_locks[work_id]
        self.logger.info(f"Released lock for work {work_id}")
        return True

    def is_work_locked(self, work_id: str) -> bool:
        """
        Check if a work is currently locked by another process.

        Args:
            work_id: The work ID to check

        Returns:
            True if work is locked by another process
        """
        # Check if locked by this process
        if work_id in self._active_locks:
            return True

        # Check if locked by another process
        return self._lock_manager.is_work_locked(work_id)

    def get_work_lock_info(self, work_id: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a work's lock status.

        Args:
            work_id: The work ID

        Returns:
            Lock info dict or None if no lock
        """
        if work_id in self._active_locks:
            return {
                'locked': True,
                'locked_by_this_process': True,
                'lock_object': self._active_locks[work_id]
            }

        lock_info = self._lock_manager.get_lock_info(work_id)
        if lock_info:
            return {
                'locked': True,
                'locked_by_this_process': False,
                **lock_info
            }

        return {'locked': False}

    def cleanup_stale_work_lock(self, work_id: str) -> bool:
        """
        Clean up a stale lock for a work.

        Use this when a lock is known to be stale (e.g., after a crash).

        Args:
            work_id: The work ID

        Returns:
            True if lock was cleaned up
        """
        return self._lock_manager.cleanup_stale_lock(work_id)

    def release_all_locks(self) -> None:
        """
        Release all active locks held by this process.

        This should be called during cleanup/shutdown.
        """
        work_ids = list(self._active_locks.keys())
        for work_id in work_ids:
            try:
                self.release_work_lock(work_id)
            except Exception as e:
                self.logger.error(f"Error releasing lock for {work_id}: {e}")
        self.logger.info(f"Released all {len(work_ids)} active locks")

    # ============== Chapter Metadata Methods ==============

    def _get_chapters_dir(self, work_id: str) -> str:
        """
        获取章节元数据目录路径。

        Args:
            work_id: 作品ID

        Returns:
            章节目录的完整路径
        """
        return os.path.join(self._get_work_dir(work_id), "chapters")

    def _ensure_chapters_dir(self, work_id: str) -> str:
        """
        确保章节目录存在。

        Args:
            work_id: 作品ID

        Returns:
            章节目录的完整路径
        """
        chapters_dir = self._get_chapters_dir(work_id)
        os.makedirs(chapters_dir, exist_ok=True)
        return chapters_dir

    def save_chapter_metadata(self, work_id: str, chapter_index: int, metadata: Dict[str, Any]) -> bool:
        """
        保存单个章节的元数据到文件。

        Args:
            work_id: 作品ID
            chapter_index: 章节号
            metadata: 章节元数据字典

        Returns:
            True if saved successfully
        """
        try:
            chapters_dir = self._ensure_chapters_dir(work_id)
            file_path = os.path.join(chapters_dir, f"chapter_{chapter_index}.json")

            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, ensure_ascii=False, indent=2)

            self.logger.info(f"[work_manager] Saved chapter metadata: chapter_{chapter_index}")
            return True

        except Exception as e:
            self.logger.error(f"[work_manager] Failed to save chapter metadata: {e}")
            return False

    def load_chapter_metadata(self, work_id: str, chapter_index: int) -> Optional[Dict[str, Any]]:
        """
        读取单个章节的元数据。

        Args:
            work_id: 作品ID
            chapter_index: 章节号

        Returns:
            章节元数据字典，如果不存在则返回None
        """
        try:
            chapters_dir = self._get_chapters_dir(work_id)
            file_path = os.path.join(chapters_dir, f"chapter_{chapter_index}.json")

            if not os.path.exists(file_path):
                return None

            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)

        except Exception as e:
            self.logger.error(f"[work_manager] Failed to load chapter metadata: {e}")
            return None

    def load_all_chapter_metadata(self, work_id: str) -> List[Dict[str, Any]]:
        """
        读取所有章节的元数据。

        Args:
            work_id: 作品ID

        Returns:
            章节元数据列表
        """
        chapters = []
        try:
            chapters_dir = self._get_chapters_dir(work_id)
            if not os.path.exists(chapters_dir):
                return chapters

            for filename in os.listdir(chapters_dir):
                if filename.startswith("chapter_") and filename.endswith(".json"):
                    file_path = os.path.join(chapters_dir, filename)
                    with open(file_path, 'r', encoding='utf-8') as f:
                        chapters.append(json.load(f))

            # 按章节号排序
            chapters.sort(key=lambda x: x.get("index", 0))
            return chapters

        except Exception as e:
            self.logger.error(f"[work_manager] Failed to load all chapter metadata: {e}")
            return chapters

    def save_fanqie_chapters(self, work_id: str, chapters: List[Dict[str, Any]]) -> bool:
        """
        保存番茄已发布章节列表到文件（兼容旧接口）。

        Args:
            work_id: 作品ID
            chapters: 章节元数据列表

        Returns:
            True if saved successfully
        """
        try:
            for chapter in chapters:
                index = chapter.get("index")
                if index is not None:
                    self.save_chapter_metadata(work_id, index, chapter)
            return True
        except Exception as e:
            self.logger.error(f"[work_manager] Failed to save fanqie chapters: {e}")
            return False
