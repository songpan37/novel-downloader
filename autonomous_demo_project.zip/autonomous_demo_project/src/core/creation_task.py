"""
创作任务数据结构定义

定义创作任务、会话、步骤的数据结构，用于统一管理创作流程。
"""
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from datetime import datetime
from pathlib import Path


def get_logger():
    """Lazy load logger to avoid None during module import."""
    from utils.logger import get_logger as _get_logger
    return _get_logger() or _setup_fallback_logger()


def _setup_fallback_logger():
    """Setup a fallback logger if not already configured."""
    from utils.logger import setup_logger
    return setup_logger()


@dataclass
class StepInfo:
    """
    步骤信息

     Attributes:
        step_id: 步骤唯一标识 (e.g., 'style_setting', 'volume_1', 'chapter_1_1_content')
        step_name: 步骤显示名称 (e.g., '文风设定', '第 1 卷', '第 1 卷 第 1 章 正文')
        status: 状态 (pending | executing | completed | skipped)
        content: 步骤内容
        prompt_content: 渲染后的提示词内容
        session_id: 所属会话 ID
        completed_at: 完成时间 (ISO 格式字符串)
        file_path: 磁盘文件路径
        word_count: 字数
        metadata: 额外元数据
    """
    step_id: str
    step_name: str
    status: str  # pending | executing | completed | skipped
    content: str
    prompt_content: str
    session_id: str
    completed_at: Optional[str] = None
    file_path: Optional[str] = None
    word_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """初始化后处理"""
        if not self.completed_at and self.status == "completed":
            self.completed_at = datetime.now().isoformat()


@dataclass
class SessionInfo:
    """
    会话信息

    Attributes:
        session_id: 会话唯一标识 (e.g., 'basic_info', 'volume_1', 'chapter_1')
        session_name: 会话显示名称 (e.g., '基本设定', '第 1 卷', '第 1 卷 章节')
        session_type: 会话类型 (basic | reference | volume | chapter | summary)
        steps: 步骤列表（仅包含输出步骤）
        status: 会话状态 (pending | executing | completed | paused)
        started_at: 开始时间
        completed_at: 完成时间
        context_inputs: 上下文输入步骤 ID 列表（按顺序输入）
        ai_output_steps: AI 输出的步骤 ID 列表（按顺序生成）
    """
    session_id: str
    session_name: str
    session_type: str  # basic | reference | volume | chapter | summary
    steps: List[StepInfo] = field(default_factory=list)
    status: str = "pending"  # pending | executing | completed | paused
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    context_inputs: List[str] = field(default_factory=list)  # 输入步骤 ID 列表
    ai_output_steps: List[str] = field(default_factory=list)  # 输出步骤 ID 列表

    @property
    def completed_step_count(self) -> int:
        """已完成的步骤数"""
        return sum(1 for step in self.steps if step.status == "completed")

    @property
    def total_step_count(self) -> int:
        """总步骤数"""
        return len(self.steps)

    @property
    def progress_percentage(self) -> float:
        """进度百分比"""
        if self.total_step_count == 0:
            return 0.0
        return (self.completed_step_count / self.total_step_count) * 100


@dataclass
class CreationTask:
    """
    创作任务

    管理一次完整创作任务的所有状态信息。

    Attributes:
        task_id: 任务唯一标识
        work_id: 作品 ID
        work_data: 作品数据
        start_volume: 起始卷号
        end_volume: 结束卷号
        chapters_per_volume: 每卷章节数
        sessions: 会话列表
        created_at: 创建时间
        updated_at: 更新时间
        status: 任务状态 (not_started | in_progress | paused | completed)
    """
    task_id: str
    work_id: str
    work_data: Dict[str, Any]
    start_volume: int
    end_volume: int
    chapters_per_volume: int
    sessions: List[SessionInfo] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    status: str = "not_started"  # not_started | in_progress | paused | completed

    @property
    def completed_session_count(self) -> int:
        """已完成的会话数"""
        return sum(1 for s in self.sessions if s.status == "completed")

    @property
    def total_step_count(self) -> int:
        """总步骤数"""
        return sum(len(s.steps) for s in self.sessions)

    @property
    def completed_step_count(self) -> int:
        """已完成的步骤数"""
        return sum(s.completed_step_count for s in self.sessions)

    @property
    def progress_percentage(self) -> float:
        """进度百分比"""
        total = self.total_step_count
        if total == 0:
            return 0.0
        return (self.completed_step_count / total) * 100

    def update_timestamp(self) -> None:
        """更新时间戳"""
        self.updated_at = datetime.now().isoformat()

    def get_session_by_id(self, session_id: str) -> Optional[SessionInfo]:
        """根据 ID 获取会话"""
        for session in self.sessions:
            if session.session_id == session_id:
                return session
        return None

    def get_step_by_id(self, step_id: str) -> Optional[StepInfo]:
        """根据 ID 获取步骤"""
        for session in self.sessions:
            for step in session.steps:
                if step.step_id == step_id:
                    return step
        return None


class CreationTaskBuilder:
    """
    创作任务构建器

    负责根据作品数据和创作范围构建完整的任务结构体。
    """

    @staticmethod
    def _cleanup_empty_step_files(work_id: str, settings) -> None:
        """
        清理空的步骤文件

        如果步骤文件存在但内容为空，说明是之前创建但未完成的任务留下的，
        需要删除这些空文件，避免被误认为已完成的步骤。

        Args:
            work_id: 作品 ID
            settings: 应用设置对象
        """
        works_dir = Path(getattr(settings, 'works_dir', ''))
        if not works_dir or not work_id:
            return

        steps_dir = works_dir / work_id / "steps"
        if not steps_dir.exists():
            return

        deleted_count = 0
        for step_file in steps_dir.glob("*.txt"):
            # 只清理 prompt 文件，不清理内容文件
            if step_file.name.endswith("_prompt.txt"):
                continue

            try:
                content = step_file.read_text(encoding='utf-8')
                if not content or content.strip() == "":
                    step_file.unlink()
                    deleted_count += 1
                    get_logger().info(f"[CLEANUP] Removed empty step file: {step_file}")
            except IOError:
                pass

        if deleted_count > 0:
            get_logger().info(f"[CLEANUP] Total empty step files removed: {deleted_count}")

    @staticmethod
    def build_task(
        work_id: str,
        work_data: Dict[str, Any],
        start_volume: int,
        end_volume: int,
        settings
    ) -> CreationTask:
        """
        构建创作任务结构体

        Args:
            work_id: 作品 ID
            work_data: 作品数据字典
            start_volume: 起始卷号
            end_volume: 结束卷号
            settings: 应用设置对象

        Returns:
            CreationTask 实例
        """
        chapters_per_volume = work_data.get('chapters_per_volume', 5)
        now = datetime.now().isoformat()

        # 清理空的步骤文件（防止未完成的任务留下的空文件被误认为已完成）
        CreationTaskBuilder._cleanup_empty_step_files(work_id, settings)

        sessions = []

        # 1. 基本设定会话
        basic_session = CreationTaskBuilder._build_basic_session(work_data, work_id, settings)
        sessions.append(basic_session)

        # 2. 创作参考会话
        ref_sessions = CreationTaskBuilder._build_reference_sessions(
            work_data, start_volume, end_volume, chapters_per_volume, work_id, settings
        )
        sessions.extend(ref_sessions)

        # 3. 分卷信息会话
        volume_sessions = CreationTaskBuilder._build_volume_sessions(
            start_volume, end_volume, work_id, settings
        )
        sessions.extend(volume_sessions)

        # 4. 章节信息会话
        chapter_sessions = CreationTaskBuilder._build_chapter_sessions(
            start_volume, end_volume, chapters_per_volume, work_id, settings
        )
        sessions.extend(chapter_sessions)

        # 5. 分卷总结会话
        summary_sessions = CreationTaskBuilder._build_summary_sessions(
            start_volume, end_volume, work_id, settings
        )
        sessions.extend(summary_sessions)

        return CreationTask(
            task_id=f"task_{work_id}_{now}",
            work_id=work_id,
            work_data=work_data,
            start_volume=start_volume,
            end_volume=end_volume,
            chapters_per_volume=chapters_per_volume,
            sessions=sessions,
            created_at=now,
            updated_at=now,
            status="not_started"
        )

    @staticmethod
    def _build_basic_session(work_data: Dict[str, Any], work_id: str = None, settings = None) -> SessionInfo:
        """构建基本设定会话"""
        basic_steps = [
            ("style_setting", "文风设定"),
            ("story_summary", "故事梗概"),
            ("worldbuilding", "时空设定"),
            ("character_design", "人物设定"),
            ("book_title", "书名"),
            ("cover_image", "封面图片"),
        ]

        steps = []
        for step_id, step_name in basic_steps:
            content = ""

            # 从 steps/ 目录加载 AI 生成的内容
            if work_id and settings:
                works_dir = Path(getattr(settings, 'works_dir', ''))
                if works_dir:
                    step_file = works_dir / work_id / "steps" / f"{step_id}.txt"
                    if step_file.exists():
                        content = step_file.read_text(encoding='utf-8')

            steps.append(StepInfo(
                step_id=step_id,
                step_name=step_name,
                status="completed" if content else "pending",
                content=content,
                prompt_content="",
                session_id="basic_info",
                word_count=len(content) if content else 0
            ))

        # 会话状态：所有步骤完成则为 completed，否则为 pending
        session_status = "completed" if all(s.status == "completed" for s in steps) else "pending"

        return SessionInfo(
            session_id="basic_info",
            session_name="基本设定",
            session_type="basic",
            steps=steps,
            status=session_status,
            started_at=None,
            completed_at=None
        )

    @staticmethod
    def _build_reference_sessions(
        work_data: Dict[str, Any],
        start_volume: int,
        end_volume: int,
        chapters_per_volume: int,
        work_id: str = None,
        settings = None
    ) -> List[SessionInfo]:
        """构建创作参考会话"""
        sessions = []
        reference_works = work_data.get('reference_works', [])
        works_dir = Path(getattr(settings, 'works_dir', '')) if settings else Path()

        # 计算章节范围
        start_chapter = (start_volume - 1) * chapters_per_volume + 1
        end_chapter = end_volume * chapters_per_volume

        # 拆书参考 - 每个作品一个会话
        for work_name in reference_works:
            safe_name = work_name.replace('/', '_').replace('\\', '_').replace(':', '_')
            step_id = f"reference_{safe_name}_{start_chapter}_{end_chapter}"

            content = ""
            # 检查磁盘状态
            if works_dir and work_id:
                step_file = works_dir / work_id / "steps" / f"{step_id}.txt"
                if step_file.exists():
                    content = step_file.read_text(encoding='utf-8')

            # Extract only the second part if work_name contains '/'
            if '/' in work_name:
                work_name_only = work_name.split('/')[1]
            else:
                work_name_only = work_name
            steps = [StepInfo(
                step_id=step_id,
                step_name=f"{work_name_only}({start_chapter}-{end_chapter}章拆书)",
                status="completed" if content else "pending",
                content=content,
                prompt_content="",
                session_id=f"reference_{safe_name}",
                word_count=len(content) if content else 0
            )]

            sessions.append(SessionInfo(
                session_id=f"reference_{safe_name}",
                session_name=f"拆书：{work_name_only}",
                session_type="reference",
                steps=steps,
                status="completed" if content else "pending",
                started_at=None,
                completed_at=None
            ))

        # 创作公式 - 单个会话
        if reference_works:
            # Extract second part after '/' first, then truncate to 10 chars
            short_names = []
            for w in reference_works[:3]:
                if '/' in w:
                    short_names.append(w.split('/')[1][:10])
                else:
                    short_names.append(w[:10])
            work_names = '_'.join(short_names)
            step_id = f"pattern_{work_names}_{start_chapter}_{end_chapter}"

            content = ""
            # 检查磁盘状态
            if works_dir and work_id:
                step_file = works_dir / work_id / "steps" / f"{step_id}.txt"
                if step_file.exists():
                    content = step_file.read_text(encoding='utf-8')

            steps = [StepInfo(
                step_id=step_id,
                step_name=f"创作公式({start_chapter}-{end_chapter}章)",
                status="completed" if content else "pending",
                content=content,
                prompt_content="",
                session_id="pattern_analysis",
                word_count=len(content) if content else 0
            )]

            sessions.append(SessionInfo(
                session_id="pattern_analysis",
                session_name="创作公式",
                session_type="reference",
                steps=steps,
                status="completed" if content else "pending",
                started_at=None,
                completed_at=None
            ))

        return sessions

    @staticmethod
    def _build_volume_sessions(
        start_volume: int,
        end_volume: int,
        work_id: str,
        settings
    ) -> List[SessionInfo]:
        """构建分卷信息会话

        每个分卷会话包含：
        - 输入步骤（5 步，每步单独发送，AI 确认）：
          1. 定义角色
          2. 定义任务
          3. 输入小说基本设定
          4. 输入前序剧情 (前 3 卷的分卷总结)
          5. 输入本次任务已完成的内容（已完成的分卷信息）
        - 输出步骤（同一会话中按顺序生成）：
          1. 分卷大纲
          2. 分卷人物
        """
        sessions = []
        works_dir = Path(getattr(settings, 'works_dir', ''))

        for vol_num in range(start_volume, end_volume + 1):
            # 定义输入步骤（context_inputs）
            context_inputs = [
                'volume_input_role',           # 1. 定义角色
                'volume_input_task',           # 2. 定义任务
                'volume_input_basic_setting',  # 3. 输入小说基本设定
                'volume_input_previous_plot',  # 4. 输入前序剧情
                'volume_input_completed',      # 5. 输入已完成的分卷信息
            ]

            # 定义输出步骤（ai_output_steps）
            ai_output_steps = [
                f'volume_{vol_num}',           # 分卷大纲
                f'volume_{vol_num}_characters', # 分卷人物
            ]

            steps = []

            # 分卷大纲
            outline_step = StepInfo(
                step_id=f"volume_{vol_num}",
                step_name=f"第{vol_num}卷 分卷大纲",
                status="pending",
                content="",
                prompt_content="",
                session_id=f"volume_{vol_num}",
                word_count=0
            )

            # 检查磁盘状态
            if works_dir and work_id:
                outline_file = works_dir / work_id / "steps" / f"volume_{vol_num}.txt"
                if outline_file.exists():
                    try:
                        content = outline_file.read_text(encoding='utf-8')
                        if content:
                            outline_step.content = content
                            outline_step.word_count = len(content)
                            outline_step.status = "completed"
                            outline_step.file_path = str(outline_file)
                            get_logger().info(f"[BUILD_VOLUME] Step {outline_step.step_id}: loaded {len(content)} chars from steps/, status=completed")
                        else:
                            get_logger().info(f"[BUILD_VOLUME] Step {outline_step.step_id}: file exists but empty, status=pending")
                    except IOError as e:
                        get_logger().warning(f"[BUILD_VOLUME] Step {outline_step.step_id}: failed to load from disk: {e}")
                else:
                    get_logger().info(f"[BUILD_VOLUME] Step {outline_step.step_id}: file not found in steps/, status=pending")

            steps.append(outline_step)

            # 分卷人物
            char_step = StepInfo(
                step_id=f"volume_{vol_num}_characters",
                step_name=f"第{vol_num}卷 分卷人物",
                status="pending",
                content="",
                prompt_content="",
                session_id=f"volume_{vol_num}",
                word_count=0
            )

            if works_dir and work_id:
                char_file = works_dir / work_id / "steps" / f"volume_{vol_num}_characters.txt"
                if char_file.exists():
                    try:
                        content = char_file.read_text(encoding='utf-8')
                        if content:
                            char_step.content = content
                            char_step.word_count = len(content)
                            char_step.status = "completed"
                            char_step.file_path = str(char_file)
                            get_logger().info(f"[BUILD_VOLUME] Step {char_step.step_id}: loaded {len(content)} chars from steps/, status=completed")
                        else:
                            get_logger().info(f"[BUILD_VOLUME] Step {char_step.step_id}: file exists but empty, status=pending")
                    except IOError as e:
                        get_logger().warning(f"[BUILD_VOLUME] Step {char_step.step_id}: failed to load from disk: {e}")
                else:
                    get_logger().info(f"[BUILD_VOLUME] Step {char_step.step_id}: file not found in steps/, status=pending")

            steps.append(char_step)

            # 会话状态
            session_status = "completed" if all(s.status == "completed" for s in steps) else "pending"

            sessions.append(SessionInfo(
                session_id=f"volume_{vol_num}",
                session_name=f"第{vol_num}卷",
                session_type="volume",
                steps=steps,
                status=session_status,
                started_at=None,
                completed_at=None,
                context_inputs=context_inputs,
                ai_output_steps=ai_output_steps
            ))

        return sessions

    @staticmethod
    def _build_chapter_sessions(
        start_volume: int,
        end_volume: int,
        chapters_per_volume: int,
        work_id: str,
        settings
    ) -> List[SessionInfo]:
        """构建章节信息会话 - 每卷的章节分组到一个会话

        每个章节会话包含：
        - 输入步骤（6 步，每步单独发送，AI 确认）：
          1. 定义角色
          2. 定义任务
          3. 输入小说基本设定
          4. 输入前序剧情（前 3 卷的分卷总结）
          5. 输入分卷大纲和分卷人物
          6. 输入本次任务已完成的内容（已完成的章节信息）
        - 输出步骤（同一会话中按顺序生成）：
          1. 章节 1 大纲 → 章节 1 正文 → 章节 2 大纲 → 章节 2 正文 → ...
        """
        sessions = []
        works_dir = Path(getattr(settings, 'works_dir', ''))

        for vol_num in range(start_volume, end_volume + 1):
            # 定义输入步骤（context_inputs）
            context_inputs = [
                'chapter_input_role',           # 1. 定义角色
                'chapter_input_task',           # 2. 定义任务
                'chapter_input_basic_setting',  # 3. 输入小说基本设定
                'chapter_input_previous_plot',  # 4. 输入前序剧情
                'chapter_input_volume_info',    # 5. 输入分卷大纲和分卷人物
                'chapter_input_completed',      # 6. 输入已完成的章节信息
            ]

            # 定义输出步骤（ai_output_steps）- 按顺序生成章节大纲、章节标题和正文
            ai_output_steps = []
            for chapter_num in range(1, chapters_per_volume + 1):
                ai_output_steps.append(f'chapter_{vol_num}_{chapter_num}_outline')
                ai_output_steps.append(f'chapter_{vol_num}_{chapter_num}_title')
                ai_output_steps.append(f'chapter_{vol_num}_{chapter_num}_content')

            steps = []

            for chapter_num in range(1, chapters_per_volume + 1):
                # 章节大纲
                outline_step = StepInfo(
                    step_id=f"chapter_{vol_num}_{chapter_num}_outline",
                    step_name=f"第{chapter_num}章 章节大纲",
                    status="pending",
                    content="",
                    prompt_content="",
                    session_id=f"chapter_{vol_num}",
                    word_count=0
                )

                # 检查磁盘状态 - 章节大纲、章节标题和正文都存储在 steps/目录下
                if works_dir and work_id:
                    # 章节大纲和正文都存储在 steps/{step_id}.txt 文件中
                    outline_file = works_dir / work_id / "steps" / f"chapter_{vol_num}_{chapter_num}_outline.txt"
                    if outline_file.exists():
                        try:
                            content = outline_file.read_text(encoding='utf-8')
                            if content:
                                outline_step.content = content
                                outline_step.word_count = len(content)
                                outline_step.status = "completed"
                                get_logger().info(f"[BUILD_CHAPTER] Step {outline_step.step_id}: loaded {len(content)} chars from steps/, status=completed")
                            else:
                                get_logger().info(f"[BUILD_CHAPTER] Step {outline_step.step_id}: file exists but empty, status=pending")
                        except IOError as e:
                            get_logger().warning(f"[BUILD_CHAPTER] Step {outline_step.step_id}: failed to load from disk: {e}")
                    else:
                        get_logger().info(f"[BUILD_CHAPTER] Step {outline_step.step_id}: file not found in steps/, status=pending")

                steps.append(outline_step)

                # 章节标题 - 存储在 steps/目录下
                title_step = StepInfo(
                    step_id=f"chapter_{vol_num}_{chapter_num}_title",
                    step_name=f"第{chapter_num}章 章节标题",
                    status="pending",
                    content="",
                    prompt_content="",
                    session_id=f"chapter_{vol_num}",
                    word_count=0
                )

                if works_dir and work_id:
                    title_file = works_dir / work_id / "steps" / f"chapter_{vol_num}_{chapter_num}_title.txt"
                    if title_file.exists():
                        try:
                            content = title_file.read_text(encoding='utf-8')
                            if content:
                                title_step.content = content
                                title_step.word_count = len(content)
                                title_step.status = "completed"
                                get_logger().info(f"[BUILD_CHAPTER] Step {title_step.step_id}: loaded {len(content)} chars from steps/, status=completed")
                            else:
                                get_logger().info(f"[BUILD_CHAPTER] Step {title_step.step_id}: file exists but empty, status=pending")
                        except IOError as e:
                            get_logger().warning(f"[BUILD_CHAPTER] Step {title_step.step_id}: failed to load from disk: {e}")
                    else:
                        get_logger().info(f"[BUILD_CHAPTER] Step {title_step.step_id}: file not found in steps/, status=pending")

                steps.append(title_step)

                # 章节正文 - 存储在 steps/目录下
                content_step = StepInfo(
                    step_id=f"chapter_{vol_num}_{chapter_num}_content",
                    step_name=f"第{chapter_num}章 章节正文",
                    status="pending",
                    content="",
                    prompt_content="",
                    session_id=f"chapter_{vol_num}",
                    word_count=0
                )

                if works_dir and work_id:
                    content_file = works_dir / work_id / "steps" / f"chapter_{vol_num}_{chapter_num}_content.txt"
                    if content_file.exists():
                        try:
                            content = content_file.read_text(encoding='utf-8')
                            if content:
                                content_step.content = content
                                content_step.word_count = len(content)
                                content_step.status = "completed"
                                get_logger().info(f"[BUILD_CHAPTER] Step {content_step.step_id}: loaded {len(content)} chars from steps/, status=completed")
                            else:
                                get_logger().info(f"[BUILD_CHAPTER] Step {content_step.step_id}: file exists but empty, status=pending")
                        except IOError as e:
                            get_logger().warning(f"[BUILD_CHAPTER] Step {content_step.step_id}: failed to load from disk: {e}")
                    else:
                        get_logger().info(f"[BUILD_CHAPTER] Step {content_step.step_id}: file not found in steps/, status=pending")

                steps.append(content_step)

            # 会话状态检查
            session_status = "completed" if all(s.status == "completed" for s in steps) else "pending"

            sessions.append(SessionInfo(
                session_id=f"chapter_{vol_num}",
                session_name=f"第{vol_num}卷 章节 ({chapters_per_volume}章)",
                session_type="chapter",
                steps=steps,
                status=session_status,
                started_at=None,
                completed_at=None,
                context_inputs=context_inputs,
                ai_output_steps=ai_output_steps
            ))

        return sessions

    @staticmethod
    def _build_summary_sessions(
        start_volume: int,
        end_volume: int,
        work_id: str,
        settings
    ) -> List[SessionInfo]:
        """构建分卷总结会话"""
        sessions = []
        works_dir = Path(getattr(settings, 'works_dir', ''))

        for vol_num in range(start_volume, end_volume + 1):
            steps = []

            # 剧情总结
            plot_step = StepInfo(
                step_id=f"volume_{vol_num}_summary_plot",
                step_name="剧情总结",
                status="pending",
                content="",
                prompt_content="",
                session_id=f"volume_summary_{vol_num}",
                word_count=0
            )

            if works_dir and work_id:
                plot_file = works_dir / work_id / "steps" / f"volume_{vol_num}_summary_plot.txt"
                if plot_file.exists():
                    try:
                        content = plot_file.read_text(encoding='utf-8')
                        if content:
                            plot_step.content = content
                            plot_step.word_count = len(content)
                            plot_step.status = "completed"
                            plot_step.file_path = str(plot_file)
                            get_logger().info(f"[BUILD_SUMMARY] Step {plot_step.step_id}: loaded {len(content)} chars from steps/, status=completed")
                        else:
                            get_logger().info(f"[BUILD_SUMMARY] Step {plot_step.step_id}: file exists but empty, status=pending")
                    except IOError as e:
                        get_logger().warning(f"[BUILD_SUMMARY] Step {plot_step.step_id}: failed to load from disk: {e}")
                else:
                    get_logger().info(f"[BUILD_SUMMARY] Step {plot_step.step_id}: file not found in steps/, status=pending")

            steps.append(plot_step)

            # 人物总结
            char_step = StepInfo(
                step_id=f"volume_{vol_num}_summary_character",
                step_name="人物总结",
                status="pending",
                content="",
                prompt_content="",
                session_id=f"volume_summary_{vol_num}",
                word_count=0
            )

            if works_dir and work_id:
                char_file = works_dir / work_id / "steps" / f"volume_{vol_num}_summary_character.txt"
                if char_file.exists():
                    try:
                        content = char_file.read_text(encoding='utf-8')
                        if content:
                            char_step.content = content
                            char_step.word_count = len(content)
                            char_step.status = "completed"
                            char_step.file_path = str(char_file)
                            get_logger().info(f"[BUILD_SUMMARY] Step {char_step.step_id}: loaded {len(content)} chars from steps/, status=completed")
                        else:
                            get_logger().info(f"[BUILD_SUMMARY] Step {char_step.step_id}: file exists but empty, status=pending")
                    except IOError as e:
                        get_logger().warning(f"[BUILD_SUMMARY] Step {char_step.step_id}: failed to load from disk: {e}")
                else:
                    get_logger().info(f"[BUILD_SUMMARY] Step {char_step.step_id}: file not found in steps/, status=pending")

            steps.append(char_step)

            # 会话状态
            session_status = "completed" if all(s.status == "completed" for s in steps) else "pending"

            sessions.append(SessionInfo(
                session_id=f"volume_summary_{vol_num}",
                session_name=f"第{vol_num}卷 分卷总结",
                session_type="summary",
                steps=steps,
                status=session_status,
                started_at=None,
                completed_at=None
            ))

        return sessions
