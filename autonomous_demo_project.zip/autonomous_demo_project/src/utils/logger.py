"""
Logger module for AI Writer application.

Provides centralized logging functionality with file rotation,
multiple log levels, and configurable output with retention policy.
Includes automatic masking of sensitive data (API keys, passwords, etc.).
"""
import logging
import os
import glob
import re
from datetime import datetime, timedelta
from logging.handlers import RotatingFileHandler
from typing import Optional, List, Tuple, Callable

# Default log configuration
DEFAULT_LOG_DIR = "logs"
DEFAULT_LOG_FORMAT = "%(asctime)s | %(levelname)s | %(module)s | %(message)s"
DEFAULT_MAX_BYTES = 10 * 1024 * 1024  # 10MB
DEFAULT_BACKUP_COUNT = 5
DEFAULT_LOG_LEVEL = logging.DEBUG
DEFAULT_RETENTION_DAYS = 7  # Keep logs for 7 days by default


class LoggerConfig:
    """Logger configuration container."""

    def __init__(
        self,
        log_dir: str = DEFAULT_LOG_DIR,
        log_format: str = DEFAULT_LOG_FORMAT,
        max_bytes: int = DEFAULT_MAX_BYTES,
        backup_count: int = DEFAULT_BACKUP_COUNT,
        log_level: int = DEFAULT_LOG_LEVEL,
        retention_days: int = DEFAULT_RETENTION_DAYS
    ):
        """
        Initialize logger configuration.

        Args:
            log_dir: Directory to store log files
            log_format: Log message format string
            max_bytes: Maximum size of log file before rotation (bytes)
            backup_count: Number of rotated backup files to keep
            log_level: Logging level (DEBUG, INFO, etc.)
            retention_days: Number of days to keep dated log files (0 = keep forever)
        """
        self.log_dir = log_dir
        self.log_format = log_format
        self.max_bytes = max_bytes
        self.backup_count = backup_count
        self.log_level = log_level
        self.retention_days = retention_days


class SensitiveLogFilter(logging.Filter):
    """
    Logging filter that masks sensitive data in log records.

    Automatically masks API keys, tokens, passwords, and other
    sensitive information in log messages.
    """

    # Patterns for sensitive data with their masking functions
    SENSITIVE_PATTERNS: List[Tuple[str, Callable[[re.Match], str]]] = [
        # API keys (sk-xxx format)
        (r'\b(sk-[a-zA-Z0-9_-]{20,})\b', lambda m: f"sk-{'*' * min(16, len(m.group(1)) - 4)}{m.group(1)[-4:]}"),
        # Claude API keys
        (r'\b(claude-[a-zA-Z0-9_-]{10,})\b', lambda m: f"claude-{'*' * min(10, len(m.group(1)) - 4)}{m.group(1)[-4:]}"),
        # Bearer tokens
        (r'(Bearer\s+)([a-zA-Z0-9._-]{20,})', lambda m: f"{m.group(1)}***{m.group(2)[-4:]}"),
        # API key parameters in logs
        (r'(api_key\s*[=:]\s*["\']?)([a-zA-Z0-9_-]{10,})(["\']?)', lambda m: f"{m.group(1)}***{m.group(2)[-3:]}{m.group(3)}"),
        # Secret parameters
        (r'(secret\s*[=:]\s*["\']?)([^\s"\']{8,})(["\']?)', lambda m: f"{m.group(1)}***{m.group(2)[-3:]}{m.group(3)}"),
        # Password parameters
        (r'(password\s*[=:]\s*["\']?)([^\s"\']{5,})(["\']?)', lambda m: f"{m.group(1)}***{m.group(2)[-3:]}{m.group(3)}"),
    ]

    def filter(self, record: logging.LogRecord) -> bool:
        """
        Filter the log record, masking sensitive data.

        Args:
            record: Log record to filter

        Returns:
            True (always allow the record to be logged)
        """
        # Mask the message
        if record.msg:
            record.msg = self._mask_text(str(record.msg))

        # Mask args if present
        if record.args:
            record.args = self._mask_args(record.args)

        return True

    def _mask_text(self, text: str) -> str:
        """Apply all masking patterns to text."""
        result = text
        for pattern, replacer in self.SENSITIVE_PATTERNS:
            result = re.sub(pattern, replacer, result, flags=re.IGNORECASE)
        return result

    def _mask_args(self, args) -> tuple:
        """Mask sensitive data in log arguments."""
        if isinstance(args, dict):
            return {k: self._mask_value(v) for k, v in args.items()}
        elif isinstance(args, tuple):
            return tuple(self._mask_value(arg) for arg in args)
        return args

    def _mask_value(self, value) -> any:
        """Mask a single value if it appears sensitive."""
        if isinstance(value, str):
            # Check if value looks like an API key
            if len(value) > 15 and re.match(r'^[a-zA-Z0-9_-]+$', value):
                return f"***{value[-4:]}" if len(value) > 4 else "***"
            return self._mask_text(value)
        return value


# Global logger instance and name
_logger: Optional[logging.Logger] = None
_logger_name: Optional[str] = None


def setup_logger(config: Optional[LoggerConfig] = None, force_reconfigure: bool = False) -> logging.Logger:
    """
    Setup and configure the application logger.

    Creates a rotating file handler with the specified configuration.
    If a logger already exists, returns it without reconfiguring unless
    force_reconfigure is True.
    Also cleans up old log files based on retention policy.

    Args:
        config: LoggerConfig instance with logging settings.
               Uses defaults if not provided.
        force_reconfigure: If True, always create fresh handlers even if logger exists.

    Returns:
        Configured logging.Logger instance
    """
    global _logger

    # Use default config if not provided
    if config is None:
        config = LoggerConfig()

    # Ensure log directory exists
    os.makedirs(config.log_dir, exist_ok=True)

    # Clean up old log files based on retention policy
    cleanup_old_logs(config.log_dir, config.retention_days)

    # Create logger with consistent name
    logger_name = f"aiwriter_{datetime.now().strftime('%Y%m%d')}"
    logger = logging.getLogger(logger_name)
    logger.setLevel(config.log_level)

    # Return existing logger if already setup and not forcing reconfigure
    if _logger is not None and not force_reconfigure:
        return _logger

    # Remove existing handlers if forcing reconfigure or handlers exist
    if logger.handlers:
        for handler in logger.handlers:
            handler.close()
            logger.removeHandler(handler)

    # Create formatter
    formatter = logging.Formatter(config.log_format)

    # Create rotating file handler
    log_file = os.path.join(
        config.log_dir,
        f"aiwriter_{datetime.now().strftime('%Y-%m-%d')}.log"
    )
    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=config.max_bytes,
        backupCount=config.backup_count,
        encoding='utf-8'
    )
    file_handler.setLevel(config.log_level)
    file_handler.setFormatter(formatter)
    # Add sensitive data filter
    file_handler.addFilter(SensitiveLogFilter())

    # Create console handler for INFO and above
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    # Add sensitive data filter
    console_handler.addFilter(SensitiveLogFilter())

    # Add handlers to logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    # Store global reference and logger name
    _logger = logger
    _logger_name = logger_name

    return logger


def get_logger() -> Optional[logging.Logger]:
    """
    Get the global logger instance.

    Returns:
        The configured Logger instance or None if not yet setup.
    """
    return _logger


def set_log_level(level: int) -> None:
    """
    Change the log level of all handlers.

    Args:
        level: Logging level (e.g., logging.DEBUG, logging.INFO)
    """
    if _logger is not None:
        for handler in _logger.handlers:
            handler.setLevel(level)
        _logger.setLevel(level)


def close_logger() -> None:
    """Close all log handlers and reset global logger."""
    global _logger, _logger_name
    if _logger is not None:
        for handler in _logger.handlers:
            handler.flush()
            handler.close()
            _logger.removeHandler(handler)

        # Clean up logger from registry to release file handles
        if _logger_name and _logger_name in logging.root.manager.loggerDict:
            del logging.root.manager.loggerDict[_logger_name]

        _logger = None
        _logger_name = None


def cleanup_old_logs(log_dir: str, retention_days: int) -> int:
    """
    Remove log files older than the specified retention period.

    Scans the log directory for dated log files (aiwriter_YYYY-MM-DD.log*)
    and removes files older than retention_days.

    Args:
        log_dir: Directory containing log files
        retention_days: Number of days to keep logs (0 = keep forever)

    Returns:
        Number of files deleted

    Note:
        This function only removes dated log files (aiwriter_YYYY-MM-DD.log pattern).
        It does not affect the current day's log file or rotated backups.
        Files are kept if they are within retention_days (inclusive).
        For example, with retention_days=3, files from today, 1, 2, 3 days ago are kept.
    """
    if retention_days <= 0:
        return 0  # Keep logs forever

    deleted_count = 0
    # Use date-only comparison (normalize to start of day)
    # Files older than (today - retention_days) are deleted
    # Example: retention_days=3 means keep files from today, 1, 2, 3 days ago
    # Delete files from 4+ days ago
    now = datetime.now()
    cutoff_date = now.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=retention_days)

    # Pattern for dated log files: aiwriter_YYYY-MM-DD.log or aiwriter_YYYY-MM-DD.log.N
    log_pattern = os.path.join(log_dir, "aiwriter_*.log*")

    for log_file in glob.glob(log_pattern):
        filename = os.path.basename(log_file)

        # Extract date from filename (aiwriter_YYYY-MM-DD.log or aiwriter_YYYY-MM-DD.log.N)
        try:
            # Match pattern: aiwriter_YYYY-MM-DD.log[.N]
            if not filename.startswith("aiwriter_"):
                continue

            # Extract date portion (YYYY-MM-DD)
            date_match = filename.replace("aiwriter_", "").split(".log")
            if len(date_match) < 1:
                continue

            date_str = date_match[0]
            # Normalize file_date to start of day for proper date-only comparison
            file_date = datetime.strptime(date_str, "%Y-%m-%d").replace(
                hour=0, minute=0, second=0, microsecond=0
            )

            # Delete if strictly older than cutoff
            # With retention_days=3, cutoff is 3 days ago at midnight
            # Files from 3 days ago have file_date == cutoff_date, so they are kept
            # Files from 4+ days ago have file_date < cutoff_date, so they are deleted
            if file_date < cutoff_date:
                os.remove(log_file)
                deleted_count += 1
        except (ValueError, OSError):
            # Skip files that don't match expected pattern or can't be deleted
            continue

    return deleted_count
