"""
File locking utilities for concurrent access handling.

Provides cross-platform file locking to prevent data corruption
when multiple processes or threads access the same work files.
"""
import os
import sys
import time
from pathlib import Path
from typing import Optional, Tuple
from datetime import datetime

# Platform-specific imports
if sys.platform.startswith('win'):
    import msvcrt
else:
    import fcntl

from .logger import get_logger

_module_logger = None


def get_file_logger():
    """Get logger, initializing if needed."""
    global _module_logger
    if _module_logger is not None:
        return _module_logger

    _module_logger = get_logger()
    if _module_logger is None:
        import logging
        _module_logger = logging.getLogger('file_lock')
        _module_logger.setLevel(logging.DEBUG)
        if not _module_logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            ))
            _module_logger.addHandler(handler)
    return _module_logger


class FileLock:
    """
    Cross-platform file lock implementation.

    Uses OS-level file locking:
    - Windows: msvcrt.locking
    - Unix/Linux/macOS: fcntl.flock

    Attributes:
        lock_file_path: Path to the lock file
        lock_handle: File handle for the lock
        locked: Whether the lock is currently held
    """

    def __init__(self, lock_file_path: str):
        """
        Initialize the file lock.

        Args:
            lock_file_path: Path to the lock file (typically {work_dir}/.lock)
        """
        self.lock_file_path = lock_file_path
        self.lock_handle: Optional[int] = None
        self.locked = False
        self._lock_file = None  # Python file object for Unix

    def acquire(self, timeout: float = 5.0, blocking: bool = True) -> bool:
        """
        Acquire the file lock.

        Args:
            timeout: Maximum time to wait for lock (seconds)
            blocking: Whether to wait for lock or fail immediately

        Returns:
            True if lock acquired, False otherwise
        """
        start_time = time.time()

        try:
            # Ensure lock directory exists
            lock_dir = os.path.dirname(self.lock_file_path)
            if lock_dir and not os.path.exists(lock_dir):
                os.makedirs(lock_dir, exist_ok=True)

            if sys.platform.startswith('win'):
                # Windows: use msvcrt.locking
                return self._acquire_windows(timeout, blocking, start_time)
            else:
                # Unix/Linux/macOS: use fcntl.flock
                return self._acquire_unix(timeout, blocking, start_time)

        except (IOError, OSError) as e:
            get_file_logger().warning(f"Failed to acquire lock on {self.lock_file_path}: {e}")
            return False

    def _acquire_windows(self, timeout: float, blocking: bool, start_time: float) -> bool:
        """Acquire lock on Windows using msvcrt."""
        while True:
            try:
                # Open lock file in write mode
                # LK_NBLK flag makes it non-blocking
                flags = os.O_RDWR | os.O_CREAT
                self.lock_handle = os.open(self.lock_file_path, flags, 0o644)

                # Try to lock (non-blocking)
                try:
                    msvcrt.locking(self.lock_handle, msvcrt.LK_LOCK, 1)
                    self.locked = True
                    get_file_logger().debug(f"Lock acquired: {self.lock_file_path}")
                    return True
                except (IOError, OSError):
                    # Lock is held by another process
                    os.close(self.lock_handle)
                    self.lock_handle = None

                    if not blocking:
                        return False

                    # Check timeout
                    if time.time() - start_time >= timeout:
                        get_file_logger().debug(f"Lock timeout: {self.lock_file_path}")
                        return False

                    # Wait a bit before retrying
                    time.sleep(0.1)

            except (IOError, OSError) as e:
                if not blocking:
                    return False
                if time.time() - start_time >= timeout:
                    return False
                time.sleep(0.1)

        return False

    def _acquire_unix(self, timeout: float, blocking: bool, start_time: float) -> bool:
        """Acquire lock on Unix/Linux/macOS using fcntl."""
        while True:
            try:
                # Open lock file
                self._lock_file = open(self.lock_file_path, 'w')

                # Try non-blocking lock first
                if blocking:
                    # Blocking with timeout
                    while True:
                        try:
                            fcntl.flock(self._lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                            self.locked = True
                            get_file_logger().debug(f"Lock acquired: {self.lock_file_path}")
                            return True
                        except (IOError, OSError):
                            if time.time() - start_time >= timeout:
                                self._lock_file.close()
                                self._lock_file = None
                                get_file_logger().debug(f"Lock timeout: {self.lock_file_path}")
                                return False
                            time.sleep(0.1)
                else:
                    # Non-blocking
                    fcntl.flock(self._lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    self.locked = True
                    get_file_logger().debug(f"Lock acquired: {self.lock_file_path}")
                    return True

            except (IOError, OSError) as e:
                if not blocking:
                    if self._lock_file:
                        self._lock_file.close()
                        self._lock_file = None
                    return False
                if time.time() - start_time >= timeout:
                    if self._lock_file:
                        self._lock_file.close()
                        self._lock_file = None
                    return False
                time.sleep(0.1)

        return False

    def release(self) -> None:
        """Release the file lock."""
        try:
            if sys.platform.startswith('win'):
                if self.lock_handle is not None:
                    try:
                        msvcrt.locking(self.lock_handle, msvcrt.LK_UNLCK, 1)
                    except (IOError, OSError):
                        pass
                    try:
                        os.close(self.lock_handle)
                    except (IOError, OSError):
                        pass
                    self.lock_handle = None
            else:
                if self._lock_file:
                    try:
                        fcntl.flock(self._lock_file.fileno(), fcntl.LOCK_UN)
                    except (IOError, OSError):
                        pass
                    try:
                        self._lock_file.close()
                    except (IOError, OSError):
                        pass
                    self._lock_file = None

            # Optionally remove lock file after release
            try:
                if os.path.exists(self.lock_file_path):
                    os.remove(self.lock_file_path)
            except (IOError, OSError):
                pass  # Don't fail if we can't remove lock file

            self.locked = False
            get_file_logger().debug(f"Lock released: {self.lock_file_path}")

        except Exception as e:
            get_file_logger().error(f"Error releasing lock: {e}")
            self.locked = False

    def is_locked(self) -> bool:
        """
        Check if the file is currently locked by another process.

        Returns:
            True if locked by another process, False otherwise
        """
        try:
            if not os.path.exists(self.lock_file_path):
                return False

            if sys.platform.startswith('win'):
                return self._is_locked_windows()
            else:
                return self._is_locked_unix()

        except (IOError, OSError):
            return False

    def _is_locked_windows(self) -> bool:
        """Check lock status on Windows."""
        try:
            handle = os.open(self.lock_file_path, os.O_RDWR | os.O_CREAT, 0o644)
            try:
                # Try to lock - if it fails, file is locked
                msvcrt.locking(handle, msvcrt.LK_NBLCK, 1)
                # We got the lock, so it wasn't locked
                msvcrt.locking(handle, msvcrt.LK_UNLCK, 1)
                os.close(handle)
                return False
            except (IOError, OSError):
                # Failed to lock, so it's locked by someone else
                os.close(handle)
                return True
        except (IOError, OSError):
            return False

    def _is_locked_unix(self) -> bool:
        """Check lock status on Unix/Linux/macOS."""
        try:
            lock_file = open(self.lock_file_path, 'r')
            try:
                # Try to acquire exclusive lock non-blocking
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                # We got the lock, so it wasn't locked
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
                lock_file.close()
                return False
            except (IOError, OSError):
                # Failed to lock, so it's locked by someone else
                lock_file.close()
                return True
        except (IOError, OSError):
            return False

    def __enter__(self) -> 'FileLock':
        """Context manager entry."""
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.release()

    def __del__(self) -> None:
        """Destructor - ensure lock is released."""
        if self.locked:
            self.release()


class WorkLockManager:
    """
    Manager for work-level file locks.

    Provides high-level interface for locking work files
    during editing operations.

    Attributes:
        works_dir: Base directory for all works
    """

    def __init__(self, works_dir: str):
        """
        Initialize the work lock manager.

        Args:
            works_dir: Base directory containing all work directories
        """
        self.works_dir = works_dir

    def get_lock_path(self, work_id: str) -> str:
        """
        Get the lock file path for a work.

        Args:
            work_id: The work ID

        Returns:
            Full path to the lock file
        """
        work_dir = os.path.join(self.works_dir, work_id)
        return os.path.join(work_dir, '.lock')

    def acquire_lock(self, work_id: str, timeout: float = 5.0,
                     blocking: bool = True) -> Optional[FileLock]:
        """
        Acquire a lock for a work.

        Args:
            work_id: The work ID to lock
            timeout: Maximum time to wait for lock
            blocking: Whether to wait for lock

        Returns:
            FileLock object if acquired, None otherwise
        """
        lock_path = self.get_lock_path(work_id)
        lock = FileLock(lock_path)

        if lock.acquire(timeout=timeout, blocking=blocking):
            # Write lock info for debugging
            self._write_lock_info(lock_path, work_id)
            return lock

        return None

    def _write_lock_info(self, lock_path: str, work_id: str) -> None:
        """Write lock metadata for debugging."""
        try:
            info = {
                'work_id': work_id,
                'pid': os.getpid(),
                'timestamp': datetime.now().isoformat()
            }
            with open(lock_path + '.info', 'w') as f:
                import json
                json.dump(info, f, indent=2)
        except Exception:
            pass  # Don't fail if we can't write lock info

    def is_work_locked(self, work_id: str) -> bool:
        """
        Check if a work is currently locked.

        Args:
            work_id: The work ID to check

        Returns:
            True if work is locked by another process
        """
        lock_path = self.get_lock_path(work_id)

        if not os.path.exists(lock_path):
            # Check if .lock.info exists (stale lock info)
            info_path = lock_path + '.info'
            if os.path.exists(info_path):
                # Clean up stale info file
                try:
                    os.remove(info_path)
                except Exception:
                    pass
            return False

        lock = FileLock(lock_path)
        return lock.is_locked()

    def get_lock_info(self, work_id: str) -> Optional[dict]:
        """
        Get information about a work lock.

        Args:
            work_id: The work ID

        Returns:
            Lock info dict or None if no lock
        """
        info_path = self.get_lock_path(work_id) + '.info'

        if not os.path.exists(info_path):
            return None

        try:
            import json
            with open(info_path, 'r') as f:
                return json.load(f)
        except Exception:
            return None

    def cleanup_stale_lock(self, work_id: str) -> bool:
        """
        Clean up a stale lock file.

        Args:
            work_id: The work ID

        Returns:
            True if lock was cleaned up
        """
        lock_path = self.get_lock_path(work_id)
        info_path = lock_path + '.info'

        cleaned = False

        try:
            if os.path.exists(lock_path):
                os.remove(lock_path)
                cleaned = True
        except Exception:
            pass

        try:
            if os.path.exists(info_path):
                os.remove(info_path)
                cleaned = True
        except Exception:
            pass

        if cleaned:
            get_file_logger().info(f"Cleaned up stale lock for work {work_id}")

        return cleaned
