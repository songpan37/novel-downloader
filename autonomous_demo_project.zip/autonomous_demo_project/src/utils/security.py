"""
Security utilities for AI Writer application.

Provides functions for masking sensitive data such as API keys,
passwords, and other credentials in log messages and error output.
"""
import logging
import re
from typing import Optional


# Constants for masking
MASK_CHAR = '*'
MIN_VISIBLE_CHARS = 4  # Number of characters to show at end of masked string
MAX_MASK_LENGTH = 20  # Maximum length of mask before truncating


def mask_api_key(api_key: str, visible_chars: int = MIN_VISIBLE_CHARS) -> str:
    """
    Mask an API key for safe logging.

    Shows only the last few characters of the API key, replacing
    the rest with asterisks. This allows identifying which key is
    being used without exposing the full key.

    Args:
        api_key: The API key to mask
        visible_chars: Number of characters to show at the end

    Returns:
        Masked API key string (e.g., "sk-***x123")

    Examples:
        >>> mask_api_key("sk-abc123xyz789")
        'sk-***yz789'
        >>> mask_api_key("short")
        '***rt'
        >>> mask_api_key("")
        '***'
    """
    if not api_key:
        return MASK_CHAR * 3

    if len(api_key) <= visible_chars:
        return MASK_CHAR * 3

    # Keep any prefix (like "sk-") and mask the rest
    prefix = ""
    key_part = api_key

    # Common API key prefixes
    for known_prefix in ["sk-", "claude-", "Bearer ", "key-"]:
        if api_key.lower().startswith(known_prefix.lower()):
            prefix = api_key[:len(known_prefix)]
            key_part = api_key[len(known_prefix):]
            break

    if len(key_part) <= visible_chars:
        return prefix + MASK_CHAR * 3

    masked_length = len(key_part) - visible_chars
    if masked_length > MAX_MASK_LENGTH:
        masked_length = MAX_MASK_LENGTH

    return prefix + MASK_CHAR * masked_length + key_part[-visible_chars:]


def mask_sensitive_data(text: str, patterns: Optional[dict] = None) -> str:
    """
    Mask sensitive data in a text string.

    Applies multiple masking patterns to hide sensitive information
    such as API keys, tokens, passwords, etc.

    Args:
        text: The text to mask
        patterns: Optional dict of pattern_name -> regex_pattern
                 Uses default patterns if not provided

    Returns:
        Text with sensitive data masked

    Default patterns detect:
        - API keys (sk-xxx, key-xxx patterns)
        - Bearer tokens
        - Password values in common formats
        - Secret values in key=value format
    """
    if not text:
        return text

    if patterns is None:
        patterns = {
            # API keys with common prefixes
            'api_key': r'\b(sk-[a-zA-Z0-9_-]{20,})\b',
            'claude_key': r'\b(claude-[a-zA-Z0-9_-]{10,})\b',
            # Bearer tokens
            'bearer_token': r'(Bearer\s+[a-zA-Z0-9._-]+)',
            # Generic key=value patterns (for sensitive keys)
            'api_key_param': r'(\bapi_key\s*[=:]\s*)["\']?([a-zA-Z0-9_-]{10,})["\']?',
            'secret_param': r'(\bsecret\s*[=:]\s*)["\']?([a-zA-Z0-9_-]{10,})["\']?',
            'password_param': r'(\bpassword\s*[=:]\s*)["\']?([^\s"\']{5,})["\']?',
        }

    result = text

    # Apply API key masking directly for known patterns
    for pattern_name, pattern in patterns.items():
        if pattern_name in ['api_key', 'claude_key']:
            # Replace full key with masked version
            def replace_key(match):
                key = match.group(1)
                return mask_api_key(key)

            result = re.sub(pattern, replace_key, result, flags=re.IGNORECASE)

        elif pattern_name in ['bearer_token']:
            # Replace token with masked version
            def replace_bearer(match):
                token_match = match.group(1)
                parts = token_match.split()
                if len(parts) == 2:
                    return f"{parts[0]} {mask_api_key(parts[1])}"
                return token_match

            result = re.sub(pattern, replace_bearer, result, flags=re.IGNORECASE)

        elif pattern_name in ['api_key_param', 'secret_param', 'password_param']:
            # Replace value but keep key name
            def replace_param(match):
                key_part = match.group(1)
                value = match.group(2)
                return f"{key_part}***{value[-3:]}" if len(value) > 3 else f"{key_part}***"

            result = re.sub(pattern, replace_param, result, flags=re.IGNORECASE)

    return result


def mask_dict_values(data: dict, sensitive_keys: Optional[list] = None) -> dict:
    """
    Mask sensitive values in a dictionary.

    Creates a copy of the dictionary with sensitive values masked
    for safe logging or display.

    Args:
        data: Dictionary to mask
        sensitive_keys: List of key names to mask
                       Uses defaults if not provided

    Returns:
        New dictionary with sensitive values masked

    Default sensitive keys:
        - api_key, apikey, API_KEY
        - secret, SECRET, secret_key
        - password, PASSWORD, passwd
        - token, TOKEN, auth_token
    """
    if sensitive_keys is None:
        sensitive_keys = [
            'api_key', 'apikey', 'API_KEY', 'apiKey',
            'secret', 'SECRET', 'secret_key', 'secretKey',
            'password', 'PASSWORD', 'passwd',
            'token', 'TOKEN', 'auth_token', 'authToken',
            'key', 'KEY',  # Only mask if value looks like a key
        ]

    result = {}
    for key, value in data.items():
        if key in sensitive_keys or key.lower() in [k.lower() for k in sensitive_keys]:
            if isinstance(value, str):
                result[key] = mask_api_key(value)
            elif value is not None:
                result[key] = '***'
        elif isinstance(value, dict):
            result[key] = mask_dict_values(value, sensitive_keys)
        elif isinstance(value, list):
            result[key] = [
                mask_dict_values(item, sensitive_keys) if isinstance(item, dict)
                else mask_api_key(item) if isinstance(item, str) and len(item) > 10
                else item
                for item in value
            ]
        else:
            result[key] = value

    return result


class SensitiveLogFilter(logging.Filter):
    """
    Logging filter that masks sensitive data in log records.

    This filter can be added to log handlers to automatically
    mask sensitive information in all log messages.

    Usage:
        logger = logging.getLogger('myapp')
        filter = SensitiveLogFilter()
        handler.addFilter(filter)
    """

    def __init__(self, name: str = ""):
        """Initialize the filter."""
        super().__init__(name)
        self.sensitive_patterns = [
            (r'\b(sk-[a-zA-Z0-9_-]{20,})\b', lambda m: mask_api_key(m.group(1))),
            (r'\b(claude-[a-zA-Z0-9_-]{10,})\b', lambda m: mask_api_key(m.group(1))),
            (r'(Bearer\s+[a-zA-Z0-9._-]+)', lambda m: f"Bearer {mask_api_key(m.group(1).split()[1])}"),
        ]

    def filter(self, record: logging.LogRecord) -> bool:
        """
        Filter the log record, masking sensitive data.

        Args:
            record: Log record to filter

        Returns:
            True (always allow the record to be logged)
        """
        # Mask the message
        record.msg = self._mask_text(str(record.msg))

        # Mask args if present
        if record.args:
            if isinstance(record.args, dict):
                record.args = mask_dict_values(record.args)
            elif isinstance(record.args, tuple):
                record.args = tuple(
                    mask_api_key(arg) if isinstance(arg, str) and len(arg) > 10 and '-' in arg
                    else arg
                    for arg in record.args
                )

        return True

    def _mask_text(self, text: str) -> str:
        """Apply all masking patterns to text."""
        result = text
        for pattern, replacer in self.sensitive_patterns:
            result = re.sub(pattern, replacer, result, flags=re.IGNORECASE)
        return result
