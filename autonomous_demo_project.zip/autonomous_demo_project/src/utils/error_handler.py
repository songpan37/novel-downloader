"""
Error handler utility for AI Writer application.

Provides centralized error handling with user-friendly dialogs
and consistent error reporting.
"""
import sys
import traceback
from typing import Optional, Callable, Any

from PyQt6.QtWidgets import QMessageBox, QWidget
from PyQt6.QtCore import pyqtSignal, QObject

from utils.logger import get_logger
from utils.exceptions import (
    AIWriterError,
    StorageError, FileNotFoundError, DirectoryNotFoundError, PermissionError,
    InvalidPathError, ConfigError,
    WorkNotFoundError, WorkExistsError, InvalidWorkStructureError,
    AIServiceError, APIAuthError, APIRateLimitError, APINetworkError,
    APITimeoutError, AIServiceUnavailableError,
    TemplateError, TemplateNotFoundError, TemplateRenderError, TemplateSyntaxError,
    PublishingError, PlatformNotSupportedError, PublishingFailedError,
    ImportExportError, InvalidArchiveError, ExportFailedError, ImportFailedError,
)


class ErrorHandler(QObject):
    """
    Centralized error handler for the application.

    Provides methods to show user-friendly error dialogs and
    handles global exception catching.

    Signals:
        error_occurred: Emitted when an error occurs (error_message, error_type)
    """

    error_occurred = pyqtSignal(str, str)

    def __init__(self, parent: Optional[QObject] = None):
        """
        Initialize the error handler.

        Args:
            parent: Parent QObject
        """
        super().__init__(parent)
        self.logger = get_logger()

    def get_user_friendly_message(self, exception: Exception) -> str:
        """
        Get a user-friendly error message for an exception.

        Args:
            exception: The exception to get message for

        Returns:
            User-friendly error message in Chinese
        """
        # Handle our custom exceptions with specific messages
        if isinstance(exception, APIAuthError):
            return "API 认证失败，请检查 API Key 是否正确设置"
        elif isinstance(exception, APIRateLimitError):
            retry_msg = ""
            if hasattr(exception, 'retry_after') and exception.retry_after:
                retry_msg = f"，请在 {exception.retry_after} 秒后重试"
            return f"请求过于频繁{retry_msg}，请稍后再试"
        elif isinstance(exception, APINetworkError):
            return "网络连接失败，请检查网络设置后重试"
        elif isinstance(exception, APITimeoutError):
            return "请求超时，请检查网络连接后重试"
        elif isinstance(exception, AIServiceUnavailableError):
            return "AI 服务暂时不可用，请稍后重试"
        elif isinstance(exception, AIServiceError):
            return f"AI 服务错误：{exception.message}"
        elif isinstance(exception, FileNotFoundError):
            return f"文件不存在，请检查路径是否正确"
        elif isinstance(exception, DirectoryNotFoundError):
            return f"目录不存在，请检查路径是否正确"
        elif isinstance(exception, PermissionError):
            action = getattr(exception, 'action', '访问')
            return f"没有{action}权限，请检查文件权限设置"
        elif isinstance(exception, InvalidPathError):
            return f"路径无效：{exception.reason}"
        elif isinstance(exception, ConfigError):
            return f"配置错误，请检查设置：{exception.config_key}"
        elif isinstance(exception, WorkNotFoundError):
            return "作品不存在，可能已被删除"
        elif isinstance(exception, WorkExistsError):
            return "作品已存在，请使用其他名称"
        elif isinstance(exception, InvalidWorkStructureError):
            return f"作品文件结构异常：{exception.reason}"
        elif isinstance(exception, TemplateNotFoundError):
            return f"模板不存在：{exception.template_name}"
        elif isinstance(exception, TemplateRenderError):
            return f"模板渲染失败：{exception.reason}"
        elif isinstance(exception, TemplateSyntaxError):
            return f"模板语法错误：{exception.reason}"
        elif isinstance(exception, PlatformNotSupportedError):
            return f"不支持的发布平台：{exception.platform}"
        elif isinstance(exception, PublishingFailedError):
            return f"发布失败：{exception.reason}"
        elif isinstance(exception, InvalidArchiveError):
            return f"无效的压缩文件：{exception.reason}"
        elif isinstance(exception, ExportFailedError):
            return f"导出失败：{exception.reason}"
        elif isinstance(exception, ImportFailedError):
            return f"导入失败：{exception.reason}"
        elif isinstance(exception, StorageError):
            return "存储操作失败，请检查存储路径和权限设置"
        elif isinstance(exception, AIWriterError):
            return exception.message
        else:
            # Generic error message for unknown exceptions
            return f"发生错误：{str(exception)}"

    def show_error_dialog(
        self,
        parent: Optional[QWidget],
        exception: Exception,
        title: str = "错误",
        detailed_text: Optional[str] = None
    ) -> None:
        """
        Show a user-friendly error dialog.

        Args:
            parent: Parent widget for the dialog
            exception: The exception that occurred
            title: Dialog title
            detailed_text: Optional detailed error information
        """
        # Get user-friendly message
        user_message = self.get_user_friendly_message(exception)

        # Log the full error details
        if self.logger:
            self.logger.error(f"{title}: {user_message}", exc_info=True)

        # Create error dialog
        msg_box = QMessageBox(parent)
        msg_box.setIcon(QMessageBox.Icon.Critical)
        msg_box.setWindowTitle(title)
        msg_box.setText(user_message)

        # Add detailed information (only visible when user clicks "Details")
        if detailed_text is None:
            detailed_text = self._get_exception_details(exception)
        msg_box.setDetailedText(detailed_text)

        # Add standard buttons
        msg_box.setStandardButtons(QMessageBox.StandardButton.Ok)
        msg_box.exec()

    def _get_exception_details(self, exception: Exception) -> str:
        """
        Get detailed exception information for logging.

        Args:
            exception: The exception to get details for

        Returns:
            Detailed error information string
        """
        details = []
        details.append(f"错误类型：{type(exception).__name__}")
        details.append(f"错误消息：{str(exception)}")

        # Add any custom attributes from the exception
        for attr_name in dir(exception):
            if not attr_name.startswith('_') and attr_name not in (
                'args', 'with_traceback', '__traceback__', '__context__',
                '__cause__', '__suppress_context__'
            ):
                try:
                    value = getattr(exception, attr_name)
                    if value is not None and not callable(value):
                        details.append(f"{attr_name}: {value}")
                except Exception:
                    pass

        # Add stack trace
        details.append("\n堆栈跟踪:")
        details.append(traceback.format_exc())

        return "\n".join(details)

    def handle_exception(
        self,
        exception: Exception,
        parent: Optional[QWidget] = None,
        title: Optional[str] = None,
        show_dialog: bool = True
    ) -> str:
        """
        Handle an exception - log it and optionally show dialog.

        Args:
            exception: The exception to handle
            parent: Parent widget for dialog
            title: Optional custom title for dialog
            show_dialog: Whether to show error dialog

        Returns:
            The user-friendly error message
        """
        # Get user-friendly message
        user_message = self.get_user_friendly_message(exception)

        # Log the error
        if self.logger:
            self.logger.error(f"Error: {user_message}", exc_info=True)

        # Show dialog if requested
        if show_dialog and parent is not None:
            self.show_error_dialog(parent, exception, title or "错误")

        # Emit signal for other components to handle
        self.error_occurred.emit(user_message, type(exception).__name__)

        return user_message


# Global error handler instance
_error_handler: Optional[ErrorHandler] = None


def get_error_handler() -> ErrorHandler:
    """Get the global error handler instance."""
    global _error_handler
    if _error_handler is None:
        _error_handler = ErrorHandler()
    return _error_handler


def init_error_handler() -> None:
    """
    Initialize global exception hook for uncaught exceptions.

    This should be called during application startup to ensure
    all uncaught exceptions are handled gracefully.
    """
    error_handler = get_error_handler()

    def global_exception_handler(
        exc_type: type,
        exc_value: Exception,
        exc_traceback: object
    ) -> None:
        """
        Handle uncaught exceptions globally.

        Args:
            exc_type: Exception type
            exc_value: Exception instance
            exc_traceback: Exception traceback
        """
        # Log the full traceback
        logger = get_logger()
        if logger:
            import traceback as tb
            try:
                # Format the exception manually to avoid Python 3.14+ logging bug
                tb_lines = tb.format_exception(exc_type, exc_value, exc_traceback)
                logger.critical("Uncaught exception: %s", "".join(tb_lines))
            except Exception as log_error:
                # Fallback: log the error message only
                logger.critical(f"Uncaught exception: {exc_type.__name__}: {exc_value}")
                logger.critical(f"Logging error: {log_error}")

        # Show user-friendly error dialog
        # Note: We can't show a dialog here without a parent widget,
        # but we ensure the message is user-friendly
        from PyQt6.QtWidgets import QApplication
        app = QApplication.instance()
        if app:
            user_message = error_handler.get_user_friendly_message(exc_value)

            # Show critical error message box
            msg_box = QMessageBox()
            msg_box.setIcon(QMessageBox.Icon.Critical)
            msg_box.setWindowTitle("应用程序错误")
            msg_box.setText("程序发生错误，即将关闭")
            msg_box.setInformativeText(user_message)
            msg_box.setStandardButtons(QMessageBox.StandardButton.Ok)
            msg_box.exec()

    # Install the global exception hook
    sys.excepthook = global_exception_handler


def show_friendly_error(
    parent: Optional[QWidget],
    exception: Exception,
    title: str = "错误"
) -> None:
    """
    Show a friendly error dialog for an exception.

    This is a convenience function that uses the global error handler.

    Args:
        parent: Parent widget for the dialog
        exception: The exception to show
        title: Dialog title
    """
    error_handler = get_error_handler()
    error_handler.show_error_dialog(parent, exception, title)


def handle_error_silently(
    exception: Exception,
    context: str = "Unknown"
) -> str:
    """
    Log an error without showing a dialog.

    Args:
        exception: The exception to handle
        context: Context information for logging

    Returns:
        User-friendly error message
    """
    error_handler = get_error_handler()
    user_message = error_handler.get_user_friendly_message(exception)

    if error_handler.logger:
        error_handler.logger.error(f"{context}: {user_message}", exc_info=True)

    return user_message


def safe_call(
    func: Callable[..., Any],
    *args: Any,
    parent: Optional[QWidget] = None,
    default: Any = None,
    **kwargs: Any
) -> Any:
    """
    Safely call a function, catching and handling any exceptions.

    Args:
        func: Function to call
        *args: Positional arguments to pass to func
        parent: Parent widget for error dialog
        default: Default value to return on error
        **kwargs: Keyword arguments to pass to func

    Returns:
        Function result or default value on error
    """
    try:
        return func(*args, **kwargs)
    except Exception as e:
        error_handler = get_error_handler()
        error_handler.handle_exception(e, parent, show_dialog=True)
        return default
