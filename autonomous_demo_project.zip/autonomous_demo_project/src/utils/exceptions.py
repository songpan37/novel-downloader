"""
Custom exception classes for AI Writer application.

Provides a hierarchy of exceptions for different error scenarios,
allowing for specific error handling and user-friendly messages.
"""
from typing import Optional


class AIWriterError(Exception):
    """
    Base exception class for all AI Writer exceptions.

    All custom exceptions in this application should inherit from this class.
    """

    def __init__(self, message: str, details: Optional[str] = None):
        """
        Initialize the exception.

        Args:
            message: User-friendly error message
            details: Optional detailed error information for logging
        """
        super().__init__(message)
        self.message = message
        self.details = details or str(self)


# Storage related exceptions
class StorageError(AIWriterError):
    """Base class for storage-related errors."""
    pass


class FileNotFoundError(StorageError):
    """Raised when a required file is not found."""

    def __init__(self, path: str, message: Optional[str] = None):
        msg = message or f"文件不存在：{path}"
        super().__init__(msg, f"File not found: {path}")
        self.path = path


class DirectoryNotFoundError(StorageError):
    """Raised when a required directory is not found."""

    def __init__(self, path: str, message: Optional[str] = None):
        msg = message or f"目录不存在：{path}"
        super().__init__(msg, f"Directory not found: {path}")
        self.path = path


class PermissionError(StorageError):
    """Raised when file/directory access is denied."""

    def __init__(self, path: str, action: str = "access", message: Optional[str] = None):
        msg = message or f"没有{action}权限：{path}"
        super().__init__(msg, f"Permission denied: {action} - {path}")
        self.path = path
        self.action = action


class InvalidPathError(StorageError):
    """Raised when an invalid path is provided."""

    def __init__(self, path: str, reason: str = "无效路径"):
        msg = f"{reason}: {path}"
        super().__init__(msg, f"Invalid path: {path} - {reason}")
        self.path = path
        self.reason = reason


class ConfigError(StorageError):
    """Raised when configuration is invalid or missing."""

    def __init__(self, config_key: str, message: Optional[str] = None):
        msg = message or f"配置错误：{config_key} 未设置或无效"
        super().__init__(msg, f"Config error: {config_key}")
        self.config_key = config_key


# Work related exceptions
class WorkNotFoundError(AIWriterError):
    """Raised when a work is not found."""

    def __init__(self, work_id: str, message: Optional[str] = None):
        msg = message or f"作品不存在：{work_id}"
        super().__init__(msg, f"Work not found: {work_id}")
        self.work_id = work_id


class WorkExistsError(AIWriterError):
    """Raised when a work already exists."""

    def __init__(self, work_id: str, message: Optional[str] = None):
        msg = message or f"作品已存在：{work_id}"
        super().__init__(msg, f"Work already exists: {work_id}")
        self.work_id = work_id


class InvalidWorkStructureError(AIWriterError):
    """Raised when work directory structure is invalid."""

    def __init__(self, work_id: str, reason: str = "目录结构不完整"):
        msg = f"作品结构无效 ({work_id}): {reason}"
        super().__init__(msg, f"Invalid work structure: {work_id} - {reason}")
        self.work_id = work_id
        self.reason = reason


# AI Service related exceptions
class AIServiceError(AIWriterError):
    """Base class for AI service errors."""

    def __init__(self, message: str, status_code: Optional[int] = None,
                 details: Optional[str] = None):
        super().__init__(message, details)
        self.status_code = status_code


class APIAuthError(AIServiceError):
    """Raised when API authentication fails."""

    def __init__(self, message: str = "API 认证失败，请检查 API Key 是否正确",
                 details: Optional[str] = None):
        super().__init__(message, 401, details or "Invalid API key")


class APIRateLimitError(AIServiceError):
    """Raised when API rate limit is exceeded."""

    def __init__(self, message: str = "请求过于频繁，请稍后再试",
                 details: Optional[str] = None, retry_after: Optional[int] = None):
        super().__init__(message, 429, details or "Rate limit exceeded")
        self.retry_after = retry_after


class APINetworkError(AIServiceError):
    """Raised when network error occurs during API call."""

    def __init__(self, message: str = "网络连接失败，请检查网络后重试",
                 details: Optional[str] = None):
        super().__init__(message, None, details or "Network error")


class APITimeoutError(AIServiceError):
    """Raised when API request times out."""

    def __init__(self, message: str = "请求超时，请检查网络连接后重试",
                 details: Optional[str] = None):
        super().__init__(message, None, details or "Request timeout")


class AIServiceUnavailableError(AIServiceError):
    """Raised when AI service is temporarily unavailable."""

    def __init__(self, message: str = "AI 服务暂时不可用，请稍后重试",
                 details: Optional[str] = None):
        super().__init__(message, 503, details or "Service unavailable")


# Template related exceptions
class TemplateError(AIWriterError):
    """Base class for template-related errors."""
    pass


class TemplateNotFoundError(TemplateError):
    """Raised when a template is not found."""

    def __init__(self, template_name: str, message: Optional[str] = None):
        msg = message or f"模板不存在：{template_name}"
        super().__init__(msg, f"Template not found: {template_name}")
        self.template_name = template_name


class TemplateRenderError(TemplateError):
    """Raised when template rendering fails."""

    def __init__(self, template_name: str, reason: str = "渲染失败"):
        msg = f"模板渲染失败 ({template_name}): {reason}"
        super().__init__(msg, f"Template render error: {template_name} - {reason}")
        self.template_name = template_name
        self.reason = reason


class TemplateSyntaxError(TemplateError):
    """Raised when template syntax is invalid."""

    def __init__(self, template_name: str, reason: str = "语法错误"):
        msg = f"模板语法错误 ({template_name}): {reason}"
        super().__init__(msg, f"Template syntax error: {template_name} - {reason}")
        self.template_name = template_name
        self.reason = reason


# Publishing related exceptions
class PublishingError(AIWriterError):
    """Base class for publishing-related errors."""
    pass


class PlatformNotSupportedError(PublishingError):
    """Raised when a publishing platform is not supported."""

    def __init__(self, platform: str, message: Optional[str] = None):
        msg = message or f"不支持的发布平台：{platform}"
        super().__init__(msg, f"Platform not supported: {platform}")
        self.platform = platform


class PublishingFailedError(PublishingError):
    """Raised when publishing fails."""

    def __init__(self, platform: str, reason: str = "发布失败"):
        msg = f"发布失败 ({platform}): {reason}"
        super().__init__(msg, f"Publishing failed: {platform} - {reason}")
        self.platform = platform
        self.reason = reason


# Import/Export related exceptions
class ImportExportError(AIWriterError):
    """Base class for import/export errors."""
    pass


class InvalidArchiveError(ImportExportError):
    """Raised when an archive file is invalid or corrupted."""

    def __init__(self, path: str, reason: str = "无效的压缩文件"):
        msg = f"无效的压缩文件：{reason}"
        super().__init__(msg, f"Invalid archive: {path} - {reason}")
        self.path = path
        self.reason = reason


class ExportFailedError(ImportExportError):
    """Raised when export operation fails."""

    def __init__(self, work_id: str, reason: str = "导出失败"):
        msg = f"导出失败：{reason}"
        super().__init__(msg, f"Export failed: {work_id} - {reason}")
        self.work_id = work_id
        self.reason = reason


class ImportFailedError(ImportExportError):
    """Raised when import operation fails."""

    def __init__(self, path: str, reason: str = "导入失败"):
        msg = f"导入失败：{reason}"
        super().__init__(msg, f"Import failed: {path} - {reason}")
        self.path = path
        self.reason = reason


# Data corruption related exceptions
class CorruptedDataError(AIWriterError):
    """
    Raised when data file is corrupted.

    Provides recovery options if backup is available.
    """

    def __init__(self, file_path: str, reason: str = "数据文件已损坏",
                 backup_available: bool = False, recovery_suggestion: str = None):
        msg = f"{reason}: {file_path}"
        if backup_available:
            msg += " (检测到备份文件，可尝试恢复)"
        super().__init__(msg, f"Corrupted data: {file_path} - {reason}")
        self.file_path = file_path
        self.reason = reason
        self.backup_available = backup_available
        self.recovery_suggestion = recovery_suggestion or "尝试从备份文件恢复数据"


class CorruptedJSONError(CorruptedDataError):
    """
    Raised when JSON file is corrupted or contains invalid JSON.

    Provides option to restore from backup if available.
    """

    def __init__(self, file_path: str, parse_error: Exception = None,
                 backup_available: bool = False):
        reason = "JSON 文件格式错误或已损坏"
        recovery = "可尝试从备份文件恢复，或手动修复 JSON 格式"
        super().__init__(
            file_path=file_path,
            reason=reason,
            backup_available=backup_available,
            recovery_suggestion=recovery
        )
        self.parse_error = parse_error


# Concurrent access related exceptions
class ConcurrentAccessError(AIWriterError):
    """
    Raised when concurrent access to a work is detected.

    This occurs when another process or user is currently editing
    the same work.
    """

    def __init__(self, work_id: str, lock_info: Optional[dict] = None,
                 message: Optional[str] = None):
        if message is None:
            msg = f"作品正被编辑中 ({work_id})，请稍后再试"
            if lock_info:
                msg += f" - 锁定于 {lock_info.get('timestamp', 'unknown time')}"
        else:
            msg = message

        details = f"Concurrent access detected: work_id={work_id}, lock_info={lock_info}"
        super().__init__(msg, details)
        self.work_id = work_id
        self.lock_info = lock_info


class FileLockError(AIWriterError):
    """
    Raised when file locking operations fail.
    """

    def __init__(self, path: str, reason: str = "文件锁定失败",
                 message: Optional[str] = None):
        msg = message or f"{reason}: {path}"
        super().__init__(msg, f"File lock error: {path} - {reason}")
        self.path = path
        self.reason = reason
