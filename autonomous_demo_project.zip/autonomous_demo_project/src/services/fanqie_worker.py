"""
Fanqie Worker Service for AI Writer application.

Manages a single Playwright browser instance in a dedicated thread,
handling all Fanqie platform operations through a task queue.
Uses FanqiePublisher for actual browser operations.
"""
import threading
import uuid
import time
import os
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, Any, Dict
from utils.logger import get_logger


class FanqieTaskType(Enum):
    """Types of tasks that can be submitted to the worker."""
    LOGIN = "login"
    CREATE_BOOK = "create_book"
    GET_PUBLISHED_CHAPTERS = "get_published_chapters"
    PUBLISH_CHAPTER = "publish_chapter"
    UPDATE_CHAPTER = "update_chapter"
    CLOSE = "close"


@dataclass
class FanqieTask:
    """A task to be executed by the worker."""
    task_id: str
    task_type: FanqieTaskType
    params: Dict[str, Any]
    result: Optional[Any] = None
    error: Optional[str] = None
    completed: bool = False
    finished_event: threading.Event = field(default_factory=threading.Event)


class FanqieWorker:
    """
    Worker that manages a single Playwright browser instance.

    Runs in a dedicated thread, processing tasks from a queue.
    Uses FanqiePublisher for actual browser operations.
    """

    def __init__(self, chrome_path: str = None, headless: bool = False, slow_mo: int = 100):
        """
        Initialize the Fanqie worker.

        Args:
            chrome_path: Path to Chrome executable
            headless: Whether to run browser in headless mode
            slow_mo: Slow motion delay for browser automation
        """
        self.logger = get_logger()
        self.chrome_path = chrome_path
        self.headless = headless
        self.slow_mo = slow_mo

        # Thread and synchronization
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._task_queue = []
        self._queue_lock = threading.Lock()

        # Publisher instance (only accessed from worker thread)
        self._publisher = None

        # Login state
        self._logged_in = False
        self._account_info = None

        # Book info
        self._current_book_id = None
        self._current_book_name = None

    def start(self) -> None:
        """Start the worker thread."""
        if self._thread is not None and self._thread.is_alive():
            return

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        self.logger.info("[fanqie_worker] Worker started")

    def stop(self) -> None:
        """Stop the worker thread."""
        if self._thread is None:
            return

        self._stop_event.set()
        self._submit_task(FanqieTask(
            task_id=str(uuid.uuid4()),
            task_type=FanqieTaskType.CLOSE,
            params={}
        ))
        self._thread.join(timeout=10)
        self._thread = None
        self.logger.info("[fanqie_worker] Worker stopped")

    def _submit_task(self, task: FanqieTask) -> None:
        """Submit a task to the queue."""
        with self._queue_lock:
            self._task_queue.append(task)

    def submit_task(self, task_type: FanqieTaskType, params: Dict[str, Any] = None, timeout: float = 300) -> tuple:
        """
        Submit a task and wait for its result.

        Args:
            task_type: Type of task to execute
            params: Task parameters
            timeout: Maximum time to wait for completion

        Returns:
            Tuple of (success: bool, result: Any or error_message: str)
        """
        if self._thread is None or not self._thread.is_alive():
            return (False, "Worker not running")

        task = FanqieTask(
            task_id=str(uuid.uuid4()),
            task_type=task_type,
            params=params or {}
        )

        with self._queue_lock:
            self._task_queue.append(task)

        # Wait for completion
        completed = task.finished_event.wait(timeout=timeout)

        if not completed:
            return (False, f"Task {task_type.value} timed out after {timeout}s")

        if task.error:
            return (False, task.error)

        return (True, task.result)

    def _run(self) -> None:
        """Main worker loop - runs in dedicated thread."""
        self.logger.info("[fanqie_worker] Worker thread started")

        while not self._stop_event.is_set():
            # Get next task
            task = None
            with self._queue_lock:
                if self._task_queue:
                    task = self._task_queue.pop(0)

            if task is None:
                # No task, sleep and continue
                time.sleep(0.1)
                continue

            # Process special CLOSE task
            if task.task_type == FanqieTaskType.CLOSE:
                self._close_publisher()
                task.completed = True
                task.finished_event.set()
                continue

            # Process task
            try:
                self._process_task(task)
            except Exception as e:
                self.logger.error(f"[fanqie_worker] Task {task.task_type.value} failed: {e}")
                task.error = str(e)

            task.completed = True
            task.finished_event.set()

        # Cleanup
        self._close_publisher()
        self.logger.info("[fanqie_worker] Worker thread exiting")

    def _process_task(self, task: FanqieTask) -> None:
        """Process a single task."""
        if task.task_type == FanqieTaskType.LOGIN:
            self._do_login(task)
        elif task.task_type == FanqieTaskType.CREATE_BOOK:
            self._do_create_book(task)
        elif task.task_type == FanqieTaskType.GET_PUBLISHED_CHAPTERS:
            self._do_get_published_chapters(task)
        elif task.task_type == FanqieTaskType.PUBLISH_CHAPTER:
            self._do_publish_chapter(task)
        elif task.task_type == FanqieTaskType.UPDATE_CHAPTER:
            self._do_update_chapter(task)
        else:
            task.error = f"Unknown task type: {task.task_type}"

    def _ensure_publisher(self) -> bool:
        """Ensure publisher is initialized."""
        if self._publisher is not None:
            return True

        try:
            from services.fanqie_publisher import FanqiePublisher

            self._publisher = FanqiePublisher(
                phone_number="",
                password="",
                chrome_path=self.chrome_path,
                headless=self.headless,
                slow_mo=self.slow_mo
            )
            return True
        except Exception as e:
            self.logger.error(f"[fanqie_worker] Failed to create publisher: {e}")
            return False

    def _ensure_book_service(self) -> bool:
        """Ensure book service is initialized."""
        if hasattr(self, '_book_service') and self._book_service is not None:
            return True

        try:
            from services.fanqie_book_service import FanqieBookService

            self._book_service = FanqieBookService(
                headless=self.headless,
                slow_mo=self.slow_mo
            )
            return True
        except Exception as e:
            self.logger.error(f"[fanqie_worker] Failed to create book service: {e}")
            return False

    def _close_publisher(self) -> None:
        """Close publisher and cleanup."""
        try:
            if self._publisher:
                self._publisher.close()
                self._publisher = None
            if hasattr(self, '_book_service') and self._book_service:
                self._book_service = None
            self._logged_in = False
            self._account_info = None
            self.logger.info("[fanqie_worker] Publisher closed")
        except Exception as e:
            self.logger.error(f"[fanqie_worker] Error closing publisher: {e}")

    def _do_login(self, task: FanqieTask) -> None:
        """Execute login task."""
        phone = task.params.get('phone')
        password = task.params.get('password')

        if not phone or not password:
            task.error = "Missing phone or password"
            return

        if not self._ensure_publisher():
            task.error = "Failed to create publisher"
            return

        try:
            # Update publisher credentials (use same attribute names as __init__)
            self._publisher.phone_number = phone
            self._publisher.password = password

            self.logger.info(f"[fanqie_worker] Starting login for {phone[:3]}****{phone[-4:]}")

            # Connect (starts browser and logs in)
            self.logger.info(f"[fanqie_worker] Calling publisher.connect()...")
            success = self._publisher.connect()
            self.logger.info(f"[fanqie_worker] publisher.connect() returned: {success}")

            if success:
                self._logged_in = True
                self._account_info = {'phone': phone}
                task.result = {'success': True, 'url': self._publisher.page.url if self._publisher.page else ''}
                self.logger.info(f"[fanqie_worker] Login successful, page URL: {self._publisher.page.url if self._publisher.page else 'N/A'}")
            else:
                task.error = "Login failed - check credentials"
                self.logger.error(f"[fanqie_worker] Login failed")

        except Exception as e:
            self.logger.error(f"[fanqie_worker] Login failed: {e}")
            task.error = str(e)

    def _do_create_book(self, task: FanqieTask) -> None:
        """Execute create book task."""
        book_title = task.params.get('book_title')
        genre = task.params.get('genre', '玄幻')

        if not self._logged_in or not self._publisher:
            task.error = "Not logged in"
            return

        # Create new page for this task
        new_page = self._publisher.create_new_page()
        if not new_page:
            task.error = "Failed to create new page"
            return

        try:
            self.logger.info(f"[fanqie_worker] Creating book: {book_title}")

            # Use FanqieBookService with the new page
            from services.fanqie_book_service import FanqieBookService
            book_service = FanqieBookService(phone_number="", password="")
            book_service.set_page(new_page, self._publisher.context, is_logged_in=True)

            # Navigate to create book page
            book_service.navigate_to_create_book()
            time.sleep(1)

            # Fill book info and create book
            result = book_service.create_book(
                book_name=book_title,
                is_male=True,  # Default to male channel
                tags=[],  # Tags can be set later
                protagonist1="",
                protagonist2="",
                description=""
            )

            if result and result[0]:
                self._current_book_id = result[1]
                self._current_book_name = book_title
                task.result = {'success': True, 'book_id': result[1]}
            else:
                error_msg = result[1] if result else "Failed to create book"
                task.error = error_msg

        except Exception as e:
            self.logger.error(f"[fanqie_worker] Create book failed: {e}")
            task.error = str(e)
        finally:
            # Close the page after task
            try:
                new_page.close()
                self.logger.info("[fanqie_worker] Closed create book page")
            except:
                pass

    def _do_get_published_chapters(self, task: FanqieTask) -> None:
        """Execute get published chapters task."""
        book_id = task.params.get('book_id')

        if not self._logged_in or not self._publisher:
            task.error = "Not logged in"
            return

        # Create new page for this task
        page = self._publisher.create_new_page()
        if not page:
            task.error = "Failed to create new page"
            return

        try:
            self.logger.info(f"[fanqie_worker] Getting published chapters for book: {book_id}")

            # Set book info
            self._publisher._book_id = book_id
            self._current_book_id = book_id

            # Navigate to chapter management page
            chapter_url = f"https://fanqienovel.com/main/writer/chapter-manage/{book_id}?type=1"
            self.logger.info(f"[fanqie_worker] Navigating to {chapter_url}")

            all_chapters = []
            current_page = 1

            # Compile regex pattern for extracting chapter number from title
            import re
            chapter_num_pattern = re.compile(r'^第(\d+)章')

            # Navigate to first page to get initial data and total count
            with page.expect_response("**/api/author/chapter/chapter_list/**", timeout=30000) as resp_info:
                page.goto(chapter_url, wait_until="commit", timeout=30000)
            resp = resp_info.value
            data = resp.json()
            self.logger.info(f"[fanqie_worker] API response body: {data}")

            if data.get("code") != 0:
                task.error = f"API error: {data.get('message')}"
                return

            result_data = data.get("data", {})
            total_count = result_data.get("total_count", 0)
            self.logger.info(f"[fanqie_worker] Total chapters: {total_count}")

            # Parse first page
            items = result_data.get("item_list", [])
            for item in items:
                item_id = str(item.get('item_id', ''))
                api_index = item.get('index', 0)  # This is NOT the chapter number
                chapter_title = item.get('title', '')

                # Extract chapter number from title like "第7章 新生·一拳碎敌"
                match = chapter_num_pattern.match(chapter_title)
                if match:
                    chapter_number = int(match.group(1))
                else:
                    # Fallback to api_index if title format is unexpected
                    chapter_number = api_index
                    self.logger.warning(f"[fanqie_worker] Could not extract chapter number from title: {chapter_title}, using api_index: {api_index}")

                all_chapters.append({
                    'item_id': item_id,
                    'chapter_id': item_id,
                    'index': chapter_number,  # Use extracted chapter number
                    'title': chapter_title,
                    'word_number': item.get('word_number', 0),
                    'article_status': item.get('article_status', 0),
                    'timer_time': item.get('timer_time', ''),
                })
                self.logger.info(f"[fanqie_worker] Parsed chapter: item_id={item_id}, chapter_number={chapter_number}, title={chapter_title}")
            self.logger.info(f"[fanqie_worker] Page {current_page}: got {len(items)} chapters")

            # If there are more pages, click "下一页" to get remaining chapters
            while len(all_chapters) < total_count:
                # Wait for next button to be available
                time.sleep(0.5)

                # Check if next button exists and is not disabled
                next_btn = page.locator(
                    'li.arco-pagination-item-next:not(.arco-pagination-item-disabled)'
                )

                if next_btn.count() == 0 or not next_btn.first.is_visible():
                    self.logger.info(f"[fanqie_worker] 已是最后一页或下一页按钮不可用，已获取 {len(all_chapters)}/{total_count} 章")
                    break

                current_page += 1
                self.logger.info(f"[fanqie_worker] [{time.strftime('%H:%M:%S')}] Clicking next page button to go to page {current_page}")

                # Get current active page indicator before clicking
                active_page_before = page.locator('li.arco-pagination-item.arco-pagination-item-active').text_content()

                # Click next page with retry logic
                click_success = False
                for retry in range(10):
                    try:
                        # Click next page and wait for API response with shorter timeout
                        with page.expect_response("**/api/author/chapter/chapter_list/**", timeout=10000) as resp_info:
                            next_btn.first.click()

                        resp = resp_info.value
                        data = resp.json()

                        # Check if API response is valid
                        if data.get("code") != 0:
                            self.logger.error(f"[fanqie_worker] [{time.strftime('%H:%M:%S')}] 第{current_page}页API返回错误: code={data.get('code')}, message={data.get('message')}")
                            break

                        # Check if page actually changed by verifying active page indicator
                        time.sleep(1)  # Wait for UI to update
                        active_page_after = page.locator('li.arco-pagination-item-active').text_content()
                        self.logger.info(f"[fanqie_worker] [{time.strftime('%H:%M:%S')}] Page {current_page} API returned, active page indicator: {active_page_after}")

                        # Verify we're on the right page (active page should match current_page)
                        if active_page_after and str(current_page) in active_page_after:
                            click_success = True
                            self.logger.info(f"[fanqie_worker] [{time.strftime('%H:%M:%S')}] Successfully navigated to page {current_page}")
                            break
                        else:
                            self.logger.warning(f"[fanqie_worker] [{time.strftime('%H:%M:%S')}] Page indicator not updated yet (retry {retry+1}/10), expected page {current_page}, got: {active_page_after}")

                    except Exception as click_err:
                        err_type = type(click_err).__name__
                        err_msg = str(click_err)
                        # Check for specific timeout errors
                        if "Timeout" in err_msg:
                            if "expect_response" in err_msg:
                                self.logger.warning(f"[fanqie_worker] [{time.strftime('%H:%M:%S')}] 点击下一页按钮后等待API响应超时 (attempt {retry+1}/10): {err_msg}")
                            elif "click" in err_msg.lower():
                                self.logger.warning(f"[fanqie_worker] [{time.strftime('%H:%M:%S')}] 点击下一页按钮超时 (attempt {retry+1}/10): {err_msg}")
                            else:
                                self.logger.warning(f"[fanqie_worker] [{time.strftime('%H:%M:%S')}] 等待API响应超时 (attempt {retry+1}/10): {err_msg}")
                        else:
                            self.logger.warning(f"[fanqie_worker] [{time.strftime('%H:%M:%S')}] 点击下一页按钮失败 (attempt {retry+1}/10, {err_type}): {err_msg}")
                        if retry < 9:
                            time.sleep(3)  # Wait 3 seconds before retry
                        continue

                if not click_success:
                    self.logger.error(f"[fanqie_worker] [{time.strftime('%H:%M:%S')}] 点击下一页按钮获取第{current_page}页章节列表失败，已重试10次仍未成功，终止获取更多章节。当前已获取 {len(all_chapters)} 章")
                    break

                items = data.get("data", {}).get("item_list", [])
                for item in items:
                    item_id = str(item.get('item_id', ''))
                    api_index = item.get('index', 0)
                    chapter_title = item.get('title', '')

                    # Extract chapter number from title like "第7章 新生·一拳碎敌"
                    match = chapter_num_pattern.match(chapter_title)
                    if match:
                        chapter_number = int(match.group(1))
                    else:
                        chapter_number = api_index
                        self.logger.warning(f"[fanqie_worker] Could not extract chapter number from title: {chapter_title}, using api_index: {api_index}")

                    all_chapters.append({
                        'item_id': item_id,
                        'chapter_id': item_id,
                        'index': chapter_number,
                        'title': chapter_title,
                        'word_number': item.get('word_number', 0),
                        'article_status': item.get('article_status', 0),
                        'timer_time': item.get('timer_time', ''),
                    })
                self.logger.info(f"[fanqie_worker] Page {current_page}: got {len(items)} chapters, total so far: {len(all_chapters)}")

            self.logger.info(f"[fanqie_worker] Found {len(all_chapters)} chapters total")
            task.result = {'success': True, 'chapters': all_chapters}

        except Exception as e:
            self.logger.error(f"[fanqie_worker] Get chapters failed: {e}")
            task.error = str(e)
        finally:
            # Always close the page after task
            try:
                page.close()
                self.logger.info("[fanqie_worker] Closed task page")
            except:
                pass

    def _do_publish_chapter(self, task: FanqieTask) -> None:
        """Execute publish chapter task."""
        chapter_number = task.params.get('chapter_number')
        chapter_title = task.params.get('chapter_title')
        chapter_content = task.params.get('chapter_content')
        chapter_id = task.params.get('chapter_id')
        scheduled_time = task.params.get('scheduled_time')

        if not self._logged_in or not self._publisher:
            task.error = "Not logged in"
            return

        if not self._current_book_id:
            task.error = "No book selected"
            return

        # Create new page for this task
        new_page = self._publisher.create_new_page()
        if not new_page:
            task.error = "Failed to create new page"
            return

        # Save original page and use new page
        original_page = self._publisher.page
        self._publisher.page = new_page

        try:
            self.logger.info(f"[fanqie_worker] Publishing chapter {chapter_number}")

            # Set book info
            self._publisher._book_id = self._current_book_id
            self._publisher._book_name = self._current_book_name

            # Publish chapter - returns item_id on success, True if no item_id, False on failure
            result = self._publisher.publish_chapter(
                chapter_number,
                chapter_title,
                chapter_content,
                chapter_id=chapter_id,
                scheduled_time=scheduled_time
            )

            if result:
                # result could be item_id (str) or True
                item_id = result if isinstance(result, str) else None
                task.result = {'success': True, 'item_id': item_id}
            else:
                task.error = "Failed to publish chapter"

        except Exception as e:
            self.logger.error(f"[fanqie_worker] Publish chapter failed: {e}")
            task.error = str(e)
        finally:
            # Restore original page and close the task page
            self._publisher.page = original_page
            try:
                new_page.close()
                self.logger.info("[fanqie_worker] Closed publish chapter page")
            except:
                pass

    def _do_update_chapter(self, task: FanqieTask) -> None:
        """Execute update chapter task."""
        chapter_id = task.params.get('chapter_id')
        chapter_number = task.params.get('chapter_number')
        chapter_title = task.params.get('chapter_title')
        chapter_content = task.params.get('chapter_content')

        if not self._logged_in or not self._publisher:
            task.error = "Not logged in"
            return

        if not self._current_book_id:
            task.error = "No book selected"
            return

        # Create new page for this task
        new_page = self._publisher.create_new_page()
        if not new_page:
            task.error = "Failed to create new page"
            return

        # Save original page and use new page
        original_page = self._publisher.page
        self._publisher.page = new_page

        try:
            self.logger.info(f"[fanqie_worker] Updating chapter {chapter_number}")

            # Set book info
            self._publisher._book_id = self._current_book_id
            self._publisher._book_name = self._current_book_name

            # Update chapter
            success = self._publisher.update_chapter(
                chapter_number,
                chapter_title,
                chapter_content,
                chapter_id=chapter_id
            )

            if success:
                task.result = {'success': True}
            else:
                # Use detailed error from publisher
                detailed_error = self._publisher.get_last_error()
                task.error = detailed_error if detailed_error else "Failed to update chapter"

        except Exception as e:
            self.logger.error(f"[fanqie_worker] Update chapter failed: {e}")
            task.error = str(e)
        finally:
            # Restore original page and close the task page
            self._publisher.page = original_page
            try:
                new_page.close()
                self.logger.info("[fanqie_worker] Closed update chapter page")
            except:
                pass

    @property
    def is_connected(self) -> bool:
        """Check if publisher is connected."""
        return self._publisher is not None and self._publisher._is_logged_in

    @property
    def is_logged_in(self) -> bool:
        """Check if logged in."""
        return self._logged_in

    @property
    def current_book_id(self) -> Optional[str]:
        """Get current book ID."""
        return self._current_book_id
