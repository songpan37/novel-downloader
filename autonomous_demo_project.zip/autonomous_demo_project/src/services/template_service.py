"""
Template Service for AI Writer application.

Handles loading, saving, and managing prompt templates.
Templates are stored as .pmpt files directly in the templates directory.
"""
import os
import shutil
from typing import Dict, List, Optional

from models.template import (
    Template,
    get_default_template,
    AVAILABLE_PLACEHOLDERS
)


class TemplateService:
    """
    Service for managing prompt templates.

    Handles loading templates from disk, saving changes,
    and providing default templates.
    """

    def __init__(self, templates_dir: str):
        """
        Initialize template service.

        Args:
            templates_dir: Directory path for storing templates
        """
        self.templates_dir = templates_dir
        self._ensure_directory()
        self._init_templates_from_prompts()

    def _ensure_directory(self) -> None:
        """Ensure templates directory exists."""
        if not os.path.exists(self.templates_dir):
            os.makedirs(self.templates_dir, exist_ok=True)

    def _init_templates_from_prompts(self) -> None:
        """
        Initialize templates directory by copying from prompts/ if needed.

        On first startup, copies all .pmpt files from prompts/ to templates/.
        Also copies any missing templates if new ones were added.
        """
        script_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        prompts_dir = os.path.join(script_dir, "prompts")

        if not os.path.exists(prompts_dir):
            return

        # Get all .pmpt files from prompts directory
        prompt_files = [f for f in os.listdir(prompts_dir) if f.endswith('.pmpt')]

        for prompt_file in prompt_files:
            src_path = os.path.join(prompts_dir, prompt_file)
            dst_path = os.path.join(self.templates_dir, prompt_file)

            # Copy if destination doesn't exist
            if not os.path.exists(dst_path):
                shutil.copy2(src_path, dst_path)

    def _get_template_path(self, category: str) -> str:
        """
        Get file path for a template category.

        Args:
            category: Template category name

        Returns:
            Full file path for template (.pmpt file)
        """
        return os.path.join(self.templates_dir, f"{category}.pmpt")

    def get_template(self, category: str) -> Optional[Template]:
        """
        Get template for a category.

        Args:
            category: Template category name

        Returns:
            Template or None if not found
        """
        template_path = self._get_template_path(category)

        if os.path.exists(template_path):
            try:
                with open(template_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                return Template(category=category, content=content, is_custom=True)
            except (IOError, UnicodeDecodeError):
                pass

        # Fall back to default template from prompts directory
        return get_default_template(category)

    def get_all_templates(self) -> Dict[str, Template]:
        """
        Get all templates in the templates directory.

        Returns:
            Dictionary mapping category to template
        """
        templates = {}

        if not os.path.exists(self.templates_dir):
            return templates

        for file_name in os.listdir(self.templates_dir):
            if file_name.endswith('.pmpt'):
                category = file_name[:-5]  # Remove .pmpt extension
                template = self.get_template(category)
                if template:
                    templates[category] = template

        return templates

    def get_all_categories(self) -> List[str]:
        """
        Get all template categories.

        Returns:
            List of category names
        """
        templates = self.get_all_templates()
        return list(templates.keys())

    def save_template(self, category: str, content: str) -> bool:
        """
        Save template content to disk.

        Args:
            category: Template category name
            content: New template content

        Returns:
            True if saved successfully, False otherwise
        """
        template_path = self._get_template_path(category)

        try:
            with open(template_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except IOError:
            return False

    def reset_template(self, category: str) -> bool:
        """
        Reset template to default content by copying from prompts/.

        Args:
            category: Template category name

        Returns:
            True if reset successfully, False otherwise
        """
        script_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        prompts_dir = os.path.join(script_dir, "prompts")
        src_path = os.path.join(prompts_dir, f"{category}.pmpt")
        dst_path = self._get_template_path(category)

        if not os.path.exists(src_path):
            return False

        try:
            shutil.copy2(src_path, dst_path)
            return True
        except IOError:
            return False

    def validate_placeholders(self, content: str) -> tuple[bool, List[str]]:
        """
        Validate placeholders in template content.

        Args:
            content: Template content to validate

        Returns:
            Tuple of (is_valid, list of invalid placeholder names)
        """
        import re
        placeholders = re.findall(r'\{(\w+)\}', content)
        invalid = []
        for ph in placeholders:
            if ph not in AVAILABLE_PLACEHOLDERS:
                invalid.append(ph)
        return len(invalid) == 0, invalid

    def get_available_placeholders(self) -> Dict[str, dict]:
        """
        Get all available placeholders with descriptions.

        Returns:
            Dictionary of placeholder info
        """
        return AVAILABLE_PLACEHOLDERS.copy()

    def get_placeholders_for_category(self, category: str) -> List[str]:
        """
        Get list of placeholder names that are valid for a category.

        Args:
            category: Template category name

        Returns:
            List of valid placeholder names
        """
        return list(AVAILABLE_PLACEHOLDERS.keys())

    def render_template(
        self,
        category: str,
        context: Dict[str, str],
        remove_empty_sections: bool = True
    ) -> tuple[str, List[str]]:
        """
        Render template with placeholder resolution.

        Args:
            category: Template category to render
            context: Dictionary mapping placeholder names to values
            remove_empty_sections: If True, remove sections with unresolved placeholders

        Returns:
            Tuple of (rendered content, list of unresolved placeholder names)
        """
        template = self.get_template(category)
        if template is None:
            return "", [f"Template category '{category}' not found"]

        # Render with provided context
        rendered, missing = template.render_with_defaults(context, keep_missing=False)

        # Second pass: try to resolve missing placeholders from file-based context
        resolved_missing = []
        for ph in missing:
            if ph in context and context[ph] is not None:
                rendered = rendered.replace(f"{{{ph}}}", str(context[ph]))
            elif ph.startswith("previous_") or ph.startswith("current_"):
                if ph in context:
                    rendered = rendered.replace(f"{{{ph}}}", str(context[ph]))
                else:
                    resolved_missing.append(ph)
            else:
                resolved_missing.append(ph)

        # Third pass: remove any remaining empty placeholders
        import re
        lines = rendered.split('\n')
        cleaned_lines = []
        for line in lines:
            cleaned_line = re.sub(r'\{[a-zA-Z_][a-zA-Z0-9_]*\}', '', line)
            if cleaned_line.strip() or not re.search(r'\{[a-zA-Z_][a-zA-Z0-9_]*\}', line):
                cleaned_lines.append(cleaned_line)
        rendered = '\n'.join(cleaned_lines)

        if remove_empty_sections:
            rendered = self._remove_empty_sections(rendered, resolved_missing)

        return rendered, resolved_missing

    def _remove_empty_sections(self, content: str, missing_placeholders: List[str]) -> str:
        """
        Remove sections that contain unresolved placeholders.

        Args:
            content: Template content with unresolved placeholders
            missing_placeholders: List of unresolved placeholder names

        Returns:
            Content with empty sections removed
        """
        result = content
        for ph in missing_placeholders:
            lines = result.split('\n')
            filtered_lines = []

            for line in lines:
                if f"{{{ph}}}" in line:
                    stripped = line.strip()
                    if stripped.startswith('#') or stripped.startswith('-'):
                        filtered_lines.append(line.replace(f"{{{ph}}}", ""))
                    else:
                        continue
                else:
                    filtered_lines.append(line)

            result = '\n'.join(filtered_lines)

        return result
