"""
Chat Service for AI Writer application.

Provides a producer-consumer pattern for AI chat tasks using browser automation.
Tasks are queued and processed asynchronously by a dedicated browser thread.
"""
import os
import time
import json
import uuid
import threading
from typing import Optional, Dict, Any, Callable, List
from dataclasses import dataclass, field
from queue import Queue, Empty
from enum import Enum

from utils.logger import get_logger


class ChatTaskStatus(Enum):
    """Status of a chat task."""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class ChatTask:
    """
    A chat task for AI conversation.

    Attributes:
        task_id: Unique identifier for the task
        prompt: The prompt to send to AI
        system_prompt: Optional system prompt
        completion: The AI response (filled when done)
        status: Current task status
        error: Error message if failed
        created_at: Creation timestamp
    """
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    prompt: str = ""
    system_prompt: str = ""
    completion: str = ""
    status: ChatTaskStatus = ChatTaskStatus.PENDING
    error: str = ""
    created_at: str = field(default_factory=lambda: time.strftime("%Y-%m-%d %H:%M:%S"))

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "task_id": self.task_id,
            "prompt": self.prompt,
            "system_prompt": self.system_prompt,
            "completion": self.completion,
            "status": self.status.value,
            "error": self.error,
            "created_at": self.created_at
        }


class ChatServiceError(Exception):
    """Base exception for ChatService."""
    pass


class ChatService:
    """
    Producer-consumer service for AI chat tasks.

    This service manages a queue of chat tasks and processes them
    asynchronously using a dedicated browser thread with Playwright/DeepSeek.
    """

    _instance: Optional['ChatService'] = None
    _lock = threading.Lock()

    # DeepSeek configuration
    LOGIN_URL = "https://chat.deepseek.com/sign_in"
    CHAT_URL = "https://chat.deepseek.com/"

    DEFAULT_CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

    @classmethod
    def get_instance(cls, chrome_path: str = DEFAULT_CHROME_PATH,
                     phone_number: str = "", password: str = "",
                     browser_phone: str = "", browser_password: str = "") -> 'ChatService':
        """
        Get singleton instance of ChatService.
        """
        with cls._lock:
            if cls._instance is None:
                phone = phone_number or browser_phone
                pwd = password or browser_password
                cls._instance = ChatService(
                    phone_number=phone,
                    password=pwd,
                    chrome_path=chrome_path
                )
            return cls._instance

    @classmethod
    def reset_instance(cls) -> None:
        """Reset singleton instance (for testing)."""
        with cls._lock:
            if cls._instance is not None:
                cls._instance.stop()
                cls._instance = None

    def __init__(
        self,
        phone_number: str = "",
        password: str = "",
        chrome_path: str = DEFAULT_CHROME_PATH,
        headless: bool = False,
        slow_mo: int = 500,
    ):
        self.phone_number = phone_number
        self.password = password
        self.chrome_path = chrome_path
        self.headless = headless
        self.slow_mo = slow_mo

        self.logger = get_logger()
        self._task_queue: Queue = Queue()
        self._tasks: Dict[str, ChatTask] = {}
        self._tasks_lock = threading.Lock()

        # Browser state
        self._browser = None
        self._context = None
        self._page = None
        self._p = None
        self._is_running = False
        self._consumer_thread: threading.Thread = None
        self._thread_ready = threading.Event()

        # Callbacks
        self._callbacks: Dict[str, Callable[[ChatTask], None]] = {}

    def start(self) -> bool:
        """Start the consumer thread and initialize browser."""
        if self._is_running:
            return True

        try:
            self.logger.info("[chat_service] Starting chat service...")
            self._is_running = True

            # Start consumer thread (NOT daemon so it can properly run Playwright)
            self._consumer_thread = threading.Thread(target=self._run_consumer, daemon=False)
            self._consumer_thread.start()

            # Wait for browser to be ready
            if not self._thread_ready.wait(timeout=60):
                self.logger.error("[chat_service] Browser initialization timeout")
                self._is_running = False
                return False

            self.logger.info("[chat_service] Chat service started")
            return True

        except Exception as e:
            self.logger.error(f"[chat_service] Failed to start: {e}")
            self._is_running = False
            return False

    def stop(self) -> None:
        """Stop the consumer thread and close browser."""
        self.logger.info("[chat_service] Stopping chat service...")
        self._is_running = False

        if self._consumer_thread and self._consumer_thread.is_alive():
            # Put stop signal
            self._task_queue.put(None)
            self._consumer_thread.join(timeout=10)

        self.logger.info("[chat_service] Chat service stopped")

    def _run_consumer(self) -> None:
        """Run consumer loop in dedicated thread."""
        from playwright.sync_api import sync_playwright

        try:
            # Initialize browser
            self.logger.info("[chat_service] Starting browser in consumer thread...")
            self.p = sync_playwright().start()

            self.browser = self.p.chromium.launch(
                headless=self.headless,
                slow_mo=self.slow_mo,
                args=['--start-maximized'],
                executable_path=self.chrome_path,
            )

            self.context = self.browser.new_context()
            self.page = self.context.new_page()

            self.logger.info("[chat_service] Navigating to DeepSeek login...")
            self.page.goto(self.LOGIN_URL)
            self.page.wait_for_load_state("load")

            # Login
            if not self._deepseek_login():
                self.logger.error("[chat_service] Login failed")
                self._thread_ready.set()
                return

            self._thread_ready.set()
            self.logger.info("[chat_service] Browser ready, starting consume loop")

            # Consume tasks
            self._consume_loop()

        except Exception as e:
            self.logger.error(f"[chat_service] Consumer thread error: {e}")
            self._thread_ready.set()
        finally:
            self._close_browser()

    def _consume_loop(self) -> None:
        """Consumer loop - processes tasks from queue."""
        self.logger.info("[chat_service] Consumer loop started")

        while self._is_running:
            try:
                # Get task with timeout
                try:
                    task = self._task_queue.get(timeout=1.0)
                except Empty:
                    continue

                if task is None:
                    # Stop signal
                    break

                # Process task
                self._process_task(task)

            except Exception as e:
                self.logger.error(f"[chat_service] Consumer loop error: {e}")
                time.sleep(1)

        self.logger.info("[chat_service] Consumer loop stopped")

    def _deepseek_login(self) -> bool:
        """Login to DeepSeek."""
        try:
            self.logger.info("[chat_service] Starting DeepSeek login...")

            # Wait for phone input
            phone_input = self.page.wait_for_selector(
                'input.ds-input__input[type="tel"][placeholder="请输入手机号"]',
                timeout=60000
            )

            if self.phone_number:
                phone_input.fill(self.phone_number)
                self.logger.info(f"[chat_service] Phone filled: {self.phone_number[:3]}****")

            # Check if password login or verification code
            if self.password:
                # Password login
                password_login_btn = self.page.locator('button.ds-sign-in-form__social-button').first
                password_login_btn.wait_for(state="visible", timeout=10000)
                password_login_btn.click()

                password_input = self.page.wait_for_selector(
                    'input.ds-input__input[type="password"][placeholder="请输入密码"]',
                    timeout=30000
                )
                password_input.fill(self.password)

                login_btn = self.page.locator('button.ds-basic-button--primary').first
                login_btn.wait_for(state="visible", timeout=10000)
                login_btn.click()
            else:
                # Verification code login
                send_code_btn = self.page.locator(".ds-link-button__text")
                send_code_btn.wait_for(state="visible")
                send_code_btn.click()

                code_input = self.page.locator(
                    'input.ds-input__input[type="tel"][placeholder="请输入验证码"]'
                ).first
                code_input.wait_for(state="visible", timeout=60000)

                # Wait for user to enter code
                self.logger.info("[chat_service] Waiting for verification code...")
                wait_start = time.time()
                while True:
                    code = code_input.get_attribute("value") or ""
                    if len(code) == 6 and code.isdigit():
                        break
                    if time.time() - wait_start > 120:
                        self.logger.error("[chat_service] Verification code timeout")
                        return False
                    time.sleep(1)

                login_btn = self.page.locator('button.ds-basic-button--primary').first
                login_btn.click()

            # Wait for login
            time.sleep(3)

            # Check login success
            if self._check_login_success():
                self.logger.info("[chat_service] DeepSeek login successful")
                return True

            self.logger.warning("[chat_service] Login unclear, assuming success")
            return True

        except Exception as e:
            self.logger.error(f"[chat_service] Login failed: {e}")
            return False

    def _check_login_success(self) -> bool:
        """Check if DeepSeek login is successful."""
        try:
            new_chat_btn = self.page.locator('text=开启新对话')
            new_chat_btn.wait_for(state="visible", timeout=5000)
            return True
        except Exception:
            return False

    def _send_message(self, prompt: str, system_prompt: str = "") -> str:
        """Send a message to DeepSeek and get response."""
        import pyperclip

        try:
            # Find new chat button
            new_chat_button = self.page.wait_for_selector('text=开启新对话', timeout=10000)
            new_chat_button.click()
            self.page.wait_for_timeout(1000)

            # Wait for chat input
            chat_input = self.page.wait_for_selector('textarea.ds-scroll-area', timeout=10000)

            # Build full prompt with system if provided
            full_prompt = prompt
            if system_prompt:
                full_prompt = f"{system_prompt}\n\n{prompt}"

            # Input message
            chat_input.click()
            chat_input.fill(full_prompt)

            # Click Deep Think and Smart Search if available
            btn_span_class = "_6dbc175"

            deep_think_btn = self.page.locator(f'span.{btn_span_class}:has-text("深度思考")')
            if deep_think_btn.count() > 0:
                deep_think_btn.wait_for(state="visible", timeout=5000)
                if not self._has_class(deep_think_btn.locator("..").locator(".."), "ds-toggle-button--selected"):
                    deep_think_btn.click()

            search_btn = self.page.locator(f'span.{btn_span_class}:has-text("智能搜索")')
            if search_btn.count() > 0:
                search_btn.wait_for(state="visible", timeout=5000)
                if not self._has_class(search_btn.locator("..").locator(".."), "ds-toggle-button--selected"):
                    search_btn.click()

            # Submit
            chat_input.press('Enter')

            # Wait for generation complete
            self._wait_for_generation_complete()

            # Check for server busy error
            server_busy_text = "服务器繁忙，请稍后重试"
            server_busy_element = self.page.locator(f'text="{server_busy_text}"')
            if server_busy_element.count() > 0 and server_busy_element.first.is_visible():
                raise ChatServiceError("Server busy")

            # Get response
            copy_button_selector = 'div.ds-icon-button:has(path[d*="M6.14923 4.02032"])'
            all_buttons = self.page.locator(copy_button_selector).all()

            if not all_buttons:
                copy_button_selector = 'div.ds-icon-button:has(path[d*="M6.14929 4.02032"])'
                all_buttons = self.page.locator(copy_button_selector).all()

            if not all_buttons:
                all_buttons = self.page.locator('div.ds-icon-button[role="button"]:has-text("复制")').all()

            if not all_buttons:
                raise ChatServiceError("Copy button not found")

            last_copy_button = all_buttons[-1]
            last_copy_button.scroll_into_view_if_needed()
            last_copy_button.click()

            time.sleep(1)
            message_text = pyperclip.paste()

            # Clean up
            message_text = message_text.replace("\r\n", "\n").replace("\n\n", "\n").replace("**", "")

            return message_text

        except ChatServiceError:
            raise
        except Exception as e:
            self.logger.error(f"[chat_service] Send message failed: {e}")
            raise ChatServiceError(f"Send message failed: {e}")

    def _wait_for_generation_complete(self, timeout: float = 120.0) -> None:
        """Wait for generation to complete."""
        send_button_selector = 'div.ds-icon-button[role="button"][aria-disabled="true"]'

        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                disabled_btn = self.page.locator(send_button_selector).first
                if disabled_btn.count() > 0:
                    stop_icon = self.page.locator('div.ds-icon svg:has(path[d*="M2 4.88"])').first
                    if stop_icon.count() > 0 and stop_icon.is_visible():
                        time.sleep(0.5)
                        continue
                    return True
            except Exception:
                pass
            time.sleep(0.5)

        raise ChatServiceError("Generation timeout")

    def _has_class(self, element, class_name: str) -> bool:
        """Check if element has a specific CSS class."""
        try:
            class_list = element.get_attribute('class')
            if class_list and class_name in class_list.split():
                return True
        except Exception:
            pass
        return False

    def _process_task(self, task: ChatTask) -> None:
        """Process a single chat task."""
        try:
            # Update status
            task.status = ChatTaskStatus.PROCESSING
            self._update_task(task)

            # Send message with retry
            max_retries = 3
            last_error = None

            for attempt in range(max_retries):
                try:
                    result = self._send_message(task.prompt, task.system_prompt)
                    task.completion = result
                    task.status = ChatTaskStatus.COMPLETED
                    break
                except ChatServiceError as e:
                    last_error = e
                    if "Server busy" in str(e) or "繁忙" in str(e):
                        self.logger.warning(f"[chat_service] Server busy, retry {attempt + 1}/{max_retries}")
                        time.sleep(5)
                        continue
                    raise
                except Exception as e:
                    last_error = e
                    self.logger.error(f"[chat_service] Task failed: {e}")
                    # Try to reconnect
                    self._close_browser()
                    time.sleep(2)
                    if not self._reconnect_browser():
                        break
                    continue

            if task.status != ChatTaskStatus.COMPLETED:
                task.status = ChatTaskStatus.FAILED
                task.error = str(last_error)

        except Exception as e:
            task.status = ChatTaskStatus.FAILED
            task.error = str(e)
            self.logger.error(f"[chat_service] Task {task.task_id} failed: {e}")

        finally:
            self._update_task(task)

            # Call callback if set
            if task.task_id in self._callbacks:
                callback = self._callbacks.pop(task.task_id)
                try:
                    callback(task)
                except Exception as e:
                    self.logger.error(f"[chat_service] Callback error: {e}")

    def _reconnect_browser(self) -> bool:
        """Reconnect browser."""
        try:
            from playwright.sync_api import sync_playwright
            self.p = sync_playwright().start()
            self.browser = self.p.chromium.launch(
                headless=self.headless,
                slow_mo=self.slow_mo,
                args=['--start-maximized'],
                executable_path=self.chrome_path,
            )
            self.context = self.browser.new_context()
            self.page = self.context.new_page()
            self.page.goto(self.LOGIN_URL)
            self.page.wait_for_load_state("load")
            return self._deepseek_login()
        except Exception as e:
            self.logger.error(f"[chat_service] Reconnect failed: {e}")
            return False

    def _close_browser(self) -> None:
        """Close browser."""
        try:
            if self.context:
                self.context.close()
        except Exception:
            pass
        self.context = None

        try:
            if self.browser:
                self.browser.close()
        except Exception:
            pass
        self.browser = None

        try:
            if self.p:
                self.p.stop()
        except Exception:
            pass
        self.p = None

        self.page = None

    def _update_task(self, task: ChatTask) -> None:
        """Update task in dictionary."""
        with self._tasks_lock:
            self._tasks[task.task_id] = task

    def add_task(
        self,
        prompt: str,
        system_prompt: str = "",
        callback: Optional[Callable[[ChatTask], None]] = None
    ) -> ChatTask:
        """Add a chat task to the queue."""
        if not self._is_running:
            self.start()

        task = ChatTask(
            prompt=prompt,
            system_prompt=system_prompt
        )

        with self._tasks_lock:
            self._tasks[task.task_id] = task

        if callback:
            self._callbacks[task.task_id] = callback

        self._task_queue.put(task)
        self.logger.info(f"[chat_service] Task added: {task.task_id}")

        return task

    def get_task(self, task_id: str) -> Optional[ChatTask]:
        """Get a task by ID."""
        with self._tasks_lock:
            return self._tasks.get(task_id)

    def wait_for_task(self, task_id: str, timeout: float = 120.0) -> Optional[ChatTask]:
        """Wait for a task to complete."""
        start_time = time.time()
        while time.time() - start_time < timeout:
            task = self.get_task(task_id)
            if task and task.status in (ChatTaskStatus.COMPLETED, ChatTaskStatus.FAILED):
                return task
            time.sleep(0.5)
        return None
