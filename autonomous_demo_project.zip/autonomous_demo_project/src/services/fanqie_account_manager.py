"""
Fanqie Account Manager for AI Writer application.

Handles CRUD operations for 番茄小说 writer accounts.
"""
import json
import os
from typing import List, Optional, Dict, Any
from datetime import datetime

from models.fanqie_account import FanqieAccount
from utils.logger import get_logger


class FanqieAccountManager:
    """
    Manager for fanqie account operations.

    Handles CRUD operations for 番茄小说 writer accounts,
    stored in fanqie_accounts.json under storage_root.
    """

    def __init__(self, storage_root: str):
        """
        Initialize the account manager.

        Args:
            storage_root: Root directory for application data
        """
        self.storage_root = storage_root
        self.accounts_file = os.path.join(storage_root, "fanqie_accounts.json")
        self._accounts_cache: Dict[str, FanqieAccount] = {}
        self._setup_logger()
        self._load_accounts()

    def _setup_logger(self) -> None:
        """Set up logger if not already available."""
        import logging
        self.logger = get_logger()
        if self.logger is None:
            # Create a simple logger if none exists
            self.logger = logging.getLogger('FanqieAccountManager')
            if not self.logger.handlers:
                handler = logging.StreamHandler()
                handler.setFormatter(logging.Formatter(
                    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
                ))
                self.logger.addHandler(handler)
                self.logger.setLevel(logging.INFO)

    def _ensure_storage(self) -> None:
        """Ensure storage directory exists."""
        os.makedirs(self.storage_root, exist_ok=True)

    def _load_accounts(self) -> None:
        """Load accounts from JSON file."""
        self._accounts_cache.clear()
        if not os.path.exists(self.accounts_file):
            return

        try:
            with open(self.accounts_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for account_data in data.get("accounts", []):
                    account = FanqieAccount.from_dict(account_data)
                    self._accounts_cache[account.id] = account
            self.logger.info(f"Loaded {len(self._accounts_cache)} fanqie accounts")
        except (json.JSONDecodeError, IOError) as e:
            self.logger.error(f"Failed to load accounts: {e}")

    def _save_accounts(self) -> None:
        """Save accounts to JSON file."""
        self._ensure_storage()
        data = {
            "accounts": [acc.to_dict() for acc in self._accounts_cache.values()]
        }
        with open(self.accounts_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        self.logger.debug(f"Saved {len(self._accounts_cache)} accounts")

    def get_all_accounts(self) -> List[FanqieAccount]:
        """Get all accounts."""
        return list(self._accounts_cache.values())

    def get_account(self, account_id: str) -> Optional[FanqieAccount]:
        """Get account by ID."""
        return self._accounts_cache.get(account_id)

    def add_account(self, phone: str, password: str, nickname: str = "") -> FanqieAccount:
        """
        Add a new account.

        Args:
            phone: Phone number
            password: Password
            nickname: Optional nickname

        Returns:
            Created account
        """
        account = FanqieAccount(phone=phone, password=password, nickname=nickname)
        self._accounts_cache[account.id] = account
        self._save_accounts()
        self.logger.info(f"Added fanqie account: {account.id}")
        return account

    def update_account(self, account_id: str, phone: str = None,
                       password: str = None, nickname: str = None) -> Optional[FanqieAccount]:
        """
        Update an existing account.

        Args:
            account_id: Account ID to update
            phone: New phone number (if provided)
            password: New password (if provided)
            nickname: New nickname (if provided)

        Returns:
            Updated account or None if not found
        """
        account = self._accounts_cache.get(account_id)
        if not account:
            return None

        if phone is not None:
            account.phone = phone
        if password is not None:
            account.password = password
        if nickname is not None:
            account.nickname = nickname

        self._save_accounts()
        self.logger.info(f"Updated fanqie account: {account_id}")
        return account

    def delete_account(self, account_id: str) -> bool:
        """
        Delete an account.

        Args:
            account_id: Account ID to delete

        Returns:
            True if deleted, False if not found
        """
        if account_id not in self._accounts_cache:
            return False

        del self._accounts_cache[account_id]
        self._save_accounts()
        self.logger.info(f"Deleted fanqie account: {account_id}")
        return True

    def reload(self) -> None:
        """Reload accounts from disk."""
        self._load_accounts()
