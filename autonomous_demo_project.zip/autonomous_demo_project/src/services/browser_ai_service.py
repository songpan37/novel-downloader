"""
Browser AI Service for AI Writer application.

Provides interface to AI services through browser automation (Playwright),
for services that don't offer public APIs or require web interface access.

Supported providers:
- DeepSeek (deepseek.com)
- Doubao (doubao.com)
"""
import os
import time
from typing import Optional, Dict, Any
from pathlib import Path

from utils.logger import get_logger


class ServerBusyError(Exception):
    """
    Special exception for server busy errors that should trigger infinite retry.

    When this exception is raised, the send_message method will retry indefinitely
    until the operation succeeds.
    """


class RateLimitError(Exception):
    """
    Special exception for rate limit errors ("消息发送过于频繁") that should trigger retry with 10s wait.

    When this exception is raised, the send_message method will wait 10 seconds and retry.
    """
    pass


class BrowserAIService:
    """
    Browser-based AI Service using Playwright for web automation.

    This class provides an interface to AI services through their web interfaces,
    automating browser interactions like login, sending prompts, and copying responses.
    """

    # Supported providers configuration
    PROVIDERS = {
        "deepseek": {
            "name": "DeepSeek",
            "login_url": "https://chat.deepseek.com/sign_in",
            "chat_url": "https://chat.deepseek.com/",
            "requires_phone": True,
            "requires_verification": True,
        },
        "doubao": {
            "name": "豆包",
            "login_url": "https://doubao.com/login",
            "chat_url": "https://doubao.com/chat/",
            "requires_phone": True,
            "requires_verification": True,
        },
    }

    DEFAULT_CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

    def __init__(
        self,
        provider: str = "deepseek",
        phone_number: str = "",
        password: str = "",  # Optional password for DeepSeek password login
        chrome_path: str = DEFAULT_CHROME_PATH,
        headless: bool = False,
        slow_mo: int = 500,
    ):
        """
        Initialize the browser AI service.

        Args:
            provider: Provider name (deepseek, doubao, etc.)
            phone_number: Phone number for login (if required)
            password: Password for login (optional, for DeepSeek password login)
            chrome_path: Path to Chrome executable
            headless: Run browser in headless mode
            slow_mo: Slow down interactions by specified milliseconds
        """
        self.provider = provider
        self.phone_number = phone_number
        self.password = password  # New password field
        self.chrome_path = chrome_path
        self.headless = headless
        self.slow_mo = slow_mo

        self.logger = get_logger()
        self.browser = None
        self.context = None
        self.page = None

        # Provider-specific configuration
        self.provider_config = self.PROVIDERS.get(provider, {})
        self.login_url = self.provider_config.get("login_url", "")
        self.chat_url = self.provider_config.get("chat_url", "")

        # Persistent thread pool for Playwright operations
        self._executor = None
        self._loop = None

    @classmethod
    def check_chrome_installed(cls, chrome_path: str = DEFAULT_CHROME_PATH) -> bool:
        """
        Check if Chrome is installed at the specified path.

        Args:
            chrome_path: Path to check for Chrome executable

        Returns:
            True if Chrome is installed, False otherwise
        """
        return os.path.exists(chrome_path)

    @classmethod
    def get_chrome_install_path(cls) -> Optional[str]:
        """
        Get the default Chrome installation path.

        Returns:
            Chrome installation path or None if not found
        """
        common_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
        for path in common_paths:
            if os.path.exists(path):
                return path
        return None

    def connect(self) -> bool:
        """
        Connect to browser and login to the AI service.

        Returns:
            True if connection and login successful, False otherwise
        """
        # Check if already connected - reuse existing browser instance
        if self.browser is not None and self.page is not None and not self.page.is_closed():
            self.logger.info(f"[{self.provider}] Already connected, reusing existing browser instance")
            return True

        try:
            import asyncio
            from playwright.sync_api import sync_playwright

            # Ensure no asyncio event loop is active in this thread
            # This prevents "Playwright Sync API inside asyncio loop" errors
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.close()
            except Exception:
                pass

            self.logger.info(f"[{self.provider}] Starting browser connection...")
            self.logger.info(f"[{self.provider}] Chrome path: {self.chrome_path}")

            # Start Playwright
            self.logger.info(f"[{self.provider}] Starting playwright...")
            self.p = sync_playwright().start()
            self.logger.info(f"[{self.provider}] Playwright started")

            # Launch browser
            self.logger.info(f"[{self.provider}] Launching browser...")
            self.browser = self.p.chromium.launch(
                headless=self.headless,
                slow_mo=self.slow_mo,
                args=['--start-maximized'],
                executable_path=self.chrome_path,
            )
            self.logger.info(f"[{self.provider}] Browser launched")

            # Create context
            self.context = self.browser.new_context()
            self.logger.info(f"[{self.provider}] Context created")

            # Call provider-specific login
            if self.provider == "deepseek":
                self.logger.info(f"[{self.provider}] Calling DeepSeek login...")
                return self._deepseek_login()
            else:
                # For other providers, create page and navigate to login page
                self.page = self.context.new_page()
                self.logger.info(f"[{self.provider}] Navigating to {self.login_url}...")
                self.page.goto(self.login_url)
                self.page.wait_for_load_state("load")
                self.logger.info(f"[{self.provider}] Browser connection completed, login page loaded")
                return True

        except Exception as e:
            self.logger.error(f"[{self.provider}] Browser connection failed: {e}")
            # Clean up any partial state
            self._cleanup_partial_state()
            return False

    def _cleanup_partial_state(self):
        """Clean up any partial browser state after a failed connection."""
        try:
            if self.context:
                try:
                    self.context.close()
                except:
                    pass
                self.context = None
            if self.browser:
                try:
                    self.browser.close()
                except:
                    pass
                self.browser = None
            if hasattr(self, 'p') and self.p:
                try:
                    self.p.stop()
                except:
                    pass
                self.p = None
            if self.page:
                try:
                    self.page.close()
                except:
                    pass
                self.page = None
        except Exception:
            pass  # Best effort cleanup

    def _deepseek_login(self) -> bool:
        """
        Login to DeepSeek with support for both password and verification code login.

        If password is configured:
        1. Creates a new page and navigates to login page
        2. Auto-fills phone number
        3. Clicks password login button
        4. Auto-fills password
        5. Clicks login button

        If password is not configured:
        1. Creates a new page and navigates to login page
        2. Auto-fills phone number
        3. Auto-clicks "Get Verification Code" button
        4. Waits for user to input 6-digit verification code
        5. Auto-clicks login button when code detected
        6. Retries if verification code is wrong until success

        Returns:
            True if login successful, False otherwise
        """
        try:
            self.logger.info("[deepseek] Starting login process...")

            # Debug: check context
            self.logger.info(f"[deepseek] context is None: {self.context is None}")
            self.logger.info(f"[deepseek] context type: {type(self.context)}")

            # Create a new page for login
            self.logger.info("[deepseek] Creating new page...")
            self.page = self.context.new_page()
            self.logger.info(f"[deepseek] Page created: {self.page is not None}, type: {type(self.page)}")

            # Navigate to login page
            self.logger.info(f"[deepseek] Navigating to {self.login_url}...")
            self.page.goto(self.login_url)
            self.page.wait_for_load_state("load")
            self.logger.info("[deepseek] Login page loaded")

            # Check if password is configured for password login
            if self.password:
                self.logger.info("[deepseek] Using password login...")
                return self._deepseek_password_login()
            else:
                self.logger.info("[deepseek] Using verification code login...")
                return self._deepseek_verification_code_login()

        except Exception as e:
            self.logger.error(f"[deepseek] Browser connection failed: {e}")
            return False

    def _deepseek_password_login(self) -> bool:
        """
        Login to DeepSeek using password.

        This method:
        1. Auto-fills phone number
        2. Clicks password login button
        3. Auto-fills password
        4. Clicks login button

        Returns:
            True if login successful, False otherwise
        """
        try:
            # Wait for phone input field and auto-fill
            self.logger.info("[deepseek] Waiting for phone input field...")
            phone_input = self.page.wait_for_selector(
                'input.ds-input__input[type="tel"][placeholder="请输入手机号"]',
                timeout=60000
            )

            if self.phone_number:
                phone_input.fill(self.phone_number)
                self.logger.info(f"[deepseek] Phone number filled: {self.phone_number}")

            # Click password login button to switch to password login mode
            # Button: <button role="button" aria-disabled="false" class="ds-atom-button ds-basic-button ds-basic-button--outlined ds-sign-in-form__social-button">
            self.logger.info("[deepseek] Looking for password login button...")
            password_login_btn = self.page.locator('button.ds-sign-in-form__social-button').first
            password_login_btn.wait_for(state="visible", timeout=10000)
            password_login_btn.click()
            self.logger.info("[deepseek] Clicked password login button")

            # Wait for password input field
            self.logger.info("[deepseek] Waiting for password input field...")
            password_input = self.page.wait_for_selector(
                'input.ds-input__input[type="password"][placeholder="请输入密码"]',
                timeout=60000
            )

            # Fill password
            password_input.fill(self.password)
            self.logger.info("[deepseek] Password filled")

            # Click login button
            self.logger.info("[deepseek] Clicking login button...")
            login_btn = self.page.locator('button.ds-basic-button--primary').first
            login_btn.wait_for(state="visible", timeout=10000)
            login_btn.click()
            self.logger.info("[deepseek] Login button clicked, waiting for login to complete...")

            # Wait for login to complete
            time.sleep(3)

            # Check if login successful
            if self._check_deepseek_login_success():
                self.logger.info("[deepseek] Password login successful!")
                return True

            # Check for errors
            if self._check_deepseek_login_error():
                self.logger.error("[deepseek] Password login failed - invalid credentials?")
                return False

            # Check URL change
            current_url = self.page.url
            if "sign_in" not in current_url:
                self.logger.info(f"[deepseek] URL changed to: {current_url}")
                return True

            self.logger.warning("[deepseek] Password login completed but success unclear")
            return True  # Assume success if no error detected

        except Exception as e:
            self.logger.error(f"[deepseek] Password login failed: {e}")
            return False

    def _deepseek_verification_code_login(self) -> bool:
        """
        Login to DeepSeek using verification code with auto-fill and retry.

        This method:
        1. Auto-fills phone number
        2. Auto-clicks "Get Verification Code" button
        3. Waits for user to input 6-digit verification code
        4. Auto-clicks login button when code detected
        5. Retries if verification code is wrong until success

        Returns:
            True if login successful, False otherwise
        """
        try:
            # Wait for phone input field and auto-fill
            self.logger.info("[deepseek] Waiting for phone input field...")
            phone_input = self.page.wait_for_selector(
                'input.ds-input__input[type="tel"][placeholder="请输入手机号"]',
                timeout=60000
            )

            if self.phone_number:
                phone_input.fill(self.phone_number)
                self.logger.info(f"[deepseek] Phone number filled: {self.phone_number}")

            # Click "Get Verification Code" button
            send_code_btn = self.page.locator(".ds-link-button__text")
            send_code_btn.wait_for(state="visible")
            send_code_btn.click()
            self.logger.info("[deepseek] Clicked 'Get Verification Code' button")

            # Wait for verification code input
            code_input = self.page.locator(
                'input.ds-input__input[type="tel"][placeholder="请输入验证码"]'
            ).first
            code_input.wait_for(state="visible", timeout=60000)

            # Login button - use the correct class selector
            # Button has class: ds-atom-button ds-basic-button ds-basic-button--primary
            login_btn = self.page.locator('button.ds-basic-button--primary').first

            self.logger.info("[deepseek] Waiting for 6-digit verification code (user input)...")

            # Wait for user to input verification code
            code_entered = False
            login_clicked = False
            wait_start_time = time.time()
            max_wait_time = 120  # 2 minutes max
            last_checked_code = ""  # Track last checked code to avoid re-processing

            while True:
                # Check if page is still open
                if self.page.is_closed():
                    self.logger.error("[deepseek] Page closed by user, login aborted")
                    return False

                # Get current code value
                current_code = code_input.get_attribute("value") or ""

                # Check if 6-digit code entered (and not already processed)
                if not code_entered and len(current_code) == 6 and current_code.isdigit():
                    if current_code != last_checked_code:
                        # New code entered, process it
                        last_checked_code = current_code
                        self.logger.info(f"[deepseek] Detected 6-digit code: {current_code}, clicking login...")
                        code_entered = True

                        try:
                            # Wait for login button to be enabled and click
                            login_btn.wait_for(state="visible", timeout=5000)
                            login_btn.click()
                            self.logger.info("[deepseek] Login button clicked")
                            login_clicked = True
                        except Exception as e:
                            self.logger.error(f"[deepseek] Failed to click login button: {e}")
                            # Clear code and let user re-enter
                            code_input.fill("")
                            code_entered = False
                            login_clicked = False
                            last_checked_code = ""
                            continue

                # Check login result after clicking
                if login_clicked:
                    time.sleep(3)  # Wait for login response

                    # Check if login successful (redirected to chat page)
                    if self._check_deepseek_login_success():
                        self.logger.info("[deepseek] Login successful!")
                        return True

                    # Check for error messages
                    if self._check_deepseek_login_error():
                        self.logger.warning("[deepseek] Login failed, clearing code for retry...")
                        code_input.fill("")
                        code_entered = False
                        login_clicked = False
                        last_checked_code = ""
                        continue

                    # Check URL
                    current_url = self.page.url
                    if "sign_in" not in current_url:
                        self.logger.info(f"[deepseek] URL changed to: {current_url}")
                        if self._check_deepseek_login_success():
                            return True

                    # If we just clicked login and still on sign_in page without error,
                    # wait a bit more before assuming failure
                    # Only clear code if we've been waiting too long after click
                    if time.time() - wait_start_time > 30:  # More than 30 seconds since last click
                        self.logger.warning("[deepseek] Login timeout, clearing code for retry...")
                        code_input.fill("")
                        code_entered = False
                        login_clicked = False
                        last_checked_code = ""
                        wait_start_time = time.time()
                        continue

                # Overall timeout
                if time.time() - wait_start_time > max_wait_time:
                    self.logger.warning("[deepseek] Verification code wait timeout")
                    code_input.fill("")
                    code_entered = False
                    login_clicked = False
                    last_checked_code = ""
                    wait_start_time = time.time()
                    continue

                time.sleep(1)

        except Exception as e:
            self.logger.error(f"[deepseek] Login failed: {e}")
            import traceback
            self.logger.error(f"[deepseek] Traceback: {traceback.format_exc()}")
            return False

    def _check_deepseek_login_success(self, wait_timeout: float = 5.0) -> bool:
        """
        Check if DeepSeek login is successful.

        Returns:
            True if login successful (chat page loaded), False otherwise
        """
        try:
            # Check for "New Chat" button (chat page feature)
            new_chat_btn = self.page.locator('text=开启新对话')
            new_chat_btn.wait_for(state="visible", timeout=int(wait_timeout * 1000))

            # Check for chat input
            chat_input = self.page.locator('textarea.ds-scroll-area')
            chat_input.wait_for(state="visible", timeout=int(wait_timeout * 1000))

            self.logger.info("[deepseek] Login success check passed - chat page loaded")
            return True

        except Exception as e:
            self.logger.debug(f"[deepseek] Login success check failed: {e}")
            return False

    def _check_deepseek_login_error(self) -> bool:
        """
        Check if there are any error messages on login page.

        Returns:
            True if error message found, False otherwise
        """
        try:
            error_selectors = [
                'div.ds-message:has-text("验证码错误")',
                'div.ds-message:has-text("验证码已过期")',
                'div.ds-message:has-text("验证码不正确")',
                'div.ds-message:has-text("请重新获取")',
                '.ds-message--error',
                'div.ds-alert:has-text("错误")',
            ]

            for selector in error_selectors:
                try:
                    error_elem = self.page.locator(selector)
                    if error_elem.count() > 0:
                        error_text = error_elem.first.inner_text()
                        self.logger.warning(f"[deepseek] Error detected: {error_text}")
                        return True
                except:
                    continue

            return False

        except Exception as e:
            self.logger.debug(f"[deepseek] Error check failed: {e}")
            return False

    def login(self, verification_code_callback=None, wait_timeout: float = 60.0) -> bool:
        """
        Login to the AI service.

        Note: This method is deprecated. Login is now handled automatically in connect().

        Args:
            verification_code_callback: Callback to get verification code from user
            wait_timeout: Timeout for waiting for page elements

        Returns:
            True if login successful, False otherwise
        """
        # Login is already completed in connect()
        # This method is kept for backward compatibility
        self.logger.warning(f"[{self.provider}] login() is deprecated, use connect() instead")
        return self.page is not None

    def _doubao_login(self, verification_code_callback=None, wait_timeout: float = 60.0) -> bool:
        """
        Login to Doubao.

        Args:
            verification_code_callback: Callback to get verification code
            wait_timeout: Timeout for waiting

        Returns:
            True if login successful
        """
        # TODO: Implement Doubao login logic
        self.logger.warning("[doubao] Login not yet implemented")
        return False

    def send_message(self, message: str, new_chat: bool = False, dial_cnt: int = 1, wait_timeout: float = 120.0, max_retries: int = 3, session_mode: str = "multi_turn", pause_check_fn=None) -> str:
        """
        Send a message and get the response.

        Args:
            message: Message to send
            new_chat: Start a new chat if True
            dial_cnt: Number of expected responses (for multi-turn conversations)
            wait_timeout: Timeout for waiting for response (in seconds)
            max_retries: Maximum retry attempts (not applied to ServerBusyError which retries infinitely)
            session_mode: Session mode - "multi_turn" for same session, "new_chat" for new session each time
            pause_check_fn: Optional callable to check if paused - returns True if should abort

        Returns:
            AI response text
        """
        last_error = None
        server_busy_retry_count = 0

        for attempt in range(max_retries):
            try:
                self.logger.info(f"[{self.provider}] Sending message (attempt {attempt + 1}/{max_retries})...")

                if self.provider == "deepseek":
                    return self._deepseek_complete(message, new_chat, dial_cnt, wait_timeout, session_mode, pause_check_fn)
                elif self.provider == "doubao":
                    return self._doubao_complete(message, new_chat, dial_cnt, wait_timeout, session_mode, pause_check_fn)
                else:
                    raise Exception(f"Unsupported provider: {self.provider}")

            except InterruptedError as e:
                # Pause interrupt - do NOT retry, just exit
                self.logger.info(f"[{self.provider}] Generation interrupted by pause: {e}")
                raise e

            except ServerBusyError as e:
                # Server busy error - retry infinitely until successful
                server_busy_retry_count += 1
                last_error = e
                self.logger.warning(f"[{self.provider}] Server busy (attempt {server_busy_retry_count}), retrying indefinitely...")

                # Wait before retry - no need to reconnect, just retry in the same session
                wait_time = 5
                self.logger.info(f"[{self.provider}] Waiting {wait_time}s before retry...")
                time.sleep(wait_time)

                # Continue the loop - this will retry sending the same message in the same session
                # Do NOT close/reconnect browser - we want to keep the same session
                # Force new_chat=False to retry within the same session
                new_chat = False
                continue

            except RateLimitError as e:
                # Rate limit error - wait 30 seconds and retry
                last_error = e
                self.logger.warning(f"[{self.provider}] Rate limit detected, waiting 30 seconds before retry...")

                # Wait 30 seconds before retry
                wait_time = 30
                self.logger.info(f"[{self.provider}] Waiting {wait_time}s before retry...")
                time.sleep(wait_time)

                # Continue the loop - this will retry sending the same message in the same session
                # Do NOT close/reconnect browser - we want to keep the same session
                # Force new_chat=False to retry within the same session
                new_chat = False
                continue

            except Exception as e:
                last_error = e
                self.logger.error(f"[{self.provider}] Send message failed (attempt {attempt + 1}/{max_retries}): {e}")

                # Don't retry on certain errors (e.g., browser closed)
                if "Browser closed" in str(e) or "page closed" in str(e).lower():
                    self.logger.error(f"[{self.provider}] Browser/page closed, stopping retries")
                    break

                # Wait before retry (exponential backoff)
                if attempt < max_retries - 1:
                    wait_time = 5 * (attempt + 1)  # 5s, 10s, 15s...
                    self.logger.info(f"[{self.provider}] Waiting {wait_time}s before retry...")
                    time.sleep(wait_time)

                    # Try to reconnect browser
                    try:
                        self.logger.info(f"[{self.provider}] Attempting to reconnect...")
                        if self.page:
                            self.page.close()
                        if self.context:
                            self.context.close()
                        if self.browser:
                            self.browser.close()
                        if hasattr(self, 'p'):
                            self.p.stop()
                        self.browser = None
                        self.context = None
                        self.page = None
                        self.connect()
                        self.logger.info(f"[{self.provider}] Reconnected successfully")
                    except Exception as reconnect_error:
                        self.logger.error(f"[{self.provider}] Reconnect failed: {reconnect_error}")

        # All retries failed
        if server_busy_retry_count > 0:
            raise Exception(f"浏览器 AI 调用失败（服务器繁忙，已重试 {server_busy_retry_count} 次）: {last_error}")
        else:
            raise Exception(f"浏览器 AI 调用失败（已重试 {max_retries} 次）: {last_error}")

    def _click_copy_button_with_retry(self, button, max_retries=3) -> str:
        """点击拷贝按钮并验证剪贴板内容，重试机制

        Args:
            button: Playwright locator 对象
            max_retries: 最大重试次数

        Returns:
            剪贴板内容

        Raises:
            Exception: 重试max_retries次后仍为空
        """
        import pyperclip

        for attempt in range(max_retries):
            # 1. 清空剪贴板
            pyperclip.copy("")

            # 2. 点击按钮
            try:
                button.scroll_into_view_if_needed(timeout=10000)
                button.click(timeout=10000)
            except Exception as click_err:
                self.logger.warning(f"[deepseek] 点击拷贝按钮失败 (attempt {attempt+1}/{max_retries}): {click_err}")
                if attempt < max_retries - 1:
                    time.sleep(2)
                    continue
                else:
                    raise Exception(f"点击拷贝按钮失败: {click_err}")

            # 3. 等待内容写入剪贴板
            time.sleep(1)

            # 4. 获取内容
            content = pyperclip.paste()

            if content and len(content.strip()) > 0:
                self.logger.info(f"[deepseek] 拷贝成功，内容长度: {len(content)}")
                return content

            self.logger.warning(f"[deepseek] 剪贴板为空 (attempt {attempt+1}/{max_retries})")

            if attempt < max_retries - 1:
                time.sleep(2)

        raise Exception("拷贝失败，剪贴板始终为空")

    def _resend_and_wait(self, message: str, wait_timeout: float = 120.0, pause_check_fn=None) -> None:
        """重新发送提示词并等待生成完成

        Args:
            message: 提示词内容
            wait_timeout: 等待超时时间
            pause_check_fn: 可选的中断检查函数

        Raises:
            Exception: 发送或等待失败
        """
        self.logger.info(f"[deepseek] 重新发送提示词，长度: {len(message)}")

        # 找到输入框
        chat_input = self.page.locator('textarea.ds-scroll-area')
        chat_input.click()
        chat_input.fill(message)
        self.logger.info("[deepseek] 提示词已填充到输入框")

        # 点击发送
        chat_input.press('Enter')
        self.logger.info("[deepseek] 提示词已重新发送")

        # 等待生成完成
        self._wait_for_generation_complete(wait_timeout, pause_check_fn)
        self.logger.info("[deepseek] 重新生成完成")

        # 等待内容渲染
        self.page.wait_for_timeout(500)

    def _deepseek_complete(self, message: str, new_chat: bool, dial_cnt: int, wait_timeout: float, session_mode: str = "multi_turn", pause_check_fn=None) -> str:
        """
        Complete a DeepSeek conversation with retry logic.

        Args:
            message: Message to send
            new_chat: Start new chat
            dial_cnt: Number of expected responses
            wait_timeout: Timeout (in seconds)
            session_mode: Session mode - "multi_turn" for same session, "new_chat" for new session each time
            pause_check_fn: Optional callable to check if paused - returns True if should abort

        Returns:
            Response text
        """
        import pyperclip

        def find_copy_buttons():
            """Find all copy buttons on the page."""
            copy_button_selector = 'div.ds-icon-button:has(path[d*="M6.14923 4.02032"])'
            all_buttons = self.page.locator(copy_button_selector).all()
            if all_buttons:
                self.logger.info(f"[deepseek] 找到 {len(all_buttons)} 个拷贝按钮 (primary selector)")
                return all_buttons

            # Fallback: try M6.14929 variant
            self.logger.info("[deepseek] 尝试 M6.14929 variant selector...")
            copy_button_selector_fallback = 'div.ds-icon-button:has(path[d*="M6.14929 4.02032"])'
            all_buttons = self.page.locator(copy_button_selector_fallback).all()
            if all_buttons:
                self.logger.info(f"[deepseek] 找到 {len(all_buttons)} 个拷贝按钮 (fallback selector)")
                return all_buttons

            # Fallback: try aria-label
            self.logger.info("[deepseek] 尝试 aria-label selector...")
            all_buttons = self.page.locator('div.ds-icon-button[role="button"]:has-text("复制")').all()
            if all_buttons:
                self.logger.info(f"[deepseek] 找到 {len(all_buttons)} 个拷贝按钮 (aria-label selector)")
                return all_buttons

            # Last resort: generic icon button
            self.logger.info("[deepseek] 尝试 generic icon button selector...")
            all_buttons = self.page.locator('div.ds-icon-button[role="button"][aria-disabled="false"]').all()
            copy_buttons = []
            for btn in all_buttons:
                try:
                    svg_path = btn.locator('svg path').first.get_attribute('d')
                    if svg_path and not svg_path.startswith('M5.5498'):
                        if svg_path.startswith('M6.14923') or svg_path.startswith('M6.14929') or svg_path.startswith('M6.14'):
                            copy_buttons.append(btn)
                except:
                    continue
            if copy_buttons:
                self.logger.info(f"[deepseek] 找到 {len(copy_buttons)} 个拷贝按钮 (generic selector)")
                return copy_buttons

            return []

        def check_page_errors():
            """检查页面错误，返回 (是否有错, 错误类型)"""
            # Check server busy
            server_busy_text = "服务器繁忙，请稍后重试"
            server_busy_element = self.page.locator(f'text="{server_busy_text}"').first
            try:
                server_busy_element.wait_for(state="visible", timeout=2000)
                return (True, "server_busy")
            except:
                pass

            # Check rate limit
            rate_limit_text = "消息发送过于频繁，请稍后重试"
            rate_limit_element = self.page.locator(f'text="{rate_limit_text}"').first
            try:
                rate_limit_element.wait_for(state="visible", timeout=2000)
                return (True, "rate_limit")
            except:
                pass

            return (False, None)

        try:
            # ========== 外层重试循环：提示词验证失败或按钮不足时重发 ==========
            for verify_retry in range(3):
                self.logger.info(f"[deepseek] ========== 开始第{verify_retry + 1}/3次生成 ==========")

                # --- 发送提示词 ---
                if verify_retry == 0:
                    # 首次发送
                    new_chat_button = self.page.wait_for_selector('text=开启新对话', timeout=wait_timeout * 1000)
                    if new_chat:
                        new_chat_button.click()
                        self.page.wait_for_timeout(1000)

                    chat_input = self.page.wait_for_selector('textarea.ds-scroll-area', timeout=wait_timeout * 1000)
                    while not chat_input.is_visible():
                        if new_chat:
                            new_chat_button.click()
                            self.page.wait_for_timeout(1000)
                        chat_input = self.page.wait_for_selector('#chat-input', timeout=wait_timeout * 1000)

                    chat_input.click()
                    chat_input.fill(message, timeout=300 * 1000)
                    self.logger.info(f"[deepseek] 发送提示词，长度: {len(message)}")

                    # Click "Deep Think" button if available
                    btn_span_class = "_6dbc175"
                    btn_parent_class_while_clicked = "ds-toggle-button--selected"

                    deep_think_btn = self.page.locator(f'span.{btn_span_class}:has-text("深度思考")')
                    deep_think_btn.wait_for(state="visible", timeout=wait_timeout * 1000)
                    if not self._has_class(deep_think_btn.locator("..").locator(".."), btn_parent_class_while_clicked):
                        deep_think_btn.click()
                        self.logger.info("[deepseek] 点击「深度思考」按钮")

                    # Click "Smart Search" button if available
                    search_btn = self.page.locator(f'span.{btn_span_class}:has-text("智能搜索")')
                    search_btn.wait_for(state="visible", timeout=wait_timeout * 1000)
                    if not self._has_class(search_btn.locator("..").locator(".."), btn_parent_class_while_clicked):
                        search_btn.click()
                        self.logger.info("[deepseek] 点击「智能搜索」按钮")

                    chat_input.press('Enter')
                    self.logger.info("[deepseek] 提示词已发送")
                else:
                    # 重新发送
                    self._resend_and_wait(message, wait_timeout, pause_check_fn)

                # --- 等待生成完成 ---
                self.logger.info(f"[deepseek] 等待生成完成 (timeout: {wait_timeout}s)...")
                self._wait_for_generation_complete(wait_timeout, pause_check_fn)
                self.logger.info("[deepseek] 生成完成")
                self.page.wait_for_timeout(500)

                # --- 检查页面错误 ---
                has_error, error_type = check_page_errors()
                if has_error:
                    if error_type == "server_busy":
                        self.logger.warning("[deepseek] <<< 检测到页面错误：服务器繁忙 >>>")
                        pyperclip.copy("")
                        raise ServerBusyError("服务器繁忙，需要重试")
                    elif error_type == "rate_limit":
                        self.logger.warning("[deepseek] <<< 检测到页面错误：消息发送过于频繁 >>>")
                        pyperclip.copy("")
                        raise RateLimitError("消息发送过于频繁，需要等待 10 秒后重试")

                # --- 查找拷贝按钮 ---
                all_buttons = find_copy_buttons()
                self.logger.info(f"[deepseek] 找到 {len(all_buttons)} 个拷贝按钮")

                if len(all_buttons) < 2:
                    # 按钮数量不足，重试发送提示词
                    self.logger.warning(f"[deepseek] 拷贝按钮数量不足: {len(all_buttons)}个，需要至少2个")
                    if verify_retry < 2:
                        continue
                    else:
                        raise Exception(f"拷贝按钮数量异常，只有{len(all_buttons)}个，已重试3次")

                # --- 1. 点击倒数第二个，获取刚发送的提示词 ---
                self.logger.info("[deepseek] 点击倒数第二个拷贝按钮验证提示词")
                second_last = all_buttons[-2]
                prev_prompt = self._click_copy_button_with_retry(second_last)

                # --- 2. 验证提示词是否一致（去掉空格和换行后比对）---
                # DeepSeek可能会对文本做格式优化，所以需要normalize后再比对
                normalized_expected = message.replace(" ", "").replace("\n", "").replace("\r", "")
                normalized_actual = prev_prompt.replace(" ", "").replace("\n", "").replace("\r", "")
                if normalized_actual != normalized_expected:
                    self.logger.warning(f"[deepseek] 提示词验证失败 (attempt {verify_retry + 1}/3)")
                    self.logger.warning(f"[deepseek] 原始期望: {message[:200]}")
                    self.logger.warning(f"[deepseek] 原始实际: {prev_prompt[:200]}")
                    self.logger.warning(f"[deepseek] normalize后期望: {normalized_expected[:200]}")
                    self.logger.warning(f"[deepseek] normalize后实际: {normalized_actual[:200]}")
                    if verify_retry < 2:
                        continue
                    else:
                        raise Exception("提示词验证失败，已重试3次")

                self.logger.info("[deepseek] 提示词验证通过")

                # --- 3. 点击最后一个，获取生成结果 ---
                self.logger.info("[deepseek] 点击最后一个拷贝按钮获取结果")
                last_button = all_buttons[-1]
                message_text = self._click_copy_button_with_retry(last_button)

                # --- 检查结果中的错误 ---
                server_busy_text = "服务器繁忙，请稍后重试"
                if server_busy_text in message_text:
                    self.logger.warning("[deepseek] <<< 结果中检测到服务器繁忙错误 >>>")
                    pyperclip.copy("")
                    raise ServerBusyError("服务器繁忙，需要重试")

                rate_limit_text = "消息发送过于频繁，请稍后重试"
                if rate_limit_text in message_text:
                    self.logger.warning("[deepseek] <<< 结果中检测到频率限制错误 >>>")
                    pyperclip.copy("")
                    raise RateLimitError("消息发送过于频繁，需要等待 10 秒后重试")

                # --- 清理并返回 ---
                message_text = message_text.replace("\r\n", "\n")
                message_text = message_text.replace("\n\n", "\n")
                message_text = message_text.replace("**", "")

                self.logger.info(f"[deepseek] ========== 生成完成，内容长度: {len(message_text)} ==========")
                return message_text

        except (ServerBusyError, RateLimitError):
            raise
        except Exception as e:
            self.logger.error(f"[deepseek] 生成失败: {e}")
            raise

        except Exception as e:
            self.logger.error(f"[deepseek] Error during operation: {e}")
            raise
        finally:
            pass

    def _wait_for_generation_complete(self, wait_timeout: float = 120.0, pause_check_fn=None) -> None:
        """
        Wait for generation to complete by checking send button status.

        Send button states:
        1. Disabled (aria-disabled="true") with arrow icon - input empty after sending
        2. Enabled (aria-disabled="false") with arrow icon - ready to send new message
        3. Enabled (aria-disabled="false") with square/stop icon - generating

        Generation is complete when button returns to state 1 or 2.

        Args:
            wait_timeout: Maximum wait time in seconds
            pause_check_fn: Optional callable to check if paused - returns True if should abort
        """
        # Send button selector - the parent div that contains the SVG
        send_button_selector = 'div.ds-icon-button[role="button"][aria-disabled="true"]'

        start_time = time.time()
        max_wait_seconds = wait_timeout
        check_interval = 0.5  # Check every 500ms
        last_status = "unknown"

        while time.time() - start_time < max_wait_seconds:
            # Check pause status first (if callback provided)
            if pause_check_fn is not None:
                try:
                    if pause_check_fn():
                        # Paused - click stop button and exit
                        self.logger.info("[deepseek] Pause detected, stopping generation...")
                        self._click_stop_button()
                        raise InterruptedError("Generation aborted due to pause")
                except InterruptedError:
                    raise
                except Exception as e:
                    self.logger.debug(f"[deepseek] Error checking pause status: {e}")

            try:
                # Check if send button is disabled (aria-disabled="true")
                # This means input is empty - could be waiting for send or generation complete
                disabled_btn = self.page.locator(send_button_selector).first

                if disabled_btn.count() > 0:
                    # Button is disabled, check if there's a generating indicator elsewhere
                    # Look for stop square icon (generating) vs arrow icon (ready)
                    stop_icon = self.page.locator('div.ds-icon svg:has(path[d*="M2 4.88"])').first
                    if stop_icon.count() > 0:
                        # Still generating (stop square icon visible somewhere)
                        if last_status != "generating":
                            self.logger.debug("[deepseek] Status: generating (stop icon visible)")
                            last_status = "generating"
                        time.sleep(check_interval)
                        continue
                    else:
                        # No stop icon, generation complete
                        self.logger.debug("[deepseek] Status: complete (disabled button, no stop icon)")
                        return True
                else:
                    # Button is enabled, check if it's send (arrow) or stop (square)
                    stop_icon_enabled = self.page.locator('div.ds-icon-button[role="button"][aria-disabled="false"] svg:has(path[d*="M2 4.88"])').first
                    if stop_icon_enabled.count() > 0:
                        # Generating (stop button shown)
                        if last_status != "generating":
                            self.logger.debug("[deepseek] Status: generating (stop button enabled)")
                            last_status = "generating"
                        time.sleep(check_interval)
                        continue
                    else:
                        # Send arrow shown, generation complete
                        self.logger.debug("[deepseek] Status: complete (send button enabled)")
                        return True

            except InterruptedError:
                # Re-raise interrupt
                raise
            except Exception as e:
                self.logger.debug(f"[deepseek] Error checking generation status: {e}")
                # On error, wait a bit and continue checking
                time.sleep(check_interval)
                continue

            time.sleep(check_interval)

        # Timeout - log warning but continue
        self.logger.warning(f"[deepseek] Generation wait timeout ({wait_timeout}s), proceeding anyway")
        return

    def _click_stop_button(self) -> bool:
        """
        Click the stop generation button.

        Returns:
            True if stop button was clicked successfully, False otherwise
        """
        try:
            # Find stop button (square icon)
            stop_button = self.page.locator('div.ds-icon-button[role="button"][aria-disabled="false"] svg:has(path[d*="M2 4.88"])').first

            if stop_button.count() > 0:
                stop_button.wait_for(state="visible", timeout=2000)
                # Click the parent button element (the div with role="button")
                stop_button.locator("..").locator("..").first.click()
                self.page.wait_for_timeout(500)
                self.logger.info("[deepseek] Stop button clicked")
                return True
            else:
                self.logger.warning("[deepseek] Stop button not found")
                return False
        except Exception as e:
            self.logger.error(f"[deepseek] Error clicking stop button: {e}")
            return False

    def is_generating(self) -> bool:
        """
        Check if AI is currently generating content.

        Returns:
            True if generation is in progress, False otherwise
        """
        try:
            # Check if stop button is visible (square icon) - means generating
            stop_icon = self.page.locator('div.ds-icon-button[role="button"][aria-disabled="false"] svg:has(path[d*="M2 4.88"])').first
            if stop_icon.count() > 0:
                try:
                    stop_icon.wait_for(state="visible", timeout=500)
                    return True
                except Exception:
                    return False
            return False
        except Exception:
            return False

    def stop_generation(self) -> bool:
        """
        Stop the current generation by clicking the stop button.

        Returns:
            True if stop was successful, False otherwise
        """
        try:
            # Find stop button (square icon)
            stop_button = self.page.locator('div.ds-icon-button[role="button"][aria-disabled="false"] svg:has(path[d*="M2 4.88"])').first

            if stop_button.count() > 0:
                stop_button.wait_for(state="visible", timeout=2000)
                stop_button.click()
                self.logger.info("[deepseek] Stop button clicked, generation interrupted")

                # Wait for generation to actually stop
                self.page.wait_for_timeout(1000)
                return True
            else:
                self.logger.warning("[deepseek] No stop button found, may not be generating")
                return False
        except Exception as e:
            self.logger.error(f"[deepseek] Error stopping generation: {e}")
            return False

    def _doubao_complete(self, message: str, new_chat: bool, dial_cnt: int, wait_timeout: float, session_mode: str = "multi_turn") -> str:
        """
        Complete a Doubao conversation.

        Args:
            message: Message to send
            new_chat: Start new chat
            dial_cnt: Number of expected responses
            wait_timeout: Timeout
            session_mode: Session mode

        Returns:
            Response text
        """
        # TODO: Implement Doubao completion logic
        self.logger.warning("[doubao] Completion not yet implemented")
        return ""

    def _has_class(self, element, class_name: str) -> bool:
        """
        Check if element has a specific CSS class.

        Args:
            element: Playwright element
            class_name: CSS class name

        Returns:
            True if element has the class
        """
        try:
            class_list = element.get_attribute('class')
            if class_list and class_name in class_list.split():
                return True
        except Exception:
            pass
        return False

    def close(self) -> None:
        """Close browser and context. Silently ignores errors."""
        # Best effort cleanup - never log errors to user
        try:
            if self.context:
                self.context.close()
        except Exception:
            pass
        self.context = None

        try:
            if self.browser:
                self.browser.close()
        except Exception:
            pass
        self.browser = None

        try:
            if hasattr(self, 'p') and self.p:
                self.p.stop()
        except Exception:
            pass
        self.p = None

        try:
            if hasattr(self, '_executor') and self._executor:
                self._executor.shutdown(wait=False)
        except Exception:
            pass
        self._executor = None

        try:
            if hasattr(self, '_loop') and self._loop:
                self._loop.stop()
        except Exception:
            pass
        self._loop = None

    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
