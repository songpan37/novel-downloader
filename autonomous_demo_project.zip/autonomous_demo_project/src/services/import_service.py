"""
Import Service for AI Writer application.

Handles importing works from ZIP files or existing directories.
"""
import os
import json
import zipfile
import shutil
from typing import Optional, List, Tuple, Dict
from datetime import datetime

from models.work import Work


class ImportConflictResolution:
    """Enumeration for import conflict resolution strategies."""
    OVERWRITE = "overwrite"
    SKIP = "skip"
    RENAME = "rename"


class ImportService:
    """
    Service for importing works from ZIP files or directories.

    Supports:
    - Importing from ZIP exports
    - Importing from work directories
    - Conflict detection and resolution
    - Validation of work structure
    """

    def __init__(self, works_dir: str):
        """
        Initialize import service.

        Args:
            works_dir: Directory containing work subdirectories
        """
        self.works_dir = works_dir
        self._ensure_directory()

    def _ensure_directory(self) -> None:
        """Ensure works directory exists."""
        if not os.path.exists(self.works_dir):
            os.makedirs(self.works_dir, exist_ok=True)

    def _get_work_dir(self, work_id: str) -> str:
        """
        Get directory path for a work.

        Args:
            work_id: Work identifier

        Returns:
            Full path to work directory
        """
        return os.path.join(self.works_dir, work_id)

    def _validate_zip_structure(self, zip_path: str) -> Tuple[bool, List[str]]:
        """
        Validate that a ZIP file has the expected work structure.

        Args:
            zip_path: Path to ZIP file

        Returns:
            Tuple of (is_valid, list of error messages)
        """
        errors = []

        try:
            with zipfile.ZipFile(zip_path, 'r') as zipf:
                namelist = zipf.namelist()

                # Check for work_info.json
                work_info_found = any("work_info.json" in name for name in namelist)
                if not work_info_found:
                    errors.append("Missing work_info.json in ZIP")

                # Check for steps directory
                steps_found = any("/steps/" in name or "\\steps\\" in name for name in namelist)
                if not steps_found:
                    errors.append("Missing steps directory in ZIP")

        except zipfile.BadZipFile:
            errors.append("Invalid ZIP file format")
        except Exception as e:
            errors.append(f"Error reading ZIP: {str(e)}")

        return len(errors) == 0, errors

    def _validate_directory_structure(self, dir_path: str) -> Tuple[bool, List[str]]:
        """
        Validate that a directory has the expected work structure.

        Args:
            dir_path: Path to work directory

        Returns:
            Tuple of (is_valid, list of error messages)
        """
        errors = []
        required_files = ["work_info.json"]
        required_dirs = ["steps"]

        for file in required_files:
            if not os.path.exists(os.path.join(dir_path, file)):
                errors.append(f"Missing required file: {file}")

        for dir_name in required_dirs:
            dir_path_full = os.path.join(dir_path, dir_name)
            if not os.path.exists(dir_path_full):
                errors.append(f"Missing required directory: {dir_name}")
            elif not os.path.isdir(dir_path_full):
                errors.append(f"{dir_name} is not a directory")

        return len(errors) == 0, errors

    def _check_work_exists(self, work_id: str) -> bool:
        """
        Check if a work already exists.

        Args:
            work_id: Work identifier

        Returns:
            True if work exists, False otherwise
        """
        work_dir = self._get_work_dir(work_id)
        return os.path.exists(work_dir)

    def _generate_new_work_id(self, original_id: str) -> str:
        """
        Generate a new unique work ID based on original.

        Args:
            original_id: Original work identifier

        Returns:
            New unique work identifier
        """
        base_id = original_id
        counter = 1

        while self._check_work_exists(f"{base_id}_import{counter}"):
            counter += 1

        return f"{base_id}_import{counter}"

    def import_from_zip(
        self,
        zip_path: str,
        conflict_resolution: str = ImportConflictResolution.RENAME
    ) -> Tuple[bool, str, Optional[str]]:
        """
        Import a work from a ZIP file.

        Args:
            zip_path: Path to ZIP file
            conflict_resolution: How to handle conflicts (overwrite, skip, rename)

        Returns:
            Tuple of (success, message, work_id if successful)
        """
        # Validate ZIP file exists
        if not os.path.exists(zip_path):
            return False, f"ZIP file not found: {zip_path}", None

        # Validate ZIP structure
        is_valid, errors = self._validate_zip_structure(zip_path)
        if not is_valid:
            return False, f"Invalid ZIP structure: {', '.join(errors)}", None

        try:
            with zipfile.ZipFile(zip_path, 'r') as zipf:
                # Extract work_id from work_info.json
                work_info_data = None
                work_id = None

                for name in zipf.namelist():
                    if name.endswith("work_info.json"):
                        with zipf.open(name) as f:
                            work_info_data = json.load(f)
                            work_id = work_info_data.get("id")
                        break

                if work_id is None:
                    return False, "Could not find work ID in ZIP file", None

                # Check for conflicts
                if self._check_work_exists(work_id):
                    if conflict_resolution == ImportConflictResolution.SKIP:
                        return False, f"Work {work_id} already exists, skipping", None
                    elif conflict_resolution == ImportConflictResolution.RENAME:
                        work_id = self._generate_new_work_id(work_id)
                    # OVERWRITE: proceed with existing ID

                # Create work directory
                work_dir = self._get_work_dir(work_id)
                os.makedirs(work_dir, exist_ok=True)

                # Extract all contents
                # Find the common prefix (work_id directory in ZIP)
                namelist = zipf.namelist()
                prefix = None
                for name in namelist:
                    if '/' in name:
                        candidate = name.split('/')[0]
                        if prefix is None or len(candidate) < len(prefix):
                            prefix = candidate
                        elif not name.startswith(prefix):
                            prefix = None
                        break

                if prefix is None:
                    prefix = namelist[0].split('/')[0] if namelist else ""

                # Extract files, removing the prefix
                for name in namelist:
                    if name.startswith(prefix + '/'):
                        relative_path = name[len(prefix) + 1:]
                        target_path = os.path.join(work_dir, relative_path)

                        # Create directories as needed
                        target_dir = os.path.dirname(target_path)
                        if target_dir and not os.path.exists(target_dir):
                            os.makedirs(target_dir, exist_ok=True)

                        # Extract file
                        if not name.endswith('/'):  # Skip directories
                            with zipf.open(name) as source:
                                with open(target_path, 'wb') as target:
                                    target.write(source.read())

                # Update work_info.json with new ID if renamed
                if work_info_data and work_info_data.get("id") != work_id:
                    work_info_data["id"] = work_id
                    work_info_path = os.path.join(work_dir, "work_info.json")
                    with open(work_info_path, 'w', encoding='utf-8') as f:
                        json.dump(work_info_data, f, ensure_ascii=False, indent=2)

                return True, f"Successfully imported work: {work_id}", work_id

        except zipfile.BadZipFile as e:
            return False, f"Invalid ZIP file: {str(e)}", None
        except json.JSONDecodeError as e:
            return False, f"Invalid JSON in work_info.json: {str(e)}", None
        except IOError as e:
            return False, f"IO error during import: {str(e)}", None
        except Exception as e:
            return False, f"Unexpected error during import: {str(e)}", None

    def import_from_directory(
        self,
        dir_path: str,
        conflict_resolution: str = ImportConflictResolution.RENAME
    ) -> Tuple[bool, str, Optional[str]]:
        """
        Import a work from a directory.

        Args:
            dir_path: Path to work directory
            conflict_resolution: How to handle conflicts (overwrite, skip, rename)

        Returns:
            Tuple of (success, message, work_id if successful)
        """
        # Validate directory exists
        if not os.path.exists(dir_path):
            return False, f"Directory not found: {dir_path}", None

        if not os.path.isdir(dir_path):
            return False, f"Path is not a directory: {dir_path}", None

        # Validate directory structure
        is_valid, errors = self._validate_directory_structure(dir_path)
        if not is_valid:
            return False, f"Invalid directory structure: {', '.join(errors)}", None

        try:
            # Read work_info.json to get work_id
            work_info_path = os.path.join(dir_path, "work_info.json")
            with open(work_info_path, 'r', encoding='utf-8') as f:
                work_info_data = json.load(f)
                work_id = work_info_data.get("id")

            if work_id is None:
                return False, "Could not find work ID in work_info.json", None

            # Check for conflicts
            if self._check_work_exists(work_id):
                if conflict_resolution == ImportConflictResolution.SKIP:
                    return False, f"Work {work_id} already exists, skipping", None
                elif conflict_resolution == ImportConflictResolution.RENAME:
                    work_id = self._generate_new_work_id(work_id)
                # OVERWRITE: proceed with existing ID

            # Create work directory
            work_dir = self._get_work_dir(work_id)

            # Copy directory tree
            if os.path.exists(work_dir) and conflict_resolution == ImportConflictResolution.OVERWRITE:
                shutil.rmtree(work_dir)

            shutil.copytree(dir_path, work_dir, dirs_exist_ok=True)

            # Update work_info.json with new ID if renamed
            if work_info_data.get("id") != work_id:
                work_info_data["id"] = work_id
                work_info_path = os.path.join(work_dir, "work_info.json")
                with open(work_info_path, 'w', encoding='utf-8') as f:
                    json.dump(work_info_data, f, ensure_ascii=False, indent=2)

            return True, f"Successfully imported work: {work_id}", work_id

        except json.JSONDecodeError as e:
            return False, f"Invalid JSON in work_info.json: {str(e)}", None
        except IOError as e:
            return False, f"IO error during import: {str(e)}", None
        except Exception as e:
            return False, f"Unexpected error during import: {str(e)}", None

    def get_conflict_info(self, work_id: str) -> Dict:
        """
        Get information about a work conflict.

        Args:
            work_id: Work identifier

        Returns:
            Dictionary with conflict information
        """
        if not self._check_work_exists(work_id):
            return {"exists": False, "work_id": work_id}

        work_dir = self._get_work_dir(work_id)
        work_info_path = os.path.join(work_dir, "work_info.json")

        existing_info = {}
        if os.path.exists(work_info_path):
            try:
                with open(work_info_path, 'r', encoding='utf-8') as f:
                    existing_info = json.load(f)
            except (json.JSONDecodeError, IOError):
                pass

        return {
            "exists": True,
            "work_id": work_id,
            "title": existing_info.get("title", "Unknown"),
            "category": existing_info.get("category", "Unknown"),
            "resolution_options": [
                ImportConflictResolution.OVERWRITE,
                ImportConflictResolution.SKIP,
                ImportConflictResolution.RENAME
            ]
        }
