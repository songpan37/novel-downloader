"""
Fanqie Publisher Service for AI Writer application.

Handles browser automation for publishing works to 番茄小说 platform.
"""
import os
import time
import threading
from typing import Optional, Dict, Any, Callable
from dataclasses import dataclass

from utils.logger import get_logger


class FanqieLoginError(Exception):
    """Exception raised when Fanqie login fails."""
    pass


class FanqiePublishError(Exception):
    """Exception raised when Fanqie publishing fails."""
    pass


@dataclass
class PublishProgress:
    """Progress information for publishing operation."""
    current_chapter: int
    total_chapters: int
    status: str  # "login", "navigating", "publishing", "completed", "error"
    message: str
    success: bool = False


class FanqiePublisher:
    """
    Browser-based publisher for 番茄小说 platform using Playwright.

    This class handles:
    - Login to Fanqie platform
    - Navigate to work management / chapter publishing
    - Publish chapters to fanqie platform
    """

    # Fanqie platform URLs (from fanqie.py reference)
    LOGIN_URL = "https://fanqienovel.com/main/writer/login"
    HOME_URL = "https://fanqienovel.com"

    DEFAULT_CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

    def __init__(
        self,
        phone_number: str,
        password: str,
        chrome_path: str = DEFAULT_CHROME_PATH,
        headless: bool = False,
        slow_mo: int = 100,
    ):
        """
        Initialize the Fanqie publisher.

        Args:
            phone_number: Phone number for login
            password: Password for login
            chrome_path: Path to Chrome executable
            headless: Run browser in headless mode
            slow_mo: Slow down interactions by specified milliseconds
        """
        self.phone_number = phone_number
        self.password = password
        self.chrome_path = chrome_path
        self.headless = headless
        self.slow_mo = slow_mo

        self.logger = get_logger()
        self.browser = None
        self.context = None
        self.page = None
        self.p = None

        # Login state
        self._is_logged_in = False

        # Book info (set before publishing)
        self._book_id: str = ""
        self._book_name: str = ""

        # Last error message (for retrieving detailed errors after method returns False)
        self._last_error: str = ""

    def get_last_error(self) -> str:
        """Get the last error message from a failed operation."""
        return self._last_error

    @classmethod
    def check_chrome_installed(cls, chrome_path: str = DEFAULT_CHROME_PATH) -> bool:
        """Check if Chrome is installed at the specified path."""
        return os.path.exists(chrome_path)

    def set_book_info(self, book_id: str, book_name: str) -> None:
        """
        Set book information for publishing.

        Args:
            book_id: Fanqie book ID
            book_name: Book name (for URL encoding)
        """
        self._book_id = book_id
        self._book_name = book_name

    def get_new_chapter_url(self) -> str:
        """Get the URL for publishing a new chapter."""
        return f"https://fanqienovel.com/main/writer/{self._book_id}/publish/?enter_from=newchapter"

    def get_edit_chapter_url(self, chapter_id: str) -> str:
        """Get the URL for editing an existing chapter."""
        return f"https://fanqienovel.com/main/writer/{self._book_id}/publish/{chapter_id}/?enter_from=modifychapter"

    def get_chapter_manage_url(self) -> str:
        """Get the chapter management URL for current book."""
        import urllib.parse
        encoded_name = urllib.parse.quote(self._book_name)
        return f"https://fanqienovel.com/main/writer/chapter-manage/{self._book_id}&{encoded_name}?type=1"

    def connect(self) -> bool:
        """
        Connect to browser and login to Fanqie platform.

        Returns:
            True if connection and login successful, False otherwise
        """
        if self.browser is not None and self.page is not None and not self.page.is_closed():
            self.logger.info("[fanqie] Already connected, reusing existing browser instance")
            return True

        try:
            from playwright.sync_api import sync_playwright

            self.logger.info(f"[fanqie] Starting browser connection...")
            self.logger.info(f"[fanqie] Chrome path: {self.chrome_path}")

            # Start Playwright
            self.p = sync_playwright().start()
            self.logger.info("[fanqie] Playwright started")

            # Launch browser
            self.browser = self.p.chromium.launch(
                headless=self.headless,
                slow_mo=self.slow_mo,
                args=['--start-maximized'],
                executable_path=self.chrome_path,
            )
            self.logger.info("[fanqie] Browser launched")

            # Create context
            self.context = self.browser.new_context()
            self.logger.info("[fanqie] Context created")

            # Create page and navigate to login
            self.page = self.context.new_page()
            self.logger.info(f"[fanqie] Navigating to {self.LOGIN_URL}...")
            self.page.goto(self.LOGIN_URL)
            self.page.wait_for_load_state("load")
            self.logger.info("[fanqie] Login page loaded")

            # Perform login
            return self._login()

        except Exception as e:
            self.logger.error(f"[fanqie] Browser connection failed: {e}")
            self._cleanup_partial_state()
            return False

    def create_new_page(self):
        """
        Create a new page in the existing browser context.

        Used by non-login tasks to create a fresh page while reusing
        the logged-in context/cookies.

        Returns:
            New Playwright Page object, or None if not connected
        """
        if not self.browser or not self.context:
            self.logger.error("[fanqie] Cannot create new page: browser not started")
            return None

        try:
            new_page = self.context.new_page()
            self.logger.info("[fanqie] Created new page")
            return new_page
        except Exception as e:
            self.logger.error(f"[fanqie] Failed to create new page: {e}")
            return None

    def _login(self) -> bool:
        """
        Login to Fanqie platform using phone and password.

        Returns:
            True if login successful, False otherwise
        """
        try:
            self.logger.info("[fanqie] Starting login process...")

            # Click "密码登录" button to switch to password login mode
            self.logger.info("[fanqie] Looking for password login button...")
            password_login_btn = self.page.locator(
                'button.arco-btn.arco-btn-text.arco-btn-size-default.arco-btn-shape-round.serial-arco-btn.slogin-form-button span:has-text("密码登录")'
            )
            password_login_btn.wait_for(state="visible", timeout=30000)
            password_login_btn.click()
            self.logger.info("[fanqie] Clicked password login button")
            time.sleep(1)  # Wait for form to appear

            # Wait for phone input field and fill
            self.logger.info("[fanqie] Waiting for phone input field...")
            phone_input = self.page.wait_for_selector(
                'input[placeholder="请输入手机号/邮箱"][name="username"]',
                timeout=30000
            )
            if self.phone_number:
                phone_input.fill(self.phone_number)
                self.logger.info(f"[fanqie] Phone number filled: {self.phone_number[:3]}****{self.phone_number[-4:]}")
            time.sleep(0.5)

            # Wait for password input field and fill
            self.logger.info("[fanqie] Waiting for password input field...")
            password_input = self.page.wait_for_selector(
                'input[placeholder="请输入密码"][type="password"]',
                timeout=30000
            )
            password_input.fill(self.password)
            self.logger.info("[fanqie] Password filled")
            time.sleep(0.5)

            # Click the protocol checkbox
            self.logger.info("[fanqie] Looking for protocol checkbox...")
            checkbox = self.page.locator("div.slogin-form-protocol__checkbox")
            checkbox.click()
            self.logger.info("[fanqie] Clicked protocol checkbox")
            time.sleep(0.5)

            # Find and click login button
            self.logger.info("[fanqie] Looking for login button...")
            login_btn = self.page.locator(
                'button.arco-btn.arco-btn-primary.arco-btn-size-large.arco-btn-shape-round.serial-arco-btn.slogin-form-button span:has-text("登录")'
            )
            login_btn.wait_for(state="visible", timeout=10000)

            # Wait for button to be enabled
            self.logger.info("[fanqie] Waiting for login button to be enabled...")
            for attempt in range(10):
                is_disabled = login_btn.get_attribute("disabled")
                if is_disabled is None:
                    self.logger.info(f"[fanqie] Login button is now enabled")
                    break
                self.logger.info(f"[fanqie] Login button disabled (attempt {attempt + 1}), re-clicking checkbox...")
                checkbox.click()
                time.sleep(0.5)

            self.logger.info("[fanqie] Clicking login button...")
            login_btn.click()
            self.logger.info("[fanqie] Login button clicked, waiting for navigation...")

            # Wait for URL to change (handles SPA navigation)
            try:
                self.page.wait_for_url(lambda url: "login" not in url.lower(), timeout=60000)
                self.logger.info(f"[fanqie] Navigation detected to: {self.page.url}")
                self._is_logged_in = True
                return True
            except Exception as e:
                self.logger.info(f"[fanqie] wait_for_url timeout: {e}")

            # Fallback: poll for redirect (handles CAPTCHA, slow responses, etc.)
            self.logger.info("[fanqie] Falling back to polling for redirect...")
            max_wait = 60
            poll_interval = 1
            elapsed = 0

            while elapsed < max_wait:
                time.sleep(poll_interval)
                elapsed += poll_interval

                current_url = self.page.url
                self.logger.info(f"[fanqie] Poll check URL: {current_url}")

                # Check if redirected away from login page
                if "login" not in current_url.lower():
                    self.logger.info(f"[fanqie] URL no longer contains 'login', login success!")
                    self._is_logged_in = True
                    return True

                # Check if login success indicators present
                if self._check_login_success():
                    self.logger.info("[fanqie] Login successful via _check_login_success!")
                    self._is_logged_in = True
                    return True

                self.logger.info(f"[fanqie] Still on login page, waiting... ({elapsed}s)")

            # Timeout reached
            self.logger.warning("[fanqie] Login timeout, assuming success")
            self._is_logged_in = True
            return True

        except Exception as e:
            self.logger.error(f"[fanqie] Login failed: {e}")
            return False

    def _check_page_valid(self) -> bool:
        """
        Check if the page is still valid and accessible.

        Returns:
            True if page is valid, False otherwise
        """
        try:
            if self.page is None:
                return False
            if self.page.is_closed():
                self.logger.warning("[fanqie] Page is closed")
                return False
            # Try to get URL to verify page is still responsive
            _ = self.page.url
            return True
        except Exception as e:
            self.logger.warning(f"[fanqie] Page validation failed: {e}")
            return False

    def _check_login_success(self) -> bool:
        """
        Check if login is successful.

        Returns:
            True if login successful, False otherwise
        """
        try:
            # Check if redirected away from login page
            current_url = self.page.url
            if "login" in current_url.lower():
                return False

            # Check for writer dashboard elements
            # Look for "作品管理" text which appears after login
            user_indicator = self.page.locator('text=作品管理').first
            if user_indicator.count() > 0:
                return True

            return True  # If no login page, assume success

        except Exception as e:
            self.logger.debug(f"[fanqie] Login success check failed: {e}")
            return False

    def _check_login_error(self) -> bool:
        """
        Check if there are any error messages on login page.

        Returns:
            True if error message found, False otherwise
        """
        try:
            # Check for common login error messages
            error_selectors = [
                'text=手机号或密码错误',
                'text=账号或密码错误',
                'text=登录失败',
                'text=请输入正确的手机号',
            ]

            for selector in error_selectors:
                error_elem = self.page.locator(selector).first
                if error_elem.count() > 0:
                    self.logger.warning(f"[fanqie] Error detected: {selector}")
                    return True

            return False

        except Exception as e:
            self.logger.debug(f"[fanqie] Error check failed: {e}")
            return False

    def navigate_to_book_manage(self) -> bool:
        """
        Navigate to book management page.

        Returns:
            True if navigation successful, False otherwise
        """
        if not self._check_page_valid():
            self.logger.error("[fanqie] Page is invalid, cannot navigate")
            return False

        if not self._book_id:
            self.logger.error("[fanqie] Book ID not set, call set_book_info first")
            return False

        try:
            manage_url = self.get_chapter_manage_url()
            self.logger.info(f"[fanqie] Navigating to chapter manage page: {manage_url}")
            self.page.goto(manage_url)
            self.page.wait_for_load_state("networkidle", timeout=30000)
            time.sleep(2)
            self.logger.info("[fanqie] Chapter manage page loaded")
            return True

        except Exception as e:
            self.logger.error(f"[fanqie] Navigation to book management failed: {e}")
            return False

    def ensure_logged_in(self) -> bool:
        """
        Ensure user is logged in, reconnect if necessary.

        Returns:
            True if logged in, False otherwise
        """
        if self._is_logged_in and self._check_page_valid():
            # Check if still on login page
            try:
                if "login" not in self.page.url.lower():
                    return True
            except Exception:
                pass

        # Need to reconnect
        self.logger.info("[fanqie] Session expired or not logged in, reconnecting...")
        self._cleanup_partial_state()
        return self.connect()

    def _wait_for_input_value(self, locator, expected_value: str, max_retries: int = 10, timeout: int = 1000) -> bool:
        """
        Wait for input value to match expected value with retries.

        Args:
            locator: Playwright locator
            expected_value: Expected value
            max_retries: Maximum retry attempts
            timeout: Timeout per retry in ms

        Returns:
            True if value matches, False otherwise
        """
        for _ in range(max_retries):
            try:
                current_value = locator.input_value()
                if current_value == expected_value:
                    return True
                locator.fill(expected_value)
            except Exception:
                pass
            time.sleep(1)
        return False

    def publish_chapter(
        self,
        chapter_number: int,
        chapter_title: str,
        chapter_content: str,
        chapter_id: str = None,
        scheduled_time: 'datetime' = None,
        progress_callback: Optional[Callable[[PublishProgress], None]] = None
    ) -> bool:
        """
        Publish a new chapter or update existing chapter on Fanqie platform.

        Args:
            chapter_number: Chapter number (just the number, e.g., 1 for "第1章")
            chapter_title: Title of the chapter
            chapter_content: Content of the chapter (plain text, will be wrapped in <p> tags)
            chapter_id: If provided, update existing chapter; otherwise, publish new chapter
            scheduled_time: Optional datetime for scheduled publishing. If None, publish immediately.
            progress_callback: Optional callback for progress updates

        Returns:
            True if publishing successful, False otherwise
        """
        if not self.ensure_logged_in():
            if progress_callback:
                progress_callback(PublishProgress(
                    current_chapter=0,
                    total_chapters=1,
                    status="error",
                    message="登录失败"
                ))
            return False

        if not self._check_page_valid():
            self.logger.error("[fanqie] Page is invalid before publishing")
            return False

        try:
            # Navigate to correct page based on new or update
            if chapter_id:
                # Update existing chapter
                edit_url = self.get_edit_chapter_url(chapter_id)
                self.logger.info(f"[fanqie] Navigating to edit chapter page: {edit_url}")
                self.page.goto(edit_url, timeout=60000)
            else:
                # Publish new chapter
                new_chapter_url = self.get_new_chapter_url()
                self.logger.info(f"[fanqie] Navigating to new chapter page: {new_chapter_url}")
                self.page.goto(new_chapter_url, timeout=60000)

            # Wait for chapter number input to be visible (more reliable than networkidle for SPAs)
            self.logger.info("[fanqie] Waiting for editor to load...")
            number_input = self.page.locator(
                'div.serial-editor-title-left span.left-input input[type="text"]'
            )
            number_input.wait_for(state="visible", timeout=30000)
            time.sleep(1)
            self.logger.info("[fanqie] Editor loaded")

            if progress_callback:
                progress_callback(PublishProgress(
                    current_chapter=1,
                    total_chapters=1,
                    status="publishing",
                    message=f"正在发布第 {chapter_number} 章: {chapter_title}"
                ))

            # Fill chapter number (first!) - input already waited above
            self.logger.info("[fanqie] Filling chapter number...")
            self._wait_for_input_value(number_input, str(chapter_number))
            self.logger.info(f"[fanqie] Chapter number filled: {chapter_number}")

            # Fill chapter title
            self.logger.info("[fanqie] Looking for chapter title input...")
            title_input = self.page.locator(
                'div.serial-editor-title-right div.serial-editor-input-hint.input input[placeholder="请输入标题"]'
            )
            title_input.wait_for(state="visible", timeout=10000)
            self._wait_for_input_value(title_input, chapter_title)
            self.logger.info(f"[fanqie] Chapter title filled: {chapter_title}")

            # Fill chapter content (ProseMirror editor) with <p> wrapped paragraphs
            self.logger.info("[fanqie] Looking for content editor...")
            content_input = self.page.locator(
                'div.ProseMirror[contenteditable="true"][spellcheck="false"][translate="no"]'
            )
            content_input.wait_for(state="visible", timeout=10000)

            # Convert plain text to HTML with <p> tags, filtering empty paragraphs
            # Handle multiple line break formats: \r\n\r\n, \n\n, or single \r\n or \n
            # Normalize: replace \r\n with \n first
            normalized = chapter_content.replace('\r\n', '\n')
            # Split by double newline first, then by single newline if no double newlines found
            paragraphs = normalized.split('\n\n')
            if len(paragraphs) == 1 and '\n' in normalized:
                # No double newlines found, treat single lines as paragraphs
                paragraphs = [p for p in normalized.split('\n') if p.strip()]
            html_parts = []
            for p in paragraphs:
                p = p.strip()
                if p:
                    html_parts.append(f'<p>{p}</p>')
            html_content = ''.join(html_parts)

            # Fill content with HTML
            max_fill_attempts = 3
            for attempt in range(max_fill_attempts):
                # Use JavaScript to clear and set innerHTML properly
                content_input.evaluate("el => { el.innerHTML = ''; }")
                content_input.evaluate(f"el => el.innerHTML = `{html_content}`")
                # Remove any empty <p> tags that might have been created
                content_input.evaluate("""
                    el => {
                        const emptyPs = el.querySelectorAll('p');
                        emptyPs.forEach(p => {
                            if (!p.textContent.trim() && p.querySelectorAll('br, img').length === 0) {
                                p.remove();
                            }
                        });
                    }
                """)
                current_len = len(content_input.text_content() or "")
                if current_len >= len(chapter_content.replace("\n", "")) - 10:
                    break
                self.logger.warning(f"[fanqie] Content fill attempt {attempt + 1} failed, retrying...")
                time.sleep(1)

            self.logger.info(f"[fanqie] Chapter content filled ({len(chapter_content)} chars)")

            # Both new chapter and update: directly click "下一步"
            self.logger.info("[fanqie] Looking for next step button...")
            next_step_btn = self.page.locator(
                'div.publish-header-right button.arco-btn span:has-text("下一步")'
            )
            next_step_btn.wait_for(state="visible", timeout=10000)
            next_step_btn.click()
            self.logger.info("[fanqie] Clicked next step button")

            # Wait for modals to appear and handle them in a loop
            # Loop until "发布设置" modal appears
            self.logger.info("[fanqie] Waiting for publish settings modal...")
            max_wait = 30  # Max 30 seconds waiting for modals
            elapsed = 0
            publish_settings_found = False

            while elapsed < max_wait:
                time.sleep(0.5)

                # Check if publish settings modal appeared (title contains "发布设置")
                publish_modal = self.page.locator(
                    'div.arco-modal[role="dialog"] div.arco-modal-title:has-text("发布设置")'
                )
                if publish_modal.count() > 0 and publish_modal.first.is_visible():
                    self.logger.info("[fanqie] Publish settings modal appeared")
                    publish_settings_found = True
                    break

                # Check and handle 30min before publish warning (uses byte-modal)
                self._handle_30min_before_publish_warning()

                # Check and handle typo warning modal
                typo_modal = self.page.locator(
                    'div.arco-modal:has-text("检测到你还有错别字未修改")'
                )
                if typo_modal.count() > 0 and typo_modal.first.is_visible():
                    self.logger.info("[fanqie] Found typo warning modal, clicking submit")
                    typo_modal.locator('button span:has-text("提交")').click()
                    time.sleep(0.5)
                    continue

                # Check and handle author note warning modal
                author_modal = self.page.locator(
                    'div.arco-modal:has-text("非章节内容请使用")'
                )
                if author_modal.count() > 0 and author_modal.first.is_visible():
                    self.logger.info("[fanqie] Found author note warning modal, clicking submit")
                    author_modal.locator('button span:has-text("提交")').click()
                    time.sleep(0.5)
                    continue

                # Check and handle content risk detection modal
                risk_modal = self.page.locator(
                    'div.arco-modal:has-text("是否进行内容风险检测")'
                )
                if risk_modal.count() > 0 and risk_modal.first.is_visible():
                    self.logger.info("[fanqie] Found content risk detection modal, clicking confirm")
                    risk_modal.locator('button span:has-text("确定")').click()
                    time.sleep(0.5)
                    continue

                elapsed += 0.5

            if not publish_settings_found:
                raise FanqiePublishError("等待发布设置弹窗超时")

            # Select "否" for AI usage - click the label containing "否"
            self.logger.info("[fanqie] Looking for AI usage option...")
            use_ai_radio = self.page.locator(
                'div.publish-confirm-card:has-text("是否使用AI") label.arco-radio:has-text("否")'
            )
            if use_ai_radio.count() > 0:
                use_ai_radio.click()
                self.logger.info("[fanqie] Selected AI usage: 否")

            # Handle scheduled publishing if configured
            if scheduled_time:
                self.logger.info(f"[fanqie] Setting scheduled publishing for {scheduled_time}")

                # Click the scheduled publishing switch to enable it
                switch_btn = self.page.locator(
                    'div.card-content-line:has-text("定时发布") button[role="switch"]'
                )
                self.logger.info(f"[fanqie] Switch button count: {switch_btn.count()}")
                if switch_btn.count() > 0:
                    switch_btn.click()
                    self.logger.info("[fanqie] Enabled scheduled publishing switch")
                    # Wait for the date/time inputs to appear after enabling switch
                    time.sleep(2)

                # Set date and time using the correct picker interaction pattern from fanqie.py
                # The custom picker requires: click input -> fill -> click confirm -> click card
                # Loop until both values match
                date_str = scheduled_time.strftime('%Y-%m-%d')
                time_str = scheduled_time.strftime('%H:%M')

                self.logger.info(f"[fanqie] Target date: {date_str}, time: {time_str}")

                # Selectors from fanqie.py reference
                card = self.page.locator('div.publish-confirm-card div.card-content-line-label:has-text("日期")')
                publish_day_input = self.page.locator('div.publish-confirm-card div.card-content-line-control div.arco-picker-input input.arco-picker-start-time[placeholder="请选择日期"]')
                publish_time_input = self.page.locator('div.publish-confirm-card div.card-content-line-control div.arco-picker-input input.arco-picker-start-time[placeholder="请选择时间"]')
                publish_time_confirm_btn = self.page.locator('div.arco-modal[role="dialog"] div.arco-modal-content span.arco-trigger div.arco-timepicker-container button.arco-btn span:has-text("确定")')
                select_date_btn = self.page.locator('span.arco-trigger[trigger-placement="top"] div.arco-picker-container div.arco-panel-date div.arco-picker-row div.arco-picker-cell.arco-picker-cell-in-view.arco-picker-cell-selected')

                max_loop_attempts = 10
                loop_count = 0
                while publish_day_input.input_value() != date_str or publish_time_input.input_value() != time_str:
                    loop_count += 1
                    if loop_count > max_loop_attempts:
                        self.logger.error(f"[fanqie] Max loop attempts reached, current: date={publish_day_input.input_value()}, time={publish_time_input.value() if hasattr(publish_time_input, 'value') else publish_time_input.input_value()}")
                        raise FanqiePublishError(f"定时发布设置失败: 达到最大重试次数")

                    self.logger.info(f"[fanqie] Setting date/time (attempt {loop_count})...")

                    # Set date
                    publish_day_input.focus()
                    publish_day_input.click()
                    publish_day_input.fill(date_str)
                    try:
                        select_date_btn.click(timeout=1000)
                    except Exception as ex:
                        self.logger.info(f"[fanqie] select_date_btn click failed: {ex}")
                        time.sleep(1)
                        continue

                    card.click()
                    self.logger.info(f"[fanqie] Set publish_day_input to: {date_str}")

                    # Set time
                    publish_time_input.focus()
                    publish_time_input.click()
                    publish_time_input.fill(time_str)
                    self.logger.info(f"[fanqie] Set publish_time_input to: {time_str}")

                    try:
                        publish_time_confirm_btn.click(timeout=1000)
                    except Exception as ex:
                        self.logger.info(f"[fanqie] publish_time_confirm_btn click failed: {ex}")
                    card.click()
                    time.sleep(1)

                    current_date = publish_day_input.input_value()
                    current_time = publish_time_input.input_value()
                    self.logger.info(f"[fanqie] Current values after attempt {loop_count}: date={current_date}, time={current_time}")

                self.logger.info(f"[fanqie] Verified scheduled publishing: date={date_str}, time={time_str}")
            else:
                self.logger.info("[fanqie] Publishing immediately (no scheduled time)")

            # Click "确认发布" button with response capture and retry
            self.logger.info("[fanqie] Looking for confirm publish button...")
            confirm_btn = self.page.locator(
                'div.arco-modal[role="dialog"]:has-text("发布设置") button span:has-text("确认发布")'
            )
            confirm_btn.wait_for(state="visible", timeout=10000)

            # Use expect_response to capture API response
            # API endpoint: POST https://fanqienovel.com/api/author/publish_article/v0/
            max_retries = 3
            item_id = None

            for attempt in range(max_retries):
                try:
                    with self.page.expect_response("**/api/author/publish_article/**", timeout=30000) as resp_info:
                        confirm_btn.click()
                        self.logger.info(f"[fanqie] Clicked confirm publish button (attempt {attempt + 1})")

                    resp = resp_info.value
                    self.logger.info(f"[fanqie] API response status: {resp.status}")

                    data = resp.json()
                    self.logger.info(f"[fanqie] API response: {data}")

                    if data.get("code") == 0:
                        item_id = data.get("data", {}).get("item_id")
                        self.logger.info(f"[fanqie] Publish successful, item_id: {item_id}")
                        break
                    else:
                        error_msg = data.get("message", "Unknown error")
                        self.logger.warning(f"[fanqie] Publish failed (attempt {attempt + 1}): {error_msg}")
                        if attempt == max_retries - 1:
                            raise FanqiePublishError(f"发布失败: {error_msg}")
                        time.sleep(2)
                        # Re-find the button for retry
                        confirm_btn = self.page.locator(
                            'div.arco-modal[role="dialog"]:has-text("发布设置") button span:has-text("确认发布")'
                        )
                        confirm_btn.wait_for(state="visible", timeout=5000)
                except Exception as e:
                    self.logger.warning(f"[fanqie] Publish attempt {attempt + 1} failed: {e}")
                    if attempt == max_retries - 1:
                        raise
                    time.sleep(2)
                    # Re-find the button for retry
                    confirm_btn = self.page.locator(
                        'div.arco-modal[role="dialog"]:has-text("发布设置") button span:has-text("确认发布")'
                    )
                    confirm_btn.wait_for(state="visible", timeout=5000)

            if progress_callback:
                progress_callback(PublishProgress(
                    current_chapter=1,
                    total_chapters=1,
                    status="completed",
                    message="发布成功",
                    success=True
                ))

            return item_id if item_id else True

        except Exception as e:
            self.logger.error(f"[fanqie] Publish chapter failed: {e}")
            if progress_callback:
                progress_callback(PublishProgress(
                    current_chapter=1,
                    total_chapters=1,
                    status="error",
                    message=f"发布失败: {str(e)}"
                ))
            return False

    def _handle_typo_warning(self) -> None:
        """Handle typo warning modal if present."""
        try:
            typo_submit_btn = self.page.locator(
                'div.arco-modal-wrapper div.arco-modal[role="dialog"] button.arco-btn span:has-text("提交")'
            )
            if typo_submit_btn.count() > 0 and typo_submit_btn.first.is_visible():
                typo_submit_btn.first.click()
                self.logger.info("[fanqie] Handled typo warning")
        except Exception as e:
            self.logger.error(f"[fanqie] Failed to handle typo warning: {e}")

    def _handle_author_note_warning(self) -> None:
        """Handle 'author note' warning modal if present."""
        try:
            author_note_warning = self.page.query_selector_all(
                'div.arco-modal-content:has-text("非章节内容请使用"作者有话说"功能")'
            )
            if len(author_note_warning) > 0:
                submit_btn = self.page.locator(
                    'div.arco-modal-wrapper div.arco-modal[role="dialog"] button.arco-btn span:has-text("提交")'
                )
                submit_btn.click()
                self.logger.info("[fanqie] Handled author note warning")
        except Exception as e:
            self.logger.error(f"[fanqie] Failed to handle author note warning: {e}")

    def _handle_30min_before_publish_warning(self) -> None:
        """Handle '请在发布时间前30分钟提交修改内容' modal if present."""
        try:
            modal = self.page.locator(
                'div.byte-modal:has-text("请在发布时间前30分钟提交修改内容")'
            )
            if modal.count() > 0 and modal.first.is_visible():
                ok_btn = modal.locator('button span:has-text("我知道了")')
                if ok_btn.count() > 0:
                    ok_btn.click()
                    self.logger.info("[fanqie] Handled 30min before publish warning")
        except Exception as e:
            self.logger.error(f"[fanqie] Failed to handle 30min before publish warning: {e}")

    def close(self) -> None:
        """Close browser and context. Silently ignores errors."""
        try:
            if self.context:
                self.context.close()
        except Exception:
            pass
        self.context = None

        try:
            if self.browser:
                self.browser.close()
        except Exception:
            pass
        self.browser = None

        try:
            if self.p:
                self.p.stop()
        except Exception:
            pass
        self.p = None

        self._is_logged_in = False

    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()

    def _cleanup_partial_state(self) -> None:
        """Clean up any partial browser state after a failed connection."""
        try:
            if self.context:
                try:
                    self.context.close()
                except:
                    pass
                self.context = None
            if self.browser:
                try:
                    self.browser.close()
                except:
                    pass
                self.browser = None
            if hasattr(self, 'p') and self.p:
                try:
                    self.p.stop()
                except:
                    pass
                self.p = None
            if self.page:
                try:
                    self.page.close()
                except:
                    pass
                self.page = None
        except Exception:
            pass  # Best effort cleanup

    def update_chapter(
        self,
        chapter_number: int,
        chapter_title: str,
        chapter_content: str,
        chapter_id: str = None,
        progress_callback: Optional[Callable[[PublishProgress], None]] = None
    ) -> bool:
        """
        更新番茄平台已发布的章节。

        Args:
            chapter_number: 章节号
            chapter_title: 章节标题
            chapter_content: 章节正文
            chapter_id: 番茄平台章节ID（用于URL）
            progress_callback: 进度回调

        Returns:
            True if update successful, False otherwise
        """
        if not self.ensure_logged_in():
            if progress_callback:
                progress_callback(PublishProgress(
                    current_chapter=0,
                    total_chapters=1,
                    status="error",
                    message="登录失败"
                ))
            return False

        if not self._check_page_valid():
            self.logger.error("[fanqie] Page is invalid before updating chapter")
            self._last_error = "页面无效，请重新登录"
            return False

        try:
            # 构造编辑页面URL
            if chapter_id:
                edit_url = f"https://fanqienovel.com/main/writer/{self._book_id}/publish/{chapter_id}/?enter_from=modifychapter"
            else:
                # 如果没有chapter_id，无法编辑已有章节
                self.logger.error("[fanqie] chapter_id is required for updating")
                self._last_error = "缺少章节ID，无法更新"
                return False

            self.logger.info(f"[fanqie] Navigating to chapter edit: {edit_url}")
            self.page.goto(edit_url, timeout=60000)

            if progress_callback:
                progress_callback(PublishProgress(
                    current_chapter=chapter_number,
                    total_chapters=1,
                    status="publishing",
                    message=f"正在更新第 {chapter_number} 章..."
                ))

            # Wait for title input to be visible (more reliable than networkidle for SPAs)
            self.logger.info("[fanqie] Waiting for editor to load...")
            title_input = self.page.locator(
                'div.serial-editor-title-right div.serial-editor-input-hint.input input[placeholder="请输入标题"]'
            )
            title_input.wait_for(state="visible", timeout=30000)
            time.sleep(1)
            self.logger.info("[fanqie] Editor loaded")

            # 填写章节标题
            self.logger.info("[fanqie] Filling chapter title...")
            self._wait_for_input_value(title_input, chapter_title)
            self.logger.info(f"[fanqie] Chapter title filled: {chapter_title}")

            # 填写章节正文
            self.logger.info("[fanqie] Filling chapter content...")
            content_input = self.page.locator(
                'div.ProseMirror[contenteditable="true"][spellcheck="false"][translate="no"]'
            )
            content_input.wait_for(state="visible", timeout=10000)

            # Convert plain text to HTML with <p> tags, filtering empty paragraphs
            # Handle multiple line break formats: \r\n\r\n, \n\n, or single \r\n or \n
            # Normalize: replace \r\n with \n first
            normalized = chapter_content.replace('\r\n', '\n')
            # Split by double newline first, then by single newline if no double newlines found
            paragraphs = normalized.split('\n\n')
            if len(paragraphs) == 1 and '\n' in normalized:
                # No double newlines found, treat single lines as paragraphs
                paragraphs = [p for p in normalized.split('\n') if p.strip()]
            html_parts = []
            for p in paragraphs:
                p = p.strip()
                if p:
                    html_parts.append(f'<p>{p}</p>')
            html_content = ''.join(html_parts)

            max_fill_attempts = 3
            for attempt in range(max_fill_attempts):
                # Use JavaScript to clear and set innerHTML properly
                content_input.evaluate("el => { el.innerHTML = ''; }")
                content_input.evaluate(f"el => el.innerHTML = `{html_content}`")
                # Remove any empty <p> tags that might have been created
                content_input.evaluate("""
                    el => {
                        const emptyPs = el.querySelectorAll('p');
                        emptyPs.forEach(p => {
                            if (!p.textContent.trim() && p.querySelectorAll('br, img').length === 0) {
                                p.remove();
                            }
                        });
                    }
                """)
                current_len = len(content_input.text_content() or "")
                if current_len >= len(chapter_content.replace("\n", "")) - 10:
                    break
                self.logger.warning(f"[fanqie] Content fill attempt {attempt + 1} failed, retrying...")
                time.sleep(1)

            self.logger.info(f"[fanqie] Chapter content filled ({len(chapter_content)} chars)")

            # 点击下一步
            self.logger.info("[fanqie] Clicking next step button...")
            next_step_btn = self.page.locator(
                'div.publish-header-right button.arco-btn span:has-text("下一步")'
            )
            next_step_btn.wait_for(state="visible", timeout=10000)
            next_step_btn.click()
            self.logger.info("[fanqie] Clicked next step button")

            # Wait for modals and handle them in a loop
            self.logger.info("[fanqie] Waiting for modals...")
            max_wait = 30
            elapsed = 0
            publish_settings_found = False

            while elapsed < max_wait:
                time.sleep(0.5)

                # Check if publish settings modal appeared
                publish_modal = self.page.locator(
                    'div.arco-modal[role="dialog"] div.arco-modal-title:has-text("发布设置")'
                )
                if publish_modal.count() > 0 and publish_modal.first.is_visible():
                    self.logger.info("[fanqie] Publish settings modal appeared")
                    publish_settings_found = True
                    break

                # Check and handle 30min before publish warning (uses byte-modal)
                self._handle_30min_before_publish_warning()

                # Check and handle typo warning modal
                typo_modal = self.page.locator(
                    'div.arco-modal:has-text("检测到你还有错别字未修改")'
                )
                if typo_modal.count() > 0 and typo_modal.first.is_visible():
                    self.logger.info("[fanqie] Found typo warning modal, clicking submit")
                    typo_modal.locator('button span:has-text("提交")').click()
                    time.sleep(0.5)
                    continue

                # Check and handle author note warning modal
                author_modal = self.page.locator(
                    'div.arco-modal:has-text("非章节内容请使用")'
                )
                if author_modal.count() > 0 and author_modal.first.is_visible():
                    self.logger.info("[fanqie] Found author note warning modal, clicking submit")
                    author_modal.locator('button span:has-text("提交")').click()
                    time.sleep(0.5)
                    continue

                # Check and handle content risk detection modal
                risk_modal = self.page.locator(
                    'div.arco-modal:has-text("是否进行内容风险检测")'
                )
                if risk_modal.count() > 0 and risk_modal.first.is_visible():
                    self.logger.info("[fanqie] Found risk detection modal, clicking submit")
                    risk_modal.locator('button span:has-text("提交")').click()
                    time.sleep(0.5)
                    continue

                elapsed += 0.5

            if not publish_settings_found:
                raise FanqiePublishError("等待发布设置弹窗超时")

            # 选择是否使用AI - 选择"否"
            self.logger.info("[fanqie] Selecting AI usage option...")
            use_ai_btn = self.page.locator(
                'div.publish-confirm-card div.card-content-line-control div.arco-radio-group[role="radiogroup"] span.arco-radio-text:has-text("否")'
            )
            if use_ai_btn.count() > 0:
                use_ai_btn.click()
                self.logger.info("[fanqie] Disabled AI usage")

            # Click confirm update button with response capture and retry
            self.logger.info("[fanqie] Looking for confirm update button...")
            confirm_btn = self.page.locator(
                'div.arco-modal[role="dialog"] div.arco-modal-footer button.arco-btn span:has-text("确认发布")'
            )
            confirm_btn.wait_for(state="visible", timeout=10000)

            # Use expect_response to capture API response
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    with self.page.expect_response("**/api/author/publish_article/**", timeout=30000) as resp_info:
                        confirm_btn.click()
                        self.logger.info(f"[fanqie] Clicked confirm update button (attempt {attempt + 1})")

                    resp = resp_info.value
                    data = resp.json()
                    self.logger.info(f"[fanqie] Update API response: {data}")

                    if data.get("code") == 0:
                        self.logger.info("[fanqie] Update successful")
                        break
                    else:
                        error_msg = data.get("message", "Unknown error")
                        self.logger.warning(f"[fanqie] Update failed (attempt {attempt + 1}): {error_msg}")
                        if attempt == max_retries - 1:
                            raise FanqiePublishError(f"更新失败: {error_msg}")
                        time.sleep(2)
                        # Re-find the button for retry
                        confirm_btn = self.page.locator(
                            'div.arco-modal[role="dialog"] div.arco-modal-footer button.arco-btn span:has-text("确认发布")'
                        )
                        confirm_btn.wait_for(state="visible", timeout=5000)
                except Exception as e:
                    self.logger.warning(f"[fanqie] Update attempt {attempt + 1} failed: {e}")
                    if attempt == max_retries - 1:
                        raise
                    time.sleep(2)
                    # Re-find the button for retry
                    confirm_btn = self.page.locator(
                        'div.arco-modal[role="dialog"] div.arco-modal-footer button.arco-btn span:has-text("确认发布")'
                    )
                    confirm_btn.wait_for(state="visible", timeout=5000)

            if progress_callback:
                progress_callback(PublishProgress(
                    current_chapter=chapter_number,
                    total_chapters=1,
                    status="completed",
                    message="更新成功",
                    success=True
                ))

            return True

        except Exception as e:
            error_msg = str(e)
            self.logger.error(f"[fanqie] Update chapter failed: {error_msg}")
            self._last_error = error_msg
            if progress_callback:
                progress_callback(PublishProgress(
                    current_chapter=chapter_number,
                    total_chapters=1,
                    status="error",
                    message=f"更新失败: {error_msg}"
                ))
            return False
