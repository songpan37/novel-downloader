"""
Fanqie Book Service for AI Writer application.

Handles browser automation for book management on 番茄小说 platform.
"""
import os
import time
import asyncio
import urllib.parse
from typing import Optional, Dict, Any, Callable

from utils.logger import get_logger


class FanqieBookError(Exception):
    """Exception raised for Fanqie book operations."""
    pass


class FanqieBookService:
    """
    Service for managing books on 番茄小说 platform using Playwright.

    This class handles:
    - Login to Fanqie platform
    - Create new book with metadata
    - Navigate to book management
    """

    # Fanqie platform URLs
    LOGIN_URL = "https://fanqienovel.com/main/writer/login"
    CREATE_BOOK_URL = "https://fanqienovel.com/main/writer/create?enter_from=home"

    DEFAULT_CHROME_PATH = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

    def __init__(
        self,
        phone_number: str,
        password: str,
        chrome_path: str = DEFAULT_CHROME_PATH,
        headless: bool = False,
        slow_mo: int = 100,
    ):
        """
        Initialize the Fanqie book service.

        Args:
            phone_number: Phone number for login
            password: Password for login
            chrome_path: Path to Chrome executable
            headless: Run browser in headless mode
            slow_mo: Slow down interactions by specified milliseconds
        """
        self.phone_number = phone_number
        self.password = password
        self.chrome_path = chrome_path
        self.headless = headless
        self.slow_mo = slow_mo

        self.logger = get_logger()
        self.browser = None
        self.context = None
        self.page = None
        self.p = None
        self._is_logged_in = False

    @classmethod
    def check_chrome_installed(cls, chrome_path: str = DEFAULT_CHROME_PATH) -> bool:
        """Check if Chrome is installed."""
        return os.path.exists(chrome_path)

    def set_page(self, page, context=None, is_logged_in=True):
        """
        Set an existing browser page for this service to use.

        This allows FanqieBookService to operate on an existing browser
        instead of creating its own.

        Args:
            page: Playwright Page object
            context: Playwright BrowserContext (optional)
            is_logged_in: Whether the page is already logged in
        """
        self.page = page
        self.context = context
        self.browser = None
        self.p = None
        self._is_logged_in = is_logged_in
        self.logger.info("[fanqie_book] Using existing browser page")

    def connect(self) -> bool:
        """
        Connect to browser and login to Fanqie.

        Returns:
            True if connection and login successful
        """
        if self.browser is not None and self.page is not None and not self.page.is_closed():
            self.logger.info("[fanqie_book] Already connected")
            return True

        try:
            import asyncio
            from playwright.sync_api import sync_playwright

            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.close()
            except Exception:
                pass

            self.logger.info("[fanqie_book] Starting browser...")
            self.p = sync_playwright().start()

            self.browser = self.p.chromium.launch(
                headless=self.headless,
                slow_mo=self.slow_mo,
                args=['--start-maximized'],
                executable_path=self.chrome_path,
            )

            self.context = self.browser.new_context()
            self.page = self.context.new_page()

            self.logger.info("[fanqie_book] Navigating to login...")
            self.page.goto(self.LOGIN_URL)
            self.page.wait_for_load_state("load")

            return self._login()

        except Exception as e:
            self.logger.error(f"[fanqie_book] Connection failed: {e}")
            self._cleanup()
            return False

    def _login(self) -> bool:
        """
        Login to Fanqie platform.

        Returns:
            True if login successful
        """
        try:
            self.logger.info("[fanqie_book] Starting login...")

            # Click password login
            password_login_btn = self.page.locator(
                'button.arco-btn.arco-btn-text.arco-btn-size-default.arco-btn-shape-round.serial-arco-btn.slogin-form-button span:has-text("密码登录")'
            )
            password_login_btn.wait_for(state="visible", timeout=30000)
            password_login_btn.click()
            self.logger.info("[fanqie_book] Clicked password login")

            # Fill phone
            phone_input = self.page.wait_for_selector(
                'input[placeholder="请输入手机号/邮箱"][name="username"]',
                timeout=30000
            )
            phone_input.fill(self.phone_number)
            self.logger.info(f"[fanqie_book] Phone filled: {self.phone_number[:3]}****")

            # Fill password
            password_input = self.page.wait_for_selector(
                'input[placeholder="请输入密码"][type="password"]',
                timeout=30000
            )
            password_input.fill(self.password)
            self.logger.info("[fanqie_book] Password filled")

            # Click protocol checkbox
            checkbox = self.page.locator("div.slogin-form-protocol__checkbox")
            checkbox.click()
            self.logger.info("[fanqie_book] Clicked checkbox")

            # Click login
            login_btn = self.page.locator(
                'button.arco-btn.arco-btn-primary.arco-btn-size-large.arco-btn-shape-round.serial-arco-btn.slogin-form-button span:has-text("登录")'
            )
            login_btn.wait_for(state="visible", timeout=30000)
            login_btn.click()
            self.logger.info("[fanqie_book] Clicked login, polling for redirect...")

            # Poll every second for redirect (handles CAPTCHA, etc.)
            max_wait = 120  # Wait up to 120 seconds for redirect
            poll_interval = 1  # Check every second
            elapsed = 0

            while elapsed < max_wait:
                time.sleep(poll_interval)
                elapsed += poll_interval

                # Check if redirected away from login page
                if "login" not in self.page.url.lower():
                    self.logger.info(f"[fanqie_book] Redirected to: {self.page.url}")
                    self._is_logged_in = True
                    return True

                # Check if login success indicators present
                if self._check_login_success():
                    self.logger.info("[fanqie_book] Login successful")
                    self._is_logged_in = True
                    return True

                self.logger.info(f"[fanqie_book] Still on login page, waiting... ({elapsed}s)")

            # Timeout reached
            self.logger.warning("[fanqie_book] Login timeout, assuming success")
            self._is_logged_in = True
            return True

        except Exception as e:
            self.logger.error(f"[fanqie_book] Login failed: {e}")
            return False

    def _check_login_success(self) -> bool:
        """Check if login was successful."""
        try:
            # Look for user info in header
            user_indicator = self.page.locator('text=作品管理')
            if user_indicator.count() > 0:
                return True

            # Look for user name
            user_name = self.page.locator('.slogin-user-avatar__info__name')
            if user_name.count() > 0:
                self.logger.info(f"[fanqie_book] Logged in as: {user_name.first.text_content()}")
                return True

            return False
        except Exception:
            return False

    def _wait_for_visible(self, locator, max_wait: int = 300, poll_interval: int = 1):
        """
        Wait for element to be visible by polling.

        Args:
            locator: Playwright locator to wait for
            max_wait: Maximum seconds to wait (default 300)
            poll_interval: Seconds between polls (default 1)

        Returns:
            True if element became visible, False if timeout
        """
        elapsed = 0
        while elapsed < max_wait:
            time.sleep(poll_interval)
            elapsed += poll_interval
            try:
                if locator.count() > 0 and locator.first.is_visible():
                    return True
            except Exception as e:
                self.logger.info(f"[fanqie_book] Waiting for element... ({elapsed}s) error: {e}")
            self.logger.info(f"[fanqie_book] Waiting for element... ({elapsed}s)")
        return False

    def navigate_to_create_book(self) -> bool:
        """
        Navigate to create new book page.

        Returns:
            True if navigation successful
        """
        if not self._is_logged_in:
            self.logger.error("[fanqie_book] Not logged in")
            return False

        try:
            self.logger.info("[fanqie_book] Navigating to create book page...")
            self.page.goto(self.CREATE_BOOK_URL)
            self.page.wait_for_load_state("networkidle", timeout=30000)
            time.sleep(2)
            self.logger.info("[fanqie_book] Create book page loaded")
            return True
        except Exception as e:
            self.logger.error(f"[fanqie_book] Navigate to create book failed: {e}")
            return False

    def create_book(
        self,
        book_name: str,
        is_male: bool,
        tags: list,
        protagonist1: str,
        protagonist2: str,
        description: str,
        callback: Optional[Callable[[bool, str], None]] = None
    ) -> tuple:
        """
        Create a new book on Fanqie platform.

        Args:
            book_name: Name of the book (max 15 chars)
            is_male: True for male channel, False for female channel
            tags: List of 7 tags
            protagonist1: First protagonist name (max 5 chars)
            protagonist2: Second protagonist name (max 5 chars)
            description: Book description (50-500 chars)
            callback: Optional callback with (success, book_id_or_error)

        Returns:
            Tuple of (success: bool, book_id: str or error_message: str)
        """
        if not self._is_logged_in:
            error = "Not logged in"
            if callback:
                callback(False, error)
            return (False, error)

        try:
            # Navigate to create page
            if not self.navigate_to_create_book():
                error = "Failed to navigate to create book page"
                if callback:
                    callback(False, error)
                return (False, error)

            # Fill book name
            self.logger.info("[fanqie_book] Filling book name...")
            name_input = self.page.locator(
                'input[placeholder="请输入作品名称"]'
            )
            name_input.wait_for(state="visible", timeout=30000)
            name_input.fill(book_name)
            self.logger.info(f"[fanqie_book] Book name: {book_name}")

            # Select channel (男频/女频)
            self.logger.info(f"[fanqie_book] Selecting channel: {'男频' if is_male else '女频'}")
            # Click the label inside #radio: index 0 for 男频, index 1 for 女频
            target_index = 0 if is_male else 1
            self.page.locator(f'#radio .arco-radio-group label').nth(target_index).click()
            self.logger.info(f"[fanqie_book] Selected {'男频' if is_male else '女频'}")

            # Fill tags - need to modify the HTML structure
            self.logger.info(f"[fanqie_book] Filling tags: {tags}")
            if not self._fill_tags(tags):
                error = "Failed to fill tags"
                if callback:
                    callback(False, error)
                return (False, error)

            # Fill protagonists
            self.logger.info("[fanqie_book] Filling protagonists...")
            prot1_input = self.page.locator(
                'input[placeholder="请输入主角名1"]'
            )
            self._wait_for_visible(prot1_input)
            prot1_input.fill(protagonist1)
            self.logger.info(f"[fanqie_book] Protagonist 1: {protagonist1}")

            prot2_input = self.page.locator(
                'input[placeholder="请输入主角名2"]'
            )
            self._wait_for_visible(prot2_input)
            prot2_input.fill(protagonist2)
            self.logger.info(f"[fanqie_book] Protagonist 2: {protagonist2}")

            # Fill description
            self.logger.info("[fanqie_book] Filling description...")
            desc_textarea = self.page.locator(
                'textarea[placeholder*="请输入50-500字"]'
            )
            self._wait_for_visible(desc_textarea)
            desc_textarea.fill(description)
            self.logger.info(f"[fanqie_book] Description length: {len(description)}")

            # Click create button - poll every second until visible
            self.logger.info("[fanqie_book] Waiting for create button to be visible...")
            create_btn = self.page.locator(
                'button.arco-btn.arco-btn-primary:has-text("立即创建")'
            )
            max_wait = 300
            elapsed = 0
            poll_interval = 1

            while elapsed < max_wait:
                time.sleep(poll_interval)
                elapsed += poll_interval

                # Check if modal dialog is blocking (作品标签 dialog)
                modal = self.page.locator('.arco-modal.serial-modal.category-modal')
                if modal.count() > 0 and modal.first.is_visible():
                    self.logger.info("[fanqie_book] Modal dialog detected, closing it...")
                    close_btn = self.page.locator('.arco-modal .arco-modal-close-icon')
                    if close_btn.count() > 0:
                        close_btn.first.click()
                        self.logger.info("[fanqie_book] Modal closed, continuing to wait for create button...")
                    time.sleep(1)
                    continue

                # Check if create button is visible
                try:
                    if create_btn.count() > 0 and create_btn.first.is_visible():
                        break
                except Exception:
                    pass
                self.logger.info(f"[fanqie_book] Waiting for create button... ({elapsed}s)")

            # Use Playwright's native async waiting methods
            click_count = 0
            start_url = self.page.url
            _captured_resp = [None]  # Use list to avoid closure issues

            # Register response listener BEFORE clicking (must be before to catch fast responses)
            def handle_response(response):
                if "/api/author/book/create/" in response.url:
                    _captured_resp[0] = response

            self.page.on("response", handle_response)

            # Keep clicking until URL redirects or we get a response
            while True:
                self.logger.info(f"[fanqie_book] Clicking create button (attempt {click_count + 1})...")
                try:
                    create_btn.click()
                except Exception as e:
                    self.logger.error(f"[fanqie_book] Click failed: {e}")
                    self.page.remove_listener("response", handle_response)
                    raise
                click_count += 1

                # Use Playwright's wait_for_url to detect redirect
                try:
                    self.logger.info("[fanqie_book] Waiting for URL redirect...")
                    self.page.wait_for_url("**/book-info/**", timeout=30000)
                    self.logger.info(f"[fanqie_book] URL redirected to: {self.page.url}")

                    # Remove listener before returning
                    self.page.remove_listener("response", handle_response)

                    # Log the captured response (it arrives around the same time as URL redirect)
                    if _captured_resp[0]:
                        resp = _captured_resp[0]
                        resp_json = resp.json()
                        self.logger.info(f"[fanqie_book] === API RESPONSE ===")
                        self.logger.info(f"[fanqie_book] Status: {resp.status}")
                        self.logger.info(f"[fanqie_book] Body: {resp_json}")
                        self.logger.info(f"[fanqie_book] ====================")

                        if resp_json.get('code') == 0:
                            book_id = resp_json.get("data", {}).get("book_id", "")
                            self.logger.info(f"[fanqie_book] Created book ID: {book_id}")
                            if callback:
                                callback(True, book_id)
                            return (True, book_id)
                        else:
                            error = f"创建失败: {resp_json.get('message')}"
                            self.logger.error(f"[fanqie_book] {error}")
                            if callback:
                                callback(False, error)
                            return (False, error)

                    # Otherwise extract from URL
                    current_url = self.page.url
                    if '/book-info/' in current_url:
                        parts = current_url.split("/book-info/")
                        if len(parts) > 1:
                            book_id = parts[1].split("?")[0]
                            self.logger.info(f"[fanqie_book] Created book ID from URL: {book_id}")
                            if callback:
                                callback(True, book_id)
                            return (True, book_id)
                    break

                except Exception as url_timeout:
                    self.logger.info(f"[fanqie_book] wait_for_url timeout: {url_timeout}")

                if click_count >= 3:
                    self.logger.warning(f"[fanqie_book] Max clicks ({click_count}) reached")
                    break

                self.logger.info(f"[fanqie_book] No redirect or response detected, will retry...")

            # Final check for URL redirect (book_id extraction)
            self.page.remove_listener("response", handle_response)
            current_url = self.page.url
            self.logger.info(f"[fanqie_book] Final URL check: {current_url}")

            if '/book-info/' in current_url:
                parts = current_url.split("/book-info/")
                if len(parts) > 1:
                    book_id = parts[1].split("?")[0]
                    self.logger.info(f"[fanqie_book] Created book ID from URL: {book_id}")
                    if callback:
                        callback(True, book_id)
                    return (True, book_id)

            error = "创建新书失败"
            self.logger.error(f"[fanqie_book] {error}")
            if callback:
                callback(False, error)
            return (False, error)

        except Exception as e:
            try:
                self.page.remove_listener("response", handle_response)
            except Exception:
                pass
            error_msg = f"Create book failed: {e}"
            self.logger.error(f"[fanqie_book] {error_msg}")
            if callback:
                callback(False, error_msg)
            return (False, error_msg)

    def _fill_tags(self, tags: list) -> bool:
        """
        Fill in book tags by modifying HTML structure.

        Args:
            tags: List of 7 tag names

        Returns:
            True if successful
        """
        try:
            # Find the select view container
            select_view = self.page.locator('.select-view').first
            self._wait_for_visible(select_view)

            # Click to open tag selector
            select_view.click()
            time.sleep(1)

            # We need to inject the tags HTML directly
            # Build the tags HTML
            tags_html = '<ul class="select-view-ul">'
            for tag in tags:
                tags_html += f'''
                <li class="create-category-item font-2">
                    <span class="item-title">{tag}</span>
                    <span class="tomato-close item-del"/>
                </li>
                '''
            tags_html += '</ul>'

            # Use JavaScript to inject the tags - first clear then add
            self.page.evaluate(f'''
                const selectView = document.querySelector('.select-view');
                if (selectView) {{
                    // Clear existing content first
                    selectView.innerHTML = '';
                    // Add new tags
                    selectView.innerHTML = `{tags_html}`;
                }}
            ''')

            time.sleep(0.5)
            self.logger.info(f"[fanqie_book] Tags filled via JS injection")
            return True

        except Exception as e:
            self.logger.error(f"[fanqie_book] Failed to fill tags: {e}")
            return False

    def get_user_info(self) -> Optional[str]:
        """
        Get logged in user info.

        Returns:
            Username if logged in, None otherwise
        """
        if not self._is_logged_in:
            return None

        try:
            user_name = self.page.locator('.slogin-user-avatar__info__name')
            if user_name.count() > 0:
                return user_name.first.text_content().strip()
            return None
        except Exception:
            return None

    def close(self) -> None:
        """Close browser."""
        self._cleanup()

    def _cleanup(self) -> None:
        """Cleanup browser resources."""
        try:
            if self.context:
                self.context.close()
        except Exception:
            pass
        self.context = None

        try:
            if self.browser:
                self.browser.close()
        except Exception:
            pass
        self.browser = None

        try:
            if self.p:
                self.p.stop()
        except Exception:
            pass
        self.p = None

        self.page = None
        self._is_logged_in = False

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def navigate_to_chapter_manage(self, book_id: str, book_name: str = "") -> bool:
        """
        导航到章节管理页面。

        Args:
            book_id: 书籍ID
            book_name: 书籍名称（用于URL编码，可选）

        Returns:
            True if navigation successful
        """
        if not self._is_logged_in:
            self.logger.error("[fanqie_book] Not logged in")
            return False

        try:
            encoded_name = urllib.parse.quote(book_name) if book_name else ""
            url = f"https://fanqienovel.com/main/writer/chapter-manage/{book_id}&{encoded_name}?type=1"

            self.logger.info(f"[fanqie_book] Navigating to chapter manage: {url}")
            self.page.goto(url)
            self.page.wait_for_load_state("networkidle", timeout=30000)
            time.sleep(2)

            self.logger.info("[fanqie_book] Chapter manage page loaded")
            return True

        except Exception as e:
            self.logger.error(f"[fanqie_book] Navigate to chapter manage failed: {e}")
            return False

    def list_published_chapters(self, book_id: str, volume_id: str = None) -> Dict[str, Any]:
        """
        获取番茄平台指定书籍的所有已发布章节。

        按文档 fanqie_list_published_chapters.md 的流程：
        1. 进入章节管理页面 chapter-manage/{book_id}
        2. 监听API响应，捕获每一页的章节数据
        3. 点击下一页按钮直到最后一页

        Args:
            book_id: 番茄书籍ID
            volume_id: 卷ID（可选）

        Returns:
            Dict包含:
                - success: bool
                - chapters: List[Dict] 所有章节元数据列表
                - total_count: int 章节总数
                - volume_id: str 卷ID
                - error: str 错误信息（如果失败）
        """
        if not self._is_logged_in:
            return {"success": False, "chapters": [], "total_count": 0, "error": "未登录"}

        try:
            # Navigate to chapter management page (NOT book-info)
            chapter_url = f"https://fanqienovel.com/main/writer/chapter-manage/{book_id}?type=1"
            self.logger.info(f"[fanqie_book] Navigating to chapter management page: {chapter_url}")

            all_chapters = []
            total_count = 0
            captured_volume_id = volume_id
            page_num = 1

            # Response captured
            _captured_resp = [None]

            # Use expect_response to wait for the API response (non-blocking, async-compatible)
            self.logger.info(f"[fanqie_book] Waiting for chapter list API response using expect_response...")
            try:
                with self.page.expect_response("**/api/author/chapter/chapter_list/**", timeout=30000) as resp_info:
                    self.page.goto(chapter_url, wait_until="commit", timeout=30000)
                resp = resp_info.value
                _captured_resp[0] = resp
                self.logger.info(f"[fanqie_book] Got response: {resp.url} status={resp.status}")
            except Exception as e:
                self.logger.warning(f"[fanqie_book] expect_response error: {e}")

            self.logger.info(f"[fanqie_book] Current URL: {self.page.url}")

            if _captured_resp[0]:
                resp = _captured_resp[0]
                data = resp.json()
                self.logger.info(f"[fanqie_book] Page {page_num} API Response: {data}")

                if data.get("code") == 0:
                    result_data = data.get("data", {})
                    total_count = result_data.get("total_count", 0)
                    self.logger.info(f"[fanqie_book] Total chapters: {total_count}")
                    captured_volume_id = result_data.get("volume_id", "")
                    self.logger.info(f"[fanqie_book] Volume ID: {captured_volume_id}")

                    items = result_data.get("item_list", [])
                    all_chapters.extend(items)
                    self.logger.info(f"[fanqie_book] Page {page_num}: got {len(items)} chapters, total so far: {len(all_chapters)}")
                else:
                    self.logger.error(f"[fanqie_book] API error: {data.get('message')}")
            else:
                self.logger.warning(f"[fanqie_book] No API response captured for initial page load!")

            _captured_resp[0] = None

            # Check if there are more pages
            # If no pagination element exists, or next button is disabled, we're done
            next_btn = self.page.locator('.arco-pagination-item-next')
            if next_btn.count() == 0:
                # No pagination at all - all chapters loaded in one page
                self.logger.info("[fanqie_book] No pagination found, all chapters loaded in one page")
            else:
                classes = next_btn.first.get_attribute("class") or ""
                if "arco-pagination-item-disabled" in classes:
                    # Last page - next button is disabled
                    self.logger.info("[fanqie_book] Next button is disabled, this is the last page")
                else:
                    # Not last page, need to click through
                    self.logger.info("[fanqie_book] More pages exist, clicking through...")
                    while True:
                        if page_num > 50:
                            self.logger.warning("[fanqie_book] Reached max page limit")
                            break

                        # Click next page button
                        self.logger.info(f"[fanqie_book] Clicking next page button (page {page_num + 1})...")
                        next_btn.click()
                        page_num += 1
                        time.sleep(1)  # Wait for page to load and response to arrive

                        # Wait for response
                        for attempt in range(20):
                            if _captured_resp[0]:
                                break
                            time.sleep(0.3)
                            self.logger.info(f"[fanqie_book] Waiting for page {page_num} response... attempt {attempt + 1}/20")

                        if _captured_resp[0]:
                            resp = _captured_resp[0]
                            data = resp.json()
                            self.logger.info(f"[fanqie_book] Page {page_num} API Response: {data}")

                            if data.get("code") == 0:
                                items = result_data.get("item_list", [])
                                all_chapters.extend(items)
                                self.logger.info(f"[fanqie_book] Page {page_num}: got {len(items)} chapters, total so far: {len(all_chapters)}")
                            else:
                                self.logger.error(f"[fanqie_book] API error: {data.get('message')}")
                        else:
                            self.logger.warning(f"[fanqie_book] No response captured for page {page_num}")

                        _captured_resp[0] = None

                        # Check if next button is now disabled
                        next_btn = self.page.locator('.arco-pagination-item-next')
                        if next_btn.count() > 0:
                            classes = next_btn.first.get_attribute("class") or ""
                            if "arco-pagination-item-disabled" in classes:
                                self.logger.info(f"[fanqie_book] Reached last page after clicking page {page_num}")
                                break
                        else:
                            self.logger.info(f"[fanqie_book] No more pagination found after page {page_num}")
                            break

            self.logger.info(f"[fanqie_book] Finished fetching chapters. Total: {len(all_chapters)}")

            return {
                "success": True,
                "chapters": all_chapters,
                "total_count": total_count,
                "volume_id": captured_volume_id,
                "error": None
            }

        except Exception as e:
            self.logger.error(f"[fanqie_book] Failed to list chapters: {e}")
            return {"success": False, "chapters": [], "total_count": 0, "error": str(e)}
