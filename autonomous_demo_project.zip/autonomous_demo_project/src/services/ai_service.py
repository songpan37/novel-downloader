"""
AI Service for AI Writer application.

Provides unified interface to AI language model APIs with support for:
1. Direct API calls (OpenAI, Anthropic, DeepSeek, Qwen, etc.)
2. Browser automation (Playwright-based web interface)

Usage:
    from services.ai_service import AIService, AIServiceMode

    # Use API mode
    service = AIService(mode=AIServiceMode.API, api_provider="qwen", ...)

    # Use browser mode
    service = AIService(mode=AIServiceMode.BROWSER, browser_provider="deepseek", ...)
"""
import asyncio
import httpx
from enum import Enum
from typing import Optional, List, Dict, AsyncIterator, Callable, Any
from datetime import datetime, timedelta

from utils.exceptions import (
    AIServiceError,
    APIAuthError,
    APIRateLimitError,
    APINetworkError,
    APITimeoutError,
    AIServiceUnavailableError,
)
from utils.logger import get_logger


class AIServiceMode(Enum):
    """AI service call mode."""
    API = "api"  # Direct API call
    BROWSER = "browser"  # Browser automation


class AIProvider(Enum):
    """Supported AI providers."""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    DEEPSEEK = "deepseek"
    QWEN = "qwen"
    DOUBAO = "doubao"


# Provider configurations
API_PROVIDERS = {
    "openai": {
        "name": "OpenAI",
        "default_url": "https://api.openai.com/v1/chat/completions",
        "default_model": "gpt-4o",
        "auth_header": "Bearer",
    },
    "anthropic": {
        "name": "Anthropic",
        "default_url": "https://api.anthropic.com/v1/messages",
        "default_model": "claude-sonnet-4-5-20250929",
        "auth_header": "Bearer",
        "headers": {"anthropic-version": "2023-06-01"},
    },
    "deepseek": {
        "name": "DeepSeek",
        "default_url": "https://api.deepseek.com/chat/completions",
        "default_model": "deepseek-chat",
        "auth_header": "Bearer",
    },
    "qwen": {
        "name": "阿里云通义千问",
        "default_url": "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
        "default_model": "qwen-plus",
        "auth_header": "Bearer",
    },
}

# Global single-thread executor for browser operations (ensures Playwright runs in same thread)
_browser_executor = None
_browser_executor_lock = None

def _get_browser_executor():
    """Get or create the global single-thread executor for browser operations."""
    global _browser_executor, _browser_executor_lock
    import threading
    from concurrent.futures import ThreadPoolExecutor

    if _browser_executor_lock is None:
        _browser_executor_lock = threading.Lock()

    with _browser_executor_lock:
        if _browser_executor is None:
            _browser_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="browser_worker")
    return _browser_executor

def _reset_browser_executor():
    """Reset the global browser executor - used when browser is in bad state."""
    global _browser_executor, _browser_executor_lock
    import threading
    import concurrent.futures

    if _browser_executor_lock is None:
        _browser_executor_lock = threading.Lock()

    with _browser_executor_lock:
        if _browser_executor is not None:
            try:
                _browser_executor.shutdown(wait=False, cancel_futures=True)
            except Exception:
                pass
            _browser_executor = None

    # Also reset the lock to ensure a fresh lock next time
    _browser_executor_lock = None

BROWSER_PROVIDERS = {
    "deepseek": {
        "name": "DeepSeek",
        "login_url": "https://chat.deepseek.com/sign_in",
        "requires_verification": True,
    },
    "doubao": {
        "name": "豆包",
        "login_url": "https://doubao.com/login",
        "requires_verification": True,
    },
}


class AIService:
    """
    Unified AI Service with support for multiple providers and call modes.

    Attributes:
        mode: Service mode (API or Browser)
        api_provider: API provider name (for API mode)
        browser_provider: Browser provider name (for Browser mode)
    """

    DEFAULT_MAX_RETRIES = 3
    DEFAULT_RETRY_DELAY = 1.0
    DEFAULT_TIMEOUT = 60.0
    # Backward compatibility constants
    DEFAULT_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"
    DEFAULT_MODEL = "qwen-plus"

    def __init__(
        self,
        mode: Optional[AIServiceMode] = None,
        # API mode settings
        api_provider: str = "qwen",
        api_url: Optional[str] = None,
        api_key: str = "",
        api_model: Optional[str] = None,
        # Browser mode settings
        browser_provider: str = "deepseek",
        browser_phone: str = "",
        browser_password: str = "",  # Optional password for DeepSeek password login
        browser_chrome_path: str = r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        # Common settings
        max_retries: int = DEFAULT_MAX_RETRIES,
        retry_delay: float = DEFAULT_RETRY_DELAY,
        timeout: float = DEFAULT_TIMEOUT,
        # Backward compatibility parameters (deprecated)
        base_url: Optional[str] = None,
        model: Optional[str] = None,
    ):
        """
        Initialize the AI service.

        Args:
            mode: Service mode (API or Browser). If None, auto-detects from other params.
            api_provider: API provider name (openai, anthropic, deepseek, qwen)
            api_url: Custom API URL (uses provider default if not specified)
            api_key: API authentication key
            api_model: Model name to use
            browser_provider: Browser provider name (deepseek, doubao)
            browser_phone: Phone number for browser login
            browser_password: Password for browser login (DeepSeek only, optional)
            browser_chrome_path: Path to Chrome executable
            max_retries: Maximum retry attempts for failed requests
            retry_delay: Base delay between retries in seconds
            timeout: Request timeout in seconds
            base_url: Deprecated - use api_url instead
            model: Deprecated - use api_model instead
        """
        # Backward compatibility: support old interface
        if mode is None:
            # Auto-detect mode - default to API for backward compatibility
            self.mode = AIServiceMode.API
        else:
            self.mode = mode

        self.logger = get_logger()

        # API mode settings - support both new and old parameter names
        self.api_provider = api_provider
        self.api_key = api_key
        # Use api_model, or model (deprecated), or default
        self.api_model = api_model or model or self._get_default_model(api_provider)
        # Use api_url, or base_url (deprecated), or provider default
        self.base_url = api_url or base_url or self._get_default_url(api_provider)
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.timeout = timeout

        # Browser mode settings
        self.browser_provider = browser_provider
        self.browser_phone = browser_phone
        self.browser_password = browser_password  # Store password for DeepSeek password login
        self.browser_chrome_path = browser_chrome_path

        # Rate limit tracking (for API mode)
        self._request_times: List[datetime] = []
        self._rate_limit_reset: Optional[datetime] = None
        self._is_rate_limited = False

        # Persistent browser service for browser mode (reused across calls)
        self._browser_service: Optional[Any] = None

    # Backward compatibility properties
    @property
    def model(self) -> Optional[str]:
        """Get the model name (for backward compatibility)."""
        return self.api_model

    @model.setter
    def model(self, value: str) -> None:
        """Set the model name (for backward compatibility)."""
        self.api_model = value

    def _get_default_url(self, provider: str) -> str:
        """Get default URL for provider."""
        config = API_PROVIDERS.get(provider, {})
        return config.get("default_url", "")

    def _get_default_model(self, provider: str) -> str:
        """Get default model for provider."""
        config = API_PROVIDERS.get(provider, {})
        return config.get("default_model", "")

    @property
    def is_rate_limited(self) -> bool:
        """Check if currently rate limited."""
        if self._rate_limit_reset and datetime.now() < self._rate_limit_reset:
            return True
        return self._is_rate_limited

    @property
    def retry_after_seconds(self) -> Optional[int]:
        """Get seconds until rate limit resets."""
        if self._rate_limit_reset:
            remaining = (self._rate_limit_reset - datetime.now()).total_seconds()
            return max(0, int(remaining))
        return None

    async def chat(
        self,
        messages: List[Dict[str, str]],
        system: Optional[str] = None,
        model: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        new_chat: bool = True,
        on_retry: Optional[Callable[[int, str], None]] = None,
        persistent_browser_service: Optional[Any] = None,  # Optional persistent BrowserAIService instance
        pause_check_fn: Optional[Callable[[], bool]] = None,  # Optional pause check function
    ) -> str:
        """
        Send a chat request and get a response.

        Args:
            messages: List of message dictionaries with role and content
            system: Optional system prompt
            model: Optional model override
            max_tokens: Maximum tokens in response
            temperature: Response temperature (0-1)
            new_chat: Whether to start a new chat session (for browser mode)
            on_retry: Optional callback for retry notifications (attempt, message)
            persistent_browser_service: Optional persistent BrowserAIService instance to reuse
            pause_check_fn: Optional callable to check if paused - returns True if should abort

        Returns:
            AI response text

        Raises:
            APIRateLimitError: If rate limit is exceeded
            APIAuthError: If API key is invalid
            APINetworkError: If network error occurs
            AIServiceError: For other API errors
        """
        if self.mode == AIServiceMode.API:
            return await self._api_chat(
                messages=messages,
                system=system,
                model=model or self.api_model,
                max_tokens=max_tokens,
                temperature=temperature,
                on_retry=on_retry,
            )
        else:
            return await self._browser_chat(
                messages=messages,
                system=system,
                new_chat=new_chat,
                persistent_browser_service=persistent_browser_service,
                pause_check_fn=pause_check_fn,
            )

    async def _api_chat(
        self,
        messages: List[Dict[str, str]],
        system: Optional[str],
        model: str,
        max_tokens: int,
        temperature: float,
        on_retry: Optional[Callable[[int, str], None]] = None,
    ) -> str:
        """Chat using direct API call."""
        if self.is_rate_limited:
            raise APIRateLimitError(
                message=f"请求过于频繁，请 {self.retry_after_seconds} 秒后重试",
                retry_after=self.retry_after_seconds
            )

        last_error: Optional[Exception] = None

        for attempt in range(self.max_retries + 1):
            try:
                response = await self._make_api_chat_request(
                    messages=messages,
                    system=system,
                    model=model,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )
                return response

            except APIRateLimitError as e:
                last_error = e
                self._handle_rate_limit(e)
                if attempt < self.max_retries:
                    wait_time = self._calculate_retry_delay(attempt, e.retry_after)
                    if self.logger:
                        self.logger.warning(
                            f"Rate limit hit, retrying in {wait_time}s (attempt {attempt + 1}/{self.max_retries})"
                        )
                    if on_retry:
                        on_retry(attempt + 1, f"请求频繁，{wait_time}秒后重试...")
                    await asyncio.sleep(wait_time)
                else:
                    if self.logger:
                        self.logger.error("Rate limit retries exhausted")
                    raise

            except APIAuthError as e:
                if self.logger:
                    self.logger.error("API authentication failed")
                raise

            except APITimeoutError as e:
                last_error = e
                if attempt < self.max_retries:
                    wait_time = self._calculate_retry_delay(attempt)
                    if on_retry:
                        on_retry(attempt + 1, f"请求超时，{wait_time}秒后重试...")
                    await asyncio.sleep(wait_time)
                else:
                    raise

            except APINetworkError as e:
                last_error = e
                if attempt < self.max_retries:
                    wait_time = self._calculate_retry_delay(attempt)
                    if on_retry:
                        on_retry(attempt + 1, f"网络错误，{wait_time}秒后重试...")
                    await asyncio.sleep(wait_time)
                else:
                    raise

            except AIServiceError as e:
                if self.logger:
                    self.logger.error(f"AI service error: {e.message}")
                raise

            except Exception as e:
                last_error = e
                if self.logger:
                    self.logger.error(f"Unexpected error: {e}")
                if attempt < self.max_retries:
                    wait_time = self._calculate_retry_delay(attempt)
                    await asyncio.sleep(wait_time)
                else:
                    raise AIServiceError(
                        message="AI 服务请求失败",
                        details=str(e)
                    )

        raise last_error or AIServiceError(message="未知错误")

    async def _browser_chat(
        self,
        messages: List[Dict[str, str]],
        system: Optional[str] = None,
        new_chat: bool = True,
        persistent_browser_service: Optional[Any] = None,  # Optional persistent BrowserAIService or AIService instance
        pause_check_fn: Optional[Callable[[], bool]] = None,  # Optional pause check function
    ) -> str:
        """Chat using browser automation with retry logic."""
        max_retries = 100  # 100 retries for long-running tasks
        retry_delay = 5  # seconds
        last_error = None

        for attempt in range(max_retries):
            try:
                # Import browser service
                from services.browser_ai_service import BrowserAIService

                self.logger.info(f"[BROWSER] Starting browser chat (attempt {attempt + 1}/{max_retries})...")

                # Combine messages into single prompt
                prompt_parts = []
                if system:
                    prompt_parts.append(f"System: {system}")
                for msg in messages:
                    role = msg.get("role", "user")
                    content = msg.get("content", "")
                    prompt_parts.append(f"{role}: {content}")
                prompt = "\n".join(prompt_parts)

                self.logger.info(f"[BROWSER] Sending message to browser AI...")

                # Use global single-thread executor for browser operations
                # This ensures Playwright runs in the same thread across calls
                executor = _get_browser_executor()

                def browser_operation():
                    """
                    Execute browser operations in a dedicated thread.
                    All Playwright operations must run in the same thread.
                    """
                    self.logger.info(f"[BROWSER] browser_operation started")
                    created_service = False
                    browser_service = None

                    # Use persistent browser service if provided
                    if persistent_browser_service is not None:
                        self.logger.info("[BROWSER] Persistent browser service provided")

                        # Check if it's an AIService wrapper - use its internal _browser_service
                        if isinstance(persistent_browser_service, AIService):
                            self.logger.info("[BROWSER] Using AIService instance's internal browser service")
                            # Use the AIService's internal _browser_service (create if not exists)
                            if persistent_browser_service._browser_service is None:
                                self.logger.info("[BROWSER] Creating BrowserAIService for AIService instance")
                                persistent_browser_service._browser_service = BrowserAIService(
                                    provider=persistent_browser_service.browser_provider,
                                    phone_number=persistent_browser_service.browser_phone,
                                    password=persistent_browser_service.browser_password,
                                    chrome_path=persistent_browser_service.browser_chrome_path,
                                )
                            browser_service = persistent_browser_service._browser_service
                            created_service = False  # Don't close, it's persistent
                        elif hasattr(persistent_browser_service, 'connect') and hasattr(persistent_browser_service, 'send_message'):
                            # It's a BrowserAIService instance
                            self.logger.info("[BROWSER] Using provided BrowserAIService instance")
                            browser_service = persistent_browser_service
                            created_service = False
                        else:
                            self.logger.warning("[BROWSER] Unknown persistent service type, creating new one")
                            browser_service = BrowserAIService(
                                provider=self.browser_provider,
                                phone_number=self.browser_phone,
                                password=self.browser_password,
                                chrome_path=self.browser_chrome_path,
                            )
                            created_service = True
                    else:
                        # No persistent service - create new one for this call
                        self.logger.info("[BROWSER] Creating BrowserAIService in thread...")
                        browser_service = BrowserAIService(
                            provider=self.browser_provider,
                            phone_number=self.browser_phone,
                            password=self.browser_password,
                            chrome_path=self.browser_chrome_path,
                        )
                        created_service = True

                    try:
                        # Connect to browser
                        self.logger.info("[BROWSER] Connecting in thread...")
                        if not browser_service.connect():
                            raise Exception("浏览器连接失败")
                        self.logger.info("[BROWSER] Connected in thread")

                        # Send message with increased timeout for generation
                        self.logger.info(f"[BROWSER] Sending message in thread, prompt length: {len(prompt)}, new_chat: {new_chat}")
                        response = browser_service.send_message(
                            prompt,
                            new_chat=new_chat,
                            wait_timeout=1800.0,  # 30 minutes timeout for generation
                            max_retries=100,  # 100 retries for long-running tasks
                            pause_check_fn=pause_check_fn,
                        )
                        self.logger.info(f"[BROWSER] Got response in thread: {len(response) if response else 0} chars")
                        return response

                    finally:
                        # Only close browser if we created it (not persistent)
                        if created_service:
                            self.logger.info("[BROWSER] Closing browser in thread...")
                            browser_service.close()
                            self.logger.info("[BROWSER] Browser closed")
                        else:
                            self.logger.info("[BROWSER] Using persistent browser service, not closing")

                # Submit to global executor and wait for result
                import asyncio
                loop = asyncio.get_event_loop()
                response = await loop.run_in_executor(executor, browser_operation)

                self.logger.info(f"[BROWSER] Received response: {len(response) if response else 0} chars")
                return response

            except InterruptedError as e:
                # Pause interrupt - do NOT retry, just exit
                self.logger.info("[BROWSER] Generation interrupted by pause, stopping retries")
                raise e

            except Exception as e:
                last_error = e
                self.logger.error(f"[BROWSER] Attempt {attempt + 1}/{max_retries} failed: {e}")

                if attempt < max_retries - 1:
                    wait_time = retry_delay * (attempt + 1)
                    self.logger.info(f"[BROWSER] Waiting {wait_time}s before retry...")
                    await asyncio.sleep(wait_time)
                else:
                    self.logger.error(f"[BROWSER] All {max_retries} attempts failed")

        # All retries failed
        raise AIServiceError(
            message=f"浏览器 AI 调用失败（已重试 {max_retries} 次）",
            details=str(last_error)
        )

    async def _make_api_chat_request(
        self,
        messages: List[Dict[str, str]],
        system: Optional[str],
        model: str,
        max_tokens: int,
        temperature: float,
    ) -> str:
        """Make the actual API request."""
        # Build request payload based on provider
        payload = self._build_api_payload(messages, system, model, max_tokens, temperature)

        # Build request headers
        headers = self._build_api_headers()

        if self.logger:
            self.logger.info(f"Making API request to {self.base_url} with model {model}")
            self.logger.debug(f"Request payload: {payload}")

        try:
            async with httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout, connect=10.0),
                follow_redirects=True
            ) as client:
                response = await client.post(
                    url=self.base_url,
                    headers=headers,
                    json=payload,
                )

                if self.logger:
                    self.logger.info(f"API response status: {response.status_code}")

                if response.status_code == 200:
                    return self._parse_api_response(response.json())
                elif response.status_code == 401:
                    raise APIAuthError(
                        message="API Key 无效或已过期，请检查设置",
                        details=f"Status {response.status_code}: {response.text}"
                    )
                elif response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", 60))
                    raise APIRateLimitError(
                        message="请求过于频繁，请稍后再试",
                        details=f"Status {response.status_code}: {response.text}",
                        retry_after=retry_after
                    )
                elif response.status_code >= 500:
                    raise APINetworkError(
                        message="服务器错误，请稍后重试",
                        details=f"Status {response.status_code}: {response.text}"
                    )
                else:
                    raise AIServiceError(
                        message="AI 服务请求失败",
                        details=f"Status {response.status_code}: {response.text}"
                    )

        except httpx.TimeoutException:
            raise APITimeoutError(
                message="请求超时，请检查网络后重试",
                details=f"Timeout after {self.timeout}s"
            )
        except httpx.NetworkError:
            raise APINetworkError(
                message="网络连接失败，请检查网络后重试",
                details="Network error"
            )
        except httpx.RequestError as e:
            raise AIServiceError(message="请求失败", details=str(e))

    def _build_api_payload(
        self,
        messages: List[Dict[str, str]],
        system: Optional[str],
        model: str,
        max_tokens: int,
        temperature: float,
    ) -> dict:
        """Build API request payload based on provider."""
        if self.api_provider == "anthropic":
            # Anthropic format
            payload = {
                "model": model,
                "max_tokens": max_tokens,
                "messages": messages,
            }
            if system:
                payload["system"] = system
        else:
            # OpenAI-compatible format (OpenAI, DeepSeek, Qwen)
            payload = {
                "model": model,
                "messages": messages,
                "max_tokens": max_tokens,
                "temperature": temperature,
            }
            if system:
                # Add system message to messages list
                payload["messages"].insert(0, {"role": "system", "content": system})

        return payload

    def _build_api_headers(self) -> dict:
        """Build API request headers based on provider."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        # Add provider-specific headers
        provider_config = API_PROVIDERS.get(self.api_provider, {})
        if "headers" in provider_config:
            headers.update(provider_config["headers"])

        return headers

    def _parse_api_response(self, data: dict) -> str:
        """Parse API response based on provider."""
        if self.api_provider == "anthropic":
            # Anthropic format: {"content": [{"type": "text", "text": "..."}]}
            content_list = data.get("content", [])
            if isinstance(content_list, list):
                text_parts = []
                for block in content_list:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                return "".join(text_parts) if text_parts else ""
            return str(content_list)
        else:
            # OpenAI-compatible format: {"choices": [{"message": {"content": "..."}}]}
            choices = data.get("choices", [])
            if choices and len(choices) > 0:
                message = choices[0].get("message", {})
                return message.get("content", "")
            # Try alternative format
            return data.get("text", "") or data.get("content", "")

    def _handle_rate_limit(self, error: APIRateLimitError) -> None:
        """Handle rate limit error."""
        self._is_rate_limited = True
        if error.retry_after:
            self._rate_limit_reset = datetime.now() + timedelta(seconds=error.retry_after)
        else:
            self._rate_limit_reset = datetime.now() + timedelta(seconds=60)
        if self.logger:
            self.logger.warning(f"Rate limit hit. Cooldown until {self._rate_limit_reset}")

    def _calculate_retry_delay(
        self,
        attempt: int,
        retry_after: Optional[int] = None
    ) -> float:
        """Calculate delay before next retry using exponential backoff."""
        if retry_after:
            return float(retry_after)
        base_delay = self.retry_delay * (2 ** attempt)
        import random
        jitter = random.uniform(0, 0.5 * base_delay)
        return min(base_delay + jitter, 60.0)

    def reset_rate_limit(self) -> None:
        """Reset rate limit state."""
        self._is_rate_limited = False
        self._rate_limit_reset = None
        if self.logger:
            self.logger.info("Rate limit state reset")

    def check_browser_chrome_installed(self) -> tuple[bool, str]:
        """
        Check if Chrome is installed for browser mode.

        Returns:
            Tuple of (is_installed, chrome_path or error_message)
        """
        from services.browser_ai_service import BrowserAIService

        if BrowserAIService.check_chrome_installed(self.browser_chrome_path):
            return True, self.browser_chrome_path
        else:
            default_path = BrowserAIService.get_chrome_install_path()
            if default_path:
                return True, default_path
            return False, "未找到 Chrome 浏览器，请安装后重试"

    def is_generating(self) -> bool:
        """
        Check if AI is currently generating content (browser mode only).
        This method executes in the browser thread to avoid Playwright thread issues.

        Returns:
            True if generation is in progress, False otherwise
        """
        if self.mode != AIServiceMode.BROWSER:
            return False

        result = {'is_generating': False}
        exception_holder = {'exception': None}

        def check_generating():
            try:
                if self._browser_service:
                    # Check if stop button is visible (square icon) - means generating
                    stop_icon = self._browser_service.page.locator('div.ds-icon-button[role="button"][aria-disabled="false"] svg:has(path[d*="M2 4.88"])').first
                    if stop_icon.count() > 0:
                        try:
                            stop_icon.wait_for(state="visible", timeout=500)
                            result['is_generating'] = True
                        except Exception:
                            result['is_generating'] = False
                    else:
                        result['is_generating'] = False
                else:
                    result['is_generating'] = False
            except Exception as e:
                exception_holder['exception'] = e
                result['is_generating'] = False

        self._run_in_browser_thread(check_generating)

        if exception_holder['exception']:
            self.logger.error(f"[AIService] Error checking generation status: {exception_holder['exception']}")

        return result['is_generating']

    def stop_generation(self) -> bool:
        """
        Stop the current generation by clicking the stop button (browser mode only).
        This method executes in the browser thread to avoid Playwright thread issues.

        Returns:
            True if stop was successful, False otherwise
        """
        if self.mode != AIServiceMode.BROWSER:
            self.logger.warning("[AIService] stop_generation called but not in browser mode")
            return False

        result = {'success': False}
        exception_holder = {'exception': None}

        def stop_gen():
            try:
                if self._browser_service:
                    # Find stop button (square icon)
                    stop_button = self._browser_service.page.locator('div.ds-icon-button[role="button"][aria-disabled="false"] svg:has(path[d*="M2 4.88"])').first

                    if stop_button.count() > 0:
                        stop_button.wait_for(state="visible", timeout=2000)
                        stop_button.click()
                        self.logger.info("[AIService] Stop button clicked, generation interrupted")
                        self._browser_service.page.wait_for_timeout(1000)
                        result['success'] = True
                    else:
                        self.logger.warning("[AIService] No stop button found, may not be generating")
                        result['success'] = False
                else:
                    self.logger.warning("[AIService] No browser service available")
                    result['success'] = False
            except Exception as e:
                exception_holder['exception'] = e
                result['success'] = False

        self._run_in_browser_thread(stop_gen)

        if exception_holder['exception']:
            self.logger.error(f"[AIService] Error stopping generation: {exception_holder['exception']}")
            return False

        return result['success']

    def _run_in_browser_thread(self, operation) -> any:
        """
        Run an operation in the browser thread using the same executor as browser_chat.

        Args:
            operation: Callable to execute in browser thread

        Returns:
            Result of the operation
        """
        if not self._browser_service:
            return None

        import asyncio

        result = {'value': None}

        def wrapped_operation():
            result['value'] = operation()

        try:
            loop = asyncio.get_event_loop()
            # Use the same executor as browser_chat (defined in this module)
            executor = _get_browser_executor()
            loop.run_until_complete(loop.run_in_executor(executor, wrapped_operation))
        except Exception as e:
            self.logger.error(f"[AIService] Error running operation in browser thread: {e}")
            return None

        return result['value']

    def close(self) -> None:
        """Close any open connections. Silently ignores errors."""
        if self._browser_service is not None:
            try:
                self._browser_service.close()
            except Exception:
                pass  # Silently ignore errors
            self._browser_service = None
        # Always reset the global browser executor to ensure clean state for next use
        _reset_browser_executor()


# Convenience functions
def get_ai_service(
    mode: AIServiceMode = AIServiceMode.API,
    api_provider: str = "qwen",
    api_key: Optional[str] = None,
    **kwargs
) -> AIService:
    """
    Create an AI service instance.

    Args:
        mode: Service mode (API or Browser)
        api_provider: API provider name
        api_key: API key (required for API mode)
        **kwargs: Additional provider-specific settings

    Returns:
        AIService instance
    """
    if mode == AIServiceMode.API and not api_key:
        from utils.exceptions import ConfigError
        raise ConfigError("api_key", "API Key 未设置，请在设置页面配置 API Key")

    return AIService(
        mode=mode,
        api_provider=api_provider,
        api_key=api_key or "",
        **kwargs
    )


def reset_ai_service() -> None:
    """Reset the global AI service instance."""
    # This is kept for backward compatibility
    pass
