"""
Export Service for AI Writer application.

Handles exporting works to ZIP files for backup or sharing.
"""
import os
import json
import zipfile
import shutil
from typing import Optional, List, Tuple
from datetime import datetime

from models.work import Work


class ExportService:
    """
    Service for exporting works to ZIP files.

    Creates ZIP archives containing all work data including:
    - Work info (work_info.json)
    - Step output files (steps/*.txt)
    - Cover images (covers/*)
    - Custom templates (templates/*)
    """

    def __init__(self, works_dir: str):
        """
        Initialize export service.

        Args:
            works_dir: Directory containing work subdirectories
        """
        self.works_dir = works_dir
        self._ensure_directory()

    def _ensure_directory(self) -> None:
        """Ensure works directory exists."""
        if not os.path.exists(self.works_dir):
            os.makedirs(self.works_dir, exist_ok=True)

    def _get_work_dir(self, work_id: str) -> str:
        """
        Get directory path for a work.

        Args:
            work_id: Work identifier

        Returns:
            Full path to work directory
        """
        return os.path.join(self.works_dir, work_id)

    def _validate_work_structure(self, work_dir: str) -> Tuple[bool, List[str]]:
        """
        Validate that a work directory has the expected structure.

        Args:
            work_dir: Path to work directory

        Returns:
            Tuple of (is_valid, list of error messages)
        """
        errors = []
        required_files = ["work_info.json"]
        required_dirs = ["volumes", "chapters"]

        for file in required_files:
            if not os.path.exists(os.path.join(work_dir, file)):
                errors.append(f"Missing required file: {file}")

        for dir_name in required_dirs:
            dir_path = os.path.join(work_dir, dir_name)
            if not os.path.exists(dir_path):
                errors.append(f"Missing required directory: {dir_name}")
            elif not os.path.isdir(dir_path):
                errors.append(f"{dir_name} is not a directory")

        return len(errors) == 0, errors

    def export_to_zip(
        self,
        work_id: str,
        output_path: str,
        include_templates: bool = True,
        include_covers: bool = True
    ) -> Tuple[bool, str]:
        """
        Export a work to a ZIP file.

        Args:
            work_id: Work identifier
            output_path: Path for output ZIP file
            include_templates: Whether to include custom templates
            include_covers: Whether to include cover images

        Returns:
            Tuple of (success, message)
        """
        work_dir = self._get_work_dir(work_id)

        if not os.path.exists(work_dir):
            return False, f"Work directory not found: {work_id}"

        # Validate work structure
        is_valid, errors = self._validate_work_structure(work_dir)
        if not is_valid:
            return False, f"Invalid work structure: {', '.join(errors)}"

        try:
            # Create ZIP file
            with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                # Add work info
                work_info_path = os.path.join(work_dir, "work_info.json")
                zipf.write(work_info_path, os.path.join(work_id, "work_info.json"))

                # Add steps (all step output files)
                steps_dir = os.path.join(work_dir, "steps")
                if os.path.exists(steps_dir):
                    for filename in os.listdir(steps_dir):
                        if filename.endswith('.txt'):
                            file_path = os.path.join(steps_dir, filename)
                            arcname = os.path.join(work_id, "steps", filename)
                            zipf.write(file_path, arcname)

                # Add covers if requested
                if include_covers:
                    covers_dir = os.path.join(work_dir, "covers")
                    if os.path.exists(covers_dir):
                        for filename in os.listdir(covers_dir):
                            file_path = os.path.join(covers_dir, filename)
                            arcname = os.path.join(work_id, "covers", filename)
                            zipf.write(file_path, arcname)

                # Add templates if requested
                if include_templates:
                    templates_dir = os.path.join(work_dir, "templates")
                    if os.path.exists(templates_dir):
                        for filename in os.listdir(templates_dir):
                            if filename.endswith('.txt'):
                                file_path = os.path.join(templates_dir, filename)
                                arcname = os.path.join(work_id, "templates", filename)
                                zipf.write(file_path, arcname)

                # Add metadata file
                metadata = {
                    "export_date": datetime.now().isoformat(),
                    "work_id": work_id,
                    "version": "1.0"
                }
                metadata_path = os.path.join(work_dir, "export_metadata.json")
                with open(metadata_path, 'w', encoding='utf-8') as f:
                    json.dump(metadata, f, ensure_ascii=False, indent=2)
                zipf.write(metadata_path, os.path.join(work_id, "export_metadata.json"))

                # Clean up temporary metadata file
                if os.path.exists(metadata_path):
                    os.remove(metadata_path)

            return True, f"Successfully exported to {output_path}"

        except zipfile.BadZipFile as e:
            return False, f"Failed to create ZIP file: {str(e)}"
        except IOError as e:
            return False, f"IO error during export: {str(e)}"
        except Exception as e:
            return False, f"Unexpected error during export: {str(e)}"

    def get_export_path_suggestion(self, work_id: str, work_title: str) -> str:
        """
        Get a suggested export file path.

        Args:
            work_id: Work identifier
            work_title: Work title

        Returns:
            Suggested file path for export
        """
        # Sanitize title for filename
        safe_title = "".join(c for c in work_title if c.isalnum() or c in ' -_').strip()
        if not safe_title:
            safe_title = work_id

        timestamp = datetime.now().strftime("%Y%m%d")
        filename = f"{safe_title}_{work_id}_{timestamp}.zip"

        # Suggest saving to desktop or documents
        home_dir = os.path.expanduser("~")
        documents_dir = os.path.join(home_dir, "Documents", "AI Writer Exports")

        if not os.path.exists(documents_dir):
            os.makedirs(documents_dir, exist_ok=True)

        return os.path.join(documents_dir, filename)
