"""
Creation View for AI Writer application.

Provides the creation management interface with flow tree,
status indicators, and content display panels.
"""
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTreeWidget, QTreeWidgetItem, QSplitter, QFrame,
    QTextEdit, QScrollArea, QSizePolicy, QLayout
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer, QMetaObject, Q_ARG
from PyQt6.QtGui import QFont, QIcon, QColor, QBrush
from typing import Optional, Dict, Any, List
from pathlib import Path
import os
from core.creation_task import CreationTask, SessionInfo, StepInfo, CreationTaskBuilder
from core.context_input import ContextInputManager


class CreationView(QWidget):
    """
    Creation management view for AI Writer.

    Features:
    - Top control bar with creation button and status indicator
    - Left panel showing flow tree of creation steps
    - Right panel showing content/results for selected step

    Signals:
        creation_started: Emitted when user clicks start creation button
        creation_paused: Emitted when user pauses creation
        creation_resumed: Emitted when user resumes creation
        step_selected: Emitted when a step in the flow tree is selected
        generation_progress: Emitted when generation progress updates (step_name, word_count)
    """

    # Signals
    creation_started = pyqtSignal(str)  # work_id
    creation_paused = pyqtSignal(str)  # work_id
    creation_resumed = pyqtSignal(str)  # work_id
    step_selected = pyqtSignal(str, str)  # work_id, step_name
    content_changed = pyqtSignal(str, str)  # step_id, new_content
    generation_progress = pyqtSignal(str, int)  # step_name, word_count
    save_requested = pyqtSignal(str, str, str)  # work_id, step_id, content
    go_to_workspace_requested = pyqtSignal()  # Request to switch to workspace
    template_edit_requested = pyqtSignal(str, str, str)  # work_id, step_id, step_name
    regenerate_requested = pyqtSignal(str, str, str)  # work_id, step_id, step_name

    def __init__(self, settings, parent=None):
        """
        Initialize creation view.

        Args:
            settings: Application settings instance
            parent: Parent widget
        """
        super().__init__(parent)
        self.settings = settings
        self.current_work_id: Optional[str] = None
        self.current_work: Optional[Dict[str, Any]] = None
        self.creation_state = "not_started"  # not_started, in_progress, paused
        self._volume_range: Optional[tuple] = None  # (start_volume, end_volume)
        self._step_status_map: Dict[str, str] = {}  # step_id -> status (pending, executing, completed)
        self._executing_step_id: Optional[str] = None
        self._streaming_step_id: Optional[str] = None  # Currently streaming step
        self._stream_buffer: str = ""  # Buffer for streaming content
        self._stream_timer: Optional[QTimer] = None  # Timer for streaming animation
        self._stream_index: int = int  # Current index in stream buffer
        self._content_map: Dict[str, str] = {}  # step_id -> full content
        self._current_viewing_step_id: Optional[str] = None  # Currently viewed step
        self._current_action_step_id: Optional[str] = None  # Currently selected step for action buttons
        self._current_action_step_name: Optional[str] = None  # Currently selected step name for action buttons
        self._content_changed_blocked: bool = False  # Flag to block recursive signals
        self._empty_state_widget: Optional[QWidget] = None  # Empty state widget

        # New creation task management attributes
        self.creation_task: Optional[CreationTask] = None
        self._task_status_logged: bool = False  # Track if task status was logged
        # Initialize logger
        from utils.logger import get_logger
        self.logger = get_logger()
        if self.logger is None:
            from utils.logger import setup_logger
            self.logger = setup_logger()
        if self.logger is None:
            import logging
            self.logger = logging.getLogger(__name__)
        self.setObjectName("creationView")
        self._setup_ui()
        self._apply_styles()
        # Show empty state initially (no work loaded yet)
        self.show_empty_state()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Top control bar (initially hidden, shown when work is loaded)
        self._setup_control_bar(layout)
        # Control bar widget is already saved in _setup_control_bar
        self.control_bar_widget.setVisible(False)

        # Main content area (splitter for left/right panels)
        self._setup_content_area(layout)

    def _setup_control_bar(self, parent_layout: QVBoxLayout) -> None:
        """Set up the top control bar."""
        control_bar = QFrame()
        control_bar.setObjectName("controlBar")
        control_bar.setFixedHeight(70)
        self.control_bar_widget = control_bar  # Save reference for visibility control

        control_layout = QHBoxLayout(control_bar)
        control_layout.setContentsMargins(20, 10, 20, 10)
        control_layout.setSpacing(20)

        # Creation control button
        self.btn_creation_control = QPushButton("开始创作")
        self.btn_creation_control.setObjectName("btnCreationControl")
        self.btn_creation_control.setFixedHeight(40)
        self.btn_creation_control.setToolTip("开始、暂停或继续 AI 创作流程")
        self.btn_creation_control.setAccessibleName("创作流程控制")
        self.btn_creation_control.setAccessibleDescription("开始、暂停或继续 AI 创作流程")
        self.btn_creation_control.clicked.connect(self._on_creation_control_clicked)
        control_layout.addWidget(self.btn_creation_control)

        # Save button
        self.btn_save = QPushButton("保存")
        self.btn_save.setObjectName("btnSave")
        self.btn_save.setFixedHeight(40)
        self.btn_save.setToolTip("保存当前步骤的内容")
        self.btn_save.setAccessibleName("保存")
        self.btn_save.setAccessibleDescription("保存当前步骤的内容")
        self.btn_save.clicked.connect(self._on_save_clicked)
        control_layout.addWidget(self.btn_save)

        # Status indicator
        status_container = QFrame()
        status_container.setObjectName("statusContainer")
        status_layout = QHBoxLayout(status_container)
        status_layout.setContentsMargins(15, 8, 15, 8)
        status_layout.setSpacing(10)

        self.lbl_status_indicator = QLabel("尚未开始创作")
        self.lbl_status_indicator.setObjectName("lblStatusIndicator")
        status_layout.addWidget(self.lbl_status_indicator)

        control_layout.addWidget(status_container)
        control_layout.addStretch()

        # Work info label
        self.lbl_work_info = QLabel("")
        self.lbl_work_info.setObjectName("lblWorkInfo")
        control_layout.addWidget(self.lbl_work_info)

        parent_layout.addWidget(control_bar)

    def _setup_content_area(self, parent_layout: QVBoxLayout) -> None:
        """Set up the main content area with left/right panels."""
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setObjectName("creationSplitter")
        splitter.setHandleWidth(4)
        splitter.setChildrenCollapsible(False)  # Prevent panels from collapsing

        # Left panel - Flow tree
        left_panel = self._create_left_panel()
        splitter.addWidget(left_panel)

        # Right panel - Content display
        right_panel = self._create_right_panel()
        splitter.addWidget(right_panel)

        # Set initial sizes (30% left, 70% right)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 0)  # Disable stretch to prevent height changes
        splitter.setSizes([350, 800])

        # Set minimum sizes for panels
        splitter.setMinimumWidth(800)

        parent_layout.addWidget(splitter)

    def _create_left_panel(self) -> QWidget:
        """Create the left panel with flow tree."""
        panel = QWidget()
        panel.setObjectName("leftPanel")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(15, 15, 10, 15)
        layout.setSpacing(10)

        # Section title
        title_label = QLabel("创作流程")
        title_label.setObjectName("panelTitle")
        layout.addWidget(title_label)

        # Flow tree
        self.flow_tree = QTreeWidget()
        self.flow_tree.setObjectName("flowTree")
        self.flow_tree.setHeaderHidden(True)
        self.flow_tree.setIndentation(20)
        self.flow_tree.setExpandsOnDoubleClick(False)
        self.flow_tree.itemClicked.connect(self._on_flow_tree_item_clicked)
        layout.addWidget(self.flow_tree)

        return panel

    def _create_right_panel(self) -> QWidget:
        """Create the right panel with content display."""
        panel = QWidget()
        panel.setObjectName("rightPanel")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 15, 15, 15)
        layout.setSpacing(5)

        # Section title with fixed height
        title_label = QLabel("内容预览")
        title_label.setObjectName("panelTitle")
        title_label.setFixedHeight(20)
        layout.addWidget(title_label)

        # Step name header (separate from editable content)
        self.step_header_label = QLabel()
        self.step_header_label.setObjectName("stepHeaderLabel")
        self.step_header_label.setVisible(False)  # Hidden by default
        self.step_header_label.setFixedHeight(20)
        layout.addWidget(self.step_header_label)

        # Action buttons (hidden by default, shown when step is selected)
        self.action_buttons_widget = QWidget()
        self.action_buttons_widget.setObjectName("actionButtonsWidget")
        self.action_buttons_widget.setVisible(False)
        action_layout = QHBoxLayout(self.action_buttons_widget)
        action_layout.setContentsMargins(0, 0, 0, 10)
        action_layout.setSpacing(10)

        # Template button
        self.btn_template = QPushButton("提示词")
        self.btn_template.setObjectName("btnTemplate")
        self.btn_template.setToolTip("查看和编辑此步骤的提示词模板")
        self.btn_template.setFixedHeight(32)
        self.btn_template.clicked.connect(self._on_template_button_clicked)
        action_layout.addWidget(self.btn_template)

        # Regenerate button
        self.btn_regenerate = QPushButton("重新生成")
        self.btn_regenerate.setObjectName("btnRegenerate")
        self.btn_regenerate.setToolTip("使用当前提示词模板重新生成此步骤内容")
        self.btn_regenerate.setFixedHeight(32)
        self.btn_regenerate.clicked.connect(self._on_regenerate_button_clicked)
        action_layout.addWidget(self.btn_regenerate)

        action_layout.addStretch()
        layout.addWidget(self.action_buttons_widget)

        # Content display area
        self.content_display = QTextEdit()
        self.content_display.setObjectName("contentDisplay")
        self.content_display.setReadOnly(False)
        self.content_display.setPlaceholderText("选择左侧流程步骤查看内容")
        self.content_display.setFont(QFont("Microsoft YaHei", 12))
        self.content_display.textChanged.connect(self._on_content_changed)
        layout.addWidget(self.content_display)

        # Word count label
        self.lbl_word_count = QLabel("字数：0")
        self.lbl_word_count.setObjectName("lblWordCount")
        layout.addWidget(self.lbl_word_count)

        return panel

    def _apply_styles(self) -> None:
        """Apply styles to the view."""
        self.setStyleSheet("""
            #creationView {
                background-color: #ffffff;
            }

            #controlBar {
                background-color: #f8f9fa;
                border-bottom: 1px solid #e0e0e0;
            }

            #btnCreationControl {
                background-color: #145a32;  /* Darker green for WCAG AA compliance */
                color: white;
                border: none;
                padding: 10px 24px;
                border-radius: 6px;
                font-size: 15px;
                font-weight: bold;
            }

            #btnCreationControl:hover {
                background-color: #0f4224;  /* Even darker on hover */
            }

            #btnCreationControl:disabled {
                background-color: #95a5a6;
            }

            #btnCreationControl.in-progress {
                background-color: #b95e00;  /* Darker orange for WCAG AA compliance */
            }

            #btnCreationControl.in-progress:hover {
                background-color: #9a5a00;  /* Even darker on hover */
            }

            #btnSave {
                background-color: #1a5276;  /* Darker blue for WCAG AA compliance */
                color: white;
                border: none;
                padding: 10px 24px;
                border-radius: 6px;
                font-size: 15px;
                font-weight: bold;
            }

            #btnSave:hover {
                background-color: #154360;  /* Even darker on hover */
            }

            #btnSave:disabled {
                background-color: #95a5a6;
            }

            #statusContainer {
                background-color: #ecf0f1;
                border-radius: 6px;
            }

            #lblStatusIndicator {
                font-size: 14px;
                color: #7f8c8d;
                font-weight: bold;
            }

            #lblStatusIndicator.in-progress {
                color: #2980b9;
            }

            #lblStatusIndicator.paused {
                color: #d35400;
            }

            #lblStatusIndicator.not-started {
                color: #7f8c8d;
            }

            #lblWorkInfo {
                font-size: 13px;
                color: #555555;
            }

            #creationSplitter {
                background-color: #ffffff;
            }

            #creationSplitter::handle {
                background-color: #e0e0e0;
            }

            #creationSplitter::handle:hover {
                background-color: #bdc3c7;
            }

            #leftPanel {
                background-color: #fafafa;
                border-right: 1px solid #e0e0e0;
            }

            #rightPanel {
                background-color: #ffffff;
            }

            #panelTitle {
                font-size: 15px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 5px;
            }

            #flowTree {
                background-color: #ffffff;
                border: 1px solid #e0e0e0;
                border-radius: 6px;
                padding: 5px;
                font-size: 13px;
                outline: none;
            }

            #flowTree::item {
                padding: 6px 8px;
                border-radius: 4px;
                border: none;
                outline: none;
            }

            #flowTree::item:hover {
                background-color: #ecf0f1;
            }

            #flowTree::item:selected {
                background-color: #1a5276;  /* Darker blue for WCAG AA compliance */
                color: white;
                border: none;
                outline: none;
            }

            #flowTree::item:focus {
                border: none;
                outline: none;
            }

            #flowTree::branch {
                border: none;
                outline: none;
            }

            #contentDisplay {
                background-color: #ffffff;
                border: 1px solid #e0e0e0;
                border-radius: 6px;
                font-size: 14px;
            }

            #contentDisplay:focus {
                border-color: #3498db;
            }

            #actionButtonsWidget {
                background-color: transparent;
            }

            #btnTemplate {
                background-color: #9b59b6;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }

            #btnTemplate:hover {
                background-color: #8e44ad;
            }

            #btnRegenerate {
                background-color: #e67e22;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }

            #btnRegenerate:hover {
                background-color: #d35400;
            }

            /* Empty State */
            #creationEmptyState {
                background-color: #ffffff;
            }

            #creationEmptyLabel {
                color: #2c3e50;
                font-size: 18px;
                font-weight: bold;
                padding: 20px;
            }

            #creationEmptyTip {
                color: #7f8c8d;
                font-size: 14px;
            }

            #creationEmptyGoToBtn {
                background-color: #1a5276;
                color: white;
                border: none;
                padding: 10px 24px;
                border-radius: 5px;
                font-size: 14px;
            }

            #creationEmptyGoToBtn:hover {
                background-color: #154360;
            }
        """)

    def load_work(self, work_data: Dict[str, Any]) -> None:
        """
        Load work data for creation.

        Args:
            work_data: Dictionary containing work information
        """
        self.current_work = work_data.copy()
        self.current_work_id = work_data.get('id')

        self.logger.info(f"[LOAD_WORK] Loading work: id={self.current_work_id}, title={work_data.get('title', 'Unknown')}")

        # Show control bar
        if hasattr(self, 'control_bar_widget') and self.control_bar_widget:
            self.control_bar_widget.setVisible(True)

        # Update work info label
        title = work_data.get('title', 'Untitled')
        category = work_data.get('category', '')
        self.lbl_work_info.setText(f"作品：{title} ({category})")

        # Reset creation state
        self.creation_state = "not_started"
        self._update_creation_state()

        # Build flow tree
        self.logger.info(f"[LOAD_WORK] About to build flow tree")
        self._build_flow_tree(work_data)
        self.logger.info(f"[LOAD_WORK] Flow tree built, top_level_count={self.flow_tree.topLevelItemCount()}")

        # Clear content display and header
        self.content_display.clear()
        self.content_display.setPlaceholderText("选择左侧流程步骤查看内容")
        self.step_header_label.setVisible(False)
        self._current_viewing_step_id = None

    def show_creation_content(self) -> None:
        """Show creation content area."""
        self.logger.info("[SHOW_CREATION_CONTENT] Showing creation content")

        # Show control bar
        if hasattr(self, 'control_bar_widget') and self.control_bar_widget:
            self.control_bar_widget.setVisible(True)

        # Hide empty state widget if it exists
        if hasattr(self, '_empty_state_widget') and self._empty_state_widget:
            self._empty_state_widget.deleteLater()
            self._empty_state_widget = None

        # Make sure splitter is visible
        main_layout = self.layout()
        if main_layout.count() > 1:
            item = main_layout.itemAt(1)
            if item and item.widget():
                widget = item.widget()
                if widget.objectName() == "creationSplitter":
                    widget.setVisible(True)

    def show_empty_state(self) -> None:
        """Show empty state when no work is selected."""
        self.logger.info("[EMPTY_STATE] Showing empty state for creation view")

        # Hide control bar
        if hasattr(self, 'control_bar_widget') and self.control_bar_widget:
            self.control_bar_widget.setVisible(False)

        # Clear current work
        self.current_work_id = None
        self.current_work = None
        self.creation_state = "not_started"
        self._update_creation_state()

        # Clear work info label
        self.lbl_work_info.setText("")

        # Clear flow tree
        self.flow_tree.clear()

        # Clear content display
        self.content_display.clear()
        self.content_display.setPlaceholderText("选择左侧流程步骤查看内容")
        self.step_header_label.setVisible(False)
        self._current_viewing_step_id = None

        # Hide action buttons
        self.action_buttons_widget.setVisible(False)

        # Hide the splitter
        main_layout = self.layout()
        if main_layout.count() > 1:
            splitter = main_layout.itemAt(1).widget()
            if splitter:
                splitter.setVisible(False)

        # Remove old empty state widget if it exists
        if hasattr(self, '_empty_state_widget') and self._empty_state_widget:
            self._empty_state_widget.deleteLater()
            self._empty_state_widget = None

        # Create empty state widget
        empty_widget = QWidget()
        empty_widget.setObjectName("creationEmptyState")
        empty_layout = QVBoxLayout(empty_widget)
        empty_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        empty_layout.setSpacing(20)

        # Empty state icon
        icon_label = QLabel()
        icon_label.setObjectName("creationEmptyIcon")
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_label.setText("\U0001F4DD")  # Memo/pencil emoji
        icon_label.setStyleSheet("""
            QLabel#creationEmptyIcon {
                font-size: 72px;
                color: #bdc3c7;
            }
        """)
        empty_layout.addWidget(icon_label)

        # Empty message
        empty_label = QLabel("暂无作品正在创作")
        empty_label.setObjectName("creationEmptyLabel")
        empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        empty_label.setStyleSheet("""
            QLabel#creationEmptyLabel {
                color: #2c3e50;
                font-size: 18px;
                font-weight: bold;
                padding: 20px;
            }
        """)
        empty_layout.addWidget(empty_label)

        # Tip label
        tip_label = QLabel("请在作品库选择作品，然后开始创作")
        tip_label.setObjectName("creationEmptyTip")
        tip_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        tip_label.setStyleSheet("""
            QLabel#creationEmptyTip {
                color: #7f8c8d;
                font-size: 14px;
            }
        """)
        empty_layout.addWidget(tip_label)

        # Go to workspace button
        go_to_btn = QPushButton("前往作品库")
        go_to_btn.setObjectName("creationEmptyGoToBtn")
        go_to_btn.setMinimumWidth(150)
        go_to_btn.setMaximumWidth(250)
        go_to_btn.setFixedHeight(40)
        go_to_btn.setToolTip("跳转到作品库页面选择作品")
        go_to_btn.setAccessibleName("前往作品库")
        go_to_btn.setAccessibleDescription("跳转到作品库页面选择作品开始创作")
        go_to_btn.clicked.connect(self._on_go_to_workspace_clicked)
        empty_layout.addWidget(go_to_btn)

        # Add empty widget to content area
        main_layout.addWidget(empty_widget, 1)
        self._empty_state_widget = empty_widget

        self.logger.info("[EMPTY_STATE] Empty state displayed")

    def _on_go_to_workspace_clicked(self) -> None:
        """Handle go to workspace button click."""
        self.logger.info("[WORKSPACE_NAV] Go to workspace button clicked")
        self.go_to_workspace_requested.emit()

    def create_creation_task(
        self,
        work_id: str,
        work_data: Dict[str, Any],
        start_volume: int,
        end_volume: int
    ) -> None:
        """
        创建创作任务结构体

        Args:
            work_id: 作品 ID
            work_data: 作品数据
            start_volume: 起始卷号
            end_volume: 结束卷号
        """
        self.logger.info(f"[CREATE_TASK] Creating task for work {work_id}, volumes {start_volume}-{end_volume}")

        # 创建任务
        self.creation_task = CreationTaskBuilder.build_task(
            work_id, work_data, start_volume, end_volume, self.settings
        )

        # Log initial task status
        self.logger.info(f"[TASK_STATUS] Task created with {len(self.creation_task.sessions)} sessions, {self.creation_task.total_step_count} steps")

        self.logger.info(f"[CREATE_TASK] Task created with {len(self.creation_task.sessions)} sessions")

    def _build_flow_tree_from_task(self) -> None:
        """从任务结构体构建流程图 UI - 保持原有的树状结构显示方式"""
        if not self.creation_task:
            return

        self.flow_tree.clear()
        self._content_map.clear()
        self._step_status_map.clear()

        self.logger.info(f"[BUILD_TREE] Building flow tree from task with {self.creation_task.total_step_count} steps, {len(self.creation_task.sessions)} sessions")

        # 构建 step_id 到 step 对象的映射，方便查找
        step_map = {}
        for session in self.creation_task.sessions:
            self.logger.info(f"[BUILD_TREE] Session: {session.session_id}, type={session.session_type}, steps={len(session.steps)}")
            for step in session.steps:
                step_map[step.step_id] = step

        # 1. 基本设定节点
        basic_info = QTreeWidgetItem(["基本设定"])
        basic_info.setData(0, Qt.ItemDataRole.UserRole, "basic_info")
        basic_info.setExpanded(True)

        basic_steps_map = [
            ("文风设定", "style_setting"),
            ("故事梗概", "story_summary"),
            ("时空设定", "worldbuilding"),
            ("人物设定", "character_design"),
            ("书名", "book_title"),
            ("封面图片", "cover_image"),
        ]

        for step_name, step_id in basic_steps_map:
            # 从任务中查找步骤状态
            step_obj = step_map.get(step_id)
            status = step_obj.status if step_obj else "pending"
            content = step_obj.content if step_obj else ""
            self._add_step_to_tree(basic_info, step_id, step_name, status, content)

        self.flow_tree.addTopLevelItem(basic_info)

        # 2. 创作参考节点
        creation_reference = QTreeWidgetItem(["创作参考"])
        creation_reference.setData(0, Qt.ItemDataRole.UserRole, "creation_reference")

        # 拆书参考子节点
        reference_analysis_item = QTreeWidgetItem(["拆书参考"])
        reference_analysis_item.setData(0, Qt.ItemDataRole.UserRole, "reference_analysis_parent")

        # 创作公式子节点
        pattern_analysis_item = QTreeWidgetItem(["创作公式"])
        pattern_analysis_item.setData(0, Qt.ItemDataRole.UserRole, "pattern_analysis_parent")

        # 先从任务中查找参考会话，添加实际步骤到子节点
        self.logger.info(f"[BUILD_TREE] Finding reference sessions...")
        ref_step_count = 0
        pattern_step_count = 0
        for session in self.creation_task.sessions:
            self.logger.info(f"[BUILD_TREE] Checking session: {session.session_id}, type={session.session_type}")
            if session.session_type == "reference":
                if session.session_id.startswith("reference_"):
                    self.logger.info(f"[BUILD_TREE] Adding reference steps from {session.session_id}, step_count={len(session.steps)}")
                    for step in session.steps:
                        self._add_step_to_tree(reference_analysis_item, step.step_id, step.step_name, step.status, step.content)
                        ref_step_count += 1
                        self.logger.info(f"[BUILD_TREE] Added ref step: {step.step_name}, ref_children_now={reference_analysis_item.childCount()}")
                elif session.session_id == "pattern_analysis":
                    self.logger.info(f"[BUILD_TREE] Adding pattern steps from {session.session_id}, step_count={len(session.steps)}")
                    for step in session.steps:
                        self._add_step_to_tree(pattern_analysis_item, step.step_id, step.step_name, step.status, step.content)
                        pattern_step_count += 1
                        self.logger.info(f"[BUILD_TREE] Added pattern step: {step.step_name}, pattern_children_now={pattern_analysis_item.childCount()}")

        self.logger.info(f"[BUILD_TREE] Reference steps collected: ref={ref_step_count}, pattern={pattern_step_count}")

        # 将子节点添加到父节点
        creation_reference.addChild(reference_analysis_item)
        creation_reference.addChild(pattern_analysis_item)
        # 将父节点添加到树中
        self.flow_tree.addTopLevelItem(creation_reference)

        self.logger.info(f"[BUILD_TREE] Creation reference final: child_count={creation_reference.childCount()}, ref_children={reference_analysis_item.childCount()}, pattern_children={pattern_analysis_item.childCount()}")

        # 添加到树后再设置展开状态
        creation_reference.setExpanded(True)
        reference_analysis_item.setExpanded(True)
        pattern_analysis_item.setExpanded(True)

        # 3. 分卷信息节点
        volume_info = QTreeWidgetItem(["分卷信息"])
        volume_info.setData(0, Qt.ItemDataRole.UserRole, "volume_info")

        self.logger.info(f"[BUILD_TREE] Finding volume sessions...")
        volume_step_count = 0
        for session in self.creation_task.sessions:
            if session.session_type == "volume":
                self.logger.info(f"[BUILD_TREE] Adding volume steps from {session.session_id}, step_count={len(session.steps)}")
                for step in session.steps:
                    self._add_step_to_tree(volume_info, step.step_id, step.step_name, step.status, step.content)
                    volume_step_count += 1

        self.logger.info(f"[BUILD_TREE] Volume steps collected: {volume_step_count}")
        self.flow_tree.addTopLevelItem(volume_info)
        volume_info.setExpanded(True)  # 添加到树后设置展开
        self.logger.info(f"[BUILD_TREE] Volume info added, child_count={volume_info.childCount()}")

        # 4. 章节内容节点（按卷分组）
        self.logger.info(f"[BUILD_TREE] Adding chapter sessions for volumes {self.creation_task.start_volume}-{self.creation_task.end_volume}")
        chapter_step_count = 0
        for vol_num in range(self.creation_task.start_volume, self.creation_task.end_volume + 1):
            volume_chapters = QTreeWidgetItem([f"第{vol_num}卷 章节信息"])
            volume_chapters.setData(0, Qt.ItemDataRole.UserRole, f"volume_{vol_num}_chapters")

            for session in self.creation_task.sessions:
                if session.session_id == f"chapter_{vol_num}":
                    self.logger.info(f"[BUILD_TREE] Adding chapter steps from {session.session_id}, step_count={len(session.steps)}")
                    for step in session.steps:
                        self._add_step_to_tree(volume_chapters, step.step_id, step.step_name, step.status, step.content)
                        chapter_step_count += 1

            self.flow_tree.addTopLevelItem(volume_chapters)
            volume_chapters.setExpanded(True)  # 添加到树后设置展开
            self.logger.info(f"[BUILD_TREE] Volume {vol_num} chapters added, child_count={volume_chapters.childCount()}")

            # 分卷总结节点（如果有）
            summary_session = None
            for session in self.creation_task.sessions:
                if session.session_id == f"volume_summary_{vol_num}":
                    summary_session = session
                    break

            if summary_session:
                volume_summary = QTreeWidgetItem([f"第{vol_num}卷 分卷总结"])
                volume_summary.setData(0, Qt.ItemDataRole.UserRole, f"volume_{vol_num}_summary")

                for step in summary_session.steps:
                    self._add_step_to_tree(volume_summary, step.step_id, step.step_name, step.status, step.content)

                self.flow_tree.addTopLevelItem(volume_summary)
                volume_summary.setExpanded(True)  # 添加到树后设置展开

        # 强制刷新树视图
        self.flow_tree.expandAll()

        # 使用 QTimer 确保在事件循环中执行展开和刷新
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(0, lambda: (self.flow_tree.expandAll(), self.flow_tree.viewport().update()))

        self.logger.info(f"[BUILD_TREE] Flow tree built with {self.flow_tree.topLevelItemCount()} top-level items")

    def _add_step_to_tree(
        self,
        parent_item: QTreeWidgetItem,
        step_id: str,
        step_name: str,
        status: str = "pending",
        content: str = ""
    ) -> None:
        """
        添加步骤到树节点的辅助方法

        Args:
            parent_item: 父节点
            step_id: 步骤 ID
            step_name: 步骤名称
            status: 步骤状态
            content: 步骤内容
        """
        display_name = step_name

        # For chapter content steps, try to get actual chapter title for display
        if step_id.endswith('_content') and step_id.startswith('chapter_'):
            # Extract vol_num and chapter_num from step_id like "chapter_1_3_content"
            parts = step_id.split('_')
            if len(parts) >= 4:
                vol_num = parts[1]
                chapter_num = parts[2]
                # Try to read title file
                if self.current_work_id:
                    steps_dir = Path(self.settings.works_dir) / self.current_work_id / 'steps'
                    title_file = steps_dir / f'chapter_{vol_num}_{chapter_num}_title.txt'
                    if title_file.exists():
                        title_content = title_file.read_text(encoding='utf-8').strip()
                        if title_content:
                            display_name = f"第{chapter_num}章 {title_content}"

        item = QTreeWidgetItem([display_name])
        item.setData(0, Qt.ItemDataRole.UserRole, step_id)

        if status == "completed" and content:
            self._content_map[step_id] = content
            self._step_status_map[step_id] = "completed"
            item.setForeground(0, QBrush(QColor("#006400")))
            item.setText(0, f"\u2713 {display_name}")
        elif status == "executing":
            self._step_status_map[step_id] = "executing"
            item.setForeground(0, QBrush(QColor(Qt.GlobalColor.darkBlue)))
            item.setText(0, f"\u27f3 {display_name}")
        else:
            self._step_status_map[step_id] = "pending"

        parent_item.addChild(item)

    def _build_flow_tree(self, work_data: Dict[str, Any]) -> None:
        """
        Build the flow tree based on work data.

        Args:
            work_data: Dictionary containing work information
        """
        self.flow_tree.clear()
        self._content_map.clear()
        self._step_status_map.clear()

        self.logger.info(f"[FLOW_TREE] Building flow tree, current_work_id={self.current_work_id}")

        # Basic info section (without 拆书参考 and 创作公式 - those go to 创作参考)
        basic_info = QTreeWidgetItem(["基本设定"])
        basic_info.setData(0, Qt.ItemDataRole.UserRole, "basic_info")
        basic_info.setExpanded(True)

        basic_steps = [
            ("文风设定", "style_setting"),
            ("故事梗概", "story_summary"),
            ("时空设定", "worldbuilding"),
            ("人物设定", "character_design"),
            ("书名", "book_title"),
            ("封面图片", "cover_image"),
        ]

        for step_name, step_id in basic_steps:
            item = QTreeWidgetItem([step_name])
            item.setData(0, Qt.ItemDataRole.UserRole, step_id)
            # Load content from steps/ directory only
            content = None
            if self.current_work_id:
                content = self._load_step_content_from_disk(step_id)
            if content:
                self._content_map[step_id] = content
                self._step_status_map[step_id] = "completed"
                item.setForeground(0, QBrush(QColor("#006400")))
                item.setText(0, f"\u2713 {step_name}")
            basic_info.addChild(item)
            self.logger.info(f"[FLOW_TREE] Added basic step: {step_name}, has_content={bool(content)}")

        self.flow_tree.addTopLevelItem(basic_info)
        self.logger.info(f"[FLOW_TREE] Basic info added, child_count={basic_info.childCount()}")

        # Creation reference section (创作参考) - dynamically generated based on selected reference works
        creation_reference = QTreeWidgetItem(["创作参考"])
        creation_reference.setData(0, Qt.ItemDataRole.UserRole, "creation_reference")
        creation_reference.setExpanded(True)

        # Add 拆书参考 sub-item (will have dynamic sub-steps for each reference work)
        reference_analysis_item = QTreeWidgetItem(["拆书参考"])
        reference_analysis_item.setData(0, Qt.ItemDataRole.UserRole, "reference_analysis_parent")
        reference_analysis_item.setExpanded(True)

        # Add 创作公式 sub-item
        pattern_analysis_item = QTreeWidgetItem(["创作公式"])
        pattern_analysis_item.setData(0, Qt.ItemDataRole.UserRole, "pattern_analysis_parent")
        pattern_analysis_item.setExpanded(True)

        creation_reference.addChild(reference_analysis_item)
        creation_reference.addChild(pattern_analysis_item)
        self.flow_tree.addTopLevelItem(creation_reference)
        self.logger.info(f"[FLOW_TREE] Creation reference added, child_count={creation_reference.childCount()}")

        # Volume outlines section
        chapters_per_volume = work_data.get('chapters_per_volume', 20)
        volume_outline = QTreeWidgetItem(["分卷信息"])
        volume_outline.setData(0, Qt.ItemDataRole.UserRole, "volume_outlines")

        # Add placeholder volume items (actual count determined when creation starts)
        for i in range(1, 4):  # Placeholder for 3 volumes
            volume_item = QTreeWidgetItem([f"第{i}卷"])
            # Don't set step_id on volume_item - it's just a group header
            # Only the sub-items (分卷大纲，分卷人物) should have step_ids
            volume_item.setData(0, Qt.ItemDataRole.UserRole, f"volume_group_{i}")
            volume_item.setExpanded(True)

            # Add sub-items for each volume
            sub_steps = [
                ("分卷大纲", f"volume_{i}"),
                ("分卷人物", f"volume_{i}_characters"),
            ]
            for sub_name, sub_id in sub_steps:
                sub_item = QTreeWidgetItem([sub_name])
                sub_item.setData(0, Qt.ItemDataRole.UserRole, sub_id)

                # Check disk for existing content
                content = self._load_step_content_from_disk(sub_id)
                if content:
                    self._content_map[sub_id] = content
                    self._step_status_map[sub_id] = "completed"
                    sub_item.setForeground(0, QBrush(QColor("#006400")))
                    sub_item.setText(0, f"\u2713 {sub_name}")
                    self.logger.info(f"[FLOW_TREE] Volume {i} sub-step {sub_name} has content")

                volume_item.addChild(sub_item)
                self.logger.info(f"[FLOW_TREE] Added sub-step {sub_name} to volume {i}")

            volume_outline.addChild(volume_item)
            self.logger.info(f"[FLOW_TREE] Volume {i} added, child_count={volume_item.childCount()}")

        self.flow_tree.addTopLevelItem(volume_outline)
        volume_outline.setExpanded(True)  # Expand AFTER adding to tree
        self.logger.info(f"[FLOW_TREE] Volume outline added, child_count={volume_outline.childCount()}, expanded={volume_outline.isExpanded()}")

        # Chapter content section
        chapter_content = QTreeWidgetItem(["章节信息"])
        chapter_content.setData(0, Qt.ItemDataRole.UserRole, "chapter_content")
        chapter_content.setExpanded(True)

        # Placeholder chapter items (actual count determined when creation starts)
        chapters_per_volume = work_data.get('chapters_per_volume', 20)
        display_chapters = min(chapters_per_volume, 5)  # Show first 5 chapters as placeholder

        # Track chapter items for later expansion
        chapter_items_to_expand = []

        for i in range(1, display_chapters + 1):
            chapter_item = QTreeWidgetItem([f"第 1 卷 第{i}章"])
            # Don't set step_id on chapter_item - it's just a group header
            # Only the sub-items (章节大纲，章节标题，章节正文) should have step_ids
            chapter_item.setData(0, Qt.ItemDataRole.UserRole, f"chapter_group_1_{i}")

            # Add sub-items for each chapter (3 steps: 章节大纲，章节标题，章节正文)
            sub_steps = [
                ("章节大纲", f"chapter_1_{i}_outline"),
                (f"第{i}章 章节标题", f"chapter_1_{i}_title"),
                ("章节正文", f"chapter_1_{i}_content"),
            ]
            for sub_name, sub_id in sub_steps:
                # For chapter content, try to get actual chapter title for display
                display_name = sub_name
                if sub_id.endswith('_content'):
                    # Try to read title file
                    steps_dir = Path(self.settings.works_dir) / self.current_work_id / 'steps'
                    title_file = steps_dir / (sub_id.replace('_content', '_title') + '.txt')
                    if title_file.exists():
                        title_content = title_file.read_text(encoding='utf-8').strip()
                        if title_content:
                            display_name = f"第{i}章 {title_content}"
                sub_item = QTreeWidgetItem([display_name])
                sub_item.setData(0, Qt.ItemDataRole.UserRole, sub_id)

                # Check disk for existing content
                content = self._load_step_content_from_disk(sub_id)
                if content:
                    self._content_map[sub_id] = content
                    self._step_status_map[sub_id] = "completed"
                    sub_item.setForeground(0, QBrush(QColor("#006400")))
                    sub_item.setText(0, f"\u2713 {display_name}")

                chapter_item.addChild(sub_item)

            chapter_content.addChild(chapter_item)
            chapter_items_to_expand.append(chapter_item)

        self.flow_tree.addTopLevelItem(chapter_content)
        self.logger.info(f"[FLOW_TREE] Chapter content added, child_count={chapter_content.childCount()}")

        # Expand chapter items after tree is built to show character list sections
        for chapter_item in chapter_items_to_expand:
            chapter_item.setExpanded(True)

        # Expand all top-level items to show content
        for i in range(self.flow_tree.topLevelItemCount()):
            self.flow_tree.topLevelItem(i).setExpanded(True)

        # Force tree update
        self.flow_tree.viewport().update()
        self.logger.info(f"[FLOW_TREE] Flow tree build complete, top_level_count={self.flow_tree.topLevelItemCount()}")

        # Log all top-level items and their children
        for i in range(self.flow_tree.topLevelItemCount()):
            top_item = self.flow_tree.topLevelItem(i)
            self.logger.info(f"[FLOW_TREE] Top item {i}: {top_item.text(0)}, child_count={top_item.childCount()}, expanded={top_item.isExpanded()}")

    def set_volume_range(self, start_volume: int, end_volume: int) -> None:
        """
        Set the volume range for creation and rebuild the flow tree.

        Args:
            start_volume: Starting volume number
            end_volume: Ending volume number
        """
        if not self.current_work:
            return

        # Store the volume range
        self._volume_range = (start_volume, end_volume)

        # Also update current_work with start_volume and end_volume
        # This is needed for _populate_reference_steps to calculate chapter range correctly
        self.current_work['start_volume'] = start_volume
        self.current_work['end_volume'] = end_volume

        # Rebuild the flow tree with actual volumes
        self._build_flow_tree_with_volumes(start_volume, end_volume)

    def _build_flow_tree_with_volumes(
        self,
        start_volume: int,
        end_volume: int
    ) -> None:
        """
        Rebuild the flow tree with actual volume range.

        Args:
            start_volume: Starting volume number
            end_volume: Ending volume number
        """
        self.logger.info(f"[FLOW_TREE_VOLUMES] Starting to build tree with volumes {start_volume}-{end_volume}")
        self.logger.info(f"[FLOW_TREE_VOLUMES] current_work_id={self.current_work_id}, current_work={bool(self.current_work)}")

        self.flow_tree.clear()
        self._content_map.clear()
        self._step_status_map.clear()

        # Populate basic info content from steps/ directory files
        # Note: AI-generated content is stored in steps/ directory, not in work_info.json
        if self.current_work_id:
            basic_steps = ["style_setting", "story_summary", "worldbuilding", "character_design", "book_title", "cover_image"]
            for step_id in basic_steps:
                content = self._load_step_content_from_disk(step_id)
                if content:
                    self._content_map[step_id] = content
                    self._step_status_map[step_id] = "completed"

        # Basic info section (without 拆书参考 and 创作公式 - those go to 创作参考)
        basic_info = QTreeWidgetItem(["基本设定"])
        basic_info.setData(0, Qt.ItemDataRole.UserRole, "basic_info")
        basic_info.setExpanded(True)

        basic_steps = [
            ("文风设定", "style_setting"),
            ("故事梗概", "story_summary"),
            ("时空设定", "worldbuilding"),
            ("人物设定", "character_design"),
            ("书名", "book_title"),
            ("封面图片", "cover_image"),
        ]

        self.logger.info(f"[FLOW_TREE_VOLUMES] Building basic info section")
        for step_name, step_id in basic_steps:
            item = QTreeWidgetItem([step_name])
            item.setData(0, Qt.ItemDataRole.UserRole, step_id)

            # Load content from steps/ directory only
            # Note: book_title and cover_image are the only fields stored in work_info.json,
            # but we load them from steps/ directory for consistency
            content = None
            if self.current_work_id:
                content = self._load_step_content_from_disk(step_id)
                self.logger.info(f"[FLOW_TREE_VOLUMES] Step {step_name}: content_from_disk={bool(content)}")

            if content:
                self._content_map[step_id] = content
                self._step_status_map[step_id] = "completed"
                item.setForeground(0, QBrush(QColor("#006400")))
                item.setText(0, f"\u2713 {step_name}")
                item.setToolTip(0, f"已从 steps/{step_id}.txt 加载")

            basic_info.addChild(item)
            self.logger.info(f"[FLOW_TREE_VOLUMES] Added basic step {step_name}, child_count={basic_info.childCount()}")

        self.flow_tree.addTopLevelItem(basic_info)
        self.logger.info(f"[FLOW_TREE_VOLUMES] Basic info added to tree, child_count={basic_info.childCount()}")

        # Creation reference section (创作参考) - dynamically generated based on selected reference works
        creation_reference = QTreeWidgetItem(["创作参考"])
        creation_reference.setData(0, Qt.ItemDataRole.UserRole, "creation_reference")
        creation_reference.setExpanded(True)

        # Add 拆书参考 sub-item (will have dynamic sub-steps for each reference work)
        reference_analysis_item = QTreeWidgetItem(["拆书参考"])
        reference_analysis_item.setData(0, Qt.ItemDataRole.UserRole, "reference_analysis_parent")
        reference_analysis_item.setExpanded(True)

        # Add 创作公式 sub-item
        pattern_analysis_item = QTreeWidgetItem(["创作公式"])
        pattern_analysis_item.setData(0, Qt.ItemDataRole.UserRole, "pattern_analysis_parent")
        pattern_analysis_item.setExpanded(True)

        creation_reference.addChild(reference_analysis_item)
        creation_reference.addChild(pattern_analysis_item)
        self.flow_tree.addTopLevelItem(creation_reference)
        self.logger.info(f"[FLOW_TREE_VOLUMES] Creation reference added, child_count={creation_reference.childCount()}")

        # Volume outlines section with actual volumes
        volume_outline = QTreeWidgetItem(["分卷信息"])
        volume_outline.setData(0, Qt.ItemDataRole.UserRole, "volume_outlines")

        self.logger.info(f"[FLOW_TREE] Building volume section: volumes {start_volume}-{end_volume}")

        # Add volume_outline to tree FIRST so child items can be expanded properly
        self.flow_tree.addTopLevelItem(volume_outline)
        volume_outline.setExpanded(True)  # Expand AFTER adding to tree
        self.logger.info(f"[FLOW_TREE] Volume outline added to tree first, expanded={volume_outline.isExpanded()}")

        for vol_num in range(start_volume, end_volume + 1):
            volume_item = QTreeWidgetItem([f"第{vol_num}卷"])
            # Don't set step_id on volume_item - it's just a group header
            # Only the sub-items (分卷大纲，分卷人物) should have step_ids
            volume_item.setData(0, Qt.ItemDataRole.UserRole, f"volume_group_{vol_num}")

            self.logger.info(f"[DEBUG] === Creating volume item: 第{vol_num}卷 ===")

            # Add sub-items for each volume
            sub_steps = [
                ("分卷大纲", f"volume_{vol_num}"),
                ("分卷人物", f"volume_{vol_num}_characters"),
            ]
            for sub_name, sub_id in sub_steps:
                sub_item = QTreeWidgetItem([sub_name])
                sub_item.setData(0, Qt.ItemDataRole.UserRole, sub_id)

                # Try to load content from disk and mark as completed if exists
                content = self._load_step_content_from_disk(sub_id)
                self.logger.info(f"[DEBUG] Volume sub-step: sub_id={sub_id}, sub_name={sub_name}, content_found={bool(content)}")

                if content:
                    self._step_status_map[sub_id] = "completed"
                    brush = QBrush(QColor("#006400"))
                    sub_item.setForeground(0, brush)
                    sub_item.setText(0, f"\u2713 {sub_name}")
                    self.logger.info(f"[DEBUG] Marked as completed: {sub_name}")
                else:
                    self.logger.info(f"[DEBUG] No content for {sub_id}")

                volume_item.addChild(sub_item)
                self.logger.info(f"[DEBUG] Added sub-item '{sub_name}' to volume {vol_num}")

            # Add volume item to parent
            volume_outline.addChild(volume_item)

            # Now expand - this will work because volume_outline is already in the tree
            volume_item.setExpanded(True)
            self.logger.info(f"[FLOW_TREE] Volume {vol_num} item expanded: {volume_item.isExpanded()}, child_count={volume_item.childCount()}")

        self.logger.info(f"[FLOW_TREE] Volume outline expanded: {volume_outline.isExpanded()}")

        # Chapter content section - use creation_task sessions
        for vol_num in range(start_volume, end_volume + 1):
            # Find the chapter session for this volume
            chapter_session = None
            for session in self.creation_task.sessions:
                if session.session_id == f"chapter_{vol_num}":
                    chapter_session = session
                    break

            if chapter_session:
                # Create top-level item for this volume's chapters
                volume_chapters = QTreeWidgetItem([f"第{vol_num}卷 章节信息"])
                volume_chapters.setData(0, Qt.ItemDataRole.UserRole, f"volume_{vol_num}_chapters")

                # Add each step from the session directly (no chapter sub-grouping)
                for step in chapter_session.steps:
                    self._add_step_to_tree(volume_chapters, step.step_id, step.step_name, step.status, step.content)

                self.flow_tree.addTopLevelItem(volume_chapters)
                volume_chapters.setExpanded(True)
                self.logger.info(f"[FLOW_TREE] Volume {vol_num} chapters added from session, child_count={volume_chapters.childCount()}")

            # Find and add volume summary as separate top-level item
            summary_session = None
            for session in self.creation_task.sessions:
                if session.session_id == f"volume_summary_{vol_num}":
                    summary_session = session
                    break

            if summary_session:
                summary_item = QTreeWidgetItem([f"第{vol_num}卷 分卷总结"])
                summary_item.setData(0, Qt.ItemDataRole.UserRole, f"volume_summary_group_{vol_num}")

                for step in summary_session.steps:
                    self._add_step_to_tree(summary_item, step.step_id, step.step_name, step.status, step.content)

                self.flow_tree.addTopLevelItem(summary_item)
                summary_item.setExpanded(True)

        # Expand all top-level items to show content
        for i in range(self.flow_tree.topLevelItemCount()):
            top_item = self.flow_tree.topLevelItem(i)
            top_item.setExpanded(True)
            self.logger.info(f"[FLOW_TREE_VOLUMES] Top item {i} '{top_item.text(0)}' expanded: {top_item.isExpanded()}")

        # Force tree update
        self.flow_tree.viewport().update()
        self.logger.info(f"[FLOW_TREE_VOLUMES] Flow tree build complete with {len(self._step_status_map)} completed steps")
        self.logger.info(f"[FLOW_TREE_VOLUMES] Top level item count: {self.flow_tree.topLevelItemCount()}")

        # Populate dynamic reference analysis and pattern analysis sub-steps
        self._populate_reference_steps()

    def _populate_reference_steps(self) -> None:
        """
        Populate dynamic reference analysis and pattern analysis sub-steps in the flow tree.

        This method:
        1. Gets reference works and chapter range from current_work
        2. Creates sub-steps for each reference work (拆书参考)
        3. Creates single pattern analysis step (创作公式)
        4. Checks disk for existing content and marks steps as completed
        """
        if not self.current_work:
            return

        # Get reference works and chapter range
        reference_works = self.current_work.get('reference_works', [])
        chapters_per_volume = self.current_work.get('chapters_per_volume', 5)
        start_volume = self.current_work.get('start_volume', 1)
        end_volume = self.current_work.get('end_volume', 1)

        # Calculate chapter range based on volumes
        # Formula: chapter_range = volume_range * chapters_per_volume
        # Example: volumes 1-3, 5 chapters/volume = chapters 1-15
        # Example: volumes 5-6, 5 chapters/volume = chapters 21-30
        start_chapter = (start_volume - 1) * chapters_per_volume + 1
        end_chapter = end_volume * chapters_per_volume

        # Find reference analysis and pattern analysis parent items
        reference_analysis_parent = None
        pattern_analysis_parent = None

        for i in range(self.flow_tree.topLevelItemCount()):
            top_item = self.flow_tree.topLevelItem(i)
            if top_item.text(0) == "创作参考":
                # Find child items
                for j in range(top_item.childCount()):
                    child_item = top_item.child(j)
                    if child_item.text(0) == "拆书参考":
                        reference_analysis_parent = child_item
                    elif child_item.text(0) == "创作公式":
                        pattern_analysis_parent = child_item
                break

        if not reference_analysis_parent or not pattern_analysis_parent:
            self.logger.warning("[POPULATE_REFERENCE] Could not find reference analysis or pattern analysis parent items")
            return

        # Clear existing children (placeholder items)
        reference_analysis_parent.takeChildren()
        pattern_analysis_parent.takeChildren()

        self.logger.info(f"[POPULATE_REFERENCE] Populating reference steps for {len(reference_works)} works, chapters {start_chapter}-{end_chapter}")

        # Add sub-steps for each reference work (拆书参考)
        for work_name in reference_works:
            safe_work_name = work_name.replace('/', '_').replace('\\', '_').replace(':', '_')
            step_id = f"reference_{safe_work_name}_{start_chapter}_{end_chapter}"
            # Extract only the second part if work_name contains '/'
            if '/' in work_name:
                work_name_only = work_name.split('/')[1]
            else:
                work_name_only = work_name
            step_name = f"{work_name_only}({start_chapter}-{end_chapter}章拆书)"

            sub_item = QTreeWidgetItem([step_name])
            sub_item.setData(0, Qt.ItemDataRole.UserRole, step_id)

            # Check disk for existing content
            content = self._load_step_content_from_disk(step_id)
            if content:
                self._content_map[step_id] = content
                self._step_status_map[step_id] = "completed"
                sub_item.setForeground(0, QBrush(QColor("#006400")))
                sub_item.setText(0, f"\u2713 {step_name}")
                self.logger.info(f"[POPULATE_REFERENCE] Found existing content for {step_id}")

            reference_analysis_parent.addChild(sub_item)

        # Add pattern analysis step (创作公式)
        if reference_works:
            # Extract second part after '/' first, then truncate to 10 chars
            short_names = []
            for w in reference_works[:3]:
                if '/' in w:
                    short_names.append(w.split('/')[1][:10])
                else:
                    short_names.append(w[:10])
            work_names_short = '_'.join(short_names)
            if len(reference_works) > 3:
                work_names_short += f"_etc{len(reference_works)-3}"

            step_id = f"pattern_{work_names_short}_{start_chapter}_{end_chapter}"
            step_name = f"创作公式({start_chapter}-{end_chapter}章)"

            pattern_item = QTreeWidgetItem([step_name])
            pattern_item.setData(0, Qt.ItemDataRole.UserRole, step_id)

            # Check disk for existing content
            content = self._load_step_content_from_disk(step_id)
            if content:
                self._content_map[step_id] = content
                self._step_status_map[step_id] = "completed"
                pattern_item.setForeground(0, QBrush(QColor("#006400")))
                pattern_item.setText(0, f"\u2713 {step_name}")
                self.logger.info(f"[POPULATE_REFERENCE] Found existing content for pattern {step_id}")

            pattern_analysis_parent.addChild(pattern_item)

        # Expand parent items to show sub-steps
        reference_analysis_parent.setExpanded(True)
        pattern_analysis_parent.setExpanded(True)

        self.logger.info(f"[POPULATE_REFERENCE] Reference steps populated, reference_analysis children: {reference_analysis_parent.childCount()}, pattern_analysis children: {pattern_analysis_parent.childCount()}")

    def _update_creation_state(self) -> None:
        """Update UI based on current creation state."""
        if self.creation_state == "not_started":
            self.btn_creation_control.setText("开始创作")
            self.btn_creation_control.setProperty("class", "")
            self.lbl_status_indicator.setText("尚未开始创作")
            self.lbl_status_indicator.setProperty("class", "not-started")
            self.btn_creation_control.setEnabled(True)
        elif self.creation_state == "in_progress":
            self.btn_creation_control.setText("暂停创作")
            self.btn_creation_control.setProperty("class", "in-progress")
            self.lbl_status_indicator.setText("正在创作中")
            self.lbl_status_indicator.setProperty("class", "in-progress")
            self.btn_creation_control.setEnabled(True)
        elif self.creation_state == "paused":
            self.btn_creation_control.setText("继续创作")
            self.btn_creation_control.setProperty("class", "")
            self.lbl_status_indicator.setText("已暂停")
            self.lbl_status_indicator.setProperty("class", "paused")
            self.btn_creation_control.setEnabled(True)

        # Refresh styles
        self.btn_creation_control.style().unpolish(self.btn_creation_control)
        self.btn_creation_control.style().polish(self.btn_creation_control)
        self.lbl_status_indicator.style().unpolish(self.lbl_status_indicator)
        self.lbl_status_indicator.style().polish(self.lbl_status_indicator)

    def is_paused(self) -> bool:
        """
        Check if creation is currently paused.

        Returns:
            True if paused, False otherwise
        """
        return self.creation_state == "paused"

    def _on_creation_control_clicked(self) -> None:
        """Handle creation control button click."""
        self.logger.info(f"[CREATION_BUTTON] Clicked, current_state={self.creation_state}, current_work_id={self.current_work_id}")
        if not self.current_work_id:
            self.logger.warning(f"[CREATION_BUTTON] No current_work_id, returning")
            return

        if self.creation_state == "not_started":
            self.logger.info(f"[CREATION_BUTTON] State=not_started, changing to in_progress")
            self.creation_state = "in_progress"
            self._update_creation_state()
            self.logger.info(f"[CREATION_BUTTON] Emitting creation_started signal")
            self.creation_started.emit(self.current_work_id)
        elif self.creation_state == "in_progress":
            self.logger.info(f"[CREATION_BUTTON] State=in_progress, changing to paused")
            self.creation_state = "paused"
            self._update_creation_state()
            self.creation_paused.emit(self.current_work_id)
        elif self.creation_state == "paused":
            self.logger.info(f"[CREATION_BUTTON] State=paused, changing to in_progress")
            self.creation_state = "in_progress"
            self._update_creation_state()
            self.creation_resumed.emit(self.current_work_id)

    def _on_flow_tree_item_clicked(self, item: QTreeWidgetItem, column: int) -> None:
        """
        Handle flow tree item click.

        Args:
            item: Clicked tree item
            column: Clicked column index
        """
        step_id = item.data(0, Qt.ItemDataRole.UserRole)
        step_name = item.text(0)

        if self.current_work_id and step_id:
            self.step_selected.emit(self.current_work_id, step_name)
            # Display content for the selected step
            self.display_step_content(step_id)

            # Show action buttons
            self._show_action_buttons(step_id, step_name)

    def _show_action_buttons(self, step_id: str, step_name: str) -> None:
        """
        Show action buttons when a step is selected.

        Args:
            step_id: The step ID
            step_name: The step name for display
        """
        # Store current step info for button actions
        self._current_action_step_id = step_id
        self._current_action_step_name = step_name.lstrip("\u27f3 \u2713 ")

        # Show action buttons widget
        self.action_buttons_widget.setVisible(True)

    def _on_template_button_clicked(self) -> None:
        """Handle template button click - show template edit dialog."""
        if not hasattr(self, '_current_action_step_id') or not self.current_work_id:
            return

        # Emit signal to request template edit dialog
        # The parent window will handle showing the dialog
        self.template_edit_requested.emit(self.current_work_id, self._current_action_step_id, self._current_action_step_name)

    def _on_regenerate_button_clicked(self) -> None:
        """Handle regenerate button click - show regenerate dialog."""
        if not hasattr(self, '_current_action_step_id') or not self.current_work_id:
            return

        # Emit signal to request regenerate dialog
        # The parent window will handle showing the dialog
        self.regenerate_requested.emit(self.current_work_id, self._current_action_step_id, self._current_action_step_name)

    def _find_item_by_step_id(self, step_id: str) -> Optional[QTreeWidgetItem]:
        """
        Find a tree item by its step ID (user data).

        Args:
            step_id: The step ID to search for

        Returns:
            The QTreeWidgetItem if found, None otherwise
        """
        def search_item(parent: QTreeWidgetItem) -> Optional[QTreeWidgetItem]:
            for i in range(parent.childCount()):
                child = parent.child(i)
                if child.data(0, Qt.ItemDataRole.UserRole) == step_id:
                    return child
                # Recursively search children
                result = search_item(child)
                if result:
                    return result
            return None

        # Search top-level items
        for i in range(self.flow_tree.topLevelItemCount()):
            top_item = self.flow_tree.topLevelItem(i)
            if top_item.data(0, Qt.ItemDataRole.UserRole) == step_id:
                return top_item
            result = search_item(top_item)
            if result:
                return result

        return None

    def set_step_status(
        self,
        step_id: str,
        status: str,
        step_name: Optional[str] = None
    ) -> None:
        """
        Set the status of a flow tree step.

        Args:
            step_id: The step ID (user data)
            status: One of 'pending', 'executing', 'completed'
            step_name: Optional step name for display (used with icon)
        """
        item = self._find_item_by_step_id(step_id)
        if item is None:
            return

        # Store status in map
        self._step_status_map[step_id] = status

        # Set status-specific styling
        if status == "executing":
            # Blue background with spinning icon
            item.setForeground(0, Qt.GlobalColor.darkBlue)
            font = item.font(0)
            font.setBold(True)
            item.setFont(0, font)
            # Add spinning icon prefix
            if step_name:
                item.setText(0, f"\u27f3 {step_name}")
            self._executing_step_id = step_id
        elif status == "completed":
            # Green with checkmark
            item.setForeground(0, Qt.GlobalColor.darkGreen)
            # Add checkmark prefix
            if step_name:
                # Use the clean step_name (already stripped of icons)
                item.setText(0, f"\u2713 {step_name}")
            if self._executing_step_id == step_id:
                self._executing_step_id = None
        elif status == "pending":
            # Gray color
            item.setForeground(0, Qt.GlobalColor.gray)
            font = item.font(0)
            font.setBold(False)
            item.setFont(0, font)
            # Remove any icon prefix
            if step_name:
                current_text = item.text(0)
                if current_text.startswith("\u27f3 ") or current_text.startswith("\u2713 "):
                    item.setText(0, step_name)
            if self._executing_step_id == step_id:
                self._executing_step_id = None

        # Refresh item
        self.flow_tree.viewport().update()

    def set_all_steps_pending(self) -> None:
        """Set all steps to pending status."""
        def mark_pending(parent: QTreeWidgetItem) -> None:
            for i in range(parent.childCount()):
                child = parent.child(i)
                step_id = child.data(0, Qt.ItemDataRole.UserRole)
                if step_id:
                    self.set_step_status(step_id, "pending", child.text(0).lstrip("\u27f3 \u2713 "))
                mark_pending(child)

        for i in range(self.flow_tree.topLevelItemCount()):
            top_item = self.flow_tree.topLevelItem(i)
            mark_pending(top_item)

    def get_executing_step(self) -> Optional[str]:
        """Get the currently executing step ID."""
        return self._executing_step_id

    def get_step_status(self, step_id: str) -> Optional[str]:
        """
        Get the status of a step.

        Args:
            step_id: The step ID

        Returns:
            The status string or None if not found
        """
        return self._step_status_map.get(step_id)

    def start_content_stream(self, step_id: str) -> None:
        """
        Start streaming content for a step.

        This method initiates the streaming mode for the specified step.
        Content will be displayed character by character using a timer.

        Args:
            step_id: The step ID to stream content for
        """
        if not self.current_work_id:
            return

        # Stop any existing stream
        self.stop_content_stream()

        self._streaming_step_id = step_id
        # Also set as current viewing step to track content during generation
        self._current_viewing_step_id = step_id
        self._stream_buffer = ""
        self._stream_index = 0
        self._content_map[step_id] = ""

        # Set step as executing
        item = self._find_item_by_step_id(step_id)
        if item:
            step_name = item.text(0).lstrip("\u27f3 \u2713 ")
            self.set_step_status(step_id, "executing", step_name)
            # Emit progress signal
            self.generation_progress.emit(step_name, 0)

            # Update header label
            self.step_header_label.setText(step_name)
            self.step_header_label.setVisible(True)

            # Auto-select the tree item
            # Clear previous selection
            self.flow_tree.clearSelection()
            # Select current item
            self.flow_tree.setCurrentItem(item)
            item.setSelected(True)
            # Scroll to item
            self.flow_tree.scrollToItem(item)

        # Display executing status in right panel (same as manual click)
        self.display_step_content(step_id)

    def _stream_next_chunk(self) -> None:
        """
        Stream the next chunk of content.

        Called by the streaming timer to append content character by character.
        """
        if self._streaming_step_id is None or self._stream_timer is None:
            return

        # Get the step item for name
        item = self._find_item_by_step_id(self._streaming_step_id)
        if not item:
            self.stop_content_stream()
            return

        # Stream 2-4 characters at a time for faster but smooth effect
        chars_per_tick = 3
        remaining = len(self._stream_buffer) - self._stream_index

        if remaining <= 0:
            # No more content to stream, but keep timer running for more content
            return

        # Get next chunk
        end_index = min(self._stream_index + chars_per_tick, len(self._stream_buffer))
        chunk = self._stream_buffer[self._stream_index:end_index]
        self._stream_index = end_index

        # Append to display
        self.content_display.insertPlainText(chunk)
        self.content_display.verticalScrollBar().setValue(
            self.content_display.verticalScrollBar().maximum()
        )

        # Update stored content
        self._content_map[self._streaming_step_id] = self._stream_buffer

        # Emit progress update with current word count
        # Count Chinese words (each character counts as 1)
        word_count = len(self._stream_buffer)
        self.generation_progress.emit(item.text(0).lstrip("\u27f3 \u2713 "), word_count)

        # If we've streamed all content and the step is still executing,
        # keep the timer running for potential additional content
        if self._stream_index >= len(self._stream_buffer):
            pass  # Keep timer running, more content may arrive

    def append_stream_content(self, content: str) -> None:
        """
        Append content to the current streaming buffer.

        The content will be streamed to the display character by character.

        Args:
            content: Content to append to the stream
        """
        if self._streaming_step_id is None:
            return

        self._stream_buffer += content

    def stop_content_stream(self, mark_completed: bool = True) -> None:
        """
        Stop the current content stream.

        Args:
            mark_completed: If True, mark the step as completed
        """
        if self._stream_timer is not None:
            self._stream_timer.stop()
            self._stream_timer.deleteLater()
            self._stream_timer = None

        if mark_completed and self._streaming_step_id:
            item = self._find_item_by_step_id(self._streaming_step_id)
            if item:
                step_name = item.text(0).lstrip("\u27f3 \u2713 ")
                self.set_step_status(self._streaming_step_id, "completed", step_name)

        # Ensure all buffered content is saved to content_map before stopping
        if self._streaming_step_id and self._stream_buffer:
            self._content_map[self._streaming_step_id] = self._stream_buffer

        self._streaming_step_id = None

    def update_step_content(self, step_id: str, content: str, streaming: bool = True) -> None:
        """
        Update content for a step.

        This is the main method for updating step content. It supports both
        streaming (character-by-character) and instant display modes.

        Args:
            step_id: The step ID to update content for
            content: The content to display
            streaming: If True, stream content character by character.
                      If False, display all content instantly.
        """
        if not self.current_work_id:
            return

        # Store the full content
        self._content_map[step_id] = content

        # Check if this is the currently selected/visible step
        current_item = self.flow_tree.currentItem()
        if current_item is None:
            return

        selected_step_id = current_item.data(0, Qt.ItemDataRole.UserRole)
        if selected_step_id != step_id:
            # Content updated for non-visible step, just store it
            return

        if streaming:
            # Start or continue streaming
            if self._streaming_step_id != step_id:
                self.start_content_stream(step_id)
            self.append_stream_content(content)
        else:
            # Display all content instantly
            item = self._find_item_by_step_id(step_id)
            step_name = item.text(0).lstrip("\u27f3 \u2713 ") if item else step_id

            # Update header label
            self.step_header_label.setText(step_name)
            self.step_header_label.setVisible(True)

            # Display content as plain text
            self.content_display.clear()
            self.content_display.setPlainText(content)
            self._content_map[step_id] = content

    def get_step_content(self, step_id: str) -> Optional[str]:
        """
        Get the stored content for a step.

        Args:
            step_id: The step ID

        Returns:
            The content string or None if not found
        """
        return self._content_map.get(step_id)

    def display_step_content(self, step_id: str) -> None:
        """
        Display the stored content for a step in the content panel.

        This is called when user clicks on a step to view its content.
        Shows different placeholder messages based on step status.

        Args:
            step_id: The step ID to display content for
        """
        # Try to get content from memory map first
        content = self._content_map.get(step_id, "")

        # If no content in memory, try to load from disk
        if not content and self.current_work_id:
            content = self._load_step_content_from_disk(step_id)

        item = self._find_item_by_step_id(step_id)
        step_name = item.text(0).lstrip("\u27f3 \u2713 ") if item else step_id

        # Set the currently viewing step
        self._current_viewing_step_id = step_id

        # Get step status to determine placeholder message
        step_status = self.get_step_status(step_id)

        # Update step header label
        if content or step_status in ("pending", "executing"):
            self.step_header_label.setText(step_name)
            self.step_header_label.setVisible(True)
        else:
            self.step_header_label.setVisible(False)

        # Build content based on status - use plain text for editable content
        # Block content_changed signal when setting placeholder text to prevent
        # accidental saving of placeholder text as actual content
        if content:
            # Step has content - display it as plain text for editing
            self.content_display.setPlainText(content)
        elif step_status == "pending":
            # Pending step - show pending placeholder
            self._content_changed_blocked = True
            html_content = (
                f"<div style='color: #a0a0a4; padding: 20px; text-align: center;'>"
                f"<p style='font-size: 16px; margin-bottom: 10px;'>⏳ 该步骤等待中</p>"
                f"<p style='font-size: 13px;'>此步骤尚未开始执行，点击\"开始创作\"按钮启动创作流程。</p>"
                f"</div>"
            )
            self.content_display.setHtml(html_content)
            self._content_changed_blocked = False
        elif step_status == "executing":
            # Currently executing - show executing placeholder
            self._content_changed_blocked = True
            html_content = (
                f"<div style='color: #2980b9; padding: 20px; text-align: center;'>"
                f"<p style='font-size: 16px; margin-bottom: 10px;'>⟳ 正在生成中...</p>"
                f"<p style='font-size: 13px;'>AI 正在创作此步骤内容，请稍候。</p>"
                f"</div>"
            )
            self.content_display.setHtml(html_content)
            self._content_changed_blocked = False
        else:
            # Default/unknown status - show generic placeholder
            self._content_changed_blocked = True
            html_content = (
                f"<div style='color: #7f8c8d; padding: 20px; text-align: center;'>"
                f"<p style='font-size: 16px; margin-bottom: 10px;'>该步骤内容尚未生成</p>"
                f"<p style='font-size: 13px;'>点击\"开始创作\"按钮开始创作流程。</p>"
                f"</div>"
            )
            self.content_display.setHtml(html_content)
            self._content_changed_blocked = False

        # Update word count display
        self._update_word_count()

    def _load_step_content_from_disk(self, step_id: str) -> Optional[str]:
        """
        Load step content from disk (steps/ directory).

        All AI-generated content is stored in steps/ directory files only.
        Fields: story_summary, worldbuilding, character_design, reference_analysis,
        pattern_analysis, volume_*, chapter_*, etc.

        Args:
            step_id: The step ID to load content for

        Returns:
            Content string or None if not found
        """
        if not self.current_work_id:
            return None

        self.logger.info(f"[LOAD_STEP_CONTENT] Loading step: {step_id}, current_work_id={self.current_work_id}")

        try:
            # Load from steps directory (TXT file)
            from pathlib import Path
            steps_dir = Path(self.settings.works_dir) / self.current_work_id / 'steps'
            step_file = steps_dir / f'{step_id}.txt'

            self.logger.info(f"[LOAD_STEP_CONTENT] Step {step_id}: checking file {step_file}, exists={step_file.exists()}")

            if step_file.exists():
                with open(step_file, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                self.logger.info(f"[LOAD_STEP_CONTENT] Step {step_id}: loaded {len(content)} chars from disk")
                if content:
                    self._content_map[step_id] = content
                    return content

        except Exception as e:
            self.logger.warning(f"Failed to load step content from disk: {e}")

        return None

    def _on_content_changed(self) -> None:
        """
        Handle content changes in the content display.

        This is called when the user edits content in the result panel.
        The changes are saved to the content map and emitted via signal.
        """
        # Skip if changes are blocked (to prevent recursive signals)
        if self._content_changed_blocked:
            return

        # Skip if no step is currently being viewed
        if self._current_viewing_step_id is None:
            return

        # Get the current content from the display
        new_content = self.content_display.toPlainText()

        # Save to content map
        self._content_map[self._current_viewing_step_id] = new_content

        # Update word count display
        self._update_word_count()

        # Emit signal to notify listeners of the change
        self.content_changed.emit(self._current_viewing_step_id, new_content)

    def _update_word_count(self) -> None:
        """
        Update the word count label with the current content word count.

        Counts Chinese characters and words in the content display.
        Each Chinese character counts as 1, each word (separated by spaces)
        in English text counts as 1.
        """
        content = self.content_display.toPlainText()
        # Count all non-whitespace characters as words (works for Chinese)
        # For mixed content, this gives a reasonable approximation
        word_count = len(content.replace(" ", "").replace("\n", "").replace("\r", ""))
        self.lbl_word_count.setText(f"字数：{word_count}")

    def _on_save_clicked(self) -> None:
        """
        Handle save button click.

        Saves the current step content to disk via signal.
        """
        if not self.current_work_id or not self._current_viewing_step_id:
            return

        # Get the current content from the display
        content = self.content_display.toPlainText()

        # Emit save request signal
        self.save_requested.emit(self.current_work_id, self._current_viewing_step_id, content)

