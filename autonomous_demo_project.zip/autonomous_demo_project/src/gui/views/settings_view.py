"""
Settings view for AI Writer application.

Allows users to configure storage paths and application settings.
"""
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QFileDialog, QFrame, QCheckBox, QGroupBox,
    QScrollArea, QComboBox, QSpacerItem, QSizePolicy
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtTest import QTest
from PyQt6.QtGui import QShowEvent
import os

from ..widgets.loading_spinner import LoadingOverlay


class SettingsView(QWidget):
    """
    Settings configuration view.

    Allows users to configure:
    - Storage root directory
    - View derived paths (works, templates, logs)
    """

    # Signal emitted when settings are saved (after storage path change)
    settings_saved = pyqtSignal()

    def __init__(self, settings, parent=None):
        """
        Initialize settings view.

        Args:
            settings: Application settings instance
            parent: Parent widget
        """
        super().__init__(parent)
        self.settings = settings
        self.setObjectName("settingsView")
        self._setup_ui()
        self._setup_connections()
        self._apply_styles()
        self._load_settings()
        self._setup_loading_overlay()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Title (fixed at top, not scrollable)
        title_label = QLabel("设置")
        title_label.setObjectName("viewTitle")
        title_label.setFixedHeight(40)
        main_layout.addWidget(title_label)

        # Create scroll area for the form content
        scroll_area = QScrollArea()
        scroll_area.setObjectName("settingsScrollArea")
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        # Create scrollable content widget
        scroll_content = QWidget()
        scroll_content.setObjectName("settingsScrollContent")
        form_layout = QVBoxLayout(scroll_content)
        form_layout.setContentsMargins(30, 10, 30, 30)
        form_layout.setSpacing(15)

        # Settings form container
        form_container = QFrame()
        form_container.setObjectName("settingsForm")
        form_container_layout = QVBoxLayout(form_container)
        form_container_layout.setSpacing(15)

        # Storage root configuration
        self._setup_storage_root_section(form_container_layout)

        # AI configuration - new dual-mode section
        self._setup_ai_config_section(form_container_layout)
        self._setup_derived_paths_section(form_container_layout)

        # Save button
        self._setup_action_buttons(form_container_layout)

        form_container_layout.addStretch()
        form_layout.addWidget(form_container)

        scroll_area.setWidget(scroll_content)
        main_layout.addWidget(scroll_area)

    def _setup_storage_root_section(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up storage root configuration section.

        Args:
            parent_layout: Layout to add section to
        """
        section_title = QLabel("存储路径配置")
        section_title.setObjectName("sectionTitle")
        section_title.setFixedHeight(32)
        parent_layout.addWidget(section_title)

        # Storage root row
        root_layout = QHBoxLayout()
        root_layout.setSpacing(10)
        root_layout.setContentsMargins(15, 0, 0, 0)

        root_label = QLabel("存储根目录:")
        root_label.setMinimumWidth(100)
        root_label.setFixedHeight(36)
        root_layout.addWidget(root_label)

        self.storage_root_input = QLineEdit()
        self.storage_root_input.setObjectName("pathInput")
        self.storage_root_input.setPlaceholderText("选择存储根目录...")
        self.storage_root_input.setFixedHeight(36)
        self.storage_root_input.setSizePolicy(
            self.storage_root_input.sizePolicy().horizontalPolicy().Expanding,
            self.storage_root_input.sizePolicy().verticalPolicy().Fixed
        )
        root_layout.addWidget(self.storage_root_input)

        self.btn_browse_root = QPushButton("浏览...")
        self.btn_browse_root.setObjectName("browseBtn")
        self.btn_browse_root.setMinimumWidth(80)
        self.btn_browse_root.setFixedHeight(36)
        self.btn_browse_root.setToolTip("选择新的存储根目录")
        self.btn_browse_root.setAccessibleName("浏览存储根目录")
        self.btn_browse_root.setAccessibleDescription("选择新的存储根目录路径")
        root_layout.addWidget(self.btn_browse_root)

        self.btn_open_root = QPushButton("打开目录")
        self.btn_open_root.setObjectName("openBtn")
        self.btn_open_root.setMinimumWidth(80)
        self.btn_open_root.setFixedHeight(36)
        self.btn_open_root.setToolTip("在文件管理器中打开存储根目录")
        self.btn_open_root.setAccessibleName("打开存储根目录")
        self.btn_open_root.setAccessibleDescription("在文件管理器中打开存储根目录")
        root_layout.addWidget(self.btn_open_root)

        parent_layout.addLayout(root_layout)

    def _setup_ai_config_section(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up AI configuration section with dual-mode support.

        Args:
            parent_layout: Layout to add section to
        """
        # Mode selection (API vs Browser)
        mode_layout = QHBoxLayout()
        mode_layout.setSpacing(10)
        mode_layout.setContentsMargins(15, 0, 0, 0)

        mode_label = QLabel("调用模式:")
        mode_label.setMinimumWidth(100)
        mode_label.setFixedHeight(36)
        mode_layout.addWidget(mode_label)

        self.ai_mode_combo = QComboBox()
        self.ai_mode_combo.setObjectName("aiModeCombo")
        self.ai_mode_combo.addItems(["API 直接调用", "浏览器自动化"])
        self.ai_mode_combo.setFixedHeight(36)
        self.ai_mode_combo.setMinimumWidth(200)
        self.ai_mode_combo.setToolTip("选择 AI 服务调用方式")
        mode_layout.addWidget(self.ai_mode_combo)
        mode_layout.addStretch()

        parent_layout.addLayout(mode_layout)

        # API Mode Configuration
        self.api_mode_group = QGroupBox("")
        self.api_mode_group.setObjectName("apiModeGroup")
        api_mode_layout = QVBoxLayout(self.api_mode_group)
        api_mode_layout.setSpacing(10)
        api_mode_layout.setContentsMargins(15, 0, 15, 10)

        # API mode section header
        api_header_label = QLabel("API 配置")
        api_header_label.setObjectName("modeSectionHeader")
        api_header_label.setFixedHeight(32)
        api_header_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        api_mode_layout.addWidget(api_header_label)

        # API Provider selection
        provider_layout = QHBoxLayout()
        provider_layout.setSpacing(10)

        provider_label = QLabel("API 提供商:")
        provider_label.setMinimumWidth(100)
        provider_label.setFixedHeight(36)
        provider_layout.addWidget(provider_label)

        self.api_provider_combo = QComboBox()
        self.api_provider_combo.setObjectName("apiProviderCombo")
        self.api_provider_combo.addItems(["Qwen (阿里云)", "OpenAI", "Anthropic", "DeepSeek"])
        self.api_provider_combo.setFixedHeight(36)
        self.api_provider_combo.setMinimumWidth(200)
        provider_layout.addWidget(self.api_provider_combo)
        provider_layout.addStretch()

        api_mode_layout.addLayout(provider_layout)

        # API URL
        api_url_layout = QHBoxLayout()
        api_url_layout.setSpacing(10)

        api_url_label = QLabel("API URL:")
        api_url_label.setMinimumWidth(100)
        api_url_label.setFixedHeight(36)
        api_url_layout.addWidget(api_url_label)

        self.api_url_input = QLineEdit()
        self.api_url_input.setObjectName("pathInput")
        self.api_url_input.setPlaceholderText("请输入 API 基础 URL...")
        self.api_url_input.setFixedHeight(36)
        api_url_layout.addWidget(self.api_url_input)

        api_mode_layout.addLayout(api_url_layout)

        # API Key
        api_key_layout = QHBoxLayout()
        api_key_layout.setSpacing(10)

        api_key_label = QLabel("API Key:")
        api_key_label.setMinimumWidth(100)
        api_key_label.setFixedHeight(36)
        api_key_layout.addWidget(api_key_label)

        self.api_key_input = QLineEdit()
        self.api_key_input.setObjectName("pathInput")
        self.api_key_input.setPlaceholderText("请输入 API Key...")
        self.api_key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_key_input.setFixedHeight(36)
        api_key_layout.addWidget(self.api_key_input)

        api_mode_layout.addLayout(api_key_layout)

        # Model
        model_layout = QHBoxLayout()
        model_layout.setSpacing(10)

        model_label = QLabel("模型:")
        model_label.setMinimumWidth(100)
        model_label.setFixedHeight(36)
        model_layout.addWidget(model_label)

        self.api_model_input = QLineEdit()
        self.api_model_input.setObjectName("pathInput")
        self.api_model_input.setPlaceholderText("请输入模型名称...")
        self.api_model_input.setFixedHeight(36)
        model_layout.addWidget(self.api_model_input)

        api_mode_layout.addLayout(model_layout)

        parent_layout.addWidget(self.api_mode_group)

        # Browser Mode Configuration
        self.browser_mode_group = QGroupBox("")
        self.browser_mode_group.setObjectName("browserModeGroup")
        browser_mode_layout = QVBoxLayout(self.browser_mode_group)
        browser_mode_layout.setSpacing(10)
        browser_mode_layout.setContentsMargins(15, 0, 15, 10)

        # Browser mode section header
        browser_header_label = QLabel("浏览器自动化配置")
        browser_header_label.setObjectName("modeSectionHeader")
        browser_header_label.setFixedHeight(32)
        browser_header_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        browser_mode_layout.addWidget(browser_header_label)

        # Browser Provider selection
        browser_provider_layout = QHBoxLayout()
        browser_provider_layout.setSpacing(10)

        browser_provider_label = QLabel("浏览器提供商:")
        browser_provider_label.setMinimumWidth(100)
        browser_provider_label.setFixedHeight(36)
        browser_provider_layout.addWidget(browser_provider_label)

        self.browser_provider_combo = QComboBox()
        self.browser_provider_combo.setObjectName("browserProviderCombo")
        self.browser_provider_combo.addItems(["DeepSeek", "豆包 (Doubao)"])
        self.browser_provider_combo.setFixedHeight(36)
        self.browser_provider_combo.setMinimumWidth(200)
        browser_provider_layout.addWidget(self.browser_provider_combo)
        browser_provider_layout.addStretch()

        browser_mode_layout.addLayout(browser_provider_layout)

        # Phone number
        phone_layout = QHBoxLayout()
        phone_layout.setSpacing(10)

        phone_label = QLabel("手机号:")
        phone_label.setMinimumWidth(100)
        phone_label.setFixedHeight(36)
        phone_layout.addWidget(phone_label)

        self.browser_phone_input = QLineEdit()
        self.browser_phone_input.setObjectName("pathInput")
        self.browser_phone_input.setPlaceholderText("请输入手机号（用于登录验证）...")
        self.browser_phone_input.setFixedHeight(36)
        phone_layout.addWidget(self.browser_phone_input)

        browser_mode_layout.addLayout(phone_layout)

        # Password (for DeepSeek password login)
        password_layout = QHBoxLayout()
        password_layout.setSpacing(10)

        self.password_label = QLabel("登录密码:")
        self.password_label.setMinimumWidth(100)
        self.password_label.setFixedHeight(36)
        password_layout.addWidget(self.password_label)

        self.browser_password_input = QLineEdit()
        self.browser_password_input.setObjectName("pathInput")
        self.browser_password_input.setPlaceholderText("请输入账号密码（可选，配置后使用密码登录）...")
        self.browser_password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.browser_password_input.setFixedHeight(36)
        password_layout.addWidget(self.browser_password_input)

        browser_mode_layout.addLayout(password_layout)

        # Password info label (only visible when DeepSeek is selected)
        self.browser_password_info_label = QLabel(
            "提示：配置密码后将使用密码登录模式，无需手动输入验证码。"
            "如果不配置密码，则使用验证码登录方式。"
        )
        self.browser_password_info_label.setObjectName("browserPasswordInfoLabel")
        self.browser_password_info_label.setWordWrap(True)
        self.browser_password_info_label.setVisible(False)  # Hidden by default
        browser_mode_layout.addWidget(self.browser_password_info_label)

        # Chrome path
        chrome_path_layout = QHBoxLayout()
        chrome_path_layout.setSpacing(10)

        chrome_path_label = QLabel("Chrome 路径:")
        chrome_path_label.setMinimumWidth(100)
        chrome_path_label.setFixedHeight(36)
        chrome_path_layout.addWidget(chrome_path_label)

        self.browser_chrome_input = QLineEdit()
        self.browser_chrome_input.setObjectName("pathInput")
        self.browser_chrome_input.setPlaceholderText("Chrome 可执行文件路径...")
        self.browser_chrome_input.setFixedHeight(36)
        chrome_path_layout.addWidget(self.browser_chrome_input)

        self.btn_check_chrome = QPushButton("检查 Chrome")
        self.btn_check_chrome.setObjectName("checkChromeBtn")
        self.btn_check_chrome.setMinimumWidth(100)
        self.btn_check_chrome.setFixedHeight(36)
        self.btn_check_chrome.setToolTip("检查指定路径的 Chrome 是否已安装")
        chrome_path_layout.addWidget(self.btn_check_chrome)

        browser_mode_layout.addLayout(chrome_path_layout)

        # Chrome status label
        self.chrome_status_label = QLabel("")
        self.chrome_status_label.setObjectName("chromeStatusLabel")
        self.chrome_status_label.setFixedHeight(30)
        browser_mode_layout.addWidget(self.chrome_status_label)

        # Browser mode info/warning
        browser_info_label = QLabel(
            "提示：浏览器自动化模式会打开真实的浏览器窗口，登录时需要手动输入验证码。"
            "请确保 Chrome 浏览器已安装，并在下方填写正确的手机号用于接收验证码。"
        )
        browser_info_label.setObjectName("browserInfoLabel")
        browser_info_label.setWordWrap(True)
        browser_mode_layout.addWidget(browser_info_label)

        parent_layout.addWidget(self.browser_mode_group)

        # Derived paths (read-only)

        # Connect mode switch signal
        self.ai_mode_combo.currentTextChanged.connect(self._on_ai_mode_changed)
        self.btn_check_chrome.clicked.connect(self._check_chrome_installed)
        self.browser_provider_combo.currentTextChanged.connect(self._on_browser_provider_changed)

    def _setup_derived_paths_section(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up derived paths display section.

        Args:
            parent_layout: Layout to add section to
        """
        section_title = QLabel("工作目录")
        section_title.setObjectName("sectionTitle")
        section_title.setFixedHeight(32)
        parent_layout.addWidget(section_title)

        # Works directory
        works_layout = QHBoxLayout()
        works_layout.setSpacing(10)
        works_layout.setContentsMargins(15, 0, 0, 0)

        works_label = QLabel("作品库路径:")
        works_label.setMinimumWidth(100)
        works_label.setFixedHeight(36)
        works_layout.addWidget(works_label)

        self.works_dir_input = QLineEdit()
        self.works_dir_input.setObjectName("readonlyPathInput")
        self.works_dir_input.setReadOnly(True)
        self.works_dir_input.setFixedHeight(36)
        self.works_dir_input.setSizePolicy(
            self.works_dir_input.sizePolicy().horizontalPolicy().Expanding,
            self.works_dir_input.sizePolicy().verticalPolicy().Fixed
        )
        works_layout.addWidget(self.works_dir_input)

        self.btn_open_works = QPushButton("打开目录")
        self.btn_open_works.setObjectName("openBtn")
        self.btn_open_works.setMinimumWidth(80)
        self.btn_open_works.setFixedHeight(36)
        self.btn_open_works.setToolTip("在文件管理器中打开作品库目录")
        self.btn_open_works.setAccessibleName("打开作品库目录")
        self.btn_open_works.setAccessibleDescription("在文件管理器中打开作品库目录")
        works_layout.addWidget(self.btn_open_works)

        parent_layout.addLayout(works_layout)

        # Templates directory
        templates_layout = QHBoxLayout()
        templates_layout.setSpacing(10)
        templates_layout.setContentsMargins(15, 0, 0, 0)

        templates_label = QLabel("模板路径:")
        templates_label.setMinimumWidth(100)
        templates_label.setFixedHeight(36)
        templates_layout.addWidget(templates_label)

        self.templates_dir_input = QLineEdit()
        self.templates_dir_input.setObjectName("readonlyPathInput")
        self.templates_dir_input.setReadOnly(True)
        self.templates_dir_input.setFixedHeight(36)
        self.templates_dir_input.setSizePolicy(
            self.templates_dir_input.sizePolicy().horizontalPolicy().Expanding,
            self.templates_dir_input.sizePolicy().verticalPolicy().Fixed
        )
        templates_layout.addWidget(self.templates_dir_input)

        self.btn_open_templates = QPushButton("打开目录")
        self.btn_open_templates.setObjectName("openBtn")
        self.btn_open_templates.setMinimumWidth(80)
        self.btn_open_templates.setFixedHeight(36)
        self.btn_open_templates.setToolTip("在文件管理器中打开模板目录")
        self.btn_open_templates.setAccessibleName("打开模板目录")
        self.btn_open_templates.setAccessibleDescription("在文件管理器中打开模板目录")
        templates_layout.addWidget(self.btn_open_templates)

        parent_layout.addLayout(templates_layout)

        # Logs directory
        logs_layout = QHBoxLayout()
        logs_layout.setSpacing(10)
        logs_layout.setContentsMargins(15, 0, 0, 0)

        logs_label = QLabel("日志路径:")
        logs_label.setMinimumWidth(100)
        logs_label.setFixedHeight(36)
        logs_layout.addWidget(logs_label)

        self.logs_dir_input = QLineEdit()
        self.logs_dir_input.setObjectName("readonlyPathInput")
        self.logs_dir_input.setReadOnly(True)
        self.logs_dir_input.setFixedHeight(36)
        self.logs_dir_input.setSizePolicy(
            self.logs_dir_input.sizePolicy().horizontalPolicy().Expanding,
            self.logs_dir_input.sizePolicy().verticalPolicy().Fixed
        )
        logs_layout.addWidget(self.logs_dir_input)

        self.btn_open_logs = QPushButton("打开目录")
        self.btn_open_logs.setObjectName("openBtn")
        self.btn_open_logs.setMinimumWidth(80)
        self.btn_open_logs.setFixedHeight(36)
        self.btn_open_logs.setToolTip("在文件管理器中打开日志目录")
        self.btn_open_logs.setAccessibleName("打开日志目录")
        self.btn_open_logs.setAccessibleDescription("在文件管理器中打开日志目录")
        logs_layout.addWidget(self.btn_open_logs)

        parent_layout.addLayout(logs_layout)

        # References directory
        references_layout = QHBoxLayout()
        references_layout.setSpacing(10)
        references_layout.setContentsMargins(15, 0, 0, 0)

        references_label = QLabel("参考作品:")
        references_label.setMinimumWidth(100)
        references_label.setFixedHeight(36)
        references_layout.addWidget(references_label)

        self.references_dir_input = QLineEdit()
        self.references_dir_input.setObjectName("readonlyPathInput")
        self.references_dir_input.setReadOnly(True)
        self.references_dir_input.setFixedHeight(36)
        self.references_dir_input.setSizePolicy(
            self.references_dir_input.sizePolicy().horizontalPolicy().Expanding,
            self.references_dir_input.sizePolicy().verticalPolicy().Fixed
        )
        references_layout.addWidget(self.references_dir_input)

        self.btn_open_references = QPushButton("打开目录")
        self.btn_open_references.setObjectName("openBtn")
        self.btn_open_references.setMinimumWidth(80)
        self.btn_open_references.setFixedHeight(36)
        self.btn_open_references.setToolTip("在文件管理器中打开参考作品目录")
        self.btn_open_references.setAccessibleName("打开参考作品目录")
        self.btn_open_references.setAccessibleDescription("在文件管理器中打开参考作品目录")
        references_layout.addWidget(self.btn_open_references)

        parent_layout.addLayout(references_layout)

    def _setup_action_buttons(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up action buttons section.

        Args:
            parent_layout: Layout to add section to
        """
        button_layout = QHBoxLayout()
        button_layout.addStretch()

        self.btn_save = QPushButton("保存更改")
        self.btn_save.setObjectName("saveBtn")
        self.btn_save.setMinimumWidth(150)
        self.btn_save.setMaximumWidth(250)
        self.btn_save.setFixedHeight(38)
        self.btn_save.setSizePolicy(
            self.btn_save.sizePolicy().horizontalPolicy().Expanding,
            self.btn_save.sizePolicy().verticalPolicy().Fixed
        )
        self.btn_save.setToolTip("保存所有路径配置到配置文件")
        self.btn_save.setAccessibleName("保存更改")
        self.btn_save.setAccessibleDescription("保存所有路径配置到配置文件")
        button_layout.addWidget(self.btn_save)

        parent_layout.addLayout(button_layout)

    def _setup_connections(self) -> None:
        """Connect signals and slots."""
        self.btn_browse_root.clicked.connect(self._browse_storage_root)
        self.btn_open_root.clicked.connect(
            lambda: self._open_directory(self.storage_root_input.text())
        )
        self.btn_open_works.clicked.connect(
            lambda: self._open_directory(self.works_dir_input.text())
        )
        self.btn_open_templates.clicked.connect(
            lambda: self._open_directory(self.templates_dir_input.text())
        )
        self.btn_open_logs.clicked.connect(
            lambda: self._open_directory(self.logs_dir_input.text())
        )
        self.btn_open_references.clicked.connect(
            lambda: self._open_directory(self.references_dir_input.text())
        )
        self.btn_save.clicked.connect(self._save_settings)

    def _on_ai_mode_changed(self) -> None:
        """Handle AI mode selection change."""
        mode = self.ai_mode_combo.currentText()
        is_api_mode = mode == "API 直接调用"

        # Show/hide appropriate group boxes
        self.api_mode_group.setVisible(is_api_mode)
        self.browser_mode_group.setVisible(not is_api_mode)

    def _on_browser_provider_changed(self) -> None:
        """Handle browser provider selection change."""
        provider_text = self.browser_provider_combo.currentText()
        is_deepseek = provider_text == "DeepSeek"

        # Show/hide password field, label, and info label for DeepSeek
        self.password_label.setVisible(is_deepseek)
        self.browser_password_input.setVisible(is_deepseek)
        self.browser_password_info_label.setVisible(is_deepseek)

    def _check_chrome_installed(self) -> None:
        """Check if Chrome is installed at the specified path."""
        chrome_path = self.browser_chrome_input.text().strip()
        if not chrome_path:
            chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

        if os.path.exists(chrome_path):
            self.chrome_status_label.setText("Chrome 已安装")
            self.chrome_status_label.setStyleSheet("color: green;")
        else:
            self.chrome_status_label.setText("Chrome 未安装，请检查路径是否正确")
            self.chrome_status_label.setStyleSheet("color: red;")

    def _do_save_settings(self) -> None:
        """Actually perform the save operation."""
        # Update AI settings from inputs
        ai_settings = self.settings.ai_settings

        # Get selected mode
        mode = self.ai_mode_combo.currentText()
        ai_settings.call_mode = 'api' if mode == "API 直接调用" else 'browser'

        # Save API settings
        provider_text = self.api_provider_combo.currentText()
        provider_map = {"OpenAI": "openai", "Anthropic": "anthropic",
                        "DeepSeek": "deepseek", "Qwen (阿里云)": "qwen"}
        ai_settings.api_provider = provider_map.get(provider_text, "qwen")
        ai_settings.api_url = self.api_url_input.text().strip()
        ai_settings.api_key = self.api_key_input.text().strip()
        ai_settings.api_model = self.api_model_input.text().strip()

        # Save browser settings
        browser_provider_text = self.browser_provider_combo.currentText()
        browser_provider_map = {"DeepSeek": "deepseek", "豆包 (Doubao)": "doubao"}
        ai_settings.browser_provider = browser_provider_map.get(browser_provider_text, "deepseek")
        ai_settings.browser_phone = self.browser_phone_input.text().strip()
        ai_settings.browser_password = self.browser_password_input.text().strip()
        ai_settings.browser_chrome_path = self.browser_chrome_input.text().strip()

        # Also update deprecated fields for backward compatibility
        self.settings.api_key = ai_settings.api_key
        self.settings.api_base_url = ai_settings.api_url
        self.settings.api_model = ai_settings.api_model
        self.settings.default_model = ai_settings.api_model

        # Save to file
        if self.settings.save():
            self._show_save_result(True, "设置已保存")
            # Emit signal to notify other components that settings changed
            self.settings_saved.emit()
        else:
            self._show_save_result(False, "保存失败，请检查目录权限")

        # Hide loading overlay
        self.loading_overlay.hide_overlay()

    def _apply_styles(self) -> None:
        """Apply styles to the view."""
        self.setStyleSheet("""
            #settingsView {
                background-color: #ffffff;
            }

            #viewTitle {
                font-size: 24px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 10px;
                padding-left: 30px;
                background-color: #ffffff;
            }

            #settingsScrollArea {
                border: none;
                background-color: #ffffff;
            }

            #settingsScrollContent {
                background-color: #ffffff;
            }

            #sectionTitle {
                font-size: 16px;
                font-weight: bold;
                color: #34495e;
                margin-top: 10px;
                margin-left: 10px;
                padding-bottom: 5px;
                border-bottom: 2px solid #3498db;
            }

            #settingsForm {
                background-color: #f9f9f9;
                border-radius: 10px;
                padding: 20px;
            }

            #pathInput, #readonlyPathInput {
                padding: 6px 10px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                font-size: 14px;
            }

            #readonlyPathInput {
                background-color: #ecf0f1;
                color: #7f8c8d;
            }

            QLabel {
                font-size: 14px;
                color: #2c3e50;
            }

            #browseBtn, #openBtn, #checkChromeBtn {
                padding: 6px 15px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                background-color: #ffffff;
                font-size: 13px;
            }

            #browseBtn:hover, #openBtn:hover, #checkChromeBtn:hover {
                background-color: #ecf0f1;
            }

            #saveBtn {
                background-color: #145a32;
                color: white;
                border: none;
                padding: 8px 25px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
            }

            #saveBtn:hover {
                background-color: #0f4224;
            }

            #aiModeCombo, #apiProviderCombo, #browserProviderCombo {
                padding: 6px 10px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                font-size: 14px;
                background-color: #ffffff;
            }

            #modeSectionHeader {
                font-size: 15px;
                font-weight: bold;
                color: #2c3e50;
                margin-top: 0px;
                margin-bottom: 10px;
                margin-left: -5px;
                padding-left: 0px;
                min-height: 32px;
            }

            #apiModeGroup, #browserModeGroup {
                margin-top: 15px;
                padding: 20px 0 10px 0;
                border: none;
                border-radius: 10px;
                background-color: #ecf0f1;
            }

            #chromeStatusLabel {
                font-size: 13px;
                font-weight: bold;
            }

            #browserInfoLabel {
                font-size: 12px;
                color: #7f8c8d;
                background-color: #fff3cd;
                border: 1px solid #ffc107;
                border-radius: 5px;
                padding: 10px;
                margin-top: 10px;
            }

            #browserPasswordInfoLabel {
                font-size: 12px;
                color: #27ae60;
                background-color: #e9f7ef;
                border: 1px solid #27ae60;
                border-radius: 5px;
                padding: 10px;
                margin-top: 10px;
            }
        """)

    def _load_settings(self) -> None:
        """Load current settings into the form."""
        self.storage_root_input.setText(os.path.normpath(self.settings.storage_root) if self.settings.storage_root else "")
        self.works_dir_input.setText(os.path.normpath(self.settings.works_dir) if self.settings.works_dir else "")
        self.templates_dir_input.setText(os.path.normpath(self.settings.templates_dir) if self.settings.templates_dir else "")
        self.logs_dir_input.setText(os.path.normpath(self.settings.logs_dir) if self.settings.logs_dir else "")
        self.references_dir_input.setText(os.path.normpath(os.path.join(self.settings.storage_root, "references")) if self.settings.storage_root else "")

        # Load AI settings from new ai_settings structure
        ai_settings = self.settings.ai_settings

        # Load mode
        call_mode = ai_settings.call_mode if hasattr(ai_settings, 'call_mode') else 'api'
        mode_index = 0 if call_mode == 'api' else 1
        self.ai_mode_combo.setCurrentIndex(mode_index)

        # Load API settings
        self.api_provider_combo.setCurrentText(
            {"openai": "OpenAI", "anthropic": "Anthropic",
             "deepseek": "DeepSeek", "qwen": "Qwen (阿里云)"}.get(
                ai_settings.api_provider, "Qwen (阿里云)")
        )
        self.api_url_input.setText(ai_settings.api_url or "")
        self.api_key_input.setText(ai_settings.api_key or "")
        self.api_model_input.setText(ai_settings.api_model or "")

        # Load browser settings
        self.browser_provider_combo.setCurrentText(
            {"deepseek": "DeepSeek", "doubao": "豆包 (Doubao)"}.get(
                ai_settings.browser_provider, "DeepSeek")
        )
        self.browser_phone_input.setText(ai_settings.browser_phone or "")
        self.browser_password_input.setText(ai_settings.browser_password or "")
        self.browser_chrome_input.setText(ai_settings.browser_chrome_path or "")

        # Update UI based on mode
        self._on_ai_mode_changed()

        # Update password field visibility based on provider
        self._on_browser_provider_changed()

        # Check Chrome installation status
        self._check_chrome_installed()

    def showEvent(self, event: QShowEvent) -> None:
        """
        Handle show event to reload settings.

        This ensures that any unsaved changes are discarded when
        the user navigates away and returns to the settings page.

        Args:
            event: Show event
        """
        super().showEvent(event)
        # Reload settings from the settings object to discard any unsaved changes
        self._load_settings()

    def _browse_storage_root(self) -> None:
        """Open directory browser for storage root selection."""
        current = self.storage_root_input.text()
        directory = QFileDialog.getExistingDirectory(
            self,
            "选择存储根目录",
            current if current else ""
        )
        if directory:
            self.storage_root_input.setText(directory)
            self._update_derived_paths(directory)

    def _update_derived_paths(self, root: str) -> None:
        """
        Update derived paths based on new root.

        Args:
            root: New storage root path
        """
        self.works_dir_input.setText(os.path.normpath(os.path.join(root, "works")))
        self.templates_dir_input.setText(os.path.normpath(os.path.join(root, "templates")))
        self.logs_dir_input.setText(os.path.normpath(os.path.join(root, "logs")))
        self.references_dir_input.setText(os.path.normpath(os.path.join(root, "references")))

    def _open_directory(self, path: str) -> None:
        """
        Open directory in file explorer.

        Args:
            path: Directory path to open
        """
        if path:
            # Normalize path to fix mixed separators
            path = os.path.normpath(path)
        if os.path.exists(path):
            os.startfile(path)

    def _setup_loading_overlay(self) -> None:
        """Set up the loading overlay for save operations."""
        self.loading_overlay = LoadingOverlay(self, "保存中...")
        self.loading_overlay.hide()

    def _save_settings(self) -> None:
        """Save settings with loading indicator."""
        root = self.storage_root_input.text().strip()

        if not root:
            self._show_save_result(False, "请指定存储根目录")
            return

        # Check if directory exists and has write permission
        import os
        if os.path.exists(root):
            if not os.path.isdir(root):
                self._show_permission_error(root, "access", "指定的路径不是目录")
                return
            if not os.access(root, os.W_OK):
                self._show_permission_error(root, "write")
                return
        else:
            # Try to create the directory to check permissions
            try:
                os.makedirs(root, exist_ok=True)
                # Clean up if we just created it (will be recreated on save)
                if not os.listdir(root):
                    os.rmdir(root)
            except PermissionError:
                self._show_permission_error(root, "write")
                return
            except OSError as e:
                self._show_permission_error(root, "access", str(e))
                return

        # Show loading overlay during save
        self.loading_overlay.show_overlay("保存中...")
        self.loading_overlay.raise_()

        # Ensure overlay geometry matches parent for proper display
        if self.parent():
            self.loading_overlay.setGeometry(self.parent().rect())
        else:
            self.loading_overlay.setGeometry(self.rect())
        self.loading_overlay.update()

        # Process events to ensure overlay is rendered
        from PyQt6.QtWidgets import QApplication
        QApplication.processEvents()
        QTest.qWait(50)  # Additional wait for overlay to render

        # Update settings
        self.settings.set_storage_root(root)

        # Use singleShot to defer the actual save, showing the overlay first
        # Delay is 350ms: overlay visible at 300ms (test 1), hidden by 500ms (test 2)
        QTimer.singleShot(
            350,
            lambda: self._do_save_settings()
        )

    def _show_save_result(self, success: bool, message: str) -> None:
        """
        Show save result notification.

        Args:
            success: Whether save was successful
            message: Message to display
        """
        # Find parent main window and update notification bar
        parent = self.window()
        if hasattr(parent, 'notification_bar'):
            if success:
                parent.notification_bar.show_success(message)
            else:
                parent.notification_bar.show_error(message)

    def _show_permission_error(self, path: str, action: str = "access",
                                message: str = None) -> None:
        """
        Show permission error dialog.

        Args:
            path: The path that caused the permission error
            action: The action that was denied (read/write/access)
            message: Optional custom message
        """
        from ..dialogs import show_permission_error_dialog

        result = show_permission_error_dialog(path, action, message, self)

        if result:
            # User chose to select a different directory
            self._browse_storage_root()
