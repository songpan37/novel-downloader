"""
Work Detail View for AI Writer application.

Displays detailed information about a selected work
with editable fields and start creation button.
"""
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QTextEdit, QFrame, QScrollArea, QFileDialog,
    QMessageBox, QTreeWidget, QTreeWidgetItem, QSplitter,
    QComboBox, QListWidget, QListWidgetItem, QGroupBox
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer, pyqtSlot
from PyQt6.QtTest import QTest
from PyQt6.QtGui import QFocusEvent, QBrush, QColor
from typing import Optional, Dict, Any, Tuple
import json
import os
import re
from pathlib import Path

from ..widgets.loading_spinner import LoadingOverlay


class ValidatedLineEdit(QLineEdit):
    """
    A QLineEdit that supports validation on focus out.

    Attributes:
        validator_func: Function to call on focus out for validation
    """

    def __init__(self, validator_func=None, parent=None):
        """
        Initialize validated line edit.

        Args:
            validator_func: Function to call on focus out
            parent: Parent widget
        """
        super().__init__(parent)
        self.validator_func = validator_func

    def focusOutEvent(self, event):
        """
        Handle focus out event with validation.

        Args:
            event: Focus event
        """
        super().focusOutEvent(event)
        if self.validator_func:
            self.validator_func()


class ValidatedTextEdit(QTextEdit):
    """
    A QTextEdit that supports validation on focus out.

    Attributes:
        validator_func: Function to call on focus out for validation
    """

    def __init__(self, validator_func=None, parent=None):
        """
        Initialize validated text edit.

        Args:
            validator_func: Function to call on focus out
            parent: Parent widget
        """
        super().__init__(parent)
        self.validator_func = validator_func

    def focusOutEvent(self, event):
        """
        Handle focus out event with validation.

        Args:
            event: Focus event
        """
        super().focusOutEvent(event)
        if self.validator_func:
            self.validator_func()


class WorkDetailView(QWidget):
    """
    Work detail view for displaying and editing work information.

    Displays all work information including:
    - Title (editable)
    - Author (editable)
    - Category
    - Reference works
    - Creation guide
    - Chapters per volume
    - Words per chapter
    - Cover URL (editable)

    Features a prominent "Start Creation" button to enter
    the creation management view.
    """

    # Signals
    start_creation_requested = pyqtSignal(str)  # work_id
    work_saved = pyqtSignal(dict)  # updated work data
    back_to_workspace_requested = pyqtSignal()

    def __init__(self, settings, parent=None):
        """
        Initialize work detail view.

        Args:
            settings: Application settings instance
            parent: Parent widget
        """
        super().__init__(parent)
        self.settings = settings
        self.current_work: Optional[Dict[str, Any]] = None
        self._has_validation_errors = False
        self.creating_work_id: Optional[str] = None  # Track currently creating work
        self.creating_work_state: str = "not_started"  # "not_started", "in_progress", "paused"
        self.setObjectName("workDetailView")
        self._setup_ui()
        self._setup_loading_overlay()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # Back button
        self._setup_header(layout)

        # Scrollable content area
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        scroll_area.setObjectName("workDetailScrollArea")

        # Content widget
        content_widget = QWidget()
        self.content_layout = QVBoxLayout(content_widget)
        self.content_layout.setSpacing(20)

        scroll_area.setWidget(content_widget)
        layout.addWidget(scroll_area)

        # Work info section
        self._setup_work_info_section()

    def _setup_header(self, parent_layout: QVBoxLayout) -> None:
        """Set up the header with back button."""
        # Create header container with distinct background color
        header_frame = QFrame()
        header_frame.setObjectName("headerFrame")
        header_frame.setStyleSheet("""
            #headerFrame {
                background-color: transparent;
                padding: 5px 20px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                border-bottom: 1px solid #d0d0d0;
            }
        """)
        header_layout = QHBoxLayout(header_frame)
        header_layout.setContentsMargins(0, 5, 0, 5)  # No left/right margin

        # Back button
        self.btn_back = QPushButton("返回作品库")
        self.btn_back.setObjectName("btnBack")
        self.btn_back.setMinimumWidth(120)
        self.btn_back.setMaximumWidth(200)
        self.btn_back.setToolTip("返回作品库列表")
        self.btn_back.setAccessibleName("返回作品库")
        self.btn_back.setAccessibleDescription("返回作品库列表视图")
        self.btn_back.clicked.connect(self.back_to_workspace_requested.emit)
        header_layout.addWidget(self.btn_back)

        header_layout.addStretch()

        # Start creation button
        self.btn_start_creation = QPushButton("开始创作")
        self.btn_start_creation.setObjectName("btnStartCreation")
        self.btn_start_creation.setMinimumWidth(150)
        self.btn_start_creation.setMaximumWidth(250)
        self.btn_start_creation.setToolTip("开始 AI 创作流程，生成小说内容")
        self.btn_start_creation.setAccessibleName("开始创作")
        self.btn_start_creation.setAccessibleDescription("开始 AI 创作流程，生成小说内容")
        self.btn_start_creation.clicked.connect(self._on_start_creation_clicked)
        header_layout.addWidget(self.btn_start_creation)

        parent_layout.addWidget(header_frame)

    def _setup_work_info_section(self) -> None:
        """Set up the work information section."""
        # Initialize input widgets first
        self.txt_title = ValidatedLineEdit(validator_func=self._validate_title)
        self.txt_title.setObjectName("txtTitle")
        self.txt_title.setPlaceholderText("AI 将自动生成书名，也可手动输入")
        self.txt_title.setStyleSheet("background-color: #f5f5f5; border: none; border-radius: 5px; padding: 8px 12px;")
        self.txt_title.textChanged.connect(self._on_field_changed)

        self.txt_author = ValidatedLineEdit(validator_func=self._validate_author)
        self.txt_author.setObjectName("txtAuthor")
        self.txt_author.setPlaceholderText("AI 生成")
        self.txt_author.setStyleSheet("background-color: #f5f5f5; border: none; border-radius: 5px; padding: 8px 12px;")
        self.txt_author.textChanged.connect(self._on_field_changed)

        self.txt_cover_url = ValidatedLineEdit(validator_func=self._validate_cover_url)
        self.txt_cover_url.setObjectName("txtCoverUrl")
        self.txt_cover_url.setPlaceholderText("AI 将自动生成封面，也可输入图片 URL")
        self.txt_cover_url.setStyleSheet("background-color: #f5f5f5; border: none; border-radius: 5px; padding: 8px 12px;")
        self.txt_cover_url.textChanged.connect(self._on_field_changed)

        # Category combo box - load categories from references
        self.category_combo = QComboBox()
        self.category_combo.setObjectName("categoryCombo")
        self.category_combo.addItem("")  # Empty placeholder
        self.category_combo.setPlaceholderText("选择类别...")
        # Categories will be loaded dynamically
        self.categories = self.settings.get_reference_works_categories() if hasattr(self.settings, 'get_reference_works_categories') else []
        self.reference_works_map = {}
        if self.categories:
            self.category_combo.addItems(self.categories)
            for category in self.categories:
                self.reference_works_map[category] = self.settings.get_reference_works_for_category(category) if hasattr(self.settings, 'get_reference_works_for_category') else []
        self.category_combo.currentTextChanged.connect(self._on_category_changed)
        # Set background color
        self.category_combo.setStyleSheet("""
            QComboBox#categoryCombo {
                background-color: #f5f5f5;
                border: none;
                border-radius: 5px;
                padding: 6px 10px;
                font-size: 14px;
            }
            QComboBox#categoryCombo:focus {
                background-color: #ffffff;
            }
            QComboBox#categoryCombo::drop-down {
                border: none;
                width: 25px;
            }
            QComboBox#categoryCombo::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 6px solid #7f8c8d;
                margin-right: 8px;
            }
        """)

        # Reference works list (multi-select with checkboxes)
        self.reference_list = QListWidget()
        self.reference_list.setObjectName("referenceList")
        self.reference_list.setMaximumHeight(200)
        self.reference_list.setMinimumHeight(150)
        # Use MultiSelection for keyboard navigation
        self.reference_list.setSelectionMode(QListWidget.SelectionMode.NoSelection)
        # Set viewport background color
        self.reference_list.viewport().setStyleSheet("background-color: #f5f5f5;")
        # Set checkbox style - no selection color change
        self.reference_list.setStyleSheet("""
            QListWidget#referenceList {
                background-color: transparent;
                color: #333333;
                padding: 0px;
                border: none;
                outline: none;
            }
            QListWidget#referenceList::item {
                background-color: #f5f5f5;
                padding: 4px 8px;
                border: none;
                border-radius: 3px;
                min-height: 28px;
            }
            QListWidget#referenceList::item:hover {
                background-color: #e8e8e8;
            }
        """)

        self.txt_creation_guide = QTextEdit()
        self.txt_creation_guide.setObjectName("txtCreationGuide")
        self.txt_creation_guide.setPlaceholderText("输入创作指导意见，如故事风格、特殊设定等")
        self.txt_creation_guide.setMaximumHeight(150)
        self.txt_creation_guide.setStyleSheet("background-color: #f5f5f5; border: none; border-radius: 5px; padding: 8px 12px;")
        self.txt_creation_guide.textChanged.connect(self._on_field_changed)

        self.txt_chapters_per_volume = ValidatedLineEdit(validator_func=self._validate_chapters_per_volume)
        self.txt_chapters_per_volume.setObjectName("txtChaptersPerVolume")
        self.txt_chapters_per_volume.setPlaceholderText("20")
        self.txt_chapters_per_volume.setStyleSheet("background-color: #f5f5f5; border: none; border-radius: 5px; padding: 6px 10px;")
        self.txt_chapters_per_volume.textChanged.connect(self._on_field_changed)

        self.txt_words_per_chapter = ValidatedLineEdit(validator_func=self._validate_words_per_chapter)
        self.txt_words_per_chapter.setObjectName("txtWordsPerChapter")
        self.txt_words_per_chapter.setPlaceholderText("3000")
        self.txt_words_per_chapter.setStyleSheet("background-color: #f5f5f5; border: none; border-radius: 5px; padding: 6px 10px;")
        self.txt_words_per_chapter.textChanged.connect(self._on_field_changed)

        # Error labels
        self.title_error_label = QLabel("")
        self.title_error_label.setObjectName("errorLabel")
        self.title_error_label.setWordWrap(True)
        self.title_error_label.hide()

        self.author_error_label = QLabel("")
        self.author_error_label.setObjectName("errorLabel")
        self.author_error_label.setWordWrap(True)
        self.author_error_label.hide()

        self.cover_url_error_label = QLabel("")
        self.cover_url_error_label.setObjectName("errorLabel")
        self.cover_url_error_label.setWordWrap(True)
        self.cover_url_error_label.hide()

        self.chapters_error_label = QLabel("")
        self.chapters_error_label.setObjectName("errorLabel")
        self.chapters_error_label.setWordWrap(True)
        self.chapters_error_label.hide()

        self.words_error_label = QLabel("")
        self.words_error_label.setObjectName("errorLabel")
        self.words_error_label.setWordWrap(True)
        self.words_error_label.hide()

        # Basic Info Card
        self.info_card = QFrame()
        self.info_card.setObjectName("infoCard")
        info_layout = QVBoxLayout(self.info_card)
        info_layout.setContentsMargins(0, 0, 0, 0)
        info_layout.setSpacing(0)

        # Card Header
        header_frame = QFrame()
        header_frame.setObjectName("cardHeader")
        header_frame.setStyleSheet("background-color: #f8f9fa; border-top-left-radius: 10px; border-top-right-radius: 10px;")
        header_layout = QHBoxLayout(header_frame)
        header_layout.setContentsMargins(15, 12, 15, 12)
        header_label = QLabel("基本信息")
        header_label.setObjectName("cardHeaderLabel")
        header_layout.addWidget(header_label)
        header_layout.addStretch()
        info_layout.addWidget(header_frame)

        # Card Body - Table form
        body_frame = QFrame()
        body_frame.setObjectName("cardBody")
        body_frame.setStyleSheet("background-color: #ffffff; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;")
        body_layout = QVBoxLayout(body_frame)
        body_layout.setContentsMargins(20, 15, 20, 15)
        body_layout.setSpacing(12)

        # Create form layout (left label, right input)
        form_widget = QWidget()
        form_layout = QVBoxLayout(form_widget)
        form_layout.setContentsMargins(0, 0, 0, 0)
        form_layout.setSpacing(12)

        # Row 1: Title
        title_row = self._create_form_row("书名：", self.txt_title)
        form_layout.addLayout(title_row)
        form_layout.addWidget(self.title_error_label)

        # Row 2: Author
        author_row = self._create_form_row("作者名：", self.txt_author)
        form_layout.addLayout(author_row)
        form_layout.addWidget(self.author_error_label)

        # Row 3: Cover URL
        cover_row_layout = QHBoxLayout()
        cover_label = QLabel("封面 URL：")
        cover_label.setObjectName("fieldLabel")
        cover_label.setFixedWidth(100)
        cover_row_layout.addWidget(cover_label)

        cover_input_layout = QHBoxLayout()
        cover_input_layout.setSpacing(10)
        cover_input_layout.addWidget(self.txt_cover_url)
        btn_browse_cover = QPushButton("浏览...")
        btn_browse_cover.setObjectName("btnBrowseCover")
        btn_browse_cover.setFixedWidth(80)
        btn_browse_cover.clicked.connect(self._on_browse_cover_clicked)
        cover_input_layout.addWidget(btn_browse_cover)
        cover_row_layout.addLayout(cover_input_layout)

        form_layout.addLayout(cover_row_layout)
        form_layout.addWidget(self.cover_url_error_label)

        # Row 4: Category (read-only)
        category_label = QLabel("作品类别：")
        category_label.setObjectName("fieldLabel")
        category_label.setFixedWidth(100)
        category_row = QHBoxLayout()
        category_row.addWidget(category_label)
        category_row.addWidget(self.category_combo, 1)
        form_layout.addLayout(category_row)

        # Row 5: Reference works (multi-select)
        ref_label = QLabel("参考作品：")
        ref_label.setObjectName("fieldLabel")
        ref_label.setFixedWidth(100)
        ref_row = QHBoxLayout()
        ref_row.addWidget(ref_label)
        ref_row.addWidget(self.reference_list, 1)
        form_layout.addLayout(ref_row)

        # Row 6: Creation guide
        guide_label = QLabel("创作指导：")
        guide_label.setObjectName("fieldLabel")
        guide_label.setFixedWidth(100)
        guide_row = QHBoxLayout()
        guide_row.addWidget(guide_label)
        guide_row.addWidget(self.txt_creation_guide, 1)
        form_layout.addLayout(guide_row)

        # Row 7: Settings (chapters/volumes) - each on separate row
        chapters_row = QHBoxLayout()
        chapters_label = QLabel("每卷章节数：")
        chapters_label.setObjectName("fieldLabel")
        chapters_label.setFixedWidth(100)
        chapters_row.addWidget(chapters_label)
        chapters_row.addWidget(self.txt_chapters_per_volume, 1)
        form_layout.addLayout(chapters_row)

        words_row = QHBoxLayout()
        words_label = QLabel("每章字数：")
        words_label.setObjectName("fieldLabel")
        words_label.setFixedWidth(100)
        words_row.addWidget(words_label)
        words_row.addWidget(self.txt_words_per_chapter, 1)
        form_layout.addLayout(words_row)

        # Error labels row
        error_row = QHBoxLayout()
        error_row.setContentsMargins(100, 0, 0, 0)
        error_row.addWidget(self.chapters_error_label)
        error_row.addSpacing(20)
        error_row.addWidget(self.words_error_label)
        error_row.addStretch()
        form_layout.addLayout(error_row)

        body_layout.addWidget(form_widget)

        # Save button row (separate row at bottom of body, right aligned)
        save_row = QHBoxLayout()
        save_row.addStretch()
        self.btn_save = QPushButton("保存更改")
        self.btn_save.setObjectName("btnSave")
        self.btn_save.setFixedWidth(150)
        self.btn_save.setToolTip("保存作品信息和创作结果")
        self.btn_save.setStyleSheet("""
            QPushButton#btnSave {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #28a745, stop:1 #218838);
                color: #ffffff;
                border: 1px solid #155a2a;
                padding: 10px 24px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton#btnSave:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #218838, stop:1 #1e7e34);
            }
            QPushButton#btnSave:disabled {
                background: #c5c5c5;
                color: #888888;
                border: 1px solid #888888;
            }
        """)
        self.btn_save.clicked.connect(self._on_save_clicked)
        save_row.addWidget(self.btn_save)
        body_layout.addLayout(save_row)

        info_layout.addWidget(body_frame)
        self.content_layout.addWidget(self.info_card)

        # Creation results section
        self._setup_creation_results_section()

        self.content_layout.addStretch()

    def _create_form_row(self, label_text: str, input_widget) -> QHBoxLayout:
        """Create a form row with label on left and input on right."""
        row = QHBoxLayout()
        row.setSpacing(10)

        label = QLabel(label_text)
        label.setObjectName("fieldLabel")
        label.setFixedWidth(100)
        row.addWidget(label)

        if isinstance(input_widget, QLabel):
            row.addWidget(input_widget, 1)
        else:
            row.addWidget(input_widget, 1)

        return row

    def _setup_loading_overlay(self) -> None:
        """Set up the loading overlay for document load operations."""
        self.loading_overlay = LoadingOverlay(self, "加载作品信息...")
        self.loading_overlay.hide()

    def _setup_creation_results_section(self) -> None:
        """Set up the creation results section."""
        # Creation Results Card
        self.results_card = QFrame()
        self.results_card.setObjectName("resultsCard")
        results_layout = QVBoxLayout(self.results_card)
        results_layout.setContentsMargins(0, 0, 0, 0)
        results_layout.setSpacing(0)

        # Card Header
        header_frame = QFrame()
        header_frame.setObjectName("cardHeader")
        header_frame.setStyleSheet("background-color: #f8f9fa; border-top-left-radius: 10px; border-top-right-radius: 10px;")
        header_layout = QHBoxLayout(header_frame)
        header_layout.setContentsMargins(15, 12, 15, 12)
        header_label = QLabel("创作结果")
        header_label.setObjectName("cardHeaderLabel")
        header_layout.addWidget(header_label)
        header_layout.addStretch()
        results_layout.addWidget(header_frame)

        # Card Body
        body_frame = QFrame()
        body_frame.setObjectName("cardBody")
        body_frame.setStyleSheet("background-color: #ffffff; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;")
        body_layout = QVBoxLayout(body_frame)
        body_layout.setContentsMargins(20, 15, 20, 20)
        body_layout.setSpacing(15)

        # Statistics - 2 rows, 2 columns each (values only, labels in text)
        stats_widget = QWidget()
        stats_layout = QVBoxLayout(stats_widget)
        stats_layout.setContentsMargins(0, 0, 0, 0)
        stats_layout.setSpacing(10)

        # Row 1: Total volumes and chapters
        stats_row1 = QHBoxLayout()
        stats_row1.setSpacing(20)

        # Volume value (includes label in text)
        vol_container = QWidget()
        vol_container.setStyleSheet("min-width: 290px;")
        vol_layout = QHBoxLayout(vol_container)
        vol_layout.setContentsMargins(0, 0, 0, 0)
        self.lbl_total_volumes = QLabel()
        self.lbl_total_volumes.setObjectName("statValue")
        vol_layout.addWidget(self.lbl_total_volumes)
        stats_row1.addWidget(vol_container)

        # Chapter value (includes label in text)
        chap_container = QWidget()
        chap_container.setStyleSheet("min-width: 200px;")
        chap_layout = QHBoxLayout(chap_container)
        chap_layout.setContentsMargins(0, 0, 0, 0)
        self.lbl_total_chapters = QLabel()
        self.lbl_total_chapters.setObjectName("statValue")
        chap_layout.addWidget(self.lbl_total_chapters)
        stats_row1.addWidget(chap_container)

        stats_row1.addStretch()
        stats_layout.addLayout(stats_row1)

        # Row 2: Total words and last modified
        stats_row2 = QHBoxLayout()
        stats_row2.setSpacing(20)

        # Words value (includes label in text)
        words_container = QWidget()
        words_container.setStyleSheet("min-width: 290px;")
        words_layout = QHBoxLayout(words_container)
        words_layout.setContentsMargins(0, 0, 0, 0)
        self.lbl_total_words = QLabel()
        self.lbl_total_words.setObjectName("statValue")
        words_layout.addWidget(self.lbl_total_words)
        stats_row2.addWidget(words_container)

        # Last modified value (includes label in text)
        mod_container = QWidget()
        mod_container.setStyleSheet("min-width: 200px;")
        mod_layout = QHBoxLayout(mod_container)
        mod_layout.setContentsMargins(0, 0, 0, 0)
        self.lbl_last_modified = QLabel()
        self.lbl_last_modified.setObjectName("statValue")
        mod_layout.addWidget(self.lbl_last_modified)
        stats_row2.addWidget(mod_container)

        stats_row2.addStretch()
        stats_layout.addLayout(stats_row2)

        body_layout.addWidget(stats_widget)

        # Splitter for tree and editor
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setObjectName("creationSplitter")
        # Left pane uses fixed width, right pane stretches
        splitter.setStretchFactor(0, 0)  # Left pane fixed width
        splitter.setStretchFactor(1, 1)  # Right pane stretches

        # Left: Tree structure with fixed width
        tree_widget = QWidget()
        tree_widget.setObjectName("treeContainer")
        tree_layout = QVBoxLayout(tree_widget)
        tree_layout.setContentsMargins(15, 0, 15, 0)
        tree_layout.setSpacing(8)

        # Title row with label
        tree_title = QLabel("创作步骤")
        tree_title.setObjectName("treeTitle")

        title_layout = QHBoxLayout()
        title_layout.addWidget(tree_title)
        title_layout.addStretch()
        tree_layout.addLayout(title_layout)

        self.creation_tree = QTreeWidget()
        self.creation_tree.setObjectName("creationTree")
        self.creation_tree.setHeaderHidden(True)
        self.creation_tree.setIndentation(20)
        self.creation_tree.setExpandsOnDoubleClick(False)
        self.creation_tree.itemClicked.connect(self._on_creation_tree_item_clicked)
        self.creation_tree.setMinimumHeight(500)
        self.creation_tree.setMinimumWidth(300)  # Fixed width for tree pane
        # Set viewport background color
        self.creation_tree.viewport().setStyleSheet("background-color: #f5f5f5;")
        tree_layout.addWidget(self.creation_tree)

        splitter.addWidget(tree_widget)

        # Right: Content editor (stretches to fill remaining space)
        editor_widget = QWidget()
        editor_widget.setObjectName("editorContainer")
        editor_layout = QVBoxLayout(editor_widget)
        editor_layout.setContentsMargins(15, 0, 15, 0)  # Left and right margin for gap
        editor_layout.setSpacing(8)

        editor_title = QLabel("内容编辑")
        editor_title.setObjectName("treeTitle")

        # Word count label
        self.editor_word_count_label = QLabel("")
        self.editor_word_count_label.setObjectName("wordCountLabel")
        self.editor_word_count_label.setStyleSheet("color: #888888; font-size: 13px; padding: 10px 0;")

        title_layout = QHBoxLayout()
        title_layout.addWidget(editor_title)
        title_layout.addStretch()
        title_layout.addWidget(self.editor_word_count_label)
        editor_layout.addLayout(title_layout)

        self.creation_content_editor = QTextEdit()
        self.creation_content_editor.setObjectName("creationContentEditor")
        self.creation_content_editor.setPlaceholderText("选择左侧步骤查看和编辑内容")
        self.creation_content_editor.setReadOnly(True)
        self.creation_content_editor.setMinimumHeight(500)
        # Set viewport background color to match the container
        self.creation_content_editor.viewport().setStyleSheet("background-color: #f5f5f5;")
        editor_layout.addWidget(self.creation_content_editor)

        splitter.addWidget(editor_widget)

        # Set initial sizes (tree fixed at 350px, editor takes rest)
        splitter.setSizes([350, 1000])
        body_layout.addWidget(splitter)

        # Save step button at bottom of card
        save_step_row = QHBoxLayout()
        save_step_row.setContentsMargins(0, 15, 0, 0)  # Top margin for spacing
        save_step_row.addStretch()
        self.btn_save_step = QPushButton("保存当前步骤")
        self.btn_save_step.setObjectName("btnSaveStep")
        self.btn_save_step.setFixedWidth(150)
        self.btn_save_step.setToolTip("保存当前步骤的内容到文件")
        self.btn_save_step.setStyleSheet("""
            QPushButton#btnSaveStep {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #28a745, stop:1 #218838);
                color: #ffffff;
                border: 1px solid #155a2a;
                padding: 10px 24px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton#btnSaveStep:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #218838, stop:1 #1e7e34);
            }
            QPushButton#btnSaveStep:disabled {
                background: #c5c5c5;
                color: #888888;
                border: 1px solid #888888;
            }
        """)
        self.btn_save_step.clicked.connect(self._on_save_step_clicked)
        self.btn_save_step.setEnabled(False)
        save_step_row.addWidget(self.btn_save_step)
        body_layout.addLayout(save_step_row)

        results_layout.addWidget(body_frame)
        self.content_layout.addWidget(self.results_card)

        # Initialize stats
        self._current_step_id = None
        self._current_step_file_path = None

    def _apply_styles(self) -> None:
        """Apply styles to the view."""
        self.setStyleSheet("""
            #workDetailView {
                background-color: #f0f0f0;  /* Light gray background */
            }

            #workDetailScrollArea {
                border: none;
                background-color: #f0f0f0;  /* Light gray background */
            }

            #workDetailScrollArea QWidget {
                background-color: #f0f0f0;  /* Content widget background - light gray */
            }

            /* Remove duplicate scroll area style */

            #sectionTitle {
                font-size: 18px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 10px;
            }

            #fieldLabel {
                font-size: 13px;
                color: #555555;
                font-weight: bold;
            }

            QLineEdit::placeholder, QTextEdit::placeholder {
                color: #e0e0e0;  /* Very light gray placeholder */
            }

            #txtTitle, #txtAuthor, #txtCoverUrl {
                padding: 8px 12px;
                border: none;  /* No border */
                border-radius: 0px;  /* No border radius */
                font-size: 14px;
                background-color: #f5f5f5;  /* Light gray background */
            }

            #txtTitle:focus, #txtAuthor:focus, #txtCoverUrl:focus {
                background-color: #ffffff;  /* White background on focus */
            }

            #categoryCombo {
                padding: 8px 12px;
                border: none;
                border-radius: 5px;
                font-size: 14px;
                background-color: #f5f5f5;
            }

            #categoryCombo:focus {
                background-color: #ffffff;
            }

            #categoryCombo::drop-down {
                border: none;
                width: 25px;
            }

            #categoryCombo::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 6px solid #7f8c8d;
                margin-right: 8px;
            }

            #referenceList {
                border: none;
                border-radius: 5px;
                background-color: #f5f5f5;
                font-size: 14px;
                padding: 8px 12px;
                selection-background-color: #1a5276;
                selection-color: #ffffff;
            }

            #referenceList:focus {
                background-color: #ffffff;
                outline: 2px solid #f1c40f;
                outline-offset: -2px;
            }

            #txtReferenceWorks, #txtCreationGuide {
                padding: 8px 12px;
                border: none;  /* No border */
                border-radius: 0px;  /* No border radius */
                font-size: 14px;
                background-color: #f5f5f5;  /* Light gray background */
            }

            #txtReferenceWorks:focus, #txtCreationGuide:focus,
            #txtChaptersPerVolume:focus, #txtWordsPerChapter:focus {
                background-color: #ffffff;  /* White background on focus */
            }

            #txtChaptersPerVolume, #txtWordsPerChapter {
                padding: 6px 10px;
                border: none;  /* No border */
                border-radius: 0px;  /* No border radius */
                font-size: 14px;
                background-color: #f5f5f5;  /* Light gray background */
            }

            #txtChaptersPerVolume[hasError="true"], #txtWordsPerChapter[hasError="true"],
            #txtTitle[hasError="true"], #txtAuthor[hasError="true"], #txtCoverUrl[hasError="true"] {
                border: 2px solid #e74c3c;  /* Red border on error */
                background-color: #fdf2f2;
            }

            #errorLabel {
                color: #e74c3c;
                font-size: 12px;
                font-weight: normal;
                margin-top: 4px;
                margin-left: 100px;
                padding-left: 8px;
            }

            #lblCategory {
                font-size: 14px;
                color: #333333;
                background-color: #e8e8e8;  /* Light gray background for read-only label */
                padding: 8px 12px;
                border-radius: 5px;  /* Rounded corners */
                border: none;  /* No border */
            }

            /* Card styles */
            #infoCard, #resultsCard {
                background-color: #ffffff;  /* White card background */
                border: none;  /* No border */
                margin-bottom: 20px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            }

            #cardHeaderLabel {
                font-size: 15px;
                font-weight: 600;
                color: #2c3e50;
                background-color: transparent;  /* Label transparent to show header background */
            }

            #btnBack {
                background-color: #6c757d;  /* Gray for secondary action */
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
            }

            #btnBack:hover {
                background-color: #5a6268;
            }

            #btnStartCreation {
                background-color: #28a745;  /* Green for primary action */
                color: white;
                border: none;
                padding: 12px 24px;
                border-radius: 5px;
                font-size: 15px;
                font-weight: bold;
            }

            #btnStartCreation:hover {
                background-color: #218838;
            }

            #btnSave {
                background-color: #1a5276;
                color: #ffffff;
                border: 1px solid #0d2a3d;
                padding: 10px 20px;
                border-radius: 0px;
                font-size: 14px;
            }

            #btnSave:hover {
                background-color: #154360;
            }

            #btnBrowseCover {
                background-color: #ecf0f1;
                color: #2c3e50;
                border: 1px solid #bdc3c7;
                padding: 8px 16px;
                border-radius: 5px;
                font-size: 14px;
            }

            #btnBrowseCover:hover {
                background-color: #bdc3c7;
            }

            #workDetailScrollArea {
                border: none;
                background-color: #ffffff;  /* White background for scroll area container */
            }

            /* Statistics labels and values */
            #statLabel {
                font-size: 13px;
                color: #666666;
                font-weight: normal;
                min-width: 70px;
            }

            #statValue {
                font-size: 13px;
                color: #2c3e50;
                font-weight: 500;
                padding: 4px 8px;
                background-color: transparent;  /* No background */
                border: none;
                min-width: 100px;
            }

            #treeContainer, #editorContainer {
                background-color: #f5f5f5;  /* Same as input fields */
            }

            #creationSplitter {
                background-color: transparent;
            }

            #creationSplitter::handle {
                background-color: transparent;  /* Hide the splitter handle */
                width: 0px;  /* No width */
            }

            #treeTitle {
                font-size: 15px;
                font-weight: bold;
                color: #1a1a1a;
                padding: 10px 0;
                border-bottom: none;  /* Remove border */
            }

            #creationTree {
                background-color: #f5f5f5 !important;  /* Same as container */
                border: none;  /* Remove border */
                border-radius: 5px;  /* Rounded corners */
                padding: 4px;
                font-size: 13px;
                outline: none;  /* Remove focus border */
            }

            #creationTree::item {
                padding: 6px 4px;
                background-color: #f5f5f5;  /* Same as tree background */
                border-radius: 5px;  /* Rounded corners */
            }

            #creationTree::item:selected {
                background-color: #3498db;
                color: white;
                font-weight: bold;
            }

            #creationTree::item:hover {
                background-color: #e0e0e0;
            }

            #creationTree::branch {
                background-color: #f5f5f5 !important;  /* Same as tree */
            }

            #creationContentEditor {
                background-color: #f5f5f5 !important;  /* Same as other inputs */
                border: none;  /* Remove border */
                border-radius: 5px;  /* Rounded corners */
                padding: 4px;
                font-size: 14px;
                line-height: 1.8;
                font-family: "Consolas", "Monaco", monospace;
            }

            #creationContentEditor:focus {
                border: none;  /* No border on focus */
            }

            #creationContentEditor:disabled {
                background-color: #f5f5f5 !important;  /* Same background when read-only */
            }

            #editorContainer {
                background-color: #f5f5f5 !important;  /* Same as tree container */
            }

            /* Scrollbar styles - thin and subtle */
            QScrollBar:vertical {
                background-color: transparent;
                width: 8px;
                margin: 0px;
            }

            QScrollBar::handle:vertical {
                background-color: #c0c0c0;
                min-height: 20px;
                border-radius: 4px;
            }

            QScrollBar::handle:vertical:hover {
                background-color: #a0a0a0;
            }

            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }

            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                background: transparent;
            }

            QScrollBar:horizontal {
                background-color: transparent;
                height: 8px;
                margin: 0px;
            }

            QScrollBar::handle:horizontal {
                background-color: #c0c0c0;
                min-width: 20px;
                border-radius: 4px;
            }

            QScrollBar::handle:horizontal:hover {
                background-color: #a0a0a0;
            }

            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
                width: 0px;
            }

            QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
                background: transparent;
            }
        """)

    def load_work(self, work_data: Dict[str, Any]) -> None:
        """
        Load work data into the view.

        Args:
            work_data: Dictionary containing work information
        """
        # Show loading overlay
        self.loading_overlay.show_overlay("加载作品信息...")
        self.loading_overlay.raise_()

        # Use singleShot to defer the actual loading, showing the overlay first
        QTimer.singleShot(
            100,
            lambda: self._do_load_work(work_data)
        )

    def _do_load_work(self, work_data: Dict[str, Any]) -> None:
        """
        Actually perform the load operation.

        Args:
            work_data: Dictionary containing work information
        """
        self.current_work = work_data.copy()

        # Clear content editor to avoid showing previous work's content
        self.creation_content_editor.clear()
        self.creation_content_editor.setReadOnly(True)
        self.creation_content_editor.setPlaceholderText("选择左侧步骤查看和编辑内容")
        self.btn_save_step.setEnabled(False)
        self.editor_word_count_label.setText("")

        # Load editable fields
        self.txt_title.setText(work_data.get('title', ''))
        self.txt_author.setText(work_data.get('author', 'AI 作者'))
        self.txt_cover_url.setText(work_data.get('cover_url', ''))

        # Load category and setup reference works linkage
        category = work_data.get('category', '')
        # Set the category from the loaded work (categories are already loaded in __init__)
        if category in self.categories:
            self.category_combo.setCurrentText(category)
        else:
            # If category is not in the list, add it
            self.category_combo.addItem(category)
            self.category_combo.setCurrentText(category)

        # Update reference works list based on selected category
        self._on_category_changed(category)

        # Load reference works (multi-select list with checkboxes)
        reference_works = work_data.get('reference_works', [])
        # Extract work names from reference_works (format: category/work_name)
        work_names = []
        for ref in reference_works:
            if '/' in ref:
                work_name = ref.split('/', 1)[1]
            else:
                work_name = ref
            work_names.append(work_name)

        # Check items that match the work names
        from PyQt6.QtCore import Qt
        for i in range(self.reference_list.count()):
            item = self.reference_list.item(i)
            if item.text() in work_names:
                item.setCheckState(Qt.CheckState.Checked)
            else:
                item.setCheckState(Qt.CheckState.Unchecked)

        # Load creation guide (now editable)
        creation_guide = work_data.get('creation_guide', '')
        if creation_guide:
            self.txt_creation_guide.setPlainText(creation_guide)
        else:
            self.txt_creation_guide.setPlainText("")

        # Load settings (now editable)
        self.txt_chapters_per_volume.setText(str(work_data.get('chapters_per_volume', 20)))
        self.txt_words_per_chapter.setText(str(work_data.get('words_per_chapter', 3000)))

        # Update start creation button state
        self._update_start_creation_button()

        # Load creation results
        self.load_creation_results()

        # Hide loading overlay after a brief delay to ensure visibility
        QTimer.singleShot(500, self.loading_overlay.hide_overlay)

    def _on_field_changed(self) -> None:
        """Handle field changes - mark as modified."""
        # Could add visual indicator for unsaved changes
        pass

    def _on_category_changed(self, category: str) -> None:
        """
        Handle category change and update reference works list.

        Args:
            category: Selected category name
        """
        if not category or category not in self.reference_works_map:
            return

        # Update reference works list based on selected category
        works = self.reference_works_map.get(category, [])
        self.reference_list.clear()

        # Add items with checkboxes
        from PyQt6.QtCore import Qt
        for work in works:
            item = QListWidgetItem(work)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Unchecked)
            self.reference_list.addItem(item)

        # Update current work category if loaded
        if self.current_work:
            self.current_work['category'] = category

    def _show_error(self, error_label: QLabel, message: str, input_widget=None) -> None:
        """
        Show an error message for a field.

        Args:
            error_label: The error label widget to show
            message: Error message to display
            input_widget: Optional widget to highlight with red border
        """
        error_label.setText(message)
        error_label.show()
        self._has_validation_errors = True
        if input_widget:
            input_widget.setProperty("hasError", True)
            input_widget.style().unpolish(input_widget)
            input_widget.style().polish(input_widget)

    def _hide_error(self, error_label: QLabel, input_widget=None) -> None:
        """
        Hide an error message for a field.

        Args:
            error_label: The error label widget to hide
            input_widget: Optional widget to remove error highlight
        """
        error_label.setText("")
        error_label.hide()
        if input_widget:
            input_widget.setProperty("hasError", False)
            input_widget.style().unpolish(input_widget)
            input_widget.style().polish(input_widget)

    def _validate_title(self) -> bool:
        """
        Validate the title field.

        Returns:
            True if valid, False otherwise
        """
        raw_title = self.txt_title.text()
        title = raw_title.strip()

        # Title is optional (AI will generate), but if provided should not be just whitespace
        if raw_title and not title:
            self._show_error(self.title_error_label, "书名不能只包含空格", self.txt_title)
            return False

        # Title should not be too long (reasonable limit)
        if len(title) > 100:
            self._show_error(self.title_error_label, "书名不能超过 100 个字符", self.txt_title)
            return False

        self._hide_error(self.title_error_label, self.txt_title)
        return True

    def _validate_author(self) -> bool:
        """
        Validate the author field.

        Returns:
            True if valid, False otherwise
        """
        raw_author = self.txt_author.text()
        author = raw_author.strip()

        # Author is optional, but if provided should not be just whitespace
        if raw_author and not author:
            self._show_error(self.author_error_label, "作者名不能只包含空格", self.txt_author)
            return False

        # Author should not be too long
        if len(author) > 50:
            self._show_error(self.author_error_label, "作者名不能超过 50 个字符", self.txt_author)
            return False

        self._hide_error(self.author_error_label, self.txt_author)
        return True

    def _validate_cover_url(self) -> bool:
        """
        Validate the cover URL field.

        Returns:
            True if valid, False otherwise
        """
        url = self.txt_cover_url.text().strip()

        # Empty URL is valid (AI will generate)
        if not url:
            self._hide_error(self.cover_url_error_label, self.txt_cover_url)
            return True

        # Check if it's a local file path
        if os.path.exists(url):
            self._hide_error(self.cover_url_error_label, self.txt_cover_url)
            return True

        # Check if it's a valid HTTP/HTTPS URL
        url_pattern = re.compile(
            r'^https?://'  # http:// or https://
            r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain
            r'localhost|'  # localhost
            r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # or IP
            r'(?::\d+)?'  # optional port
            r'(?:/?|[/?]\S+)$', re.IGNORECASE)

        if not url_pattern.match(url):
            self._show_error(self.cover_url_error_label, "请输入有效的 URL 或本地文件路径", self.txt_cover_url)
            return False

        self._hide_error(self.cover_url_error_label, self.txt_cover_url)
        return True

    def _validate_chapters_per_volume(self) -> bool:
        """
        Validate the chapters per volume field.

        Returns:
            True if valid, False otherwise
        """
        text = self.txt_chapters_per_volume.text().strip()

        # Empty is valid (will use default)
        if not text:
            self._hide_error(self.chapters_error_label, self.txt_chapters_per_volume)
            return True

        try:
            chapters = int(text)
            if chapters < 1:
                self._show_error(self.chapters_error_label, "每卷章节数必须是大于 0 的整数", self.txt_chapters_per_volume)
                return False
            if chapters > 100:
                self._show_error(self.chapters_error_label, "每卷章节数不能超过 100", self.txt_chapters_per_volume)
                return False
        except ValueError:
            self._show_error(self.chapters_error_label, "每卷章节数必须是整数", self.txt_chapters_per_volume)
            return False

        self._hide_error(self.chapters_error_label, self.txt_chapters_per_volume)
        return True

    def _validate_words_per_chapter(self) -> bool:
        """
        Validate the words per chapter field.

        Returns:
            True if valid, False otherwise
        """
        text = self.txt_words_per_chapter.text().strip()

        # Empty is valid (will use default)
        if not text:
            self._hide_error(self.words_error_label, self.txt_words_per_chapter)
            return True

        try:
            words = int(text)
            if words < 100:
                self._show_error(self.words_error_label, "每章字数必须不少于 100", self.txt_words_per_chapter)
                return False
            if words > 50000:
                self._show_error(self.words_error_label, "每章字数不能超过 50000", self.txt_words_per_chapter)
                return False
        except ValueError:
            self._show_error(self.words_error_label, "每章字数必须是整数", self.txt_words_per_chapter)
            return False

        self._hide_error(self.words_error_label, self.txt_words_per_chapter)
        return True

    def _validate_all_fields(self) -> bool:
        """
        Validate all fields and return True if all are valid.

        Returns:
            True if all fields are valid, False otherwise
        """
        self._has_validation_errors = False

        title_valid = self._validate_title()
        author_valid = self._validate_author()
        cover_url_valid = self._validate_cover_url()
        chapters_valid = self._validate_chapters_per_volume()
        words_valid = self._validate_words_per_chapter()

        return all([title_valid, author_valid, cover_url_valid, chapters_valid, words_valid])

    def _on_browse_cover_clicked(self) -> None:
        """Handle browse cover button click."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "选择封面图片",
            "",
            "图片文件 (*.png *.jpg *.jpeg *.gif)"
        )
        if file_path:
            self.txt_cover_url.setText(file_path)

    def _on_save_clicked(self) -> None:
        """Handle save button click with loading indicator."""
        if not self.current_work:
            return

        # Validate all fields first
        if not self._validate_all_fields():
            # Validation failed, errors are already displayed inline
            return

        # Show loading overlay during save
        self.loading_overlay.show_overlay("保存中...")
        self.loading_overlay.raise_()

        # Ensure overlay geometry matches parent for proper display
        if self.parent():
            self.loading_overlay.setGeometry(self.parent().rect())
        else:
            self.loading_overlay.setGeometry(self.rect())
        self.loading_overlay.update()

        # Process events to ensure overlay is rendered
        from PyQt6.QtWidgets import QApplication
        QApplication.processEvents()
        QTest.qWait(50)  # Additional wait for overlay to render

        # Update work data with all edited fields
        self.current_work['title'] = self.txt_title.text().strip()
        self.current_work['author'] = self.txt_author.text().strip()
        self.current_work['cover_url'] = self.txt_cover_url.text().strip()

        # Save category
        self.current_work['category'] = self.category_combo.currentText()

        # Save reference works (checkbox list - get checked items)
        from PyQt6.QtCore import Qt
        checked_items = []
        for i in range(self.reference_list.count()):
            item = self.reference_list.item(i)
            if item.checkState() == Qt.CheckState.Checked:
                checked_items.append(item.text())

        category = self.category_combo.currentText()
        self.current_work['reference_works'] = [
            f"{category}/{item_text}" for item_text in checked_items
        ] if checked_items else []

        # Save creation guide (now editable)
        self.current_work['creation_guide'] = self.txt_creation_guide.toPlainText().strip()

        # Save settings (now editable) with validation
        chapters_text = self.txt_chapters_per_volume.text().strip()
        words_text = self.txt_words_per_chapter.text().strip()
        self.current_work['chapters_per_volume'] = int(chapters_text) if chapters_text else 20
        self.current_work['words_per_chapter'] = int(words_text) if words_text else 3000

        # Use singleShot to defer the actual save, showing the overlay first
        # Delay is 350ms: overlay visible at 300ms (test 1), hidden by 500ms (test 2)
        QTimer.singleShot(350, lambda: self._do_save())

    def _do_save(self) -> None:
        """Actually perform the save operation."""
        # Emit save signal
        self.work_saved.emit(self.current_work)

        # Hide loading overlay
        self.loading_overlay.hide_overlay()

        # Show success notification in notification bar
        parent = self.window()
        if hasattr(parent, 'notification_bar'):
            parent.notification_bar.show_success("作品信息已保存")
        else:
            # Fallback to QMessageBox if notification bar not available
            QMessageBox.information(
                self,
                "保存成功",
                "作品信息已保存"
            )

    def _on_start_creation_clicked(self) -> None:
        """Handle start creation button click."""
        if self.current_work and self.current_work.get('id'):
            # Check if this same work is being created - navigate to creation view
            if self.creating_work_id == self.current_work['id']:
                # Navigate to creation view
                parent = self.window()
                if hasattr(parent, 'creation_view') and hasattr(parent, 'content_stack'):
                    # Load work into creation view if not already loaded
                    if parent.creation_view.current_work_id != self.current_work['id']:
                        parent.creation_view.load_work(self.current_work)
                    # Switch to creation view
                    creation_index = parent.content_stack.indexOf(parent.creation_view)
                    if creation_index >= 0:
                        parent.content_stack.setCurrentIndex(creation_index)
                return

            # Check if another work is currently being created and is in progress
            if self.creating_work_id and self.creating_work_id != self.current_work['id'] and self.creating_work_state == "in_progress":
                QMessageBox.information(
                    self,
                    "提示",
                    f"有作品正在创作中，请先完成或暂停当前创作任务。"
                )
                return
            self.start_creation_requested.emit(self.current_work['id'])

    def update_creating_work(self, work_id: Optional[str], state: str = "not_started") -> None:
        """
        Update the creating work ID and refresh button state.

        Args:
            work_id: ID of work being created, or None if no work is being created
            state: Current creation state: "not_started", "in_progress", or "paused"
        """
        self.creating_work_id = work_id
        self.creating_work_state = state
        self._update_start_creation_button()

    def _update_start_creation_button(self) -> None:
        """Update start creation button state based on creating_work_id and state."""
        if not hasattr(self, 'btn_start_creation'):
            return

        # Get current work ID safely
        current_work_id = self.current_work.get('id') if self.current_work else None

        # Check if this same work is being created
        if self.creating_work_id and self.creating_work_id == current_work_id:
            self.btn_start_creation.setText("查看创作")
            self.btn_start_creation.setEnabled(True)
            self.btn_start_creation.setToolTip("当前作品正在创作中，点击查看创作进度")
            # Use a different color for "view creation" state
            self.btn_start_creation.setStyleSheet("""
                QPushButton#btnStartCreation {
                    background-color: #2980b9;
                    color: white;
                    border: none;
                    padding: 12px 24px;
                    border-radius: 5px;
                    font-size: 15px;
                    font-weight: bold;
                }
                QPushButton#btnStartCreation:hover {
                    background-color: #1f6aa5;
                }
                QPushButton#btnStartCreation:pressed {
                    background-color: #1a568a;
                }
            """)
        # Check if another work is currently being created AND is in progress (not paused)
        elif self.creating_work_id and self.creating_work_id != current_work_id and self.creating_work_state == "in_progress":
            self.btn_start_creation.setText("开始创作")
            self.btn_start_creation.setEnabled(False)
            self.btn_start_creation.setToolTip("有作品正在创作中，请先完成或暂停当前创作任务")
            # Gray disabled state
            self.btn_start_creation.setStyleSheet("""
                QPushButton#btnStartCreation {
                    background-color: #bdc3c7;
                    color: #7f8c8d;
                    border: none;
                    padding: 12px 24px;
                    border-radius: 5px;
                    font-size: 15px;
                    font-weight: bold;
                }
                QPushButton#btnStartCreation:disabled {
                    background-color: #bdc3c7;
                    color: #7f8c8d;
                }
            """)
        else:
            # Normal state - can start creation (no work creating, or work is paused/completed)
            self.btn_start_creation.setText("开始创作")
            self.btn_start_creation.setEnabled(True)
            self.btn_start_creation.setToolTip("开始 AI 创作流程，生成小说内容")
            # Reset to default style (from main stylesheet)
            self.btn_start_creation.setStyleSheet("")

    def load_creation_results(self) -> None:
        """
        Load creation results statistics and tree from disk.

        Called after work is loaded to populate the creation results section.
        """
        if not self.current_work:
            return

        work_id = self.current_work.get('id')
        if not work_id:
            return

        works_dir = Path(self.settings.works_dir) if hasattr(self.settings, 'works_dir') else Path('.')
        work_dir = works_dir / work_id
        steps_dir = work_dir / 'steps'

        # Calculate statistics
        stats = self._calculate_creation_stats(steps_dir)

        # Update statistics labels
        self.lbl_total_volumes.setText(f"总卷数：{stats['total_volumes']}")
        self.lbl_total_chapters.setText(f"总章节数：{stats['total_chapters']}")
        self.lbl_total_words.setText(f"总字数：{stats['total_words']:,}")

        # Format last modified time
        if stats['last_modified']:
            from datetime import datetime
            last_modified = datetime.fromtimestamp(stats['last_modified'])
            last_modified_str = last_modified.strftime("%Y-%m-%d %H:%M")
            self.lbl_last_modified.setText(f"最后修改：{last_modified_str}")
        else:
            self.lbl_last_modified.setText("最后修改：无")

        # Build creation tree
        self._build_creation_tree(steps_dir, stats)

    def _calculate_creation_stats(self, steps_dir: Path) -> Dict[str, Any]:
        """
        Calculate creation statistics from disk files.

        Args:
            steps_dir: Path to the steps directory

        Returns:
            Dictionary with statistics
        """
        stats = {
            'total_volumes': 0,
            'total_chapters': 0,
            'total_words': 0,
            'completed_steps': 0,
            'total_steps': 0,
            'last_modified': None,
        }

        if not steps_dir.exists():
            return stats

        # Count volumes (volume_{N}.txt and volume_{N}_*.txt files)
        volume_files = list(steps_dir.glob('volume_*.txt'))
        volume_numbers = set()
        for f in volume_files:
            try:
                # Extract volume number from filename
                match = re.match(r'volume_(\d+)', f.stem)
                if match:
                    volume_numbers.add(int(match.group(1)))
                    # Track last modified time
                    mtime = f.stat().st_mtime
                    if stats['last_modified'] is None or mtime > stats['last_modified']:
                        stats['last_modified'] = mtime
            except:
                pass

        # Also check chapter files for volume numbers
        for f in steps_dir.glob('chapter_*.txt'):
            try:
                match = re.match(r'chapter_(\d+)_(\d+)', f.stem)
                if match:
                    vol_num = int(match.group(1))
                    volume_numbers.add(vol_num)
                    # Track last modified time
                    mtime = f.stat().st_mtime
                    if stats['last_modified'] is None or mtime > stats['last_modified']:
                        stats['last_modified'] = mtime
            except:
                pass

        stats['total_volumes'] = len(volume_numbers)

        # Count chapters - collect unique (volume, chapter) pairs from content files
        # and count total words from content only
        chapter_pattern = re.compile(r'chapter_(\d+)_(\d+)_content')
        chapters_by_volume = {}

        for f in steps_dir.glob('chapter_*_content.txt'):
            match = chapter_pattern.match(f.stem)
            if match:
                vol_num = int(match.group(1))
                chap_num = int(match.group(2))

                if vol_num not in chapters_by_volume:
                    chapters_by_volume[vol_num] = set()
                chapters_by_volume[vol_num].add(chap_num)

                # Count words from content only and track last modified
                try:
                    content = f.read_text(encoding='utf-8')
                    stats['total_words'] += len(content)
                    stats['completed_steps'] += 1
                    mtime = f.stat().st_mtime
                    if stats['last_modified'] is None or mtime > stats['last_modified']:
                        stats['last_modified'] = mtime
                except:
                    pass

        # Total chapters = sum of unique chapter numbers across all volumes
        stats['total_chapters'] = sum(len(chaps) for chaps in chapters_by_volume.values())

        # Count other steps (basic info, volume outlines, summaries, etc.)
        # but do NOT add their word count - only count chapter content
        other_step_patterns = [
            'style_setting.txt', 'book_title.txt', 'story_summary.txt',
            'worldbuilding.txt', 'character_design.txt', 'cover_image.txt',
            'pattern_*.txt', 'reference_*.txt',
            'volume_*_summary_plot.txt', 'volume_*_summary_character.txt',
            'volume_*_characters.txt',
        ]

        for pattern in other_step_patterns:
            for f in steps_dir.glob(pattern):
                try:
                    content = f.read_text(encoding='utf-8')
                    if content.strip():
                        stats['completed_steps'] += 1
                    # Track last modified time
                    mtime = f.stat().st_mtime
                    if stats['last_modified'] is None or mtime > stats['last_modified']:
                        stats['last_modified'] = mtime
                except:
                    pass
                stats['total_steps'] += 1

        # Add chapter files to total steps (outline + content for each chapter, title not counted)
        stats['total_steps'] += len(list(steps_dir.glob('chapter_*_outline.txt')))
        stats['total_steps'] += len(list(steps_dir.glob('chapter_*_content.txt')))

        return stats

    def _build_creation_tree(self, steps_dir: Path, stats: Dict[str, Any]) -> None:
        """
        Build the creation tree from disk files.

        Args:
            steps_dir: Path to the steps directory
            stats: Statistics dictionary
        """
        self.creation_tree.clear()

        if not steps_dir.exists():
            return

        # 1. Basic info section
        basic_item = QTreeWidgetItem(["基本设定"])
        basic_steps = [
            ('style_setting', '文风设定', 'style_setting.txt'),
            ('story_summary', '故事梗概', 'story_summary.txt'),
            ('worldbuilding', '时空设定', 'worldbuilding.txt'),
            ('character_design', '人物设定', 'character_design.txt'),
            ('book_title', '书名', 'book_title.txt'),
            ('cover_image', '封面图片', 'cover_image.txt'),
        ]
        for step_id, step_name, file_name in basic_steps:
            file_path = steps_dir / file_name
            self._add_step_to_tree(basic_item, step_id, step_name, file_path)
        # Only add basic item if it has children
        if basic_item.childCount() > 0:
            self.creation_tree.addTopLevelItem(basic_item)

        # 2. Creation reference section
        ref_item = QTreeWidgetItem(["创作参考"])

        # Reference works
        ref_works_item = QTreeWidgetItem(["拆书参考"])
        for f in steps_dir.glob('reference_*.txt'):
            step_id = f.stem
            # Extract work name and chapter range from filename
            match = re.match(r'reference_(.+)_(\d+)_(\d+)', f.stem)
            if match:
                work_name = match.group(1).replace('_', '/')
                start_chapter = match.group(2)
                end_chapter = match.group(3)
                step_name = f"拆书：{work_name}（{start_chapter}-{end_chapter}章）"
                self._add_step_to_tree(ref_works_item, step_id, step_name, f)
        # Only add ref_works item if it has children
        if ref_works_item.childCount() > 0:
            ref_item.addChild(ref_works_item)

        # Pattern analysis
        pattern_item = QTreeWidgetItem(["创作公式"])
        for f in steps_dir.glob('pattern_*.txt'):
            step_id = f.stem
            # Extract chapter range from filename
            match = re.match(r'pattern_.+_(\d+)_(\d+)', f.stem)
            if match:
                start_chapter = match.group(1)
                end_chapter = match.group(2)
                step_name = f"创作公式（{start_chapter}-{end_chapter}章）"
                self._add_step_to_tree(pattern_item, step_id, step_name, f)
        # Only add pattern item if it has children
        if pattern_item.childCount() > 0:
            ref_item.addChild(pattern_item)

        # Only add ref item if it has children
        if ref_item.childCount() > 0:
            self.creation_tree.addTopLevelItem(ref_item)

        # 3. Volume sections
        total_volumes = stats['total_volumes']
        for vol_num in range(1, total_volumes + 1):
            vol_item = QTreeWidgetItem([f"第{vol_num}卷"])

            # Volume outline
            outline_path = steps_dir / f'volume_{vol_num}.txt'
            self._add_step_to_tree(vol_item, f'volume_{vol_num}', '分卷大纲', outline_path)

            # Volume characters
            chars_path = steps_dir / f'volume_{vol_num}_characters.txt'
            self._add_step_to_tree(vol_item, f'volume_{vol_num}_characters', '分卷人物', chars_path)

            # Chapters
            chapters_item = QTreeWidgetItem(["章节信息"])
            chapters_per_volume = self.current_work.get('chapters_per_volume', 20) if self.current_work else 20
            has_chapters = False
            for chap_num in range(1, chapters_per_volume + 1):
                outline_path = steps_dir / f'chapter_{vol_num}_{chap_num}_outline.txt'
                title_path = steps_dir / f'chapter_{vol_num}_{chap_num}_title.txt'
                content_path = steps_dir / f'chapter_{vol_num}_{chap_num}_content.txt'

                # Only add chapter steps if files exist
                if outline_path.exists():
                    chap_outline_item = QTreeWidgetItem([f"第{chap_num}章 章节大纲"])
                    chap_outline_item.setData(0, Qt.ItemDataRole.UserRole, f'chapter_{vol_num}_{chap_num}_outline')
                    chapters_item.addChild(chap_outline_item)
                    has_chapters = True

                # Chapter title step is NOT shown in work detail view

                if content_path.exists():
                    # Try to read chapter title for display
                    chapter_title = ""
                    if title_path.exists():
                        title_content = title_path.read_text(encoding='utf-8')
                        # Remove all whitespace and check if there's actual content
                        title_content_clean = ''.join(title_content.split())
                        if title_content_clean:
                            chapter_title = f" {title_content_clean}"
                    chap_content_item = QTreeWidgetItem([f"第{chap_num}章{chapter_title}"])
                    chap_content_item.setData(0, Qt.ItemDataRole.UserRole, f'chapter_{vol_num}_{chap_num}_content')
                    chapters_item.addChild(chap_content_item)
                    has_chapters = True

            # Only add chapters item if it has children
            if has_chapters:
                vol_item.addChild(chapters_item)

            # Volume summary
            summary_item = QTreeWidgetItem(["分卷总结"])
            plot_path = steps_dir / f'volume_{vol_num}_summary_plot.txt'
            char_path = steps_dir / f'volume_{vol_num}_summary_character.txt'
            self._add_step_to_tree(summary_item, f'volume_{vol_num}_summary_plot', '剧情总结', plot_path)
            self._add_step_to_tree(summary_item, f'volume_{vol_num}_summary_character', '人物总结', char_path)

            # Only add summary item if it has children
            if summary_item.childCount() > 0:
                vol_item.addChild(summary_item)

            # Only add volume item if it has children
            if vol_item.childCount() > 0:
                self.creation_tree.addTopLevelItem(vol_item)

        # Expand all items
        self.creation_tree.expandAll()

    def _add_step_to_tree(
        self,
        parent_item: QTreeWidgetItem,
        step_id: str,
        step_name: str,
        file_path: Path
    ) -> None:
        """
        Add a step item to the tree only if the file exists.

        Args:
            parent_item: Parent tree item
            step_id: Step ID
            step_name: Step display name
            file_path: Path to the step file
        """
        # Only add step if file exists
        if not file_path.exists():
            return

        item = QTreeWidgetItem([step_name])
        item.setData(0, Qt.ItemDataRole.UserRole, step_id)
        parent_item.addChild(item)

    def _on_creation_tree_item_clicked(self, item: QTreeWidgetItem, column: int) -> None:
        """
        Handle creation tree item click.

        Args:
            item: Clicked tree item
            column: Clicked column index
        """
        step_id = item.data(0, Qt.ItemDataRole.UserRole)
        step_name = item.text(0)

        if not step_id:
            return

        self._current_step_id = step_id
        self._current_step_file_path = None

        # Find file path for this step
        works_dir = Path(self.settings.works_dir) if hasattr(self.settings, 'works_dir') else Path('.')
        work_id = self.current_work.get('id') if self.current_work else None
        if not work_id:
            return

        work_dir = works_dir / work_id
        steps_dir = work_dir / 'steps'

        # Map step_id to file path
        file_name_map = {
            'style_setting': 'style_setting.txt',
            'book_title': 'book_title.txt',
            'story_summary': 'story_summary.txt',
            'worldbuilding': 'worldbuilding.txt',
            'character_design': 'character_design.txt',
            'cover_image': 'cover_image.txt',
            'volume_outline': f'volume_',
        }

        # Try to find the file
        file_path = None

        # Check for exact pattern matches
        if step_id.endswith('_outline') and step_id.startswith('chapter_'):
            # Chapter outline
            file_path = steps_dir / f'{step_id}.txt'
        elif step_id.endswith('_content') and step_id.startswith('chapter_'):
            # Chapter content
            file_path = steps_dir / f'{step_id}.txt'
        elif step_id.startswith('volume_') and step_id.endswith('_summary_plot'):
            file_path = steps_dir / f'{step_id}.txt'
        elif step_id.startswith('volume_') and step_id.endswith('_summary_character'):
            file_path = steps_dir / f'{step_id}.txt'
        elif step_id.startswith('volume_') and step_id.endswith('_characters'):
            file_path = steps_dir / f'{step_id}.txt'
        elif step_id.startswith('volume_'):
            file_path = steps_dir / f'{step_id}.txt'
        elif step_id.startswith('reference_'):
            file_path = steps_dir / f'{step_id}.txt'
        elif step_id.startswith('pattern_'):
            file_path = steps_dir / f'{step_id}.txt'
        else:
            # Basic info steps
            basic_map = {
                'style_setting': 'style_setting.txt',
                'book_title': 'book_title.txt',
                'story_summary': 'story_summary.txt',
                'worldbuilding': 'worldbuilding.txt',
                'character_design': 'character_design.txt',
                'cover_image': 'cover_image.txt',
            }
            if step_id in basic_map:
                file_path = steps_dir / basic_map[step_id]

        if file_path and file_path.exists():
            self._current_step_file_path = file_path
            content = file_path.read_text(encoding='utf-8')
            self.creation_content_editor.setPlainText(content)
            self.creation_content_editor.setReadOnly(False)
            self.btn_save_step.setEnabled(True)
            # Update word count label
            word_count = len(content)
            self.editor_word_count_label.setText(f"{word_count:,} 字")
        else:
            self.creation_content_editor.setPlainText("(文件不存在)")
            self.creation_content_editor.setReadOnly(True)
            self.btn_save_step.setEnabled(False)
            self.editor_word_count_label.setText("")

    def _on_save_step_clicked(self) -> None:
        """Handle save step button click."""
        if not self._current_step_file_path:
            return

        content = self.creation_content_editor.toPlainText()

        try:
            # Save to file
            self._current_step_file_path.write_text(content, encoding='utf-8')

            # Refresh tree to show updated status
            self._refresh_current_tree_item()

            # Show success message
            QMessageBox.information(self, "保存成功", f"步骤内容已保存到：{self._current_step_file_path.name}")
        except Exception as e:
            QMessageBox.critical(self, "保存失败", f"保存失败：{str(e)}")

    def _refresh_current_tree_item(self) -> None:
        """Refresh the current tree item status after save."""
        if not self._current_step_id:
            return

        # Find and refresh the item
        def refresh_item(parent: QTreeWidgetItem) -> None:
            for i in range(parent.childCount()):
                child = parent.child(i)
                if child.data(0, Qt.ItemDataRole.UserRole) == self._current_step_id:
                    # Update status
                    if self._current_step_file_path and self._current_step_file_path.exists():
                        child.setText(0, f"✓ {child.text(0).lstrip('✓ ')}")
                        child.setForeground(0, QBrush(QColor("#006400")))
                    return
                refresh_item(child)

        for i in range(self.creation_tree.topLevelItemCount()):
            top_item = self.creation_tree.topLevelItem(i)
            refresh_item(top_item)
