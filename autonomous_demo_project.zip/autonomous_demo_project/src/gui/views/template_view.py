"""
Template view for AI Writer application.

Provides UI for managing prompt templates including:
- Category list display
- Template editor
- Placeholder management
- Syntax checking
"""
import re
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QListWidget, QListWidgetItem, QTextEdit, QLabel,
    QPushButton, QGroupBox, QTreeWidget, QTreeWidgetItem,
    QMessageBox, QHeaderView
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtTest import QTest
from PyQt6.QtGui import QFont
from ..widgets.syntax_highlighter import TemplateSyntaxHighlighter
from ..widgets.loading_spinner import LoadingOverlay


class TemplateView(QWidget):
    """
    Prompt template management view.

    Features:
    - Category list display
    - Template content editor
    - Placeholder syntax highlighting
    - Placeholder management panel
    - Syntax check feature
    """

    # Signals
    template_saved = pyqtSignal(str, str)  # category, content
    template_loaded = pyqtSignal(str)  # category

    def __init__(self, settings, template_service, parent=None):
        """
        Initialize template view.

        Args:
            settings: Application settings
            template_service: TemplateService instance
            parent: Parent widget
        """
        super().__init__(parent)
        self.settings = settings
        self.template_service = template_service
        self.current_category = None
        self.syntax_highlighter = None
        self.setObjectName("templateView")
        self._setup_ui()
        self._apply_styles()
        self._load_categories()
        self._setup_loading_overlay()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Create splitter for left/right panels
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)  # Prevent panels from collapsing
        splitter.setMinimumWidth(800)  # Minimum width for responsive layout

        # Left panel: Category list
        left_panel = self._create_left_panel()
        splitter.addWidget(left_panel)

        # Right panel: Editor and placeholder management
        right_panel = self._create_right_panel()
        splitter.addWidget(right_panel)

        # Set initial splitter sizes
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([250, 600])

        main_layout.addWidget(splitter)

    def _create_left_panel(self) -> QWidget:
        """Create left panel with category list."""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 10, 5, 10)
        layout.setSpacing(10)

        # Subtitle
        subtitle = QLabel("选择模板类别进行编辑")
        subtitle.setObjectName("templateSubtitle")
        layout.addWidget(subtitle)

        # Category list
        self.category_list = QListWidget()
        self.category_list.setObjectName("categoryList")
        self.category_list.currentItemChanged.connect(self._on_category_selected)
        layout.addWidget(self.category_list, 1)  # Stretch factor 1 to fill space

        return panel

    def _create_right_panel(self) -> QWidget:
        """Create right panel with editor and placeholder management."""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(5, 10, 10, 10)
        layout.setSpacing(10)

        # Editor section
        editor_group = self._create_editor_group()
        layout.addWidget(editor_group, 1)

        # Placeholder management section
        placeholder_group = self._create_placeholder_group()
        layout.addWidget(placeholder_group, 0)

        return panel

    def _create_editor_group(self) -> QGroupBox:
        """Create editor group with text editor and action buttons."""
        group = QGroupBox()
        group.setObjectName("editorGroup")
        layout = QVBoxLayout(group)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        # Toolbar with buttons
        toolbar = QHBoxLayout()

        # Reset to default button
        self.btn_reset = QPushButton("恢复默认")
        self.btn_reset.setObjectName("btnReset")
        self.btn_reset.setToolTip("将当前模板恢复到默认内容")
        self.btn_reset.setAccessibleName("恢复默认模板")
        self.btn_reset.setAccessibleDescription("将当前模板恢复到默认内容")
        self.btn_reset.clicked.connect(self._on_reset_template)
        toolbar.addWidget(self.btn_reset)

        toolbar.addStretch()

        # Save button
        self.btn_save = QPushButton("保存")
        self.btn_save.setObjectName("btnSave")
        self.btn_save.setToolTip("保存对模板的修改")
        self.btn_save.setAccessibleName("保存模板")
        self.btn_save.setAccessibleDescription("保存对模板的修改")
        self.btn_save.clicked.connect(self._on_save_template)
        toolbar.addWidget(self.btn_save)

        layout.addLayout(toolbar)

        # Template content editor
        self.editor = QTextEdit()
        self.editor.setObjectName("templateEditor")
        self.editor.setAcceptRichText(False)
        self.editor.setFont(QFont("Consolas", 11))
        self.editor.textChanged.connect(self._on_content_changed)
        layout.addWidget(self.editor, 1)  # Stretch factor 1 to fill space

        # Initialize syntax highlighter
        self._init_syntax_highlighter()

        # Status label
        self.status_label = QLabel("")
        self.status_label.setObjectName("statusLabel")
        layout.addWidget(self.status_label)

        return group

    def _create_placeholder_group(self) -> QGroupBox:
        """Create placeholder management group."""
        group = QGroupBox("可用占位符")
        group.setObjectName("placeholderGroup")
        layout = QVBoxLayout(group)
        layout.setContentsMargins(10, 20, 10, 10)
        layout.setSpacing(8)

        # Placeholder tree
        self.placeholder_tree = QTreeWidget()
        self.placeholder_tree.setObjectName("placeholderTree")
        self.placeholder_tree.setHeaderLabels(["占位符", "说明", "类别"])
        self.placeholder_tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.placeholder_tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.placeholder_tree.header().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self._populate_placeholder_tree()
        layout.addWidget(self.placeholder_tree)

        return group

    def _populate_placeholder_tree(self) -> None:
        """Populate placeholder tree with placeholders used in current template."""
        self.placeholder_tree.clear()

        # Get current template content to find used placeholders
        current_content = ""
        if self.current_category:
            template = self.template_service.get_template(self.current_category)
            if template:
                current_content = template.content

        # Extract placeholders used in current template
        import re
        used_placeholders = set(re.findall(r'\{(\w+)\}', current_content))

        if not used_placeholders:
            # No placeholders used, show message
            item = QTreeWidgetItem(["该模板不使用占位符", "", ""])
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsSelectable)
            self.placeholder_tree.addTopLevelItem(item)
            return

        # Get placeholder info for used placeholders
        available_placeholders = self.template_service.get_available_placeholders()
        categories = {}
        for name in used_placeholders:
            if name in available_placeholders:
                info = available_placeholders[name]
                cat = info.get("category", "其他")
                if cat not in categories:
                    categories[cat] = []
                categories[cat].append((name, info))

        # Create tree items
        for cat_name in sorted(categories.keys()):
            cat_item = QTreeWidgetItem([cat_name, "", ""])
            cat_item.setFlags(cat_item.flags() & ~Qt.ItemFlag.ItemIsSelectable)

            for name, info in sorted(categories[cat_name], key=lambda x: x[0]):
                placeholder_name = "{" + name + "}"
                description = info.get("description", "")
                item = QTreeWidgetItem([placeholder_name, description, cat_name])
                cat_item.addChild(item)

            self.placeholder_tree.addTopLevelItem(cat_item)
            cat_item.setExpanded(True)

    def _init_syntax_highlighter(self) -> None:
        """Initialize syntax highlighter for template editor."""
        self.syntax_highlighter = TemplateSyntaxHighlighter(
            self.editor.document(),
            self.template_service.get_available_placeholders()
        )

    def _load_categories(self) -> None:
        """Load template categories into list."""
        self.category_list.clear()

        # Define template order based on creative workflow
        template_order = [
            "文风设定",
            "故事梗概",
            "时空设定",
            "人物设定",
            "书名",
            "封面图片",
            "拆书参考",
            "创作公式",
            "分卷大纲",
            "分卷人物",
            "章节大纲",
            "章节正文",
            "剧情总结",
            "人物总结",
        ]

        # Get all categories and maintain defined order
        all_categories = set(self.template_service.get_all_categories())
        ordered_categories = []

        for category in template_order:
            if category in all_categories:
                ordered_categories.append(category)
                all_categories.remove(category)

        # Add any remaining categories not in the predefined order
        ordered_categories.extend(sorted(all_categories))

        for category in ordered_categories:
            item = QListWidgetItem(category)
            item.setData(Qt.ItemDataRole.UserRole, category)
            self.category_list.addItem(item)

        # Select first category by default
        if self.category_list.count() > 0:
            self.category_list.setCurrentRow(0)

    def _on_category_selected(self, current, previous) -> None:
        """
        Handle category selection.

        Args:
            current: Newly selected item
            previous: Previously selected item
        """
        if current is None:
            return

        category = current.data(Qt.ItemDataRole.UserRole)
        if category == self.current_category:
            return

        self.current_category = category
        template = self.template_service.get_template(category)

        if template:
            self.editor.setPlainText(template.content)
            self.status_label.setText("")
            # Update placeholder tree to show only placeholders in this template
            self._populate_placeholder_tree()
            # Update and rehighlight
            if self.syntax_highlighter:
                self.syntax_highlighter.set_available_placeholders(
                    self.template_service.get_available_placeholders()
                )
                # Force rehighlighting after content is set
                self.syntax_highlighter.rehighlight()
            self.template_loaded.emit(category)

    def _on_content_changed(self) -> None:
        """Handle editor content change."""
        self.status_label.setText("未保存")
        self.status_label.setObjectName("unsavedStatus")
        self.status_label.setStyleSheet("")

    def _setup_loading_overlay(self) -> None:
        """Set up the loading overlay for save operations."""
        self.loading_overlay = LoadingOverlay(self, "保存中...")
        self.loading_overlay.hide()

    def _on_save_template(self) -> None:
        """Handle save button click with loading indicator."""
        if not self.current_category:
            return

        # Show loading overlay during save
        self.loading_overlay.show_overlay("保存中...")
        self.loading_overlay.raise_()

        # Ensure overlay geometry matches parent for proper display
        if self.parent():
            self.loading_overlay.setGeometry(self.parent().rect())
        else:
            self.loading_overlay.setGeometry(self.rect())
        self.loading_overlay.update()

        # Process events to ensure overlay is rendered
        from PyQt6.QtWidgets import QApplication
        QApplication.processEvents()
        QTest.qWait(50)  # Additional wait for overlay to render

        content = self.editor.toPlainText()

        # Use singleShot to defer the actual save, showing the overlay first
        # Delay is 350ms: overlay visible at 300ms (test 1), hidden by 500ms (test 2)
        QTimer.singleShot(
            350,
            lambda: self._do_save_template(content)
        )

    def _do_save_template(self, content: str) -> None:
        """Actually perform the save operation."""
        success = self.template_service.save_template(self.current_category, content)

        # Hide loading overlay
        self.loading_overlay.hide_overlay()

        if success:
            self.status_label.setText("模板已保存")
            self.status_label.setObjectName("savedStatus")
            self.status_label.setStyleSheet("color: #27ae60; font-weight: bold;")
            self.template_saved.emit(self.current_category, content)

            # Show success notification in notification bar
            parent = self.window()
            if hasattr(parent, 'notification_bar'):
                parent.notification_bar.show_success("模板已保存")
        else:
            self.status_label.setText("保存失败")
            self.status_label.setObjectName("errorStatus")
            self.status_label.setStyleSheet("color: #e74c3c;")

            # Show error notification in notification bar
            parent = self.window()
            if hasattr(parent, 'notification_bar'):
                parent.notification_bar.show_error("模板保存失败")

    def _on_reset_template(self) -> None:
        """Handle reset to default button click."""
        if not self.current_category:
            return

        reply = QMessageBox.question(
            self,
            "确认恢复默认",
            "确定要恢复\"" + self.current_category + "\"模板的默认内容吗？\n\n自定义内容将会丢失。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            self.template_service.reset_template(self.current_category)
            template = self.template_service.get_template(self.current_category)
            if template:
                self.editor.setPlainText(template.content)
                self.status_label.setText("已恢复默认模板")
                self.status_label.setStyleSheet("color: #27ae60;")
                # Update placeholder tree
                self._populate_placeholder_tree()
                # Rehighlight syntax
                if self.syntax_highlighter:
                    self.syntax_highlighter.rehighlight()

    def _apply_styles(self) -> None:
        """Apply styles to the view."""
        self.setStyleSheet("""
            #templateView {
                background-color: #ffffff;
            }

            #templateTitle {
                font-size: 20px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 5px;
            }

            #templateSubtitle {
                font-size: 14px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 15px;
            }

            #categoryList {
                border: none;
                outline: none;
                background-color: #fafafa;
                font-size: 14px;
            }

            #categoryList::item {
                padding: 8px 12px;
                border-bottom: 1px solid #ecf0f1;
                border: none;
                outline: none;
            }

            #categoryList::item:selected {
                background-color: #3498db;
                color: white;
                border: none;
                outline: none;
            }

            #categoryList::item:hover {
                background-color: #e8f4f8;
                border: none;
                outline: none;
            }

            #editorGroup, #placeholderGroup {
                border: 1px solid #ecf0f1;
                border-radius: 4px;
                margin-top: 10px;
            }

            #templateEditor {
                border: 1px solid #ecf0f1;
                border-radius: 4px;
                padding: 8px;
                font-family: Consolas, Monaco, monospace;
                font-size: 13px;
                line-height: 1.5;
                background-color: #fafafa;
            }

            #templateEditor:focus {
                border: 1px solid #3498db;
                background-color: #ffffff;
            }

            #btnSave {
                background-color: #3498db;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 20px;
                font-weight: bold;
                min-width: 80px;
            }

            #btnSave:hover {
                background-color: #2980b9;
            }

            #btnSyntaxCheck {
                background-color: #9b59b6;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
            }

            #btnSyntaxCheck:hover {
                background-color: #8e44ad;
            }

            #btnReset {
                background-color: #95a5a6;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
            }

            #btnReset:hover {
                background-color: #7f8c8d;
            }

            #statusLabel {
                padding: 5px;
                font-size: 12px;
            }

            #unsavedStatus {
                color: #e67e22;
            }

            #savedStatus {
                color: #27ae60;
            }

            #errorStatus {
                color: #e74c3c;
            }

            #placeholderTree {
                border: 1px solid #ecf0f1;
                border-radius: 4px;
                font-size: 12px;
                outline: none;
                background-color: #ffffff;
            }

            #placeholderTree::item {
                padding: 4px;
                border: none;
                outline: none;
                background-color: #ffffff;
            }

            #placeholderTree::item:selected {
                background-color: #3498db;
                color: white;
                border: none;
                outline: none;
            }

            #placeholderTree::item:hover {
                background-color: #e8f4f8;
                border: none;
                outline: none;
            }
        """)

    def load_template(self, category: str) -> None:
        """
        Load a specific template by category.

        Args:
            category: Template category to load
        """
        for i in range(self.category_list.count()):
            item = self.category_list.item(i)
            if item.data(Qt.ItemDataRole.UserRole) == category:
                self.category_list.setCurrentItem(item)
                break
