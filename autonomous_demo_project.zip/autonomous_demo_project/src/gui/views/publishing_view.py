"""
Publishing View for AI Writer application.

Provides a single-page interface for publishing works to platforms like 番茄小说.
"""
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QComboBox, QGroupBox, QPushButton,
    QSpinBox, QRadioButton, QButtonGroup, QCheckBox,
    QMessageBox, QSizePolicy, QSpacerItem, QScrollArea,
    QTextEdit, QDialog, QDialogButtonBox, QLineEdit,
    QListWidget, QListWidgetItem, QDateEdit, QTimeEdit, QApplication
)
from PyQt6.QtCore import Qt, pyqtSignal, QSize, QTimer, QThread
from PyQt6.QtGui import QFont, QPalette, QIntValidator
from typing import Optional, Dict, Any
import json
import os

from config.settings import Settings
from models.work import Work
from services.fanqie_account_manager import FanqieAccountManager
from services.fanqie_publisher import FanqiePublisher, FanqieLoginError, FanqiePublishError, PublishProgress
from services.fanqie_book_service import FanqieBookService
from services.fanqie_worker import FanqieWorker, FanqieTaskType
from services.chat_service import ChatService, ChatTaskStatus
from gui.dialogs.fanqie_account_dialog import FanqieAccountDialog
from utils.logger import get_logger


class ClickableLabel(QLabel):
    """A clickable label that can toggle checked state."""
    clicked = pyqtSignal()

    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self._checked = False
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMouseTracking(True)

    def setChecked(self, checked):
        self._checked = checked
        self._update_style()

    def isChecked(self):
        return self._checked

    def mousePressEvent(self, event):
        self._checked = not self._checked
        self._update_style()
        self.clicked.emit()

    def _update_style(self):
        if self._checked:
            self.setStyleSheet("""
                ClickableLabel {
                    background-color: #27ae60;
                    color: #ffffff;
                    border-radius: 4px;
                    font-size: 12px;
                }
            """)
        else:
            self.setStyleSheet("""
                ClickableLabel {
                    background-color: #f5f5f5;
                    color: #2c3e50;
                    border-radius: 4px;
                    font-size: 12px;
                }
            """)


# Prompt for generating book metadata
BOOK_METADATA_PROMPT = '''你是一个专业的番茄小说编辑。请根据以下作品信息，为在番茄小说平台创建新书生成元数据。

【作品信息】
标题：{title}
类型：{category}
简介：{description}

请生成以下格式的JSON数据（必须是可以直接解析的JSON，不要包含其他文字）：

{{
    "is_male": true/false（true=男频，false=女频）,
    "category_tags": ["主分类标签"]（从标签库中选择1个主分类标签）,
    "theme_tags": ["主题标签1", "主题标签2"]（从标签库中选择1-2个主题标签）,
    "character_tags": ["角色标签1", "角色标签2"]（从标签库中选择1-2个角色标签）,
    "plot_tags": ["情节标签1", "情节标签2"]（从标签库中选择1-2个情节标签）,
    "protagonist1": "主角1名字（不超过5字）",
    "protagonist2": "主角2名字（不超过5字）",
    "description": "作品简介（50-500字，基于原简介扩写或改编）"
}}

注意：
1. 标签数量限制：
   - 主分类标签：必须恰好1个
   - 主题标签：1-2个
   - 角色标签：1-2个
   - 情节标签：1-2个
2. 标签必须从以下标签库中选择：
   主分类标签：西方奇幻、东方仙侠、科幻末世、男频衍生、都市高武、悬疑灵异、悬疑脑洞、抗战谍战、历史古代、历史脑洞、都市种田、都市脑洞、都市日常、玄幻脑洞、战神赘婿、动漫衍生、游戏体育、传统玄幻、都市修真
   主题标签：衍生、仕途、综影视、天灾、第一人人称、赛博朋克、第四天灾、规则怪谈、搞笑轻松、古代、悬疑、克苏鲁、都市异能、末日求生、灵气复苏、高武世界、异世大陆、东方玄幻、谍战、清朝、宋朝、断层、武将、国运、综漫、开局、架空、奇幻仙侠、都市、玄幻、历史、体育、武侠
   角色标签：多女主、赘婿、全能、大佬、大小姐、特工、游戏主播、神探、宫廷侯爵、皇帝、单女主、校花、无女主、女帝、特种兵、反派、神医、奶爸、学霸、天才、腹黑、扮猪吃虎
   情节标签：风水秘术、斩神衍生、十日衍生、西游衍生、公版衍生、红楼衍生、甄嬛衍生、如懿衍生、都市江湖、惊悚游戏、卡牌、山海经、捉鬼、剑修、废土、副本、黑科技、无脑爽、魂穿、高手下山、黑化、迪化、发家致富、无后宫、争霸、1v1、升级流、灵魂互换、科举、封神、四合院、电竞、双重生、乡村、同人、打脸、破案、囤物资、钓鱼、网游、奥特同人、求生、无敌、九叔、穿书、聊天群、大秦、龙珠、漫威神奇宝贝、海贼、火影、职场、明朝、家庭、三国、末世、直播、无限流、诸天万界、大唐、宠物、外卖、星际、美食、剑道、盗墓、灵异、鉴宝、系统、神豪、重生、穿越、二次元、海岛、娱乐圈、空间、推理、洪荒
3. is_male根据作品类型判断：玄幻、都市、科幻、武侠、历史、游戏等偏男性向选true，言情、偶像等偏女性向选false
4. description必须50-500字，不能有低俗暴力内容

直接输出JSON，不要有任何其他文字。'''


class BookMetadataConfirmDialog(QDialog):
    """Dialog for confirming generated book metadata."""

    def __init__(self, metadata: Dict[str, Any], parent=None):
        super().__init__(parent)
        self.metadata = metadata
        self._setup_ui()

    def _setup_ui(self) -> None:
        self.setWindowTitle("确认新书信息")
        self.setMinimumSize(600, 500)
        self.setModal(True)

        layout = QVBoxLayout(self)

        # Info label
        info_label = QLabel("请确认以下新书信息，确认无误后点击创建：")
        layout.addWidget(info_label)

        # Display fields
        self._add_field(layout, "书名:", self.metadata.get("book_name", ""))
        self._add_field(layout, "频道:", "男频" if self.metadata.get("is_male", True) else "女频")

        tags_text = "、".join(self.metadata.get("tags", []))
        self._add_field(layout, "标签:", tags_text)

        self._add_field(layout, "主角1:", self.metadata.get("protagonist1", ""))
        self._add_field(layout, "主角2:", self.metadata.get("protagonist2", ""))

        # Description
        desc_label = QLabel("简介:")
        layout.addWidget(desc_label)
        desc_edit = QTextEdit()
        desc_edit.setPlainText(self.metadata.get("description", ""))
        desc_edit.setReadOnly(True)
        desc_edit.setMaximumHeight(150)
        layout.addWidget(desc_edit)

        # Raw JSON for reference
        json_label = QLabel("原始JSON（供参考）:")
        layout.addWidget(json_label)
        json_edit = QTextEdit()
        json_edit.setPlainText(json.dumps(self.metadata, ensure_ascii=False, indent=2))
        json_edit.setReadOnly(True)
        json_edit.setMaximumHeight(100)
        json_edit.setStyleSheet("font-family: monospace; font-size: 11px;")
        layout.addWidget(json_edit)

        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def _add_field(self, layout, label: str, value: str) -> None:
        row = QHBoxLayout()
        row.addWidget(QLabel(label))
        row.addWidget(QLabel(value))
        row.addStretch()
        layout.addLayout(row)


class BookMetadataEditDialog(QDialog):
    """Dialog for editing book metadata."""

    def __init__(self, work, parent=None):
        super().__init__(parent)
        self.work = work
        self._setup_ui()

    def _setup_ui(self) -> None:
        self.setWindowTitle("编辑新书信息")
        self.setMinimumSize(500, 400)
        self.setModal(True)

        layout = QVBoxLayout(self)

        # Book name
        name_layout = QHBoxLayout()
        name_layout.addWidget(QLabel("书名:"))
        self.name_edit = QTextEdit()
        self.name_edit.setPlainText(self.work.fanqie_book_title or "")
        self.name_edit.setMaximumHeight(60)
        name_layout.addWidget(self.name_edit)
        layout.addLayout(name_layout)

        # Channel
        channel_layout = QHBoxLayout()
        channel_layout.addWidget(QLabel("频道:"))
        self.male_radio = QRadioButton("男频")
        self.female_radio = QRadioButton("女频")
        channel_layout.addWidget(self.male_radio)
        channel_layout.addWidget(self.female_radio)
        if self.work.fanqie_is_male:
            self.male_radio.setChecked(True)
        else:
            self.female_radio.setChecked(True)
        channel_layout.addStretch()
        layout.addLayout(channel_layout)

        # Tags
        tags_layout = QHBoxLayout()
        tags_layout.addWidget(QLabel("标签:"))
        self.tags_edit = QTextEdit()
        self.tags_edit.setPlainText("、".join(self.work.fanqie_tags or []))
        self.tags_edit.setMaximumHeight(80)
        tags_layout.addWidget(self.tags_edit)
        layout.addLayout(tags_layout)

        # Protagonists
        prot_layout = QHBoxLayout()
        prot_layout.addWidget(QLabel("主角1:"))
        self.prot1_edit = QTextEdit()
        self.prot1_edit.setPlainText(self.work.fanqie_protagonist1 or "")
        self.prot1_edit.setMaximumHeight(40)
        prot_layout.addWidget(self.prot1_edit)
        prot_layout.addWidget(QLabel("主角2:"))
        self.prot2_edit = QTextEdit()
        self.prot2_edit.setPlainText(self.work.fanqie_protagonist2 or "")
        self.prot2_edit.setMaximumHeight(40)
        prot_layout.addWidget(self.prot2_edit)
        layout.addLayout(prot_layout)

        # Description
        desc_layout = QHBoxLayout()
        desc_layout.addWidget(QLabel("简介:"))
        self.desc_edit = QTextEdit()
        self.desc_edit.setPlainText(self.work.fanqie_description or "")
        self.desc_edit.setMaximumHeight(100)
        desc_layout.addWidget(self.desc_edit)
        layout.addLayout(desc_layout)

        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self._on_accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def _on_accept(self) -> None:
        # Update work with new values
        self.work.fanqie_book_title = self.name_edit.toPlainText().strip()
        self.work.fanqie_is_male = self.male_radio.isChecked()
        tags_text = self.tags_edit.toPlainText().strip()
        self.work.fanqie_tags = [t.strip() for t in tags_text.split("、") if t.strip()]
        self.work.fanqie_protagonist1 = self.prot1_edit.toPlainText().strip()
        self.work.fanqie_protagonist2 = self.prot2_edit.toPlainText().strip()
        self.work.fanqie_description = self.desc_edit.toPlainText().strip()
        self.accept()


class AssociateExistingBookDialog(QDialog):
    """Dialog for associating with an existing Fanqie book."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.book_id = ""
        self.book_name = ""
        self._setup_ui()

    def _setup_ui(self) -> None:
        self.setWindowTitle("关联已有作品")
        self.setMinimumSize(500, 300)
        self.setModal(True)

        layout = QVBoxLayout(self)

        # Info text
        info_label = QLabel('请输入番茄小说后台"章节管理"页面的书本信息：')
        layout.addWidget(info_label)

        # Hint about URL format
        hint = QLabel(
            '提示：从番茄作家后台的"章节管理"页面URL中获取信息。\n\n'
            "URL格式：https://fanqienovel.com/main/writer/chapter-manage/书本ID&书名?type=1\n\n"
            "示例：https://fanqienovel.com/main/writer/chapter-manage/7626727431100959768&星际题材小说?type=1\n"
            "则 书本ID = 7626727431100959768，书名 = 星际题材小说"
        )
        hint.setStyleSheet("color: #7f8c8d; font-size: 12px; background-color: #f8f9fa; padding: 10px; border-radius: 4px;")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        # Book ID input
        id_layout = QHBoxLayout()
        id_layout.addWidget(QLabel("书本ID:"))
        self.book_id_input = QLineEdit()
        self.book_id_input.setPlaceholderText("输入书本ID数字")
        id_layout.addWidget(self.book_id_input)
        layout.addLayout(id_layout)

        # Book name input
        name_layout = QHBoxLayout()
        name_layout.addWidget(QLabel("书名:"))
        self.book_name_input = QLineEdit()
        self.book_name_input.setPlaceholderText("输入书名")
        name_layout.addWidget(self.book_name_input)
        layout.addLayout(name_layout)

        layout.addStretch()

        # Buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self._on_accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def _on_accept(self) -> None:
        self.book_id = self.book_id_input.text().strip()
        self.book_name = self.book_name_input.text().strip()
        if not self.book_id:
            QMessageBox.warning(self, "提示", "请输入书本ID")
            return
        if not self.book_name:
            QMessageBox.warning(self, "提示", "请输入书名")
            return
        self.accept()


class CreateBookThread(QThread):
    """Thread for creating book on Fanqie platform in background."""
    create_finished = pyqtSignal(bool, str)  # success, book_id or error_message

    def __init__(
        self,
        settings,
        account_id: str,
        account_manager,
        book_title: str,
        metadata: dict
    ):
        super().__init__()
        self.settings = settings
        self.account_id = account_id
        self.account_manager = account_manager
        self.book_title = book_title
        self.metadata = metadata

    def run(self):
        """Run book creation in background thread."""
        try:
            # Get account credentials
            account = self.account_manager.get_account(self.account_id)
            if not account:
                self.create_finished.emit(False, "找不到账号信息")
                return

            # Check Chrome installation
            chrome_path = self.settings.ai_settings.browser_chrome_path
            if not FanqieBookService.check_chrome_installed(chrome_path):
                self.create_finished.emit(False, "Chrome 浏览器未安装")
                return

            # Create book service
            book_service = FanqieBookService(
                phone_number=account.phone,
                password=account.password,
                chrome_path=chrome_path,
                headless=False,
                slow_mo=100
            )

            try:
                # Connect and login
                if not book_service.connect():
                    self.create_finished.emit(False, "登录失败，请检查账号密码")
                    return

                # Combine all tag categories
                all_tags = []
                all_tags.extend(self.metadata.get("category_tags", []))
                all_tags.extend(self.metadata.get("theme_tags", []))
                all_tags.extend(self.metadata.get("character_tags", []))
                all_tags.extend(self.metadata.get("plot_tags", []))

                # Create book
                success, result = book_service.create_book(
                    book_name=self.book_title,
                    is_male=self.metadata.get("is_male", True),
                    tags=all_tags,
                    protagonist1=self.metadata.get("protagonist1", ""),
                    protagonist2=self.metadata.get("protagonist2", ""),
                    description=self.metadata.get("description", "")
                )

                self.create_finished.emit(success, result)

            finally:
                book_service.close()

        except Exception as e:
            self.create_finished.emit(False, f"创建出错: {str(e)}")


class PublishingView(QWidget):
    """
    Publishing center view with single-page interface.

    Signals:
        platform_changed: Emitted when platform selection changes (platform_name)
        work_changed: Emitted when work selection changes (work_id)
        publish_clicked: Emitted when publish button is clicked
        publish_progress: Emitted with PublishProgress during publishing
    """

    platform_changed = pyqtSignal(str)
    work_changed = pyqtSignal(str)
    publish_clicked = pyqtSignal()
    publish_progress = pyqtSignal(object)  # PublishProgress
    title_gen_progress = pyqtSignal(int, int)  # completed, total
    title_gen_complete = pyqtSignal(int)  # total chapters
    metadata_generated = pyqtSignal(str, bool)  # completion_text, is_regenerate

    def __init__(self, settings: Settings, work_manager=None,
                 fanqie_account_manager: FanqieAccountManager = None, parent=None):
        """
        Initialize publishing view.

        Args:
            settings: Application settings
            work_manager: WorkManager instance for loading works
            fanqie_account_manager: FanqieAccountManager for account operations
            parent: Parent widget
        """
        super().__init__(parent)
        self.settings = settings
        self.work_manager = work_manager
        self.fanqie_account_manager = fanqie_account_manager
        self.logger = self._setup_logger()

        # Current state
        self._current_platform: Optional[str] = None
        self._current_work_id: Optional[str] = None
        self._current_work: Optional[Work] = None
        self._current_account_id: Optional[str] = None

        # Fanqie worker for browser automation
        self._fanqie_worker: Optional[FanqieWorker] = None

        # Progress tracking for chapter title generation
        self._title_gen_timer = None
        self._title_gen_completed = 0
        self._title_gen_total = 0
        self._title_gen_dot_count = 0

        # Word count for restructure
        self._confirmed_word_count = 3000
        self._updating_word_count = False  # Flag to prevent confirmation during programmatic updates
        self._initializing_ui = False  # Flag to prevent confirmation during UI initialization
        self._setting_radio_button = False  # Flag to prevent confirmation when programmatically setting radio

        # Publishing completion state
        self._publishing_completed = False  # True when publishing has completed successfully

        self._setup_ui()
        self._setup_connections()
        self._apply_styles()
        self._load_works()
        self._refresh_account_list()

        # Initialize platform after connections are set up
        self._current_platform = self.platform_combo.currentText()
        # Validate current step to enable/disable buttons properly
        self._validate_current_step()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        # Main layout
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        # Step indicator at top
        self._setup_step_indicator()

        # Content area with stacked widget for each step
        self.content_stack = QWidget()
        content_layout = QVBoxLayout(self.content_stack)
        content_layout.setContentsMargins(20, 20, 20, 20)
        content_layout.setSpacing(15)

        # Create each step widget
        self.step1_widget = self._create_step1_widget()  # Platform
        self.step2_widget = self._create_step2_widget()  # Work
        self.step3_widget = self._create_step3_widget()  # Range
        self.step4_widget = self._create_step4_widget()  # Account
        self.step5_widget = self._create_step5_widget()  # Publish Strategy
        self.step6_widget = self._create_step6_widget()  # Summary

        # Add step widgets to stacked layout
        self.step_stack = QVBoxLayout()
        self.step_stack.addWidget(self.step1_widget)
        self.step_stack.addWidget(self.step2_widget)
        self.step_stack.addWidget(self.step3_widget)
        self.step_stack.addWidget(self.step4_widget)
        self.step_stack.addWidget(self.step5_widget)
        self.step_stack.addWidget(self.step6_widget)
        content_layout.addLayout(self.step_stack)

        self.main_layout.addWidget(self.content_stack)

        # Bottom navigation buttons
        self._setup_nav_buttons()

        # Initialize to step 1
        self._current_step = 1
        self._update_step_visibility()

    def _setup_step_indicator(self) -> None:
        """Set up the step indicator at top."""
        self.step_indicator = QWidget()
        self.step_indicator.setObjectName("stepIndicator")
        self.step_indicator.setFixedHeight(110)
        indicator_layout = QHBoxLayout(self.step_indicator)
        indicator_layout.setContentsMargins(40, 20, 40, 20)
        indicator_layout.setSpacing(0)

        self.step_circles = []  # List of circle labels
        self.step_names = []    # List of name labels
        self.step_lines = []
        steps = ["选择平台", "选择作品", "发布队列", "选择账号", "发布策略", "汇总发布"]

        # Add stretch at the beginning for centering
        indicator_layout.addStretch()

        for i, step_name in enumerate(steps):
            # Step circle with number - 28px diameter = 14px radius for perfect circle
            circle = QLabel(str(i + 1))
            circle.setFixedSize(28, 28)
            circle.setAlignment(Qt.AlignmentFlag.AlignCenter)
            circle.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
            circle.setStyleSheet("""
                QLabel {
                    background-color: #bdc3c7;
                    color: #ffffff;
                    border-radius: 14px;
                    font-weight: bold;
                    font-size: 13px;
                    padding: 0px;
                }
            """)

            name = QLabel(step_name)
            name.setAlignment(Qt.AlignmentFlag.AlignCenter)
            name.setStyleSheet("color: #7f8c8d; font-size: 12px; padding: 0px;")
            name.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)

            # Use a vertical layout to stack circle and name
            step_layout = QVBoxLayout()
            step_layout.setSpacing(1)
            step_layout.setContentsMargins(0, 0, 0, 0)
            step_layout.addWidget(circle, alignment=Qt.AlignmentFlag.AlignHCenter)
            step_layout.addWidget(name, alignment=Qt.AlignmentFlag.AlignHCenter)

            step_widget = QWidget()
            step_widget.setLayout(step_layout)
            step_widget.setStyleSheet("margin: 0; padding: 0;")
            step_widget.setMinimumWidth(90)
            step_widget.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
            indicator_layout.addWidget(step_widget)
            self.step_circles.append(circle)
            self.step_names.append(name)

            # Connector line (except after last step)
            if i < len(steps) - 1:
                line = QWidget()
                line.setFixedHeight(2)
                line.setMinimumWidth(40)
                line.setStyleSheet("background-color: #bdc3c7;")
                indicator_layout.addWidget(line)
                self.step_lines.append(line)

        # Add stretch at the end for centering
        indicator_layout.addStretch()

        self.main_layout.addWidget(self.step_indicator)

        # Add separator line below step indicator (centered, partial width)
        separator_widget = QWidget()
        separator_layout = QHBoxLayout(separator_widget)
        separator_layout.setContentsMargins(0, 10, 0, 10)
        separator_layout.addStretch()
        self.step_separator = QWidget()
        self.step_separator.setFixedHeight(1)
        self.step_separator.setStyleSheet("background-color: #dcdcdc;")
        self.step_separator.setFixedWidth(400)
        separator_layout.addWidget(self.step_separator)
        separator_layout.addStretch()
        self.main_layout.addWidget(separator_widget)

    def _setup_nav_buttons(self) -> None:
        """Set up navigation buttons."""
        nav_widget = QWidget()
        nav_widget.setObjectName("navButtons")
        nav_layout = QHBoxLayout(nav_widget)
        nav_layout.setContentsMargins(20, 10, 20, 15)
        nav_layout.setSpacing(10)

        self.prev_btn = QPushButton("上一步")
        self.prev_btn.setObjectName("prevBtn")
        self.prev_btn.setFixedHeight(36)
        self.prev_btn.setMinimumWidth(100)
        self.prev_btn.setVisible(False)
        nav_layout.addWidget(self.prev_btn)

        nav_layout.addStretch()

        self.next_btn = QPushButton("下一步")
        self.next_btn.setObjectName("nextBtn")
        self.next_btn.setFixedHeight(36)
        self.next_btn.setMinimumWidth(100)
        nav_layout.addWidget(self.next_btn)

        # Create book and publish buttons (moved to nav bar for consistency)
        self.create_book_btn = QPushButton("创建书本")
        self.create_book_btn.setObjectName("createBookBtn")
        self.create_book_btn.setFixedHeight(36)
        self.create_book_btn.setMinimumWidth(120)
        self.create_book_btn.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: #ffffff;
                border: none;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #229954;
            }
        """)
        self.create_book_btn.setVisible(False)
        nav_layout.addWidget(self.create_book_btn)

        self.publish_btn = QPushButton("发布章节")
        self.publish_btn.setObjectName("publishBtn")
        self.publish_btn.setFixedHeight(36)
        self.publish_btn.setMinimumWidth(120)
        self.publish_btn.setStyleSheet("""
            QPushButton {
                background-color: #2980b9;
                color: #ffffff;
                border: none;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2472a4;
            }
            QPushButton:disabled {
                background-color: #95a5a6;
            }
        """)
        self.publish_btn.setVisible(False)
        nav_layout.addWidget(self.publish_btn)

        self.main_layout.addWidget(nav_widget)


    # ============== Step Widget Creation Methods ==============

    def _create_step1_widget(self) -> QWidget:
        """Step 1: Platform selection."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(20)

        # Title
        title = QLabel("选择发布平台")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
        layout.addWidget(title)

        # Platform options
        platform_group = QGroupBox("平台")
        platform_layout = QVBoxLayout(platform_group)

        self.platform_combo = QComboBox()
        self.platform_combo.addItems(["番茄", "起点"])
        self.platform_combo.setFixedHeight(40)
        self.platform_combo.setStyleSheet("""
            QComboBox {
                font-size: 14px;
                padding: 5px 10px;
            }
        """)
        platform_layout.addWidget(self.platform_combo)
        layout.addWidget(platform_group)

        layout.addStretch()
        return widget

    def _create_step2_widget(self) -> QWidget:
        """Step 2: Work selection with book info display."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(20)

        # Title
        title = QLabel("选择发布作品")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
        layout.addWidget(title)

        # Work selection
        work_group = QGroupBox("选择作品")
        work_layout = QVBoxLayout(work_group)

        self.work_combo = QComboBox()
        self.work_combo.addItem("请选择作品...", "")
        self.work_combo.setFixedHeight(36)
        self.work_combo.setStyleSheet("""
            QComboBox {
                font-size: 14px;
                padding: 5px 10px;
            }
        """)
        work_layout.addWidget(self.work_combo)
        layout.addWidget(work_group)

        # Book info container (for Fanqie)
        self.book_info_container = QWidget()
        book_info_layout = QVBoxLayout(self.book_info_container)
        book_info_layout.setSpacing(15)

        # Prompt message (shown when no metadata)
        self.book_info_prompt = QLabel("该作品尚未生成新书信息，请先生成")
        self.book_info_prompt.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.book_info_prompt.setStyleSheet("color: #e74c3c; font-size: 14px; padding: 20px;")
        book_info_layout.addWidget(self.book_info_prompt)

        # Loading indicator (shown during generation)
        self.book_info_loading = QLabel("正在生成新书信息...")
        self.book_info_loading.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.book_info_loading.setStyleSheet("color: #3498db; font-size: 14px; padding: 20px;")
        self.book_info_loading.setVisible(False)
        book_info_layout.addWidget(self.book_info_loading)

        # Generate button
        self.generate_meta_btn = QPushButton("生成新书信息")
        self.generate_meta_btn.setFixedHeight(40)
        self.generate_meta_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: #ffffff;
                font-size: 14px;
                font-weight: bold;
                border: none;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        book_info_layout.addWidget(self.generate_meta_btn)

        # Book info display widget (shown when metadata exists)
        self.book_info_widget = QWidget()
        self.book_info_widget.setVisible(False)
        self.book_info_widget.setStyleSheet("background-color: #e8e8e8;")
        # Table layout: 2 columns - label | input
        info_layout = QGridLayout(self.book_info_widget)
        info_layout.setSpacing(15)
        info_layout.setColumnMinimumWidth(0, 80)
        info_layout.setColumnStretch(1, 1)
        info_layout.setContentsMargins(15, 15, 15, 15)

        label_style = "font-weight: bold; color: #34495e;"

        # Row 0: 频道
        info_layout.addWidget(QLabel("频道"), 0, 0, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        channel_widget = QWidget()
        channel_layout = QHBoxLayout(channel_widget)
        channel_layout.setSpacing(10)
        channel_layout.setContentsMargins(0, 0, 0, 0)
        self.channel_male_radio = QRadioButton("男频")
        self.channel_female_radio = QRadioButton("女频")
        self.channel_male_radio.setFixedHeight(26)
        self.channel_female_radio.setFixedHeight(26)
        self.channel_male_radio.setStyleSheet("""
            QRadioButton {
                color: #2c3e50;
                font-size: 12px;
                padding: 5px 10px 5px 26px;
                background-color: #f5f5f5;
                border-radius: 4px;
                min-width: 50px;
            }
            QRadioButton:hover {
                background-color: #e0e0e0;
            }
            QRadioButton::indicator {
                width: 0px;
                border: none;
                background: transparent;
            }
            QRadioButton:checked {
                background-color: #27ae60;
                color: #ffffff;
            }
        """)
        self.channel_female_radio.setStyleSheet("""
            QRadioButton {
                color: #2c3e50;
                font-size: 12px;
                padding: 5px 10px 5px 26px;
                background-color: #f5f5f5;
                border-radius: 4px;
                min-width: 50px;
            }
            QRadioButton:hover {
                background-color: #e0e0e0;
            }
            QRadioButton::indicator {
                width: 0px;
                border: none;
                background: transparent;
            }
            QRadioButton:checked {
                background-color: #27ae60;
                color: #ffffff;
            }
        """)
        channel_layout.addWidget(self.channel_male_radio)
        channel_layout.addWidget(self.channel_female_radio)
        channel_layout.addStretch()
        info_layout.addWidget(channel_widget, 0, 1)

        # Helper function to create flow layout checkbox widget
        def create_flow_checkboxes(tags, columns=4):
            from PyQt6.QtWidgets import QSizePolicy
            widget = QWidget()
            layout = QGridLayout(widget)
            layout.setSpacing(6)
            layout.setContentsMargins(0, 0, 0, 0)
            checkboxes = []
            for i, tag in enumerate(tags):
                row = i // columns
                col = i % columns
                label = ClickableLabel(tag)
                label.setFixedHeight(26)
                label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
                label.setChecked(False)
                layout.addWidget(label, row, col)
                layout.setRowMinimumHeight(row, 26)
                layout.setRowStretch(row, 0)
                layout.setColumnStretch(col, 1)
                checkboxes.append(label)
            return widget, checkboxes

        # Row 1: 主分类标签
        info_layout.addWidget(QLabel("主分类"), 1, 0, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        cat_widget, self.category_tags_cbs = create_flow_checkboxes([
            "西方奇幻", "东方仙侠", "科幻末世", "男频衍生", "都市高武", "悬疑灵异", "悬疑脑洞", "抗战谍战",
            "历史古代", "历史脑洞", "都市种田", "都市脑洞", "都市日常", "玄幻脑洞", "战神赘婿", "动漫衍生", "游戏体育", "传统玄幻", "都市修真"
        ], columns=4)
        info_layout.addWidget(cat_widget, 1, 1)

        # Row 2: 主题标签
        info_layout.addWidget(QLabel("主题"), 2, 0, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        theme_widget, self.theme_tags_cbs = create_flow_checkboxes([
            "衍生", "仕途", "综影视", "天灾", "第一人称", "赛博朋克", "第四天灾", "规则怪谈", "搞笑轻松", "古代", "悬疑", "克苏鲁", "都市异能", "末日求生", "灵气复苏", "高武世界", "异世大陆", "东方玄幻", "谍战", "清朝", "宋朝", "断层", "武将", "国运", "综漫", "开局", "架空", "奇幻仙侠", "都市", "玄幻", "历史", "体育", "武侠"
        ], columns=5)
        info_layout.addWidget(theme_widget, 2, 1)

        # Row 3: 角色标签
        info_layout.addWidget(QLabel("角色"), 3, 0, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        char_widget, self.character_tags_cbs = create_flow_checkboxes([
            "多女主", "赘婿", "全能", "大佬", "大小姐", "特工", "游戏主播", "神探", "宫廷侯爵", "皇帝", "单女主", "校花", "无女主", "女帝", "特种兵", "反派", "神医", "奶爸", "学霸", "天才", "腹黑", "扮猪吃虎"
        ], columns=4)
        info_layout.addWidget(char_widget, 3, 1)

        # Row 4: 情节标签
        info_layout.addWidget(QLabel("情节"), 4, 0, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        plot_widget, self.plot_tags_cbs = create_flow_checkboxes([
            "风水秘术", "斩神衍生", "十日衍生", "西游衍生", "公版衍生", "红楼衍生", "甄嬛衍生", "如懿衍生", "都市江湖", "惊悚游戏", "卡牌", "山海经", "捉鬼", "剑修", "废土", "副本", "黑科技", "无脑爽", "魂穿", "高手下山", "黑化", "迪化", "发家致富", "无后宫", "争霸", "1v1", "升级流", "灵魂互换", "科举", "封神", "四合院", "电竞", "双重生", "乡村", "同人", "打脸", "破案", "囤物资", "钓鱼", "网游", "奥特同人", "求生", "无敌", "九叔", "穿书", "聊天群", "大秦", "龙珠", "漫威神奇宝贝", "海贼", "火影", "职场", "明朝", "家庭", "三国", "末世", "直播", "无限流", "诸天万界", "大唐", "宠物", "外卖", "星际", "美食", "剑道", "盗墓", "灵异", "鉴宝", "系统", "神豪", "重生", "穿越", "二次元", "海岛", "娱乐圈", "空间", "推理", "洪荒"
        ], columns=6)
        info_layout.addWidget(plot_widget, 4, 1)

        # Row 5: 主角
        info_layout.addWidget(QLabel("主角"), 5, 0, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        prot_widget = QWidget()
        prot_layout = QHBoxLayout(prot_widget)
        prot_layout.setSpacing(15)
        prot_layout.setContentsMargins(0, 0, 0, 0)
        self.prot1_input = QLineEdit()
        self.prot1_input.setPlaceholderText("主角1")
        self.prot1_input.setFixedWidth(150)
        self.prot1_input.setStyleSheet("background-color: #ffffff; border: 1px solid #dcdcdc; border-radius: 4px; padding: 4px 8px;")
        prot_layout.addWidget(self.prot1_input)
        self.prot2_input = QLineEdit()
        self.prot2_input.setPlaceholderText("主角2")
        self.prot2_input.setFixedWidth(150)
        self.prot2_input.setStyleSheet("background-color: #ffffff; border: 1px solid #dcdcdc; border-radius: 4px; padding: 4px 8px;")
        prot_layout.addWidget(self.prot2_input)
        prot_layout.addStretch()
        info_layout.addWidget(prot_widget, 5, 1)

        # Row 6: 简介
        info_layout.addWidget(QLabel("简介"), 6, 0, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.desc_input = QTextEdit()
        self.desc_input.setPlaceholderText("请输入作品简介（50-500字）")
        self.desc_input.setMinimumHeight(100)
        self.desc_input.setStyleSheet("background-color: #ffffff; border: 1px solid #dcdcdc; border-radius: 4px; padding: 5px;")
        info_layout.addWidget(self.desc_input, 6, 1)

        # Wrap book_info_widget in scroll area for scrolling
        self.book_info_scroll_area = QScrollArea()
        self.book_info_scroll_area.setWidgetResizable(True)
        self.book_info_scroll_area.setWidget(self.book_info_widget)
        self.book_info_scroll_area.setStyleSheet("QScrollArea { border: none; }")
        self.book_info_scroll_area.setVisible(False)
        book_info_layout.addWidget(self.book_info_scroll_area)

        # Buttons below table - regenerate and save
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        self.regenerate_meta_btn = QPushButton("重新生成新书信息")
        self.regenerate_meta_btn.setFixedSize(150, 36)
        self.regenerate_meta_btn.setStyleSheet("""
            QPushButton {
                background-color: #2980b9;
                color: #ffffff;
                border: none;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2472a4;
            }
        """)
        btn_layout.addWidget(self.regenerate_meta_btn)
        self.save_meta_btn = QPushButton("保存新书信息")
        self.save_meta_btn.setFixedSize(150, 36)
        self.save_meta_btn.setStyleSheet("""
            QPushButton {
                background-color: #2980b9;
                color: #ffffff;
                border: none;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2472a4;
            }
        """)
        btn_layout.addWidget(self.save_meta_btn)
        book_info_layout.addLayout(btn_layout)
        layout.addWidget(self.book_info_container)

        # Initially hide the book info container
        self.book_info_container.setVisible(False)

        layout.addStretch()
        return widget

    def _create_step3_widget(self) -> QWidget:
        """Step 3: Publish range selection."""
        # Use scroll area as container for scrolling support
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QScrollArea.Shape.NoFrame)

        # Inner widget with the actual content
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(20)

        # Title
        title = QLabel("设置发布队列")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
        layout.addWidget(title)

        # 发布队列状态 GroupBox
        status_group = QGroupBox("发布队列状态")
        status_layout = QVBoxLayout(status_group)
        status_layout.setSpacing(8)

        self.stage2_total_label = QLabel("本地总章节: - 章")
        self.stage2_total_label.setStyleSheet("color: #34495e; font-size: 13px;")
        status_layout.addWidget(self.stage2_total_label)

        self.stage2_in_queue_label = QLabel("已进入发布队列: - 章")
        self.stage2_in_queue_label.setStyleSheet("color: #34495e; font-size: 13px;")
        status_layout.addWidget(self.stage2_in_queue_label)

        self.stage2_pending_label = QLabel("待进入发布队列: - 章")
        self.stage2_pending_label.setStyleSheet("color: #27ae60; font-size: 13px; font-weight: bold;")
        status_layout.addWidget(self.stage2_pending_label)

        layout.addWidget(status_group)

        # Chapter range inputs
        range_group = QGroupBox("发布章节范围")
        range_layout = QVBoxLayout(range_group)

        # Hint text
        range_hint = QLabel("提示：将转换第1章到所选章节的所有章节到发布队列")
        range_hint.setStyleSheet("color: #7f8c8d; font-size: 12px; padding: 5px 0;")
        range_layout.addWidget(range_hint)

        range_row = QHBoxLayout()
        range_row.setSpacing(15)

        range_row.addWidget(QLabel("发布到第"))
        self.end_chapter_input = QLineEdit()
        self.end_chapter_input.setValidator(QIntValidator(1, 9999, self))
        self.end_chapter_input.setText("10")
        self.end_chapter_input.setFixedWidth(100)
        self.end_chapter_input.setFixedHeight(32)
        self.end_chapter_input.setAlignment(Qt.AlignmentFlag.AlignCenter)
        range_row.addWidget(self.end_chapter_input)

        range_row.addWidget(QLabel("章"))

        self.publish_all_btn = QPushButton("选择全部章节")
        self.publish_all_btn.setFixedHeight(32)
        self.publish_all_btn.setStyleSheet("""
            QPushButton {
                background-color: #2980b9;
                color: #ffffff;
                border: none;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #2472a4;
            }
        """)
        range_row.addWidget(self.publish_all_btn)
        range_row.addStretch()
        range_layout.addLayout(range_row)

        layout.addWidget(range_group)

        # Chapter split options
        split_group = QGroupBox("章节划分方式")
        split_layout = QVBoxLayout(split_group)
        split_layout.setSpacing(8)
        split_layout.setContentsMargins(10, 10, 10, 10)

        self.publish_type_group = QButtonGroup()

        self.original_radio = QRadioButton("按原始章节发布")
        self.original_radio.setChecked(True)
        self.original_radio.setFixedHeight(32)
        split_layout.addWidget(self.original_radio)
        self.publish_type_group.addButton(self.original_radio)

        self.restructure_radio = QRadioButton("按自定义字数重新划分章节")
        self.restructure_radio.setFixedHeight(32)
        split_layout.addWidget(self.restructure_radio)
        self.publish_type_group.addButton(self.restructure_radio)

        # Word count input container - hidden when original radio is selected
        self.word_input_widget = QWidget()
        self.word_input_widget.setFixedHeight(48)
        word_input_layout = QHBoxLayout(self.word_input_widget)
        word_input_layout.setContentsMargins(10, 10, 0, 10)

        self.restructure_word_label = QLabel("每章目标字数:")
        self.restructure_word_label.setFixedHeight(26)
        word_input_layout.addWidget(self.restructure_word_label)
        self.restructure_word_input = QLineEdit()
        self.restructure_word_input.setValidator(QIntValidator(1000, 10000, self))
        self.restructure_word_input.setText("3000")
        self.restructure_word_input.setFixedWidth(120)
        self.restructure_word_input.setFixedHeight(32)
        self.restructure_word_input.setAlignment(Qt.AlignmentFlag.AlignCenter)
        word_input_layout.addWidget(self.restructure_word_input)

        # Button to start restructuring - visible only when restructure radio is selected
        self.start_restructure_btn = QPushButton("重新划分章节")
        self.start_restructure_btn.setFixedHeight(32)
        self.start_restructure_btn.setStyleSheet("""
            QPushButton {
                background-color: #2980b9;
                color: #ffffff;
                border: none;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #2472a4;
            }
        """)
        word_input_layout.addWidget(self.start_restructure_btn)

        word_input_layout.addStretch()
        split_layout.addWidget(self.word_input_widget)

        self.restructure_hint = QLabel("重新划分章节后，将自动重新生成章节标题")
        self.restructure_hint.setStyleSheet("color: #7f8c8d; font-size: 12px;")
        split_layout.addWidget(self.restructure_hint)

        # Progress label for restructuring
        self.restructure_progress = QLabel("")
        self.restructure_progress.setStyleSheet("color: #3498db; font-size: 12px; font-weight: bold;")
        self.restructure_progress.setVisible(False)
        split_layout.addWidget(self.restructure_progress)

        layout.addWidget(split_group)

        layout.addStretch()

        # Set the inner widget as scroll area's widget
        scroll_area.setWidget(widget)

        return scroll_area

    def _create_step4_widget(self) -> QWidget:
        """Step 4: Account selection."""
        # Outer scroll area
        outer_scroll = QScrollArea()
        outer_scroll.setWidgetResizable(True)
        outer_scroll.setFrameShape(QScrollArea.Shape.NoFrame)

        # Container widget
        container = QWidget()
        container_layout = QVBoxLayout(container)
        container_layout.setSpacing(20)

        # Title
        title = QLabel("选择发布账号")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
        container_layout.addWidget(title)

        # Account group - expands to fill width
        account_group = QGroupBox("番茄账号")
        account_group_layout = QVBoxLayout(account_group)
        account_group_layout.setSpacing(10)

        # Account list - fixed height
        self.account_list = QListWidget()
        self.account_list.setObjectName("accountList")
        self.account_list.setFixedHeight(150)
        self.account_list.setSelectionMode(QListWidget.SelectionMode.SingleSelection)
        self.account_list.setStyleSheet("""
            QListWidget {
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                background-color: #ffffff;
                font-size: 14px;
                outline: none;
            }
            QListWidget::item:selected {
                background-color: #3498db;
                color: #ffffff;
                outline: none;
            }
        """)
        account_group_layout.addWidget(self.account_list)

        # Buttons row (Add/Edit/Delete)
        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)

        self.add_account_btn = QPushButton("添加账号")
        self.add_account_btn.setObjectName("addAccountBtn")
        self.add_account_btn.setFixedSize(100, 32)
        btn_row.addWidget(self.add_account_btn)

        self.edit_account_btn = QPushButton("编辑")
        self.edit_account_btn.setObjectName("editAccountBtn")
        self.edit_account_btn.setFixedSize(80, 32)
        self.edit_account_btn.setEnabled(False)
        btn_row.addWidget(self.edit_account_btn)

        self.delete_account_btn = QPushButton("删除")
        self.delete_account_btn.setObjectName("deleteAccountBtn")
        self.delete_account_btn.setFixedSize(80, 32)
        self.delete_account_btn.setEnabled(False)
        btn_row.addWidget(self.delete_account_btn)

        btn_row.addStretch()
        account_group_layout.addLayout(btn_row)

        # Form container - hidden when not editing
        self.account_form_widget = QWidget()
        self.account_form_widget.setObjectName("formWidget")
        self.account_form_widget.setVisible(False)
        form_layout = QVBoxLayout(self.account_form_widget)
        form_layout.setSpacing(10)

        # Phone row
        phone_row = QHBoxLayout()
        phone_row.setSpacing(10)
        self.phone_input = QLineEdit()
        self.phone_input.setPlaceholderText("手机号")
        self.phone_input.setFixedHeight(36)
        phone_row.addWidget(self.phone_input)
        form_layout.addLayout(phone_row)

        # Password row
        password_row = QHBoxLayout()
        password_row.setSpacing(10)
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("密码")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_input.setFixedHeight(36)
        password_row.addWidget(self.password_input)
        form_layout.addLayout(password_row)

        # Nickname row
        nickname_row = QHBoxLayout()
        nickname_row.setSpacing(10)
        self.nickname_input = QLineEdit()
        self.nickname_input.setPlaceholderText("备注（如'主号'、'备用'）")
        self.nickname_input.setFixedHeight(36)
        nickname_row.addWidget(self.nickname_input)
        form_layout.addLayout(nickname_row)

        # Form buttons (save/cancel)
        form_btn_row = QHBoxLayout()
        form_btn_row.setSpacing(10)
        form_btn_row.addStretch()

        self.cancel_account_form_btn = QPushButton("取消")
        self.cancel_account_form_btn.setFixedSize(80, 32)
        form_btn_row.addWidget(self.cancel_account_form_btn)

        self.save_account_form_btn = QPushButton("保存")
        self.save_account_form_btn.setObjectName("saveAccountBtn")
        self.save_account_form_btn.setFixedSize(80, 32)
        form_btn_row.addWidget(self.save_account_form_btn)
        form_layout.addLayout(form_btn_row)

        account_group_layout.addWidget(self.account_form_widget)

        container_layout.addWidget(account_group)

        outer_scroll.setWidget(container)
        return outer_scroll

    def _create_step5_widget(self) -> QWidget:
        """Step 5: Publish strategy - all sections on one screen."""
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QScrollArea.Shape.NoFrame)

        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(20)

        # Title
        title = QLabel("发布策略")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
        layout.addWidget(title)

        # Section 1: 更新元数据
        section1_group = QGroupBox("更新元数据")
        section1_layout = QVBoxLayout(section1_group)
        section1_layout.setSpacing(10)

        info_label = QLabel("从番茄平台获取已发布章节的元数据，同步到本地")
        info_label.setStyleSheet("color: #7f8c8d; font-size: 13px;")
        section1_layout.addWidget(info_label)

        self.stage1_status_label = QLabel("准备获取番茄已发布章节...")
        self.stage1_status_label.setStyleSheet("color: #34495e; font-size: 14px; padding: 10px; background-color: #f5f5f5; border-radius: 4px;")
        section1_layout.addWidget(self.stage1_status_label)

        self.stage1_fetch_btn = QPushButton("获取番茄已发布章节")
        self.stage1_fetch_btn.setFixedHeight(36)
        self.stage1_fetch_btn.setVisible(False)
        self.stage1_fetch_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: #ffffff;
                border: none;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        section1_layout.addWidget(self.stage1_fetch_btn)

        # Button row for unpublished works: "关联已有作品" and "创建新书"
        self.stage1_btn_row = QWidget()
        stage1_btn_layout = QHBoxLayout(self.stage1_btn_row)
        stage1_btn_layout.setSpacing(10)

        self.stage1_link_btn = QPushButton("关联已有作品")
        self.stage1_link_btn.setFixedHeight(36)
        self.stage1_link_btn.setVisible(False)
        self.stage1_link_btn.setStyleSheet("""
            QPushButton {
                background-color: #9b59b6;
                color: #ffffff;
                border: none;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #8e44ad;
            }
        """)
        stage1_btn_layout.addWidget(self.stage1_link_btn)

        self.stage1_create_btn = QPushButton("创建新书")
        self.stage1_create_btn.setFixedHeight(36)
        self.stage1_create_btn.setVisible(False)
        self.stage1_create_btn.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: #ffffff;
                border: none;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #229954;
            }
        """)
        stage1_btn_layout.addWidget(self.stage1_create_btn)

        stage1_btn_layout.addStretch()
        section1_layout.addWidget(self.stage1_btn_row)

        layout.addWidget(section1_group)

        # Section 2: 发布章节范围 (hidden initially)
        self.stage2_group = QGroupBox("发布章节范围")
        self.stage2_group.setVisible(False)
        section2_layout = QVBoxLayout(self.stage2_group)
        section2_layout.setSpacing(10)

        range_info = QLabel("选择本地章节和番茄平台对齐的章节范围")
        range_info.setStyleSheet("color: #7f8c8d; font-size: 13px;")
        section2_layout.addWidget(range_info)

        # Range selection
        range_sel_row = QHBoxLayout()
        range_sel_row.setSpacing(15)

        range_sel_row.addWidget(QLabel("从第"))
        self.stage2_start_input = QLineEdit()
        self.stage2_start_input.setValidator(QIntValidator(1, 9999))
        self.stage2_start_input.setFixedWidth(80)
        self.stage2_start_input.setAlignment(Qt.AlignmentFlag.AlignCenter)
        range_sel_row.addWidget(self.stage2_start_input)

        range_sel_row.addWidget(QLabel("章 到 第"))

        self.stage2_end_input = QLineEdit()
        self.stage2_end_input.setValidator(QIntValidator(1, 9999))
        self.stage2_end_input.setFixedWidth(80)
        self.stage2_end_input.setAlignment(Qt.AlignmentFlag.AlignCenter)
        range_sel_row.addWidget(self.stage2_end_input)

        range_sel_row.addWidget(QLabel("章"))
        range_sel_row.addStretch()
        section2_layout.addLayout(range_sel_row)

        self.stage2_preview_label = QLabel("")
        self.stage2_preview_label.setStyleSheet("color: #7f8c8d; font-size: 12px; padding: 5px 0;")
        section2_layout.addWidget(self.stage2_preview_label)

        layout.addWidget(self.stage2_group)

        # Section 3: 发布方式 (hidden initially)
        self.stage3_group = QGroupBox("发布方式")
        self.stage3_group.setVisible(False)
        section3_layout = QVBoxLayout(self.stage3_group)
        section3_layout.setSpacing(10)

        mode_row = QHBoxLayout()
        mode_row.setSpacing(15)

        self.direct_publish_radio = QRadioButton("直接发布")
        self.direct_publish_radio.setChecked(True)
        mode_row.addWidget(self.direct_publish_radio)

        self.timed_publish_radio = QRadioButton("定时发布")
        mode_row.addWidget(self.timed_publish_radio)

        mode_row.addStretch()
        section3_layout.addLayout(mode_row)

        # Timed publish settings (hidden by default)
        self.timed_settings_widget = QWidget()
        self.timed_settings_widget.setVisible(False)
        timed_layout = QVBoxLayout(self.timed_settings_widget)
        timed_layout.setSpacing(10)

        daily_row = QHBoxLayout()
        daily_label = QLabel("每日发布")
        daily_label.setFixedWidth(70)
        daily_row.addWidget(daily_label)
        self.daily_count_input = QLineEdit()
        self.daily_count_input.setValidator(QIntValidator(1, 20, self))
        self.daily_count_input.setText("2")
        self.daily_count_input.setFixedWidth(90)
        self.daily_count_input.setFixedHeight(30)
        self.daily_count_input.setAlignment(Qt.AlignmentFlag.AlignCenter)
        daily_row.addWidget(self.daily_count_input)
        daily_row.addWidget(QLabel("章"))
        daily_row.addStretch()
        timed_layout.addLayout(daily_row)

        date_row = QHBoxLayout()
        date_label = QLabel("开始日期")
        date_label.setFixedWidth(70)
        date_row.addWidget(date_label)
        self.start_date_input = QDateEdit()
        self.start_date_input.setCalendarPopup(True)
        self.start_date_input.setDisplayFormat("yyyy-MM-dd")
        self.start_date_input.setFixedWidth(130)
        self.start_date_input.setFixedHeight(30)
        # Default to today
        from PyQt6.QtCore import QDate
        self.start_date_input.setDate(QDate.currentDate())
        date_row.addWidget(self.start_date_input)
        date_row.addStretch()
        timed_layout.addLayout(date_row)

        time_row = QHBoxLayout()
        time_label = QLabel("时间范围")
        time_label.setFixedWidth(70)
        time_row.addWidget(time_label)
        self.start_time_input = QTimeEdit()
        self.start_time_input.setDisplayFormat("HH:mm")
        self.start_time_input.setFixedWidth(90)
        self.start_time_input.setFixedHeight(30)
        # Default to 21:00
        from PyQt6.QtCore import QTime
        self.start_time_input.setTime(QTime(21, 0))
        time_row.addWidget(self.start_time_input)
        time_row.addWidget(QLabel(" - "))
        self.end_time_input = QTimeEdit()
        self.end_time_input.setDisplayFormat("HH:mm")
        self.end_time_input.setFixedWidth(90)
        self.end_time_input.setFixedHeight(30)
        # Default to 23:00
        self.end_time_input.setTime(QTime(23, 0))
        time_row.addWidget(self.end_time_input)
        time_row.addStretch()
        timed_layout.addLayout(time_row)

        self.generate_schedule_btn = QPushButton("生成发布时间表")
        self.generate_schedule_btn.setFixedHeight(32)
        self.generate_schedule_btn.setStyleSheet("""
            QPushButton {
                background-color: #9b59b6;
                color: #ffffff;
                border: none;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #8e44ad;
            }
        """)
        timed_layout.addWidget(self.generate_schedule_btn)

        section3_layout.addWidget(self.timed_settings_widget)

        # Schedule table (hidden by default)
        self.schedule_table_widget = QWidget()
        self.schedule_table_widget.setVisible(False)
        schedule_layout = QVBoxLayout(self.schedule_table_widget)
        schedule_layout.setSpacing(5)

        schedule_title = QLabel("发布时间表")
        schedule_title.setStyleSheet("font-weight: bold; color: #2c3e50;")
        schedule_layout.addWidget(schedule_title)

        self.schedule_list_widget = QListWidget()
        self.schedule_list_widget.setMinimumHeight(300)
        schedule_layout.addWidget(self.schedule_list_widget)

        section3_layout.addWidget(self.schedule_table_widget)

        layout.addWidget(self.stage3_group)

        layout.addStretch()

        scroll_area.setWidget(widget)
        return scroll_area

    def _create_step6_widget(self) -> QWidget:
        """Step 6: Summary and publish."""
        # Use scroll area to allow scrolling when content is tall
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setStyleSheet("QScrollArea { background-color: transparent; border: none; } QScrollArea > QWidget { background-color: transparent; }")

        # Container widget for scroll area content
        container = QWidget()
        container.setObjectName("step6Container")
        container.setStyleSheet("background-color: transparent; border: none;")
        layout = QVBoxLayout(container)
        layout.setSpacing(15)
        layout.setContentsMargins(0, 0, 0, 0)

        # Title
        title = QLabel("确认并发布")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;")
        layout.addWidget(title)

        # Summary table - each row fixed height
        self.summary_table = QWidget()
        self.summary_table.setStyleSheet("background-color: transparent; border: none;")
        summary_layout = QVBoxLayout(self.summary_table)
        summary_layout.setSpacing(0)
        summary_layout.setContentsMargins(0, 0, 0, 0)

        # Create rows for summary
        self._create_summary_row("作品名称：", self._create_value_label("请选择作品"))
        self._create_summary_row("发布平台：", self._create_value_label("请选择平台"))
        self._create_summary_row("发布账号：", self._create_value_label("请选择账号"))
        self._create_summary_row("发布队列：", self._create_value_label("请设置范围"))
        self._create_summary_row("章节划分：", self._create_value_label("请选择划分方式"))
        self._create_summary_row("已进入发布队列：", self._create_value_label("0 章"))
        self._create_summary_row("待进入发布队列：", self._create_value_label("0 章"))
        self._create_summary_row("番茄书本ID：", self._create_value_label("未创建"))

        layout.addWidget(self.summary_table)

        # Schedule list widget for detailed publish schedule
        schedule_title = QLabel("发布时间表：")
        schedule_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #2c3e50; margin-top: 10px;")
        layout.addWidget(schedule_title)

        self.schedule_summary_list = QListWidget()
        self.schedule_summary_list.setStyleSheet("""
            QListWidget {
                border: 1px solid #dcdcdc;
                border-radius: 4px;
                background-color: #fafafa;
                padding: 5px;
                min-height: 300px;
            }
            QListWidget::item {
                padding: 8px;
                border-bottom: 1px solid #eee;
                font-size: 14px;
            }
            QListWidget::item:last {
                border-bottom: none;
            }
        """)
        layout.addWidget(self.schedule_summary_list)

        # Progress display
        self.progress_label = QLabel()
        self.progress_label.setStyleSheet("color: #27ae60; font-size: 14px; font-weight: bold;")
        self.progress_label.setVisible(False)
        layout.addWidget(self.progress_label)

        # Progress bar
        self.progress_bar = QWidget()
        progress_layout = QVBoxLayout(self.progress_bar)
        progress_layout.setSpacing(5)

        self.progress_text = QLabel("准备发布...")
        self.progress_text.setStyleSheet("color: #7f8c8d; font-size: 12px;")
        progress_layout.addWidget(self.progress_text)

        self.progress_bar_inner = QWidget()
        self.progress_bar_inner.setStyleSheet("background-color: #ecf0f1; border-radius: 4px; height: 8px;")
        progress_bar_layout = QHBoxLayout(self.progress_bar_inner)
        progress_bar_layout.setContentsMargins(0, 0, 0, 0)
        self.progress_fill = QWidget()
        self.progress_fill.setFixedWidth(0)
        self.progress_fill.setStyleSheet("background-color: #27ae60; border-radius: 4px;")
        progress_bar_layout.addWidget(self.progress_fill)
        progress_bar_layout.addStretch()
        progress_layout.addWidget(self.progress_bar_inner)

        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

        layout.addStretch()

        # Set scroll area properties
        scroll.setWidget(container)

        # Return the scroll area as the widget
        return scroll

    def _create_summary_row(self, label_text: str, value_widget: QWidget) -> None:
        """Create a row in the summary table."""
        row = QWidget()
        row.setFixedHeight(40)
        row_layout = QHBoxLayout(row)
        row_layout.setSpacing(10)
        row_layout.setContentsMargins(0, 0, 0, 0)

        label = QLabel(label_text)
        label.setFixedWidth(100)
        label.setFixedHeight(40)
        label.setAlignment(Qt.AlignmentFlag.AlignVCenter)
        label.setStyleSheet("color: #7f8c8d; font-size: 14px;")
        row_layout.addWidget(label)

        value_widget.setFixedHeight(40)
        value_widget.setAlignment(Qt.AlignmentFlag.AlignVCenter)
        value_widget.setStyleSheet("color: #2c3e50; font-size: 14px; font-weight: bold;")
        row_layout.addWidget(value_widget)
        row_layout.addStretch()

        self.summary_table.layout().addWidget(row)

    def _create_value_label(self, text: str) -> QLabel:
        """Create a value label for the summary table."""
        label = QLabel(text)
        label.setObjectName("summaryValue")
        return label

    def _update_step_visibility(self) -> None:
        """Update which step widget is visible."""
        steps = [self.step1_widget, self.step2_widget, self.step3_widget, self.step4_widget, self.step5_widget, self.step6_widget]

        for i, step_widget in enumerate(steps, 1):
            step_widget.setVisible(i == self._current_step)

        # Update radio button visibility state when showing step 3
        if self._current_step == 3:
            # Don't call _on_original_toggled here - it will be called when user actually clicks the radio
            # Just ensure the UI state is correct based on current radio state
            pass

        # Update step indicator colors using direct list access
        publishing_completed = getattr(self, '_publishing_completed', False)
        for i in range(6):
            circle = self.step_circles[i]
            name = self.step_names[i]
            step_num = i + 1

            if publishing_completed:
                # All steps completed - all green
                circle.setFixedSize(28, 28)
                circle.setStyleSheet("""
                    QLabel {
                        background-color: #27ae60;
                        color: #ffffff;
                        border-radius: 14px;
                        font-weight: bold;
                        font-size: 13px;
                    }
                """)
                name.setStyleSheet("color: #27ae60; font-size: 12px;")
            elif step_num == self._current_step:
                # Current step - 32px diameter = 16px radius for perfect circle
                circle.setFixedSize(32, 32)
                circle.setStyleSheet("""
                    QLabel {
                        background-color: #3498db;
                        color: #ffffff;
                        border-radius: 16px;
                        font-weight: bold;
                        font-size: 15px;
                    }
                """)
                name.setStyleSheet("color: #3498db; font-size: 14px; font-weight: bold;")
            elif step_num < self._current_step:
                # Completed step - 28px diameter = 14px radius
                circle.setFixedSize(28, 28)
                circle.setStyleSheet("""
                    QLabel {
                        background-color: #27ae60;
                        color: #ffffff;
                        border-radius: 14px;
                        font-weight: bold;
                        font-size: 13px;
                    }
                """)
                name.setStyleSheet("color: #27ae60; font-size: 12px;")
            else:
                # Future step - 28px diameter = 14px radius
                circle.setFixedSize(28, 28)
                circle.setStyleSheet("""
                    QLabel {
                        background-color: #bdc3c7;
                        color: #ffffff;
                        border-radius: 14px;
                        font-weight: bold;
                        font-size: 13px;
                    }
                """)
                name.setStyleSheet("color: #7f8c8d; font-size: 12px;")

            # Update connector lines
            if i < 5 and i < len(self.step_lines):
                line = self.step_lines[i]
                if publishing_completed or step_num < self._current_step:
                    line.setStyleSheet("background-color: #27ae60;")
                else:
                    line.setStyleSheet("background-color: #bdc3c7;")

        # Update navigation buttons
        if publishing_completed:
            # Hide step navigation, show "再次发布"
            self.prev_btn.setVisible(False)
            self.next_btn.setVisible(False)
            self.publish_btn.setVisible(True)
            self.publish_btn.setText("再次发布")
        else:
            self.prev_btn.setVisible(self._current_step > 1)
            self.next_btn.setVisible(self._current_step < 6)
            self.publish_btn.setVisible(self._current_step == 6)
            self.publish_btn.setText("发布章节")

        # Auto-load chapters from local storage when entering step 5
        if self._current_step == 5:
            self._load_local_chapters()
            self._init_step5_button_state()

        # Update next button state based on step validation
        self._validate_current_step()

    def _validate_current_step(self) -> None:
        """Validate current step and update next button state."""
        valid = False
        tooltip = ""
        self.logger.info(f"[publish] _validate_current_step: called, current_step={self._current_step}")

        if self._current_step == 1:
            valid = self._current_platform is not None
            self.logger.info(f"[publish] _validate_current_step: step=1, valid={valid}")
        elif self._current_step == 2:
            valid = self._current_work_id is not None
            self.logger.info(f"[publish] _validate_current_step: step=2, valid={valid}, work_id={self._current_work_id}")
        elif self._current_step == 3:
            # If custom mode selected, need to complete restructuring first
            self.logger.info(f"[publish] _validate_current_step: step=3, restructure_radio.isChecked()={self.restructure_radio.isChecked()}, original_radio.isChecked()={self.original_radio.isChecked()}, _restructure_complete={getattr(self, '_restructure_complete', False)}")
            # Always allow proceeding with original_radio
            if self.restructure_radio.isChecked():
                # Check if restructuring was already done (either in this session or previously)
                if getattr(self, '_restructure_complete', False):
                    valid = True
                    self.logger.info(f"[publish] _validate_current_step: step=3, restructure_radio=True, _restructure_complete=True -> valid=True")
                elif self._has_publish_files():
                    # Publish directory has files from previous restructuring, allow proceeding
                    valid = True
                    self.logger.info(f"[publish] _validate_current_step: step=3, restructure_radio=True, has_publish_files=True -> valid=True")
                else:
                    valid = False
                    tooltip = "请先完成重新划分章节"
                    self.logger.info(f"[publish] _validate_current_step: step=3, restructure_radio=True, _restructure_complete=False, no_publish_files -> valid=False")
            else:
                valid = True
                self.logger.info(f"[publish] _validate_current_step: step=3, restructure_radio=False (original selected) -> valid=True")
        elif self._current_step == 4:
            valid = self._current_platform != "番茄" or self._current_account_id is not None
            self.logger.info(f"[publish] _validate_current_step: step=4, valid={valid}")
        elif self._current_step == 5:
            # Publish strategy step - always valid to proceed
            valid = True
            self.logger.info(f"[publish] _validate_current_step: step=5, valid={valid}")
        elif self._current_step == 6:
            # Summary step - always valid
            valid = True
            self.logger.info(f"[publish] _validate_current_step: step=6, valid={valid}")

        self.logger.info(f"[publish] _validate_current_step: setting next_btn.enabled={valid}, tooltip={tooltip}")
        self.next_btn.setEnabled(valid)
        if tooltip:
            self.next_btn.setToolTip(tooltip)
        else:
            self.next_btn.setToolTip("")

    def _update_summary(self) -> None:
        """Update the summary display in step 6 (summary step)."""
        # Find all summary value labels by object name
        value_labels = self.summary_table.findChildren(QLabel, "summaryValue")

        self.logger.info(f"[publish] _update_summary called, value_labels count = {len(value_labels)}")

        # Update each row if label exists at that index
        # Row 0: 作品名称
        if len(value_labels) > 0:
            value_labels[0].setText(self._current_work.title if self._current_work else "请选择作品")

        # Row 1: 发布平台
        if len(value_labels) > 1:
            value_labels[1].setText(self._current_platform or "请选择平台")

        # Row 2: 发布账号
        if len(value_labels) > 2:
            if self._current_platform == "番茄" and self._current_account_id:
                account = self.fanqie_account_manager.get_account(self._current_account_id)
                if account:
                    value_labels[2].setText(f"{account.phone[:3]}****{account.phone[-4:]}")
                else:
                    value_labels[2].setText("请选择账号")
            else:
                value_labels[2].setText("请选择账号")

        # Row 3: 发布队列
        if len(value_labels) > 3:
            try:
                start_ch = int(self.stage2_start_input.text() or "0")
                end_ch = int(self.stage2_end_input.text() or "0")
                value_labels[3].setText(f"第 {start_ch} 章 至 第 {end_ch} 章")
            except ValueError:
                value_labels[3].setText("请设置范围")

        # Row 4: 章节划分
        if len(value_labels) > 4:
            if self.restructure_radio.isChecked():
                words = int(self.restructure_word_input.text() or "0")
                value_labels[4].setText(f"按 {words} 字/章 重新划分")
            else:
                value_labels[4].setText("按原始章节")

        # Row 5: 已进入发布队列章节数
        if len(value_labels) > 5:
            if self._current_work:
                converted_count = getattr(self._current_work, 'steps_to_publish_converted_count', 0)
            else:
                converted_count = 0
            value_labels[5].setText(f"{converted_count} 章")

        # Row 6: 待进入发布队列章节数
        if len(value_labels) > 6:
            try:
                start_ch = int(self.stage2_start_input.text() or "0")
                end_ch = int(self.stage2_end_input.text() or "0")
                pending_count = max(0, end_ch - converted_count)
                value_labels[6].setText(f"{pending_count} 章")
            except ValueError:
                value_labels[6].setText("0 章")

        # Row 7: 番茄书本ID
        if len(value_labels) > 7:
            if self._current_work and self._current_work.fanqie_book_id:
                value_labels[7].setText(self._current_work.fanqie_book_id)
            else:
                value_labels[7].setText("未创建")

        # Update schedule list
        self.schedule_summary_list.clear()
        if self.timed_publish_radio.isChecked() and hasattr(self, '_generated_schedule') and self._generated_schedule:
            self.schedule_summary_list.addItems(self._generated_schedule)
        elif self.timed_publish_radio.isChecked():
            self.schedule_summary_list.addItem("点击上方\"生成发布时间表\"按钮生成")
        else:
            self.schedule_summary_list.addItem("直接发布（无时间表）")

        # Update button visibility
        self._update_publish_buttons()

    def _update_publish_buttons(self) -> None:
        """Update publish button visibility based on book creation status."""
        if not self._current_work:
            self.create_book_btn.setVisible(False)
            self.publish_btn.setVisible(False)
            return

        if self._current_platform == "番茄":
            # Show create book button if book ID not created
            self.create_book_btn.setVisible(not bool(self._current_work.fanqie_book_id))
            # Show publish button if book ID exists
            self.publish_btn.setVisible(bool(self._current_work.fanqie_book_id))
        else:
            self.create_book_btn.setVisible(False)
            self.publish_btn.setVisible(True)


    def _setup_connections(self) -> None:
        """Connect signals and slots."""
        # Navigation buttons
        self.prev_btn.clicked.connect(self._on_prev_step)
        self.next_btn.clicked.connect(self._on_next_step)
        self.publish_btn.clicked.connect(self._on_publish)
        self.create_book_btn.clicked.connect(self._on_create_book)

        # Step 1: Platform
        self.platform_combo.currentTextChanged.connect(self._on_platform_changed)

        # Step 2: Work
        self.work_combo.currentIndexChanged.connect(self._on_work_changed)
        self.generate_meta_btn.clicked.connect(self._on_generate_metadata)
        self.regenerate_meta_btn.clicked.connect(self._on_generate_metadata)
        self.save_meta_btn.clicked.connect(self._on_save_metadata)

        # Metadata generation signal (from chat service callback)
        self.metadata_generated.connect(self._handle_metadata_generated_result)

        # Step 3: Chapter range
        self.publish_all_btn.clicked.connect(self._on_publish_all)
        self.original_radio.toggled.connect(self._on_original_toggled)
        self.restructure_radio.toggled.connect(self._on_restructure_toggled)
        self.start_restructure_btn.clicked.connect(self._on_start_restructure)
        self.restructure_word_input.textChanged.connect(self._on_word_count_changed)

        # Step 4: Account - list widget and buttons
        if hasattr(self, 'account_list'):
            self.account_list.itemSelectionChanged.connect(self._on_inline_account_selection_changed)
            self.add_account_btn.clicked.connect(self._on_add_inline_account)
            self.edit_account_btn.clicked.connect(self._on_edit_inline_account)
            self.delete_account_btn.clicked.connect(self._on_delete_inline_account)
            self.cancel_account_form_btn.clicked.connect(self._on_cancel_inline_account_form)
            self.save_account_form_btn.clicked.connect(self._on_save_inline_account_form)

        # Title generation signals
        self.title_gen_progress.connect(self._on_title_gen_progress)
        self.title_gen_complete.connect(self._on_title_gen_complete)

        # Step 5: Strategy controls
        self.stage1_fetch_btn.clicked.connect(self._on_fetch_fanqie_chapters)
        self.stage1_link_btn.clicked.connect(self._on_link_existing_book)
        self.stage1_create_btn.clicked.connect(self._on_create_new_book)
        self.stage2_start_input.textChanged.connect(self._on_strategy_range_changed)
        self.stage2_end_input.textChanged.connect(self._on_strategy_range_changed)
        self.direct_publish_radio.toggled.connect(self._on_publish_mode_changed)
        self.timed_publish_radio.toggled.connect(self._on_publish_mode_changed)
        self.generate_schedule_btn.clicked.connect(self._on_generate_schedule)

        # Initialize current platform with default selection
        self._current_platform = self.platform_combo.currentText()

    def _setup_logger(self):
        """Set up logger if not already available."""
        import logging
        logger = get_logger()
        if logger is None:
            # Create a simple logger if none exists
            logger = logging.getLogger('PublishingView')
            if not logger.handlers:
                handler = logging.StreamHandler()
                handler.setFormatter(logging.Formatter(
                    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
                ))
                logger.addHandler(handler)
                logger.setLevel(logging.INFO)
        return logger

    def _apply_styles(self) -> None:
        """Apply styles to the view."""
        self.setStyleSheet("""
            QGroupBox {
                font-size: 14px;
                font-weight: bold;
                color: #2c3e50;
                padding-top: 10px;
                margin-top: 8px;
            }

            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 8px;
                color: #3498db;
            }

            QComboBox {
                padding: 4px 12px;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                background-color: #ffffff;
                font-size: 14px;
                min-height: 28px;
                max-height: 28px;
            }

            QComboBox:hover {
                border-color: #3498db;
            }

            QComboBox:focus {
                border-color: #3498db;
                outline: none;
            }

            QComboBox::drop-down {
                border: none;
                width: 30px;
            }

            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 6px solid #7f8c8d;
                margin-right: 10px;
            }

            QSpinBox {
                padding: 4px 12px;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                background-color: #ffffff;
                font-size: 14px;
                min-height: 28px;
                max-height: 28px;
            }

            QSpinBox:hover {
                border-color: #3498db;
            }

            QSpinBox:focus {
                border-color: #3498db;
                outline: none;
            }

            QPushButton {
                padding: 8px 16px;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                background-color: #ffffff;
                font-size: 14px;
                color: #2c3e50;
            }

            QPushButton:hover {
                background-color: #f5f5f5;
                border-color: #3498db;
            }

            QPushButton:disabled {
                background-color: #e0e0e0;
                color: #9e9e9e;
                border-color: #d0d0d0;
            }

            QRadioButton {
                spacing: 8px;
                font-size: 14px;
                color: #2c3e50;
                min-height: 36px;
                max-height: 36px;
            }

            QRadioButton:hover {
                color: #1976d2;
            }

            QRadioButton:checked {
                color: #1976d2;
                font-weight: bold;
            }

            #cancelBtn {
                min-width: 100px;
            }

            #publishBtn {
                background-color: #3498db;
                color: #ffffff;
                border: none;
                font-weight: bold;
                min-width: 100px;
            }

            #publishBtn:hover {
                background-color: #2980b9;
            }

            #manageAccountBtn, #publishAllBtn {
                background-color: #9b59b6;
                color: #ffffff;
                border: none;
            }

            #manageAccountBtn:hover, #publishAllBtn:hover {
                background-color: #8e44ad;
            }

            QLabel {
                color: #2c3e50;
                font-size: 14px;
                min-height: 28px;
            }

            #workInfoLabel {
                color: #7f8c8d;
                font-size: 13px;
                padding: 8px;
                background-color: #f8f9fa;
                border-radius: 4px;
            }
        """)

    def _load_works(self) -> None:
        """Load works into the work combo box."""
        if self.work_manager is None:
            return

        try:
            works = self.work_manager.get_all_works()

            # Clear existing items except the placeholder
            while self.work_combo.count() > 1:
                self.work_combo.removeItem(1)

            # Add works
            for work in works:
                display_title = work.get_display_title()
                # Mark works that have been published to fanqie
                if work.fanqie_book_id:
                    display_title = f"{display_title} (已发布)"
                self.work_combo.addItem(display_title, work.id)

        except Exception as e:
            self.logger.error(f"Failed to load works: {e}")

    def _refresh_account_list(self) -> None:
        """Refresh the account list."""
        if self.fanqie_account_manager is None:
            return

        if not hasattr(self, 'account_list'):
            return

        self.account_list.clear()
        for account in self.fanqie_account_manager.get_all_accounts():
            item = QListWidgetItem(account.get_display_name())
            item.setData(Qt.ItemDataRole.UserRole, account.id)
            self.account_list.addItem(item)

    def _select_account_in_list(self, account_id: str) -> None:
        """Select an account in the account list by its ID."""
        if not hasattr(self, 'account_list'):
            return

        for i in range(self.account_list.count()):
            item = self.account_list.item(i)
            if item.data(Qt.ItemDataRole.UserRole) == account_id:
                self.account_list.setCurrentItem(item)
                self._current_account_id = account_id
                # Trigger the selection changed handler
                self._on_inline_account_selection_changed()
                break

    def _on_prev_step(self) -> None:
        """Handle previous step button click."""
        if self._current_step > 1:
            self._current_step -= 1
            self._update_step_visibility()

    def _on_next_step(self) -> None:
        """Handle next step button click."""
        # Before moving from step 3, handle chapter copying to publish directory
        if self._current_step == 3:
            if self.original_radio.isChecked():
                # Copy original chapters to publish directory
                success, msg = self._copy_original_chapters_to_publish()
                if not success:
                    QMessageBox.warning(self, "提示", msg)
                    return

                # Save the converted count to Work model
                end_chapter = int(self.end_chapter_input.text() or "0")
                work = self.work_manager.get_work(self._current_work_id)
                if work:
                    work.steps_to_publish_converted_count = end_chapter
                    self.work_manager.update_work(work)
                    self.logger.info(f"[publish] Saved steps_to_publish_converted_count = {end_chapter}")
            elif self.restructure_radio.isChecked():
                # Check if restructuring is complete or publish files exist
                if not getattr(self, '_restructure_complete', False) and not self._has_publish_files():
                    QMessageBox.warning(self, "提示", "请先完成重新划分章节")
                    return
                # Restructure done, save end_chapter
                end_chapter = int(self.end_chapter_input.text() or "0")
                work = self.work_manager.get_work(self._current_work_id)
                if work:
                    work.steps_to_publish_converted_count = end_chapter
                    self.work_manager.update_work(work)
                    self.logger.info(f"[publish] Saved steps_to_publish_converted_count (from restructure) = {end_chapter}")

        # Before moving from step 4, save account to work metadata
        if self._current_step == 4:
            if self._current_platform == "番茄" and self._current_account_id and self._current_work_id:
                work = self.work_manager.get_work(self._current_work_id)
                if work:
                    work.fanqie_account_id = self._current_account_id
                    self.work_manager.update_work(work)
                    self.logger.info(f"[publish] Saved fanqie_account_id = {self._current_account_id}")

        if self._current_step < 6:
            self._current_step += 1
            self._update_step_visibility()
            # Update summary when entering step 6 (summary step)
            if self._current_step == 6:
                self._update_summary()

    def _copy_original_chapters_to_publish(self) -> tuple:
        """Copy original chapters from steps to publish directory.

        Returns:
            (success: bool, message: str)
        """
        if not self._current_work_id or not self.work_manager:
            return (False, "未选择作品")

        try:
            work_dir = os.path.join(self.work_manager.works_dir, self._current_work_id)
            steps_dir = os.path.join(work_dir, "steps")
            publish_dir = os.path.join(work_dir, "publish")

            if not os.path.exists(steps_dir):
                return (False, "章节目录不存在")

            # Create publish directory if not exists
            if not os.path.exists(publish_dir):
                os.makedirs(publish_dir)

            # Get end chapter limit and chapters per volume from work
            work = self.work_manager.get_work(self._current_work_id)
            if not work:
                return (False, "无法获取作品信息")

            end_chapter = int(self.end_chapter_input.text() or "0")
            chapters_per_volume = getattr(work, 'chapters_per_volume', 10)  # Default to 10 if not set

            # Find all chapter content files in steps
            chapter_files = sorted([f for f in os.listdir(steps_dir)
                                    if f.startswith("chapter_") and f.endswith("_content.txt")])

            if not chapter_files:
                return (False, "没有找到章节文件")

            copied = 0
            for chapter_file in chapter_files:
                # Extract volume and chapter numbers
                # Pattern: chapter_{vol}_{chap}_content.txt
                parts = chapter_file.replace("chapter_", "").replace("_content.txt", "").split("_")
                if len(parts) < 2:
                    continue

                vol_num = int(parts[0])
                chap_num = int(parts[1])

                # Calculate total chapter number (chapters are numbered sequentially across volumes)
                total_chapter_num = (vol_num - 1) * chapters_per_volume + chap_num

                # Skip if beyond end chapter
                if total_chapter_num > end_chapter:
                    continue

                # Read chapter content
                chapter_path = os.path.join(steps_dir, chapter_file)
                with open(chapter_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                # Try to read chapter title from title file
                title_file = chapter_file.replace("_content.txt", "_title.txt")
                title_path = os.path.join(steps_dir, title_file)
                if os.path.exists(title_path):
                    with open(title_path, 'r', encoding='utf-8') as f:
                        title = f.read().strip()
                else:
                    # Fallback: use first line of content if it looks like a title
                    lines = content.split('\n', 1)
                    if lines and len(lines[0].strip()) <= 20 and not lines[0].strip().startswith('#'):
                        title = lines[0].strip()
                        content = lines[1].strip() if len(lines) > 1 else ""
                    else:
                        title = f"第{total_chapter_num}章"

                # Skip if title looks like a comment or细纲
                if title.startswith('#') or '细纲' in title:
                    title = f"第{total_chapter_num}章"

                # Write to publish directory
                dest_file = f"第{total_chapter_num}章 {title}.txt"
                dest_path = os.path.join(publish_dir, dest_file)
                with open(dest_path, 'w', encoding='utf-8') as f:
                    f.write(content)

                copied += 1
                self.logger.info(f"[publish] Copied chapter to publish: {dest_file}")

            if copied == 0:
                return (False, f"没有找到1到第{end_chapter}章的章节文件")

            return (True, f"已拷贝 {copied} 个章节到publish目录")

        except Exception as e:
            self.logger.error(f"[publish] Failed to copy chapters: {e}")
            return (False, f"拷贝章节失败: {str(e)}")

    def refresh(self) -> None:
        """Refresh publishing view (clear cached data after settings change)."""
        # Clear cached fanqie chapters
        if hasattr(self, '_fanqie_chapters'):
            self._fanqie_chapters = []
        self._fanqie_chapters_fetched = False

        # Reset summary display
        self._update_summary()

    def _on_link_existing_book(self) -> None:
        """Handle '关联已有作品' button click - show dialog to input book_id and name."""
        if not self._current_work_id or not self.work_manager:
            QMessageBox.warning(self, "提示", "请先选择作品")
            return

        # Show dialog to input book_id and book name
        dialog = QDialog(self)
        dialog.setWindowTitle("关联已有作品")
        dialog.setFixedSize(400, 180)
        layout = QVBoxLayout(dialog)

        # Book ID input
        id_layout = QHBoxLayout()
        id_layout.addWidget(QLabel("书本ID:"))
        id_input = QLineEdit()
        id_input.setPlaceholderText("请输入番茄小说书本ID")
        id_layout.addWidget(id_input)
        layout.addLayout(id_layout)

        # Book name input
        name_layout = QHBoxLayout()
        name_layout.addWidget(QLabel("书名:"))
        name_input = QLineEdit()
        name_input.setPlaceholderText("请输入书名")
        name_layout.addWidget(name_input)
        layout.addLayout(name_layout)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        save_btn = QPushButton("保存")
        cancel_btn = QPushButton("取消")
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)

        def on_save():
            book_id = id_input.text().strip()
            book_name = name_input.text().strip()
            if not book_id:
                QMessageBox.warning(dialog, "提示", "请输入书本ID")
                return
            if not book_name:
                QMessageBox.warning(dialog, "提示", "请输入书名")
                return

            # Save to work metadata
            work = self.work_manager.get_work(self._current_work_id)
            if work:
                work.fanqie_book_id = book_id
                work.fanqie_book_title = book_name
                self.work_manager.update_work(work)
                self.logger.info(f"[publish] Linked existing book: id={book_id}, name={book_name}")

            dialog.accept()

            # Update button state to show "更新元数据"
            self.stage1_status_label.setText(f"已关联作品: {book_name}")
            self.stage1_fetch_btn.setVisible(True)
            self.stage1_fetch_btn.setText("更新元数据")
            self.stage1_fetch_btn.setStyleSheet("""
                QPushButton {
                    background-color: #3498db;
                    color: #ffffff;
                    border: none;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #2980b9;
                }
            """)
            self.stage1_fetch_btn.setEnabled(True)
            self.stage1_link_btn.setVisible(False)
            self.stage1_create_btn.setVisible(False)

        save_btn.clicked.connect(on_save)
        cancel_btn.clicked.connect(dialog.reject)
        dialog.exec()

    def _on_create_new_book(self) -> None:
        """Handle '创建新书' button click."""
        self._start_create_book_flow()

    def _on_fetch_fanqie_chapters(self) -> None:
        """Handle fetch fanqie chapters button click (更新元数据 flow)."""
        if not self._current_work_id:
            QMessageBox.warning(self, "提示", "请先选择作品")
            return

        if not self._current_account_id:
            QMessageBox.warning(self, "提示", "请先选择番茄账号")
            return

        work = self.work_manager.get_work(self._current_work_id)
        book_id = getattr(work, 'fanqie_book_id', None) if work else None

        if not book_id:
            QMessageBox.warning(self, "提示", "该书未曾发布，请先关联已有作品或创建新书")
            return

        # Proceed with fetching chapters
        self._start_loading_animation(self.stage1_status_label, "正在获取番茄已发布章节")
        self.stage1_fetch_btn.setEnabled(False)

        try:
            account = self.fanqie_account_manager.get_account(self._current_account_id)
            if not account:
                self._stop_loading_animation()
                self.stage1_status_label.setText("无法获取账号信息")
                self.stage1_fetch_btn.setEnabled(True)
                return

            # Use the worker to fetch chapters (reuses single browser instance)
            if self._fanqie_worker is None:
                chrome_path = self.settings.ai_settings.browser_chrome_path
                self._fanqie_worker = FanqieWorker(
                    chrome_path=chrome_path,
                    headless=False,
                    slow_mo=100
                )
                self._fanqie_worker.start()

            # Login via worker if not already logged in
            if not self._fanqie_worker.is_logged_in:
                self.logger.info(f"[publish] Logging in via worker for chapter fetch")
                success, result = self._fanqie_worker.submit_task(
                    FanqieTaskType.LOGIN,
                    {'phone': account.phone, 'password': account.password},
                    timeout=120
                )
                if not success:
                    self._stop_loading_animation()
                    self.stage1_status_label.setText(f"登录失败：{result}")
                    self.stage1_fetch_btn.setEnabled(True)
                    return

            # Get published chapters via worker
            success, result = self._fanqie_worker.submit_task(
                FanqieTaskType.GET_PUBLISHED_CHAPTERS,
                {'book_id': book_id},
                timeout=120
            )

            self._stop_loading_animation()

            if not success:
                self.stage1_status_label.setText(f"获取章节失败：{result}")
                self.stage1_fetch_btn.setEnabled(True)
                return

            # Extract chapters from result
            chapters = result.get('chapters', [])

            # Save to work_manager
            save_ok = self.work_manager.save_fanqie_chapters(self._current_work_id, chapters)
            if not save_ok:
                self.stage1_status_label.setText("保存章节失败")
                self.stage1_fetch_btn.setEnabled(True)
                return

            # Clean up local metadata for chapters that no longer exist on Fanqie
            # (user might have deleted them directly on Fanqie)
            fanqie_chapter_indices = set(ch.get('index') for ch in chapters)
            chapters_dir = os.path.join(self.work_manager.works_dir, self._current_work_id, "chapters")
            if os.path.exists(chapters_dir):
                for filename in os.listdir(chapters_dir):
                    if filename.startswith("chapter_") and filename.endswith(".json"):
                        file_path = os.path.join(chapters_dir, filename)
                        try:
                            with open(file_path, 'r', encoding='utf-8') as f:
                                metadata = json.load(f)
                            # Check if this chapter was published to Fanqie but no longer exists on the platform
                            chapter_index = metadata.get('index')
                            if chapter_index is not None and chapter_index not in fanqie_chapter_indices:
                                # Check if it was previously published (has item_id or published flag)
                                if metadata.get('item_id') or metadata.get('published'):
                                    os.remove(file_path)
                                    self.logger.info(f"[fanqie] Removed orphaned chapter metadata: {filename}")
                        except Exception as e:
                            self.logger.warning(f"[fanqie] Failed to check chapter metadata {filename}: {e}")

            self._fanqie_chapters_fetched = True
            self._fanqie_chapters = chapters

            # Update status
            self.stage1_status_label.setText(f"已获取 {len(chapters)} 个章节")
            # Hide fetch button since chapters are now fetched
            self.stage1_fetch_btn.setVisible(False)

            # Show sections 2 and 3
            self.stage2_group.setVisible(True)
            self.stage3_group.setVisible(True)

            # Update range status and reload local chapters to get latest published count
            self._update_strategy_range_status()
            self._load_local_chapters()

        except Exception as e:
            self._stop_loading_animation()
            self.logger.error(f"[publish] Failed to fetch fanqie chapters: {e}")
            self.stage1_status_label.setText(f"获取失败: {str(e)}")
            self.stage1_fetch_btn.setEnabled(True)

    def _start_create_book_flow(self) -> None:
        """Start the create book flow with loading animation."""
        # Update UI for creating book
        self._start_loading_animation(self.stage1_status_label, "正在创建新书")
        self.stage1_fetch_btn.setText("创建中...")
        self.stage1_fetch_btn.setEnabled(False)

        # Get work and validate
        work = self.work_manager.get_work(self._current_work_id)
        if not work:
            self._stop_loading_animation()
            self.stage1_status_label.setText("找不到选择的作品")
            self._reset_fetch_button()
            return

        # Validate metadata
        if not work.fanqie_category_tags or not work.fanqie_protagonist1:
            self._stop_loading_animation()
            self.stage1_status_label.setText("请先生成并保存作品信息")
            self._reset_fetch_button()
            return

        # Build metadata
        metadata = {
            "is_male": getattr(work, 'fanqie_is_male', True),
            "category_tags": getattr(work, 'fanqie_category_tags', []) or [],
            "theme_tags": getattr(work, 'fanqie_theme_tags', []) or [],
            "character_tags": getattr(work, 'fanqie_character_tags', []) or [],
            "plot_tags": getattr(work, 'fanqie_plot_tags', []) or [],
            "protagonist1": getattr(work, 'fanqie_protagonist1', ''),
            "protagonist2": getattr(work, 'fanqie_protagonist2', ''),
            "description": getattr(work, 'fanqie_description', '') or ""
        }

        # Run create book in background
        from PyQt6.QtCore import QThread
        self._create_book_thread = CreateBookThread(
            self.settings,
            self._current_account_id,
            self.fanqie_account_manager,
            work.title,
            metadata
        )
        self._create_book_thread.create_finished.connect(self._on_create_book_finished)
        self._create_book_thread.start()

    def _on_create_book_finished(self, success: bool, result: str) -> None:
        """Handle create book completion."""
        self._stop_loading_animation()

        if success:
            # Save book_id to work
            work = self.work_manager.get_work(self._current_work_id)
            if work:
                work.fanqie_book_id = result
                work.fanqie_book_title = work.title
                work.fanqie_account_id = self._current_account_id
                self.work_manager.update_work(work)

            self.stage1_status_label.setText(f"创建成功！Book ID: {result}")
            # Hide fetch button for new book (no chapters published yet)
            self.stage1_fetch_btn.setVisible(False)

            # Show sections 2 and 3
            self.stage2_group.setVisible(True)
            self.stage3_group.setVisible(True)

            # Set correct chapter range defaults (from fanqie_count+1 to local_count)
            # fanqie_count=0 for new book, so defaults will be 1 to local_count
            self._update_strategy_range_status()
        else:
            self.stage1_status_label.setText(f"创建失败: {result}")
            self._reset_fetch_button()

    def _reset_fetch_button(self) -> None:
        """Reset fetch button to normal state."""
        self.stage1_fetch_btn.setText("获取番茄已发布章节")
        self.stage1_fetch_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: #ffffff;
                border: none;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        self.stage1_fetch_btn.setEnabled(True)

    def _start_loading_animation(self, label: QLabel, base_text: str) -> None:
        """Start cycling loading animation on a label."""
        self._loading_animation_label = label
        self._loading_animation_base = base_text
        self._loading_animation_index = 0
        self._loading_animation_dots = 0
        self._loading_timer = QTimer()
        self._loading_timer.timeout.connect(self._update_loading_animation)
        self._loading_timer.start(500)  # Update every 500ms

    def _update_loading_animation(self) -> None:
        """Update loading animation frame."""
        if not hasattr(self, '_loading_timer') or not self._loading_timer:
            return
        self._loading_animation_dots = (self._loading_animation_dots + 1) % 4
        dots_str = "." * self._loading_animation_dots
        prefix = "*" if self._loading_animation_dots % 2 == 0 else "·"
        self._loading_animation_label.setText(f"{prefix}{self._loading_animation_base}{dots_str}")

    def _stop_loading_animation(self) -> None:
        """Stop loading animation."""
        if hasattr(self, '_loading_timer') and self._loading_timer:
            self._loading_timer.stop()
            self._loading_timer.deleteLater()
            self._loading_timer = None
            self.stage1_fetch_btn.setEnabled(True)

    def _display_fanqie_chapters(self, chapters: list) -> None:
        """Display fanqie chapters in stage1 list."""
        # Clear existing items
        while self.stage1_chapter_container_layout.count():
            child = self.stage1_chapter_container_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        # Add chapter items
        for chapter in chapters[:50]:  # Show first 50
            item = QLabel(f"第{chapter.get('index', '?')}章 - {chapter.get('title', '无标题')}")
            item.setStyleSheet("color: #34495e; font-size: 12px; padding: 2px 5px;")
            self.stage1_chapter_container_layout.addWidget(item)

        if len(chapters) > 50:
            more = QLabel(f"... 还有 {len(chapters) - 50} 个章节")
            more.setStyleSheet("color: #7f8c8d; font-size: 12px; padding: 2px 5px;")
            self.stage1_chapter_container_layout.addWidget(more)

        self.stage1_chapter_list.setVisible(True)
        self.stage1_fetch_btn.setEnabled(True)

    def _init_step5_button_state(self) -> None:
        """Initialize Step 5 button state based on whether book has been published."""
        if not self._current_work_id or not self.work_manager:
            return

        work = self.work_manager.get_work(self._current_work_id)
        book_id = getattr(work, 'fanqie_book_id', None) if work else None

        if not book_id:
            # No book_id means this book has never been published - show two buttons
            self.stage1_status_label.setText("该书未曾发布，可关联已有作品或创建新书")
            self.stage1_fetch_btn.setVisible(False)
            self.stage1_link_btn.setVisible(True)
            self.stage1_create_btn.setVisible(True)
            self.stage1_link_btn.setEnabled(True)
            self.stage1_create_btn.setEnabled(True)
        else:
            # Has book_id - check if local chapters metadata exists
            local_chapters_count = self._get_local_chapters_count()

            if local_chapters_count > 0:
                # Has local metadata - show it
                self.stage1_status_label.setText(f"本地已有 {local_chapters_count} 个已发布章节信息")
            else:
                # No local metadata
                self.stage1_status_label.setText("本地无已发布章节信息，点击下方按钮获取番茄已发布章节")

            self.stage1_fetch_btn.setVisible(True)
            self.stage1_fetch_btn.setText("更新元数据")
            self.stage1_fetch_btn.setStyleSheet("""
                QPushButton {
                    background-color: #3498db;
                    color: #ffffff;
                    border: none;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #2980b9;
                }
            """)
            self.stage1_fetch_btn.setEnabled(True)
            self.stage1_link_btn.setVisible(False)
            self.stage1_create_btn.setVisible(False)

    def _get_local_chapters_count(self) -> int:
        """Get the count of local chapter metadata files."""
        if not self._current_work_id or not self.work_manager:
            return 0

        try:
            work_dir = os.path.join(self.work_manager.works_dir, self._current_work_id)
            chapters_dir = os.path.join(work_dir, "chapters")

            if not os.path.exists(chapters_dir):
                return 0

            count = 0
            for filename in os.listdir(chapters_dir):
                if filename.startswith("chapter_") and filename.endswith(".json"):
                    count += 1
            return count
        except Exception:
            return 0

    def _load_local_chapters(self) -> None:
        """Load published chapters from local chapters directory when entering step 5.

        Reads chapter metadata from the chapters/ directory to get info about
        already published chapters, and sets the start chapter accordingly.
        End chapter is set from the publish directory's latest chapter.
        """
        if not self._current_work_id or not self.work_manager:
            return

        try:
            work_dir = os.path.join(self.work_manager.works_dir, self._current_work_id)
            chapters_dir = os.path.join(work_dir, "chapters")
            publish_dir = os.path.join(work_dir, "publish")

            # Find the highest published chapter index from chapters directory filename
            # Format: chapter_{index}.json
            max_published_chapter = 0
            if os.path.exists(chapters_dir):
                import re
                for filename in os.listdir(chapters_dir):
                    if filename.startswith("chapter_") and filename.endswith(".json"):
                        match = re.match(r"chapter_(\d+)\.json", filename)
                        if match:
                            num = int(match.group(1))
                            if num > max_published_chapter:
                                max_published_chapter = num

            # Find the highest chapter number in publish directory
            max_publish_chapter = 0
            if os.path.exists(publish_dir):
                import re
                for filename in os.listdir(publish_dir):
                    # Match patterns like "第123章 xxx.txt" or "第123章.txt"
                    match = re.match(r"第(\d+)章", filename)
                    if match:
                        num = int(match.group(1))
                        if num > max_publish_chapter:
                            max_publish_chapter = num

            self.logger.info(f"[publish] _load_local_chapters: max_published_chapter={max_published_chapter}, max_publish_chapter={max_publish_chapter}")

            # Set start chapter = max_published_chapter + 1 (next chapter to publish)
            start_chapter = max_published_chapter + 1
            # Set end chapter = max_publish_chapter (latest chapter ready to publish)
            end_chapter = max_publish_chapter

            self.stage2_start_input.setText(str(start_chapter))
            self.stage2_end_input.setText(str(end_chapter))

            # Show sections 2 and 3 now that we have local data
            self.stage2_group.setVisible(True)
            self.stage3_group.setVisible(True)

            # Update preview label
            self._update_strategy_range_preview()

            self.logger.info(f"[publish] _load_local_chapters: set start={start_chapter}, end={end_chapter}")

        except Exception as e:
            self.logger.error(f"[publish] _load_local_chapters failed: {e}")

    def _update_strategy_range_status(self) -> None:
        """Update stage 2 range status display."""
        # Get steps directory chapter count (local total chapters)
        steps_count = 0
        if self._current_work_id:
            work_dir = os.path.join(self.work_manager.works_dir, self._current_work_id)
            steps_dir = os.path.join(work_dir, "steps")
            if os.path.exists(steps_dir):
                chapter_files = [f for f in os.listdir(steps_dir) if f.startswith("chapter_") and f.endswith("_content.txt")]
                steps_count = len(chapter_files)
                self.logger.info(f"[publish] steps_count = {steps_count}")

        # Get converted count from Work model
        converted_count = 0
        if self._current_work_id:
            work = self.work_manager.get_work(self._current_work_id)
            if work:
                converted_count = getattr(work, 'steps_to_publish_converted_count', 0)
                self.logger.info(f"[publish] converted_count from Work model = {converted_count}")

        # Calculate pending
        pending_count = max(0, steps_count - converted_count)

        self.stage2_total_label.setText(f"本地总章节: {steps_count} 章")
        self.stage2_in_queue_label.setText(f"已进入发布队列: {converted_count} 章")
        self.stage2_pending_label.setText(f"待进入发布队列: {pending_count} 章")

        # Set default range: start from converted_count+1, end at steps_count
        self.stage2_start_input.setText(str(converted_count + 1))
        self.stage2_end_input.setText(str(steps_count))

        # Update next button state
        self._validate_current_step()

    def _on_strategy_range_changed(self) -> None:
        """Handle strategy range spinbox change."""
        self._update_strategy_range_preview()

    def _update_strategy_range_preview(self) -> None:
        """Update stage 2 range preview text."""
        try:
            start = int(self.stage2_start_input.text() or "0")
            end = int(self.stage2_end_input.text() or "0")
        except ValueError:
            return

        if end < start:
            self.stage2_preview_label.setText("结束章节不能小于开始章节")
            return

        self.stage2_preview_label.setText(f"待进入发布队列的章节：{start}-{end}章")

    def _on_publish_mode_changed(self) -> None:
        """Handle publish mode radio button change."""
        if self.timed_publish_radio.isChecked():
            self.timed_settings_widget.setVisible(True)
        else:
            self.timed_settings_widget.setVisible(False)
            self.schedule_table_widget.setVisible(False)

    def _on_generate_schedule(self) -> None:
        """Handle generate schedule button click."""
        import random
        from datetime import datetime, timedelta

        start_time = self.start_time_input.text().strip()
        end_time = self.end_time_input.text().strip()
        start_date = self.start_date_input.text().strip()
        daily_count = int(self.daily_count_input.text() or "0")

        if not start_time or not end_time or not start_date:
            QMessageBox.warning(self, "提示", "请填写开始时间、结束时间和开始日期")
            return

        # Parse times
        try:
            start_dt = datetime.strptime(start_time, "%H:%M")
            end_dt = datetime.strptime(end_time, "%H:%M")
        except ValueError:
            QMessageBox.warning(self, "提示", "时间格式错误，请使用 HH:MM 格式")
            return

        # Get chapters in range
        try:
            start_chapter = int(self.stage2_start_input.text() or "0")
            end_chapter = int(self.stage2_end_input.text() or "0")
        except ValueError:
            QMessageBox.warning(self, "提示", "请输入有效的章节数字")
            return
        total_chapters = end_chapter - start_chapter + 1

        # Generate schedule
        self.schedule_list_widget.clear()
        current_date = datetime.strptime(start_date, "%Y-%m-%d")
        self._generated_schedule = []

        # Calculate earliest publish time (must be at least 1 hour from now)
        now = datetime.now()
        min_publish_time = now + timedelta(hours=1)
        self.logger.info(f"[schedule] Current time: {now}, earliest publish time: {min_publish_time}")

        chapter_num = start_chapter

        while chapter_num <= end_chapter:
            # Today's time range
            today_start = datetime.combine(current_date.date(), start_dt.time())
            today_end = datetime.combine(current_date.date(), end_dt.time())
            tomorrow_start = datetime.combine(current_date.date() + timedelta(days=1), datetime.min.time())

            # Case 1: min_publish_time is after today_end -> skip today
            if min_publish_time >= today_end:
                current_date = current_date + timedelta(days=1)
                continue

            # Case 2 & 3: Calculate available time range
            if min_publish_time <= today_start:
                available_start = today_start
            else:
                # min_publish_time is between today_start and today_end
                available_start = min_publish_time

            available_end = min(today_end, tomorrow_start)

            # If no available time, skip today
            if available_start >= available_end:
                current_date = current_date + timedelta(days=1)
                continue

            # Convert to minutes from start of day
            avail_start_min = available_start.hour * 60 + available_start.minute
            avail_end_min = available_end.hour * 60 + available_end.minute

            # Calculate how many chapters to schedule today
            chapters_today = min(daily_count, total_chapters - (chapter_num - start_chapter))

            # Generate random times and sort them
            random_times = sorted([random.randint(avail_start_min, avail_end_min - 1) for _ in range(chapters_today)])

            for j in range(chapters_today):
                if chapter_num > end_chapter:
                    break
                random_minutes = random_times[j]
                publish_time = datetime.combine(
                    current_date.date(),
                    (datetime.min + timedelta(minutes=random_minutes)).time()
                )
                schedule_str = f"{publish_time.strftime('%Y-%m-%d %H:%M')} - 第{chapter_num}章"
                self.schedule_list_widget.addItem(schedule_str)
                self._generated_schedule.append(schedule_str)
                chapter_num += 1

            current_date = current_date + timedelta(days=1)

        self.schedule_table_widget.setVisible(True)

    def _on_platform_changed(self, platform: str) -> None:
        """Handle platform selection change."""
        self._current_platform = platform
        self.platform_changed.emit(platform)
        self.logger.info(f"Platform changed to: {platform}")

        # Update book info display based on new platform
        self._update_book_info_display()

        # Update next button state
        self._validate_current_step()

    def _on_work_changed(self, index: int) -> None:
        """Handle work selection change."""
        if index == 0:
            self._current_work_id = None
            self._current_work = None
            self._hide_book_info()
            return

        work_id = self.work_combo.itemData(index)
        self._current_work_id = work_id
        self.work_changed.emit(work_id)

        # Load work
        if self.work_manager:
            self._current_work = self.work_manager.get_work(work_id)

            # Auto-select the account that was used to create this book
            if self._current_platform == "番茄" and self._current_work:
                saved_account_id = getattr(self._current_work, 'fanqie_account_id', None)
                if saved_account_id:
                    self._select_account_in_list(saved_account_id)

        # Update chapter range based on selected work
        self._update_chapter_range(work_id)

        # Update book info display if platform is 番茄
        if self._current_platform == "番茄":
            self._update_book_info_display()

        # Update step 5 button state if on step 5
        if self._current_step == 5:
            self._init_step5_button_state()

        # Validate current step
        self._validate_current_step()

    def _update_chapter_range(self, work_id: str) -> None:
        """Update chapter range spin boxes based on work's chapter count."""
        if self.work_manager is None or not work_id:
            # Clear Stage 2 status labels
            self.stage2_total_label.setText("本地总章节: - 章")
            self.stage2_in_queue_label.setText("已进入发布队列: - 章")
            self.stage2_pending_label.setText("待进入发布队列: - 章")
            # Validate current step to update button state
            self._validate_current_step()
            return

        try:
            work = self.work_manager.get_work(work_id)

            # Read local total chapter count from steps directory in real-time
            steps_count = 0
            work_dir = os.path.join(self.work_manager.works_dir, work_id)
            steps_dir = os.path.join(work_dir, "steps")
            if os.path.exists(steps_dir):
                chapter_files = [f for f in os.listdir(steps_dir) if f.startswith("chapter_") and f.endswith("_content.txt")]
                steps_count = len(chapter_files)

            if steps_count > 0:
                self.end_chapter_input.setText(str(steps_count))

                # Read converted count from work metadata (defaults to 0 if not set)
                converted_count = getattr(work, 'steps_to_publish_converted_count', 0) if work else 0
                pending_count = max(0, steps_count - converted_count)

                self.stage2_total_label.setText(f"本地总章节: {steps_count} 章")
                self.stage2_in_queue_label.setText(f"已进入发布队列: {converted_count} 章")
                self.stage2_pending_label.setText(f"待进入发布队列: {pending_count} 章")

                # Load saved chapter split mode (with flag to prevent confirmation dialogs)
                if work:
                    self.logger.info(f"[publish] _update_chapter_range: work.fanqie_chapter_split_mode = {getattr(work, 'fanqie_chapter_split_mode', 'NOT_SET')}")
                    self._setting_radio_button = True
                    if hasattr(work, 'fanqie_chapter_split_mode') and work.fanqie_chapter_split_mode == "custom":
                        self.logger.info(f"[publish] _update_chapter_range: setting restructure_radio checked")
                        self.restructure_radio.setChecked(True)
                        if hasattr(work, 'fanqie_custom_words_per_chapter'):
                            self._updating_word_count = True
                            self.restructure_word_input.setText(str(work.fanqie_custom_words_per_chapter))
                            self._confirmed_word_count = work.fanqie_custom_words_per_chapter
                            self._updating_word_count = False
                    else:
                        self.logger.info(f"[publish] _update_chapter_range: setting original_radio checked")
                        self.original_radio.setChecked(True)
                    self._setting_radio_button = False

                # Update next button state after setting radio button
                self.logger.info(f"[publish] _update_chapter_range: calling _validate_current_step")
                self._validate_current_step()
            else:
                # Clear Stage 2 status labels when no chapters
                self.stage2_total_label.setText("本地总章节: 0 章")
                self.stage2_in_queue_label.setText("已进入发布队列: 0 章")
                self.stage2_pending_label.setText("待进入发布队列: 0 章")
                # Reset to original radio
                self._setting_radio_button = True
                self.original_radio.setChecked(True)
                self._setting_radio_button = False
                # Validate current step to update button state
                self._validate_current_step()
        except Exception as e:
            self.logger.error(f"Failed to update chapter range: {e}")

    def _hide_book_info(self) -> None:
        """Hide the book info group UI elements."""
        self.book_info_container.setVisible(False)
        self.book_info_prompt.setVisible(False)
        self.generate_meta_btn.setVisible(False)
        self.regenerate_meta_btn.setVisible(False)
        self.save_meta_btn.setVisible(False)
        self.book_info_scroll_area.setVisible(False)
        self.book_info_widget.setVisible(False)

    def _update_book_info_display(self) -> None:
        """Update book info display based on selected work and platform."""
        # Hide all first
        self._hide_book_info()

        # Only show book info container for 番茄 platform
        if self._current_platform != "番茄":
            self.book_info_container.setVisible(False)
            return

        # Need a work selected
        if not self._current_work_id or not self.work_manager:
            self.book_info_container.setVisible(False)
            return

        try:
            work = self.work_manager.get_work(self._current_work_id)
            if not work:
                self.book_info_container.setVisible(False)
                return

            self._current_work = work

            # Show the container
            self.book_info_container.setVisible(True)

            # Check if book metadata already exists (either fanqie_book_id or any metadata field)
            has_metadata = work.fanqie_book_id or work.fanqie_category_tags or work.fanqie_theme_tags or work.fanqie_character_tags or work.fanqie_plot_tags or work.fanqie_protagonist1
            if has_metadata:
                # Show existing book info - display the metadata table and allow save/regenerate
                self.book_info_prompt.setVisible(False)
                self.generate_meta_btn.setVisible(False)
                self.regenerate_meta_btn.setVisible(True)
                self.save_meta_btn.setVisible(True)
                self.book_info_scroll_area.setVisible(True)
                self.book_info_widget.setVisible(True)

                # Display book info in table format
                # Channel
                self.channel_male_radio.setChecked(work.fanqie_is_male)
                self.channel_female_radio.setChecked(not work.fanqie_is_male)

                # Clear all tag checkboxes first
                for cb in self.category_tags_cbs:
                    cb.setChecked(False)
                for cb in self.theme_tags_cbs:
                    cb.setChecked(False)
                for cb in self.character_tags_cbs:
                    cb.setChecked(False)
                for cb in self.plot_tags_cbs:
                    cb.setChecked(False)

                # Load and display saved tags from 4 separate fields
                for tag in work.fanqie_category_tags or []:
                    for cb in self.category_tags_cbs:
                        if cb.text() == tag:
                            cb.setChecked(True)
                            break
                for tag in work.fanqie_theme_tags or []:
                    for cb in self.theme_tags_cbs:
                        if cb.text() == tag:
                            cb.setChecked(True)
                            break
                for tag in work.fanqie_character_tags or []:
                    for cb in self.character_tags_cbs:
                        if cb.text() == tag:
                            cb.setChecked(True)
                            break
                for tag in work.fanqie_plot_tags or []:
                    for cb in self.plot_tags_cbs:
                        if cb.text() == tag:
                            cb.setChecked(True)
                            break

                # Load and display saved protagonists
                self.prot1_input.setText(work.fanqie_protagonist1 or "")
                self.prot2_input.setText(work.fanqie_protagonist2 or "")

                # Load description
                self.desc_input.setPlainText(work.fanqie_description or "")
            else:
                # No book metadata, show prompt and generate button only
                self.book_info_prompt.setVisible(True)
                self.book_info_prompt.setText("该作品尚未生成新书信息，请先生成")
                self.generate_meta_btn.setVisible(True)
                self.regenerate_meta_btn.setVisible(False)
                self.save_meta_btn.setVisible(False)
                self.book_info_scroll_area.setVisible(False)
                self.book_info_widget.setVisible(False)

        except Exception as e:
            self.logger.error(f"Failed to update book info display: {e}")

    def _on_generate_metadata(self) -> None:
        """Handle generate metadata button click."""
        if not self._current_work_id or not self.work_manager:
            QMessageBox.warning(self, "提示", "请先选择作品")
            return

        work = self.work_manager.get_work(self._current_work_id)
        if not work:
            QMessageBox.warning(self, "提示", "找不到选择的作品")
            return

        # Check if regenerating existing metadata
        is_regenerate = bool(work.fanqie_book_id or work.fanqie_category_tags or work.fanqie_theme_tags or work.fanqie_character_tags or work.fanqie_plot_tags or work.fanqie_protagonist1)

        # Show confirmation if regenerating
        if is_regenerate:
            reply = QMessageBox.question(
                self, "确认重新生成",
                "重新生成将覆盖现有的新书信息，确定要继续吗？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

        # Show loading state - hide all other UI elements
        self.book_info_prompt.setVisible(False)
        self.generate_meta_btn.setVisible(False)
        self.regenerate_meta_btn.setVisible(False)
        self.save_meta_btn.setVisible(False)
        self.book_info_scroll_area.setVisible(False)
        self.book_info_widget.setVisible(False)
        self.book_info_loading.setVisible(True)
        self.book_info_loading.setText("正在生成新书信息...")

        # Get work's basic settings content first
        try:
            basic_context = self._get_basic_settings_context(work.id)
        except Exception as e:
            self.logger.warning(f"[publish] Could not load basic settings context: {e}")
            basic_context = ""

        # Build prompt with settings context
        title = work.title or "未命名作品"
        category = work.category or ""
        description = work.creation_guide or f"这是一部{category}类型的小说，讲述精彩的故事。"

        prompt = f'''你是一个专业的番茄小说编辑。请根据以下作品设定，为在番茄小说平台创建新书生成元数据。

{basic_context if basic_context else f"【作品设定】\n类型：{category}\n简介：{description}"}

请根据以上作品设定，生成以下格式的JSON数据（必须是可以直接解析的JSON，不要包含其他文字）：

{{
    "is_male": true/false（true=男频，false=女频）,
    "category_tags": ["主分类标签"]（从标签库中选择1个主分类标签）,
    "theme_tags": ["主题标签1", "主题标签2"]（从标签库中选择1-2个主题标签）,
    "character_tags": ["角色标签1", "角色标签2"]（从标签库中选择1-2个角色标签）,
    "plot_tags": ["情节标签1", "情节标签2"]（从标签库中选择1-2个情节标签）,
    "protagonist1": "主角1名字（不超过5字）",
    "protagonist2": "主角2名字（不超过5字）",
    "description": "作品简介（50-500字，基于原简介扩写或改编）"
}}

注意：
1. 标签数量限制：
   - 主分类标签：必须恰好1个
   - 主题标签：1-2个
   - 角色标签：1-2个
   - 情节标签：1-2个
2. 标签必须从以下标签库中选择：
   主分类标签：西方奇幻、东方仙侠、科幻末世、男频衍生、都市高武、悬疑灵异、悬疑脑洞、抗战谍战、历史古代、历史脑洞、都市种田、都市脑洞、都市日常、玄幻脑洞、战神赘婿、动漫衍生、游戏体育、传统玄幻、都市修真
   主题标签：衍生、仕途、综影视、天灾、第一人人称、赛博朋克、第四天灾、规则怪谈、搞笑轻松、古代、悬疑、克苏鲁、都市异能、末日求生、灵气复苏、高武世界、异世大陆、东方玄幻、谍战、清朝、宋朝、断层、武将、国运、综漫、开局、架空、奇幻仙侠、都市、玄幻、历史、体育、武侠
   角色标签：多女主、赘婿、全能、大佬、大小姐、特工、游戏主播、神探、宫廷侯爵、皇帝、单女主、校花、无女主、女帝、特种兵、反派、神医、奶爸、学霸、天才、腹黑、扮猪吃虎
   情节标签：风水秘术、斩神衍生、十日衍生、西游衍生、公版衍生、红楼衍生、甄嬛衍生、如懿衍生、都市江湖、惊悚游戏、卡牌、山海经、捉鬼、剑修、废土、副本、黑科技、无脑爽、魂穿、高手下山、黑化、迪化、发家致富、无后宫、争霸、1v1、升级流、灵魂互换、科举、封神、四合院、电竞、双重生、乡村、同人、打脸、破案、囤物资、钓鱼、网游、奥特同人、求生、无敌、九叔、穿书、聊天群、大秦、龙珠、漫威神奇宝贝、海贼、火影、职场、明朝、家庭、三国、末世、直播、无限流、诸天万界、大唐、宠物、外卖、星际、美食、剑道、盗墓、灵异、鉴宝、系统、神豪、重生、穿越、二次元、海岛、娱乐圈、空间、推理、洪荒
3. is_male根据作品类型判断：玄幻、都市、科幻、武侠、历史、游戏等偏男性向选true，言情、偶像等偏女性向选false
4. description必须50-500字，不能有低俗暴力内容

直接输出JSON，不要有任何其他文字。注意：不要返回book_name，书名使用作品标题。'''

        # Use chat_service to generate metadata
        chat_service = ChatService.get_instance(
            phone_number=self.settings.ai_settings.browser_phone,
            password=self.settings.ai_settings.browser_password,
            chrome_path=self.settings.ai_settings.browser_chrome_path
        )

        def on_metadata_generated(task):
            self.logger.info(f"[publish] Metadata generation completed: {task.status}")
            # Emit signal to trigger result handling in main thread
            self.metadata_generated.emit(task.completion, is_regenerate)

        # Add task
        QApplication.processEvents()  # Force UI to update before blocking call
        chat_service.add_task(prompt, callback=on_metadata_generated)

    def _handle_metadata_generated_result(self, completion_text: str, is_regenerate: bool) -> None:
        """Handle metadata generation result - runs in main thread via signal."""
        if not completion_text:
            self.book_info_loading.setVisible(False)
            self.book_info_prompt.setVisible(True)
            self.book_info_prompt.setText("生成失败，请重试")
            if is_regenerate:
                self.regenerate_meta_btn.setVisible(True)
            else:
                self.generate_meta_btn.setVisible(True)
            QMessageBox.warning(self, "生成失败", "生成新书信息失败")
            return

        # Get work reference
        if not self._current_work_id or not self.work_manager:
            return
        work = self.work_manager.get_work(self._current_work_id)
        if not work:
            return

        # Process the generated metadata (parse JSON, validate, display)
        self._process_generated_metadata(completion_text, work, is_regenerate)

    def _process_generated_metadata(self, json_text: str, work, is_regenerate: bool = False) -> None:
        """Process generated metadata JSON and update display."""
        self.logger.info(f"[publish] Processing generated metadata: {json_text[:500]}...")

        # Parse JSON
        try:
            # Try to extract JSON from response (might have markdown code blocks)
            json_str = json_text.strip()
            if json_str.startswith("```"):
                # Remove markdown code block markers
                lines = json_str.split("\n")
                json_str = "\n".join(lines[1:-1])  # Remove first and last line

            metadata = json.loads(json_str)
        except json.JSONDecodeError as e:
            self.logger.error(f"[publish] Failed to parse JSON: {e}")
            # Try to extract JSON by finding braces
            try:
                start_idx = json_text.find("{")
                end_idx = json_text.rindex("}") + 1
                if start_idx >= 0 and end_idx > start_idx:
                    json_str = json_text[start_idx:end_idx]
                    metadata = json.loads(json_str)
                else:
                    raise
            except Exception:
                self.book_info_loading.setVisible(False)
                self.book_info_prompt.setVisible(True)
                self.book_info_prompt.setText("解析失败，请重试")
                if is_regenerate:
                    self.regenerate_meta_btn.setVisible(True)
                else:
                    self.generate_meta_btn.setVisible(True)
                QMessageBox.warning(self, "解析失败", f"无法解析生成的JSON：{e}")
                return

        # Validate required fields
        if not self._validate_book_metadata(metadata):
            self.book_info_loading.setVisible(False)
            self.book_info_prompt.setVisible(True)
            self.book_info_prompt.setText("验证失败，请重试")
            if is_regenerate:
                self.regenerate_meta_btn.setVisible(True)
            else:
                self.generate_meta_btn.setVisible(True)
            return

        # Directly update display (book creation happens only when user clicks publish)
        self._display_generated_metadata(metadata, work, is_regenerate)

    def _display_generated_metadata(self, metadata: Dict[str, Any], work, is_regenerate: bool = False) -> None:
        """Display generated metadata in the book info widget."""
        # Hide loading, prompt, and generate button
        self.book_info_loading.setVisible(False)
        self.book_info_prompt.setVisible(False)
        self.generate_meta_btn.setVisible(False)
        self.regenerate_meta_btn.setVisible(False)
        self.save_meta_btn.setVisible(True)

        # Show scroll area and widget
        self.book_info_scroll_area.setVisible(True)
        self.book_info_widget.setVisible(True)

        # Save metadata to work (but NOT account_id - that's set at publish time)
        work.fanqie_is_male = metadata.get("is_male", True)
        # Save 4 separate tag categories
        work.fanqie_category_tags = metadata.get("category_tags", [])
        work.fanqie_theme_tags = metadata.get("theme_tags", [])
        work.fanqie_character_tags = metadata.get("character_tags", [])
        work.fanqie_plot_tags = metadata.get("plot_tags", [])
        work.fanqie_protagonist1 = metadata.get("protagonist1", "")
        work.fanqie_protagonist2 = metadata.get("protagonist2", "")
        work.fanqie_description = metadata.get("description", "")
        self.work_manager.update_work(work)
        self.logger.info(f"[publish] Metadata saved to work {work.id}")

        # Update display with metadata
        is_male = metadata.get("is_male", True)
        self.channel_male_radio.setChecked(is_male)
        self.channel_female_radio.setChecked(not is_male)

        # Clear all tag checkboxes first
        for cb in self.category_tags_cbs:
            cb.setChecked(False)
        for cb in self.theme_tags_cbs:
            cb.setChecked(False)
        for cb in self.character_tags_cbs:
            cb.setChecked(False)
        for cb in self.plot_tags_cbs:
            cb.setChecked(False)

        # Set category tags
        for tag in metadata.get("category_tags", []):
            for cb in self.category_tags_cbs:
                if cb.text() == tag:
                    cb.setChecked(True)
                    break

        # Set theme tags
        for tag in metadata.get("theme_tags", []):
            for cb in self.theme_tags_cbs:
                if cb.text() == tag:
                    cb.setChecked(True)
                    break

        # Set character tags
        for tag in metadata.get("character_tags", []):
            for cb in self.character_tags_cbs:
                if cb.text() == tag:
                    cb.setChecked(True)
                    break

        # Set plot tags
        for tag in metadata.get("plot_tags", []):
            for cb in self.plot_tags_cbs:
                if cb.text() == tag:
                    cb.setChecked(True)
                    break

        # Set protagonists
        self.prot1_input.setText(metadata.get("protagonist1", ""))
        self.prot2_input.setText(metadata.get("protagonist2", ""))

        # Set description
        self.desc_input.setPlainText(metadata.get("description", ""))

        # Show regenerate button if regenerating
        if is_regenerate:
            self.regenerate_meta_btn.setVisible(True)

    def _validate_book_metadata(self, metadata: Dict[str, Any]) -> bool:
        """Validate book metadata format."""
        required_fields = ["is_male", "protagonist1", "protagonist2", "description"]

        for field in required_fields:
            if field not in metadata:
                self.logger.error(f"[publish] Missing required field: {field}")
                QMessageBox.warning(self, "验证失败", f"缺少必需字段：{field}")
                return False

        # Validate tag categories exist
        category_tags = metadata.get("category_tags", [])
        theme_tags = metadata.get("theme_tags", [])
        character_tags = metadata.get("character_tags", [])
        plot_tags = metadata.get("plot_tags", [])

        # At least some tags should be present
        total_tags = len(category_tags) + len(theme_tags) + len(character_tags) + len(plot_tags)
        if total_tags == 0:
            self.logger.error(f"[publish] No tags provided")
            QMessageBox.warning(self, "验证失败", "至少需要选择一个标签")
            return False

        # Validate description length
        desc = metadata.get("description", "")
        if len(desc) < 50 or len(desc) > 500:
            self.logger.error(f"[publish] Invalid description length: {len(desc)}")
            QMessageBox.warning(self, "验证失败", f"简介长度必须在50-500字之间，当前为{len(desc)}字")
            return False

        return True

    def _save_and_create_fanqie_book(self, metadata: Dict[str, Any], work) -> None:
        """Save metadata to work and create book on Fanqie."""
        # Get account credentials
        if not self._current_account_id or not self.fanqie_account_manager:
            QMessageBox.warning(self, "提示", "请先选择番茄账号")
            self.book_info_loading.setVisible(False)
            self.book_info_prompt.setVisible(True)
            self.book_info_prompt.setText("请先选择账号")
            self.generate_meta_btn.setVisible(True)
            self.regenerate_meta_btn.setVisible(True)
            return

        account = self.fanqie_account_manager.get_account(self._current_account_id)
        if not account:
            QMessageBox.warning(self, "提示", "找不到选择的账号")
            self.book_info_loading.setVisible(False)
            self.book_info_prompt.setVisible(True)
            self.book_info_prompt.setText("账号无效")
            self.generate_meta_btn.setVisible(True)
            self.regenerate_meta_btn.setVisible(True)
            return

        # Check Chrome installation
        chrome_path = self.settings.ai_settings.browser_chrome_path
        if not FanqieBookService.check_chrome_installed(chrome_path):
            QMessageBox.warning(self, "提示", "未找到 Chrome 浏览器，请确认已安装")
            self.book_info_loading.setVisible(False)
            self.book_info_prompt.setVisible(True)
            self.book_info_prompt.setText("Chrome 未安装")
            self.generate_meta_btn.setVisible(True)
            self.regenerate_meta_btn.setVisible(True)
            return

        # Update loading state
        self.book_info_loading.setText("正在创建新书...")

        # Create book service
        book_service = FanqieBookService(
            phone_number=account.phone,
            password=account.password,
            chrome_path=chrome_path,
            headless=False,
            slow_mo=100
        )

        try:
            # Connect and login
            if not book_service.connect():
                QMessageBox.warning(self, "登录失败", "无法登录番茄平台，请检查账号密码")
                self.book_info_loading.setVisible(False)
                self.book_info_prompt.setVisible(True)
                self.book_info_prompt.setText("登录失败")
                self.generate_meta_btn.setVisible(True)
                self.regenerate_meta_btn.setVisible(True)
                return

            # Create book
            # Combine all tag categories into single tags list
            all_tags = []
            all_tags.extend(metadata.get("category_tags", []))
            all_tags.extend(metadata.get("theme_tags", []))
            all_tags.extend(metadata.get("character_tags", []))
            all_tags.extend(metadata.get("plot_tags", []))
            success, result = book_service.create_book(
                book_name=work.title,
                is_male=metadata["is_male"],
                tags=all_tags,
                protagonist1=metadata["protagonist1"],
                protagonist2=metadata["protagonist2"],
                description=metadata["description"]
            )

            if not success:
                QMessageBox.warning(self, "创建失败", f"创建新书失败：{result}")
                self.book_info_loading.setVisible(False)
                self.book_info_prompt.setVisible(True)
                self.book_info_prompt.setText("创建失败")
                self.generate_meta_btn.setVisible(True)
                self.regenerate_meta_btn.setVisible(True)
                return

            # Save book_id and metadata to work
            book_id = result
            self.logger.info(f"[publish] Created book with ID: {book_id}")

            work.fanqie_book_id = book_id
            work.fanqie_book_title = work.title
            work.fanqie_is_male = metadata["is_male"]
            # Save 4 separate tag categories
            work.fanqie_category_tags = metadata.get("category_tags", [])
            work.fanqie_theme_tags = metadata.get("theme_tags", [])
            work.fanqie_character_tags = metadata.get("character_tags", [])
            work.fanqie_plot_tags = metadata.get("plot_tags", [])
            work.fanqie_protagonist1 = metadata["protagonist1"]
            work.fanqie_protagonist2 = metadata["protagonist2"]
            work.fanqie_description = metadata["description"]
            work.fanqie_account_id = self._current_account_id
            self.work_manager.update_work(work)

            # Update display
            self._update_book_info_display()

            QMessageBox.information(self, "创建成功", f"新书创建成功！\n书名：{work.title}")

        except Exception as e:
            self.logger.error(f"[publish] Create book error: {e}")
            QMessageBox.warning(self, "错误", f"创建新书时出错：{e}")
            self.book_info_loading.setVisible(False)
            self.book_info_prompt.setVisible(True)
            self.book_info_prompt.setText("创建出错")
            self.generate_meta_btn.setVisible(True)
            self.regenerate_meta_btn.setVisible(True)
        finally:
            book_service.close()

    def _on_save_metadata(self) -> None:
        """Handle save metadata button click - saves table inputs to work metadata."""
        if not self._current_work:
            QMessageBox.warning(self, "提示", "请先选择作品")
            return

        try:
            work = self._current_work

            # Save channel
            work.fanqie_is_male = self.channel_male_radio.isChecked()

            # Collect tags from checkbox lists
            work.fanqie_category_tags = [cb.text() for cb in self.category_tags_cbs if cb.isChecked()]
            work.fanqie_theme_tags = [cb.text() for cb in self.theme_tags_cbs if cb.isChecked()]
            work.fanqie_character_tags = [cb.text() for cb in self.character_tags_cbs if cb.isChecked()]
            work.fanqie_plot_tags = [cb.text() for cb in self.plot_tags_cbs if cb.isChecked()]

            # Save protagonists
            work.fanqie_protagonist1 = self.prot1_input.text().strip()
            work.fanqie_protagonist2 = self.prot2_input.text().strip()

            # Save description
            work.fanqie_description = self.desc_input.toPlainText().strip()

            # Validate description length
            if len(work.fanqie_description) < 50:
                QMessageBox.warning(self, "保存失败", "简介长度必须至少50字")
                return

            # Save to work manager
            self.work_manager.update_work(work)

            # Refresh work combo to show updated title (keep selection)
            saved_work_id = self._current_work_id
            self._load_works()
            # Restore selection
            if saved_work_id:
                index = self.work_combo.findData(saved_work_id)
                if index >= 0:
                    self.work_combo.setCurrentIndex(index)

            QMessageBox.information(self, "保存成功", "新书信息已保存")
            self.logger.info(f"[publish] Metadata saved for work {work.id}")

        except Exception as e:
            self.logger.error(f"[publish] Failed to save metadata: {e}")
            QMessageBox.warning(self, "保存失败", f"保存新书信息失败：{e}")


    def _on_inline_account_selection_changed(self) -> None:
        """Handle inline account list selection change."""
        if not hasattr(self, 'account_list'):
            return
        has_selection = len(self.account_list.selectedItems()) > 0
        self.edit_account_btn.setEnabled(has_selection)
        self.delete_account_btn.setEnabled(has_selection)

        # Update current account ID for step validation
        if has_selection:
            selected = self.account_list.selectedItems()[0]
            self._current_account_id = selected.data(Qt.ItemDataRole.UserRole)
        else:
            self._current_account_id = None

        self._validate_current_step()

    def _on_add_inline_account(self) -> None:
        """Handle add inline account button click."""
        self._editing_account_id = None
        self.phone_input.clear()
        self.password_input.clear()
        self.nickname_input.clear()
        self.account_form_widget.setVisible(True)
        self.cancel_account_form_btn.setVisible(True)
        self.save_account_form_btn.setVisible(True)
        self.add_account_btn.setEnabled(False)
        self.edit_account_btn.setEnabled(False)
        self.delete_account_btn.setEnabled(False)
        self.account_list.setEnabled(False)

    def _on_edit_inline_account(self) -> None:
        """Handle edit inline account button click."""
        if not hasattr(self, 'account_list'):
            return
        selected = self.account_list.selectedItems()
        if not selected:
            return

        account_id = selected[0].data(Qt.ItemDataRole.UserRole)
        account = self.fanqie_account_manager.get_account(account_id)
        if account:
            self._editing_account_id = account.id
            self.phone_input.setText(account.phone)
            self.password_input.setText(account.password)
            self.nickname_input.setText(account.nickname)
            self.account_form_widget.setVisible(True)
            self.cancel_account_form_btn.setVisible(True)
            self.save_account_form_btn.setVisible(True)
            self.add_account_btn.setEnabled(False)
            self.edit_account_btn.setEnabled(False)
            self.delete_account_btn.setEnabled(False)
            self.account_list.setEnabled(False)

    def _on_delete_inline_account(self) -> None:
        """Handle delete inline account button click."""
        if not hasattr(self, 'account_list'):
            return
        selected = self.account_list.selectedItems()
        if not selected:
            return

        account_id = selected[0].data(Qt.ItemDataRole.UserRole)
        account = self.fanqie_account_manager.get_account(account_id)
        if not account:
            return

        reply = QMessageBox.question(
            self,
            "确认删除",
            f"确定要删除账号 '{account.get_display_name()}' 吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            self.fanqie_account_manager.delete_account(account_id)
            self._refresh_account_list()
            self._refresh_account_list()

    def _on_cancel_inline_account_form(self) -> None:
        """Hide the inline account form and re-enable other controls."""
        self.account_form_widget.setVisible(False)
        self.cancel_account_form_btn.setVisible(False)
        self.save_account_form_btn.setVisible(False)
        self.add_account_btn.setEnabled(True)
        self.account_list.setEnabled(True)
        has_selection = len(self.account_list.selectedItems()) > 0
        self.edit_account_btn.setEnabled(has_selection)
        self.delete_account_btn.setEnabled(has_selection)

    def _on_save_inline_account_form(self) -> None:
        """Handle save inline account form button click."""
        phone = self.phone_input.text().strip()
        password = self.password_input.text().strip()
        nickname = self.nickname_input.text().strip()

        if not phone:
            QMessageBox.warning(self, "提示", "请输入手机号")
            return

        if not password:
            QMessageBox.warning(self, "提示", "请输入密码")
            return

        if hasattr(self, '_editing_account_id') and self._editing_account_id:
            # Update existing
            self.fanqie_account_manager.update_account(
                self._editing_account_id,
                phone=phone,
                password=password,
                nickname=nickname
            )
        else:
            # Add new
            self.fanqie_account_manager.add_account(phone, password, nickname)

        self._on_cancel_inline_account_form()
        self._refresh_account_list()
        self._refresh_account_list()

    def _on_original_toggled(self, checked: bool) -> None:
        """Handle original chapters option toggle."""
        self.logger.info(f"[publish] _on_original_toggled called, checked={checked}, _setting_radio_button={getattr(self, '_setting_radio_button', False)}")
        if not checked:
            return

        # Skip confirmation if programmatically setting radio button
        if getattr(self, '_setting_radio_button', False):
            self.word_input_widget.setVisible(False)
            self.restructure_hint.setVisible(False)
            self.restructure_progress.setVisible(False)
            self.start_restructure_btn.setVisible(False)
            return

        # Check if publish directory has files - if so, warn user
        if self._has_publish_files():
            msg = QMessageBox(self)
            msg.setWindowTitle("确认切换")
            msg.setText("切换章节划分方式将清空publish目录中的所有文件")
            msg.setInformativeText("确定要切换到按原始章节发布吗？")
            msg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            msg.setDefaultButton(QMessageBox.StandardButton.No)
            msg.setMinimumHeight(150)
            reply = msg.exec()
            if reply != QMessageBox.StandardButton.Yes:
                # User cancelled, switch back to restructure radio - use flag to prevent loop
                self._setting_radio_button = True
                self.restructure_radio.setChecked(True)
                self._setting_radio_button = False
                return
            # Clean publish directory
            self._clean_publish_directory()

        self.word_input_widget.setVisible(False)
        self.restructure_hint.setVisible(False)
        self.restructure_progress.setVisible(False)
        self.start_restructure_btn.setVisible(False)
        # Save split mode
        self._save_chapter_split_mode("original")
        self._validate_current_step()

    def _on_restructure_toggled(self, checked: bool) -> None:
        """Handle restructure option toggle."""
        self.logger.info(f"[publish] _on_restructure_toggled called, checked={checked}, _setting_radio_button={getattr(self, '_setting_radio_button', False)}")
        if not checked:
            return

        # Skip confirmation if programmatically setting radio button
        if getattr(self, '_setting_radio_button', False):
            self.word_input_widget.setVisible(True)
            self.restructure_hint.setVisible(True)
            self.start_restructure_btn.setVisible(True)
            self.start_restructure_btn.setText("重新划分章节")
            return

        # If no work selected yet, just setup UI without confirmation
        if not self._current_work_id:
            self.word_input_widget.setVisible(True)
            self.restructure_hint.setVisible(True)
            self.start_restructure_btn.setVisible(True)
            self.start_restructure_btn.setText("重新划分章节")
            return

        # Check if publish directory has files - if so, warn user
        if self._has_publish_files():
            msg = QMessageBox(self)
            msg.setWindowTitle("确认切换")
            msg.setText("切换章节划分方式将清空publish目录中的所有文件")
            msg.setInformativeText("确定要切换到按自定义字数重新划分章节吗？")
            msg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            msg.setDefaultButton(QMessageBox.StandardButton.No)
            msg.setMinimumHeight(150)
            reply = msg.exec()
            if reply != QMessageBox.StandardButton.Yes:
                # User cancelled, switch back to original radio - use flag to prevent loop
                self._setting_radio_button = True
                self.original_radio.setChecked(True)
                self._setting_radio_button = False
                return
            # Clean publish directory
            self._clean_publish_directory()

        self.word_input_widget.setVisible(True)
        self.restructure_hint.setVisible(True)
        self.start_restructure_btn.setVisible(True)
        self.start_restructure_btn.setText("重新划分章节")
        # Reset completion flag
        self._restructure_complete = False
        # Save split mode
        self._save_chapter_split_mode("custom")
        self._validate_current_step()

    def _has_publish_files(self) -> bool:
        """Check if publish directory has any files."""
        if not self._current_work_id or not self.work_manager:
            return False
        try:
            work_dir = os.path.join(self.work_manager.works_dir, self._current_work_id)
            publish_dir = os.path.join(work_dir, "publish")
            if os.path.exists(publish_dir):
                files = [f for f in os.listdir(publish_dir) if os.path.isfile(os.path.join(publish_dir, f))]
                self.logger.info(f"[publish] _has_publish_files: {len(files)} files found, returning {len(files) > 0}")
                return len(files) > 0
        except Exception:
            pass
        return False

    def _clean_publish_directory(self) -> None:
        """Clean all files in publish directory."""
        if not self._current_work_id or not self.work_manager:
            return
        try:
            work_dir = os.path.join(self.work_manager.works_dir, self._current_work_id)
            publish_dir = os.path.join(work_dir, "publish")
            if os.path.exists(publish_dir):
                for f in os.listdir(publish_dir):
                    file_path = os.path.join(publish_dir, f)
                    if os.path.isfile(file_path):
                        os.remove(file_path)
                self.logger.info(f"[publish] Cleaned publish directory")
        except Exception as e:
            self.logger.error(f"[publish] Failed to clean publish directory: {e}")

    def _save_chapter_split_mode(self, mode: str) -> None:
        """Save chapter split mode to work."""
        if not self._current_work or not self.work_manager:
            return
        try:
            self._current_work.fanqie_chapter_split_mode = mode
            if mode == "custom":
                self._current_work.fanqie_custom_words_per_chapter = int(self.restructure_word_input.text() or "0")
            self.work_manager.update_work(self._current_work)
            self.logger.info(f"[publish] Saved chapter split mode: {mode}")
        except Exception as e:
            self.logger.error(f"[publish] Failed to save chapter split mode: {e}")

    def _on_publish_all(self) -> None:
        """Handle publish all remaining chapters button click."""
        if self._current_work_id and self.work_manager:
            try:
                work = self.work_manager.get_work(self._current_work_id)
                if work:
                    self.end_chapter_input.setText(str(work.chapter_count))
            except Exception as e:
                self.logger.error(f"Failed to set publish all: {e}")

    def _on_start_restructure(self) -> None:
        """Handle start restructuring button click."""
        self.logger.info(f"[publish] _on_start_restructure called, _current_work_id={self._current_work_id}, _restructure_complete={getattr(self, '_restructure_complete', False)}, _title_gen_in_progress={getattr(self, '_title_gen_in_progress', False)}")
        # Check if can open directory directly (completed or in progress)
        if getattr(self, '_restructure_complete', False) or getattr(self, '_title_gen_in_progress', False):
            self.logger.info("[publish] Button clicked: opening publish directory")
            self._on_view_publish()
            return

        if not self._current_work_id or not self.work_manager:
            QMessageBox.warning(self, "提示", "请先选择作品")
            return

        work = self.work_manager.get_work(self._current_work_id)
        if not work:
            QMessageBox.warning(self, "提示", "找不到选择的作品")
            return

        target_words = int(self.restructure_word_input.text() or "0")

        # Show confirmation
        msg = QMessageBox(self)
        msg.setWindowTitle("确认重新划分")
        msg.setText(f"确定要重新划分所有章节吗？")
        msg.setInformativeText(f"每章目标字数：{target_words}字\n\n注意：已完成的章节会跳过，不会重新生成。")
        msg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        msg.setDefaultButton(QMessageBox.StandardButton.No)
        msg.setMinimumHeight(150)
        reply = msg.exec()

        if reply != QMessageBox.StandardButton.Yes:
            return

        # Change button to indicate it can open the directory during processing (keep enabled)
        self.start_restructure_btn.setText("查看新划分章节")

        # Show progress
        if self.restructure_progress:
            self.restructure_progress.setText("正在读取章节...")
            self.restructure_progress.setVisible(True)

        # Run in background thread
        import threading
        thread = threading.Thread(target=self._run_restructure, args=(work, target_words), daemon=True)
        thread.start()

    def _on_word_count_changed(self, value: str) -> None:
        """Handle word count line edit change."""
        # Convert to int - textChanged emits string
        try:
            value_int = int(value) if value else 0
        except ValueError:
            return

        confirmed = getattr(self, '_confirmed_word_count', 0)
        self.logger.info(f"[publish] _on_word_count_changed called, value={value_int}, _confirmed_word_count={confirmed}, _updating_word_count={getattr(self, '_updating_word_count', False)}, _current_work_id={self._current_work_id}")

        # Skip if this is a programmatic update (not from user interaction)
        if getattr(self, '_updating_word_count', False):
            return

        # Only show confirmation if there are existing files and value actually changed
        if self._has_publish_files() and value_int != confirmed:
            msg = QMessageBox(self)
            msg.setWindowTitle("确认重新划分")
            msg.setText("修改每章目标字数将清空publish目录并重新划分章节")
            msg.setInformativeText(f"新的每章目标字数：{value_int}字\n\n确定要重新划分吗？")
            msg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            msg.setDefaultButton(QMessageBox.StandardButton.No)
            msg.setMinimumHeight(150)
            reply = msg.exec()
            if reply != QMessageBox.StandardButton.Yes:
                # Reset to previous confirmed value
                self.restructure_word_input.setText(str(self._confirmed_word_count))
                return
            # User confirmed - clean publish directory and reset completion flag
            self._clean_publish_directory()
            self._restructure_complete = False
            self._confirmed_word_count = value_int
            self._validate_current_step()
            self.logger.info(f"[publish] Word count changed to {value_int}, reset completion")
        elif value_int != confirmed:
            # No files, just update confirmed value silently
            self._confirmed_word_count = value_int
            self.logger.info(f"[publish] Word count updated to {value_int} (no publish files)")

    def _run_restructure(self, work, target_words: int) -> None:
        """Run chapter restructuring in background thread."""
        try:
            import os
            import shutil
            from services.chat_service import ChatService, ChatTaskStatus

            # Get work directory
            work_dir = os.path.join(self.work_manager.works_dir, work.id)
            steps_dir = os.path.join(work_dir, "steps")
            publish_dir = os.path.join(work_dir, "publish")

            self.logger.info(f"[publish] Starting chapter restructure for {work.id}, target_words={target_words}")

            # Step 1: Read all chapters up to end_chapter and form full text
            if not os.path.exists(steps_dir):
                self.logger.error(f"[publish] Steps directory not found: {steps_dir}")
                self._schedule_restructure_error("章节目录不存在")
                return

            # Get all chapter files up to end_chapter
            all_step_files = sorted([f for f in os.listdir(steps_dir) if f.startswith("chapter_") and f.endswith("_content.txt")])

            if not all_step_files:
                self._schedule_restructure_error("没有找到章节文件")
                return

            # Get end chapter limit
            end_chapter = int(self.end_chapter_input.text() or "0")

            # Filter and read chapters up to end_chapter
            chapter_files = []
            for f in all_step_files:
                parts = f.replace("chapter_", "").replace("_content.txt", "").split("_")
                if len(parts) >= 2:
                    chap_num = int(parts[1])
                    if chap_num <= end_chapter:
                        chapter_files.append(f)

            if not chapter_files:
                self._schedule_restructure_error(f"没有找到第{end_chapter}章之前的章节文件")
                return

            # Read all content
            all_paragraphs = []
            for chapter_file in chapter_files:
                chapter_path = os.path.join(steps_dir, chapter_file)
                with open(chapter_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # Split by paragraph (empty line)
                    paragraphs = [p.strip() for p in content.split('\n') if p.strip()]
                    all_paragraphs.extend(paragraphs)

            self.logger.info(f"[publish] Read {len(all_paragraphs)} paragraphs from {len(chapter_files)} chapters, target_words={target_words}")

            # Step 2: Split into new chapters by concatenating paragraphs
            # Per spec: 一段一段拼接，当拼接完某一段后，字数超过了设置的每章目标字数，且该段落不以逗号/顿号/分号/冒号结尾，就算拼接好了一章
            excluded_endings = ('，', '、', '；', '：', ':')
            new_chapters = []
            current_chapter = []
            current_word_count = 0

            for para in all_paragraphs:
                para_len = len(para)
                # Check if we must add this paragraph (previous ended with excluded punctuation)
                must_add = current_chapter and current_chapter[-1].endswith(excluded_endings)

                if not must_add and current_word_count + para_len > target_words and current_chapter:
                    # Would exceed target and we have existing content
                    # Check if current chapter's last paragraph ends with excluded punctuation
                    if current_chapter[-1].endswith(excluded_endings):
                        # Must add this paragraph, don't split yet
                        current_chapter.append(para)
                        current_word_count += para_len
                    else:
                        # Save current chapter (without this new paragraph)
                        new_chapters.append('\n\n'.join(current_chapter))
                        current_chapter = [para]
                        current_word_count = para_len
                else:
                    # Add paragraph to current chapter
                    current_chapter.append(para)
                    current_word_count += para_len

            # Handle last chapter
            if current_chapter:
                if len(new_chapters) > 0 and current_word_count < target_words * 0.5:
                    new_chapters[-1] += '\n\n' + '\n\n'.join(current_chapter)
                else:
                    new_chapters.append('\n\n'.join(current_chapter))

            self.logger.info(f"[publish] Split into {len(new_chapters)} new chapters")

            # Step 3: Write to publish directory
            # Create publish directory if not exists
            if not os.path.exists(publish_dir):
                os.makedirs(publish_dir)

            # Get existing files
            existing_files = set(os.listdir(publish_dir)) if os.path.exists(publish_dir) else set()

            # Write new chapters without titles (skip only if "第x章 xxx.txt" with title already exists)
            chapter_paths = []
            skipped_count = 0
            for i, chapter_content in enumerate(new_chapters, 1):
                chapter_file = f"第{i}章"
                chapter_file_with_title_pattern = f"第{i}章 "
                chapter_path = os.path.join(publish_dir, f"{chapter_file}.txt")

                # Skip if file with title exists (e.g., "第1章 测灵石前的少年.txt")
                has_title = any(f.startswith(chapter_file_with_title_pattern) for f in existing_files)

                if has_title:
                    self.logger.info(f"[publish] Skipping chapter with title: {chapter_file}")
                    skipped_count += 1
                    continue

                with open(chapter_path, 'w', encoding='utf-8') as f:
                    f.write(chapter_content)
                chapter_paths.append(chapter_path)

            self.logger.info(f"[publish] Wrote {len(chapter_paths)} chapters to publish directory, skipped {skipped_count}")

            # Update progress after writing
            total_chapters = len(new_chapters)
            chapters_need_title = len(chapter_paths)
            if self.restructure_progress:
                if skipped_count > 0:
                    self.restructure_progress.setText(f"已完成章节划分，共 {total_chapters} 章，开始生成标题...")
                else:
                    self.restructure_progress.setText(f"已完成章节划分，共 {total_chapters} 章，开始生成标题...")
                self.restructure_progress.setVisible(True)

            # Step 4: Generate titles using chat service
            self.logger.info(f"[publish] About to call _generate_chapter_titles with {len(chapter_paths)} new chapters")
            self._generate_chapter_titles(chapter_paths, work, total_chapters)

        except Exception as e:
            self.logger.error(f"[publish] Restructure failed: {e}")
            self._schedule_restructure_error(f"重新划分失败：{str(e)}")

    def _generate_chapter_titles(self, chapter_paths: list, work, total_new: int) -> None:
        """Generate titles for chapters in publish directory - asynchronous version."""
        import re
        import os

        self.logger.info(f"[publish] _generate_chapter_titles called with chapter_paths count={len(chapter_paths)}, total_new={total_new}")

        # Find chapters without titles
        chapters_needing_titles = []
        for path in chapter_paths:
            filename = os.path.basename(path)
            # Check if it's just "第x章.txt" without title
            if re.match(r'^第\d+章\.txt$', filename):
                chapters_needing_titles.append(path)

        if not chapters_needing_titles:
            # All chapters already have titles or no new chapters to process
            self.logger.info(f"[publish] No chapters need titles, calling _schedule_restructure_complete")
            self._restructure_complete = True
            self._schedule_restructure_complete(total_new)
            return

        self.logger.info(f"[publish] Generating titles for {len(chapters_needing_titles)} chapters")

        # Get chat service
        from services.chat_service import ChatService
        chat_service = ChatService.get_instance(
            phone_number=self.settings.ai_settings.browser_phone,
            password=self.settings.ai_settings.browser_password,
            chrome_path=self.settings.ai_settings.browser_chrome_path
        )

        # Initialize progress tracking
        self._title_gen_completed = 0
        self._title_gen_total = len(chapters_needing_titles)
        self._title_gen_total_new = total_new
        self._title_gen_dot_count = 0
        self._title_gen_in_progress = True
        self._restructure_complete = False

        # Schedule progress update on main thread using singleShot loop
        self._schedule_progress_update()

        # Submit tasks with callbacks
        for path in chapters_needing_titles:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()

            prompt = f'''请为以下章节内容生成一个简短的标题（不超过20个字）：

{content}

直接输出标题，不要有任何其他文字。'''

            # Capture path for callback closure
            chapter_path = path

            def make_callback(cp):
                def on_task_done(task):
                    self._on_title_gen_task_done(task, cp)
                return on_task_done

            chat_service.add_task(prompt, callback=make_callback(chapter_path))

    def _schedule_progress_update(self) -> None:
        """Schedule the next progress update on the main thread."""
        if not getattr(self, '_title_gen_in_progress', False):
            return
        QTimer.singleShot(500, self._on_title_gen_timer_tick)

    def _on_title_gen_timer_tick(self) -> None:
        """Update animated dots every 0.5 seconds during title generation - runs in main thread."""
        if not getattr(self, '_title_gen_in_progress', False):
            return
        if self._title_gen_total > 0:
            # Cycle leading char: · -> * -> · -> ...
            self._title_gen_dot_count = (self._title_gen_dot_count % 3) + 1
            leading_char = "·" if self._title_gen_dot_count % 2 == 1 else "*"
            # Cycle trailing dots: . -> .. -> ...
            trailing_dots = "." * self._title_gen_dot_count
            self.restructure_progress.setText(f"{leading_char} 正在生成标题: {self._title_gen_completed}/{self._title_gen_total}{trailing_dots}")
            self.restructure_progress.setVisible(True)
        # Schedule next update
        self._schedule_progress_update()

    def _on_title_gen_progress(self, completed: int, total: int) -> None:
        """Handle progress update signal - runs in main thread."""
        self._update_restructure_progress(completed, total)

    def _on_title_gen_task_done(self, task, chapter_path: str, retry_count: int = 0) -> None:
        """Handle individual title generation task completion - called from consumer thread."""
        import re
        import os

        MAX_TITLE_LENGTH = 15
        MAX_RETRIES = 3

        if task.status.value == "completed":
            # Extract title
            title = task.completion.strip()
            title = re.sub(r'^["\'"\'"]+|["\'"\'"]+$', '', title)

            self.logger.info(f"[publish] Generated title for {os.path.basename(chapter_path)}: '{title}' (length={len(title)})")

            # Validate title length
            if len(title) > MAX_TITLE_LENGTH and retry_count < MAX_RETRIES:
                # Title too long, regenerate
                self.logger.warning(f"[publish] Title too long ({len(title)} > {MAX_TITLE_LENGTH}), regenerating (retry {retry_count + 1}/{MAX_RETRIES})")

                # Read chapter content again
                with open(chapter_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                # Modified prompt emphasizing shorter title
                prompt = f'''请为以下章节内容生成一个简短的标题（必须不超过15个字）：

{content}

直接输出标题，不要有任何其他文字。'''

                # Resubmit with retry
                def make_retry_callback(cp, retries):
                    def on_task_done(task):
                        self._on_title_gen_task_done(task, cp, retries)
                    return on_task_done

                from services.chat_service import ChatService
                chat_service = ChatService.get_instance(
                    phone_number=self.settings.ai_settings.browser_phone,
                    password=self.settings.ai_settings.browser_password,
                    chrome_path=self.settings.ai_settings.browser_chrome_path
                )
                chat_service.add_task(prompt, callback=make_retry_callback(chapter_path, retry_count + 1))
                return

            if len(title) > MAX_TITLE_LENGTH and retry_count >= MAX_RETRIES:
                self.logger.warning(f"[publish] Title still too long after {MAX_RETRIES} retries, using truncated title")
                title = title[:MAX_TITLE_LENGTH]

            # Rename the chapter file (file I/O is thread-safe)
            dir_path = os.path.dirname(chapter_path)
            old_name = os.path.basename(chapter_path)
            match = re.match(r'(第\d+章)', old_name)
            if match:
                new_name = f"{match.group(1)} {title}.txt"
                new_path = os.path.join(dir_path, new_name)
                try:
                    os.rename(chapter_path, new_path)
                    self.logger.info(f"[publish] Renamed: {old_name} -> {new_name}")
                except Exception as e:
                    self.logger.error(f"[publish] Rename failed: {e}")

        self._title_gen_completed += 1

        # Check if all done
        if self._title_gen_completed >= self._title_gen_total:
            self._title_gen_in_progress = False
            # Schedule completion on main thread
            self.title_gen_complete.emit(self._title_gen_total_new)

    def _on_title_gen_complete(self, total_chapters: int) -> None:
        """Handle title generation completion - runs in main thread."""
        self._title_gen_in_progress = False
        self._on_restructure_complete(total_chapters)

    def _schedule_restructure_complete(self, total_chapters: int) -> None:
        """Schedule completion callback on main thread."""
        self.logger.info(f"[publish] _schedule_restructure_complete called with {total_chapters}")
        # Use signal to ensure callback runs in main thread
        self.title_gen_complete.emit(total_chapters)

    def _schedule_restructure_error(self, error_msg: str) -> None:
        """Schedule error callback on main thread."""
        QTimer.singleShot(100, lambda: self._on_restructure_error(error_msg))

    def _update_restructure_progress(self, completed: int, total: int) -> None:
        """Update the progress display."""
        if self.restructure_progress:
            # Use animated dots to show progress
            dots = "." * ((completed % 3) + 1)
            self.restructure_progress.setText(f"正在生成标题: {completed}/{total}{dots}")
            self.restructure_progress.setVisible(True)

    def _on_restructure_complete(self, total_chapters: int) -> None:
        """Handle restructure completion."""
        self.logger.info(f"[publish] _on_restructure_complete called with {total_chapters}, _restructure_complete will be set to True")
        self._restructure_complete = True
        self._confirmed_word_count = int(self.restructure_word_input.text() or "0")

        # Save the converted count to Work model (end_chapter, not total_chapters)
        end_chapter = int(self.end_chapter_input.text() or "0")
        work = self.work_manager.get_work(self._current_work_id)
        if work:
            work.steps_to_publish_converted_count = end_chapter
            self.work_manager.update_work(work)
            self.logger.info(f"[publish] Saved steps_to_publish_converted_count = {end_chapter}")

        if self.start_restructure_btn:
            self.start_restructure_btn.setEnabled(True)
            self.start_restructure_btn.setText("查看新划分章节")

        if self.restructure_progress:
            self.restructure_progress.setText(f"已完成！共处理 {total_chapters} 章")

        if self.restructure_hint:
            self.restructure_hint.setVisible(False)

        # Update next button state
        self._validate_current_step()

    def _on_restructure_error(self, error_msg: str) -> None:
        """Handle restructure error."""
        self._restructure_complete = False
        if self.start_restructure_btn:
            self.start_restructure_btn.setEnabled(True)
            self.start_restructure_btn.setText("重新划分章节")

        if self.restructure_progress:
            self.restructure_progress.setVisible(False)

        if self.restructure_hint:
            self.restructure_hint.setVisible(True)

        QMessageBox.warning(self, "错误", error_msg)

    def _on_view_publish(self) -> None:
        """Open publish directory."""
        import os
        self.logger.info(f"[publish] _on_view_publish called, _current_work_id={self._current_work_id}, _restructure_complete={getattr(self, '_restructure_complete', False)}")

        # Validate work_id - must be non-empty string
        work_id = self._current_work_id
        if not work_id or not isinstance(work_id, str) or not work_id.strip():
            self.logger.warning("[publish] Cannot open publish dir: no work selected or invalid work_id")
            return

        # Validate works_dir is a valid absolute path
        works_dir = getattr(self.work_manager, 'works_dir', None)
        if not works_dir or not os.path.isabs(works_dir):
            self.logger.warning(f"[publish] Cannot open publish dir: invalid works_dir={works_dir}")
            return

        # Normalize path to fix mixed separators (e.g., D:/foo/bar\works -> D:\foo\bar\works)
        works_dir = os.path.normpath(works_dir)
        work_dir = os.path.join(works_dir, work_id)
        publish_dir = os.path.normpath(os.path.join(work_dir, "publish"))
        self.logger.info(f"[publish] Opening publish directory: {publish_dir}")
        if os.path.exists(publish_dir):
            os.startfile(publish_dir)
        else:
            self.logger.warning(f"[publish] Publish directory not found: {publish_dir}")

    def _on_create_book(self) -> None:
        """Handle create book button click - creates book on Fanqie platform."""
        # Validate platform selection
        if not self._current_platform:
            QMessageBox.warning(self, "提示", "请选择发布平台")
            return

        # Validate work selection
        if not self._current_work_id:
            QMessageBox.warning(self, "请选择作品", "请先选择要发布的作品")
            return

        # Validate account selection for fanqie platform
        if self._current_platform == "番茄" and not self._current_account_id:
            QMessageBox.warning(self, "提示", "请先选择番茄账号")
            return

        # Get work info
        work = self.work_manager.get_work(self._current_work_id)
        if not work:
            QMessageBox.warning(self, "提示", "找不到选择的作品")
            return

        # Ask user whether to create new book or associate existing
        msg = QMessageBox(self)
        msg.setWindowTitle("选择创建方式")
        msg.setText("请选择如何关联番茄小说作品：")
        msg.setInformativeText("")
        msg.setIcon(QMessageBox.Icon.Question)

        # Add custom buttons
        create_new_btn = msg.addButton("创建新作品", QMessageBox.ButtonRole.AcceptRole)
        associate_btn = msg.addButton("关联已有作品", QMessageBox.ButtonRole.AcceptRole)
        cancel_btn = msg.addButton("取消", QMessageBox.ButtonRole.RejectRole)
        msg.setDefaultButton(create_new_btn)

        msg.exec()

        if msg.clickedButton() == cancel_btn:
            return

        if msg.clickedButton() == associate_btn:
            # Show dialog to input book ID and name
            dialog = AssociateExistingBookDialog(self)
            if dialog.exec():
                book_id = dialog.book_id
                book_name = dialog.book_name
                self.logger.info(f"[publish] Associating existing book: id={book_id}, name={book_name}")
                # Save book_id to work
                work.fanqie_book_id = book_id
                work.fanqie_book_title = book_name
                self.work_manager.update_work(work)
                # Update UI
                self._update_summary()
                self._update_publish_buttons()
                QMessageBox.information(self, "成功", f"已关联作品：{book_name}")
            return

        # User chose to create new book
        # Check if metadata is complete
        if not work.fanqie_category_tags or not work.fanqie_protagonist1:
            QMessageBox.warning(self, "提示", "请先生成并保存作品信息")
            return

        # Build metadata dict for book creation
        metadata = {
            "is_male": work.fanqie_is_male,
            "category_tags": work.fanqie_category_tags or [],
            "theme_tags": work.fanqie_theme_tags or [],
            "character_tags": work.fanqie_character_tags or [],
            "plot_tags": work.fanqie_plot_tags or [],
            "protagonist1": work.fanqie_protagonist1,
            "protagonist2": work.fanqie_protagonist2 or "",
            "description": work.fanqie_description or ""
        }

        # Create book
        self._save_and_create_fanqie_book(metadata, work)

        # Update summary after creation
        self._update_summary()

    def _on_cancel(self) -> None:
        """Cancel and reset to step 1."""
        self._current_step = 1
        self._update_step_visibility()

    def _reset_publish_state(self) -> None:
        """Reset publishing state to allow re-publishing."""
        self._publishing_completed = False
        self._current_step = 1
        self.publish_btn.setText("发布章节")
        self._update_step_visibility()

    def _on_publish(self) -> None:
        """Handle publish button click."""
        # Check if this is "再次发布" (reset and start over)
        if getattr(self, '_publishing_completed', False):
            self._reset_publish_state()
            return

        # Validate platform selection
        if not self._current_platform:
            QMessageBox.warning(self, "提示", "请选择发布平台")
            return

        # Validate work selection
        if not self._current_work_id:
            QMessageBox.warning(self, "提示", "请选择要发布的作品")
            return

        # Validate account selection for fanqie platform
        if self._current_platform == "番茄" and not self._current_account_id:
            QMessageBox.warning(self, "提示", "请选择番茄账号")
            return

        # Get work info
        work = self.work_manager.get_work(self._current_work_id)
        if not work:
            QMessageBox.warning(self, "提示", "找不到选择的作品")
            return

        # Validate book exists for fanqie
        if self._current_platform == "番茄" and not work.fanqie_book_id:
            QMessageBox.warning(self, "提示", "请先创建书本")
            return

        # Get chapter range from step 5 strategy (对齐范围) - no defaults, must have values
        try:
            start_ch_str = self.stage2_start_input.text().strip()
            end_ch_str = self.stage2_end_input.text().strip()
            if not start_ch_str:
                QMessageBox.warning(self, "提示", "请输入发布起始章节")
                return
            if not end_ch_str:
                QMessageBox.warning(self, "提示", "请输入发布结束章节")
                return
            start_ch = int(start_ch_str)
            end_ch = int(end_ch_str)
        except ValueError:
            QMessageBox.warning(self, "提示", "请输入有效的章节数字")
            return

        if start_ch < 1 or end_ch < 1:
            QMessageBox.warning(self, "提示", "章节号必须大于0")
            return

        if start_ch > end_ch:
            QMessageBox.warning(self, "提示", "起始章节不能大于结束章节")
            return

        self.publish_clicked.emit()

        # Start publishing based on platform
        if self._current_platform == "番茄":
            self._publish_to_fanqie(work, start_ch, end_ch)
        else:
            QMessageBox.information(self, "提示", f"{self._current_platform}平台发布功能待实现")

    def _get_basic_settings_context(self, work_id: str) -> str:
        """Get basic settings context from steps directory."""
        try:
            work_dir = self.work_manager._get_work_dir(work_id)
            steps_dir = os.path.join(work_dir, "steps")

            # Look for all relevant setting files
            context_files = [
                "story_summary.txt",           # 故事梗概
                "book_title.txt",             # 书名
                "literary_style.txt",        # 文风
                "time_and_space_settings.txt", # 时空设定
                "character_design.txt",       # 人物设定
            ]

            context_parts = []
            for filename in context_files:
                filepath = os.path.join(steps_dir, filename)
                if os.path.exists(filepath):
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read().strip()
                        if content:
                            # Use readable name for display
                            display_name = filename.replace(".txt", "").replace("_", " ")
                            context_parts.append(f"【{display_name}】\n{content[:1000]}")

            return "\n\n".join(context_parts)
        except Exception as e:
            self.logger.warning(f"[publish] Error loading basic settings: {e}")
            return ""

    def _publish_to_fanqie(self, work, start_chapter: int, end_chapter: int) -> None:
        """Publish chapters to Fanqie platform using worker pattern."""
        if not self.fanqie_account_manager or not self._current_account_id:
            QMessageBox.warning(self, "提示", "请先选择番茄账号")
            return

        # Get account credentials
        account = self.fanqie_account_manager.get_account(self._current_account_id)
        if not account:
            QMessageBox.warning(self, "提示", "找不到选择的账号")
            return

        # Get work
        work = self.work_manager.get_work(self._current_work_id)
        if not work:
            QMessageBox.warning(self, "提示", "找不到选择的作品")
            return

        # Check Chrome installation
        chrome_path = self.settings.ai_settings.browser_chrome_path
        if not FanqiePublisher.check_chrome_installed(chrome_path):
            QMessageBox.warning(self, "提示", "未找到 Chrome 浏览器，请确认已安装")
            return

        # Disable publish button during publishing
        self.publish_btn.setEnabled(False)
        self.publish_btn.setText("发布中...")

        # Start worker if not running
        if self._fanqie_worker is None:
            self._fanqie_worker = FanqieWorker(
                chrome_path=chrome_path,
                headless=False,
                slow_mo=100
            )
            self._fanqie_worker.start()

        # Run publishing in background
        self._run_fanqie_publish_in_thread(work, start_chapter, end_chapter, account)

    def _run_fanqie_publish_in_thread(self, work, start_chapter: int, end_chapter: int, account) -> None:
        """Run the actual publishing logic in a background thread."""
        from PyQt6.QtCore import QObject, pyqtSlot

        class PublishSignals(QObject):
            progress = pyqtSignal(object)
            finished = pyqtSignal(bool, str)
            error = pyqtSignal(str)

        signals = PublishSignals()

        def publish_in_thread():
            try:
                worker = self._fanqie_worker
                if worker is None:
                    signals.error.emit("Worker not initialized")
                    return

                # Step 1: Login
                self.logger.info(f"[fanqie] Logging in with account {account.phone[:3]}****{account.phone[-4:]}")
                signals.progress.emit(PublishProgress(
                    current_chapter=0,
                    total_chapters=1,
                    status="login",
                    message="正在登录番茄平台..."
                ))

                success, result = worker.submit_task(
                    FanqieTaskType.LOGIN,
                    {'phone': account.phone, 'password': account.password},
                    timeout=60
                )

                if not success:
                    signals.error.emit(f"登录失败：{result}")
                    return

                # Step 2: Load local chapter metadata to determine update vs publish
                book_id = work.fanqie_book_id if work.fanqie_book_id else ""
                worker._current_book_id = book_id
                worker._current_book_name = work.title

                # Load existing chapters from local metadata (Step 5 already fetched and saved)
                existing_chapters = self.work_manager.load_all_chapter_metadata(work.id)
                self.logger.info(f"[fanqie] Loaded {len(existing_chapters)} existing chapters from local metadata")

                # Step 3: Publish chapters
                total = end_chapter - start_chapter + 1
                success_count = 0
                fail_count = 0

                # Check publish mode - timed or immediate
                is_timed_publish = self.timed_publish_radio.isChecked()
                schedule = getattr(self, '_generated_schedule', None) or []

                self.logger.info(f"[fanqie] Timed publish: {is_timed_publish}, schedule entries: {len(schedule)}, range: {start_chapter}-{end_chapter}")

                for i, chapter_num in enumerate(range(start_chapter, end_chapter + 1)):
                    # Get chapter content from publish directory
                    actual_chapter_num, chapter_title, chapter_content = self._get_chapter_content(work.id, chapter_num)
                    if not chapter_content:
                        self.logger.warning(f"[fanqie] Chapter {chapter_num} content not found, skipping")
                        fail_count += 1
                        continue

                    # Calculate scheduled time for this chapter
                    scheduled_time = None
                    if is_timed_publish and schedule:
                        # Parse scheduled time from schedule list
                        # Format: "YYYY-MM-DD HH:MM - 第X章"
                        from datetime import datetime
                        try:
                            schedule_idx = i  # Index matches chapter order
                            if schedule_idx < len(schedule):
                                schedule_str = schedule[schedule_idx]
                                # Extract datetime part: "2026-04-12 08:00"
                                dt_str = schedule_str.split(' ')[0] + ' ' + schedule_str.split(' ')[1]
                                scheduled_time = datetime.strptime(dt_str, '%Y-%m-%d %H:%M')
                                self.logger.info(f"[fanqie] Chapter {chapter_num} scheduled for {scheduled_time}")
                        except Exception as e:
                            self.logger.warning(f"[fanqie] Failed to parse schedule for chapter {chapter_num}: {e}")
                            scheduled_time = None

                    # Emit progress
                    status_msg = f"正在发布第 {chapter_num} 章: {chapter_title}"
                    if scheduled_time:
                        status_msg += f" [定时: {scheduled_time.strftime('%m-%d %H:%M')}]"
                    signals.progress.emit(PublishProgress(
                        current_chapter=i + 1,
                        total_chapters=total,
                        status="publishing",
                        message=status_msg
                    ))

                    # Check if this chapter already exists on platform (update) or is new (publish)
                    # Compare using the actual chapter number from filename
                    existing = next((ch for ch in existing_chapters if str(ch.get('index')) == str(actual_chapter_num)), None)

                    if existing:
                        # Update existing chapter
                        success, result = worker.submit_task(
                            FanqieTaskType.UPDATE_CHAPTER,
                            {
                                'chapter_id': existing.get('item_id', ''),
                                'chapter_number': actual_chapter_num,
                                'chapter_title': chapter_title,
                                'chapter_content': chapter_content,
                                'scheduled_time': scheduled_time
                            },
                            timeout=60
                        )
                    else:
                        # Publish new chapter
                        success, result = worker.submit_task(
                            FanqieTaskType.PUBLISH_CHAPTER,
                            {
                                'chapter_number': actual_chapter_num,
                                'chapter_title': chapter_title,
                                'chapter_content': chapter_content,
                                'scheduled_time': scheduled_time
                            },
                            timeout=60
                        )

                    if success:
                        success_count += 1
                        self.work_manager.update_last_published_chapter(work.id, chapter_num)

                        # Get item_id from API response (both publish and update return item_id)
                        item_id = result.get('item_id') if isinstance(result, dict) else None

                        # Ensure index is integer for consistent comparisons
                        chapter_index = int(actual_chapter_num) if str(actual_chapter_num).isdigit() else actual_chapter_num

                        chapter_metadata = {
                            'item_id': item_id,
                            'chapter_id': item_id,
                            'index': chapter_index,
                            'title': chapter_title,
                            'word_number': 0,
                            'article_status': 0,
                            'published': True
                        }
                        self.work_manager.save_chapter_metadata(work.id, chapter_index, chapter_metadata)
                        self.logger.info(f"[fanqie] Saved chapter metadata: chapter_{chapter_index}, item_id={item_id}")

                        # Update existing_chapters so subsequent chapters can be published
                        existing_chapters.append({
                            'item_id': item_id,
                            'chapter_id': item_id,
                            'index': chapter_index,
                            'title': chapter_title
                        })
                    else:
                        self.logger.warning(f"[fanqie] Chapter {chapter_num} failed: {result}")
                        fail_count += 1
                        # Stop publishing subsequent chapters if any chapter fails
                        signals.progress.emit(PublishProgress(
                            current_chapter=i + 1,
                            total_chapters=total,
                            status="error",
                            message=f"第 {chapter_num} 章发布失败，停止发布",
                            success=False
                        ))
                        signals.error.emit(f"第 {chapter_num} 章发布失败: {result}")
                        return

                # Emit completion
                signals.progress.emit(PublishProgress(
                    current_chapter=total,
                    total_chapters=total,
                    status="completed",
                    message=f"发布完成: 成功 {success_count}, 失败 {fail_count}",
                    success=(fail_count == 0)
                ))

                if fail_count == 0:
                    signals.finished.emit(True, f"成功发布 {success_count} 章到番茄小说")
                else:
                    signals.finished.emit(False, f"成功 {success_count} 章，失败 {fail_count} 章")

            except Exception as e:
                self.logger.error(f"[fanqie] Unexpected error: {e}")
                signals.error.emit(f"发生错误：{str(e)}")

        @pyqtSlot(object)
        def on_progress(progress):
            self.publish_progress.emit(progress)

        @pyqtSlot(bool, str)
        def on_finished(success, message):
            self.publish_btn.setEnabled(True)
            self.publish_btn.setText("发布章节")
            if success:
                self._publishing_completed = True
                self._update_step_visibility()
                QMessageBox.information(self, "发布成功", message)
            else:
                QMessageBox.warning(self, "发布完成", message)

        @pyqtSlot(str)
        def on_error(message):
            self.publish_btn.setEnabled(True)
            self.publish_btn.setText("发布章节")
            QMessageBox.warning(self, "发布失败", message)

        signals.progress.connect(on_progress)
        signals.finished.connect(on_finished)
        signals.error.connect(on_error)

        import threading
        thread = threading.Thread(target=publish_in_thread)
        thread.start()

    def _ensure_fanqie_worker(self) -> FanqieWorker:
        """Ensure Fanqie worker is running and logged in."""
        if self._fanqie_worker is None:
            chrome_path = self.settings.ai_settings.browser_chrome_path
            self._fanqie_worker = FanqieWorker(
                chrome_path=chrome_path,
                headless=False,
                slow_mo=100
            )
            self._fanqie_worker.start()
        return self._fanqie_worker

    def _close_fanqie_worker(self) -> None:
        """Close Fanqie worker and cleanup."""
        if self._fanqie_worker:
            self._fanqie_worker.stop()
            self._fanqie_worker = None

    def _get_chapter_content(self, work_id: str, chapter_num: int) -> tuple:
        """
        Get chapter title and content from publish directory.

        Args:
            work_id: Work ID
            chapter_num: Chapter number

        Returns:
            Tuple of (chapter_number, title, content), empty strings if not found
            - chapter_number: The actual chapter number from filename (may differ from input)
            - title: Chapter title extracted from filename
            - content: Chapter body text
        """
        import re
        try:
            # Get publish directory path
            work_dir = os.path.join(self.work_manager.works_dir, work_id)
            publish_dir = os.path.join(work_dir, "publish")

            if not os.path.exists(publish_dir):
                self.logger.error(f"[fanqie] Publish directory not found: {publish_dir}")
                return ("", "", "")

            # Find file matching "第{chapter_num}章 {title}.txt"
            pattern = rf'^第{chapter_num}章\s+(.+)\.txt$'
            chapter_files = [f for f in os.listdir(publish_dir) if f.startswith(f"第{chapter_num}章") and f.endswith(".txt")]

            if not chapter_files:
                self.logger.warning(f"[fanqie] No chapter file found for chapter {chapter_num} in {publish_dir}")
                return ("", "", "")

            filename = chapter_files[0]
            match = re.match(pattern, filename)
            if not match:
                self.logger.error(f"[fanqie] Failed to parse filename: {filename}")
                return ("", "", "")

            chapter_title = match.group(1).strip()

            # Read file content
            file_path = os.path.join(publish_dir, filename)
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            self.logger.info(f"[fanqie] Loaded chapter {chapter_num}: '{chapter_title}' ({len(content)} chars)")
            return (str(chapter_num), chapter_title, content)

        except Exception as e:
            self.logger.error(f"[fanqie] Failed to load chapter {chapter_num}: {e}")
            return ("", "", "")

    @property
    def current_platform(self) -> Optional[str]:
        """Get the currently selected platform."""
        return self._current_platform

    @property
    def current_work_id(self) -> Optional[str]:
        """Get the currently selected work ID."""
        return self._current_work_id

    @property
    def current_account_id(self) -> Optional[str]:
        """Get the currently selected account ID."""
        return self._current_account_id

    @property
    def start_chapter(self) -> int:
        """Get the start chapter number (always 1, since we publish from chapter 1)."""
        return 1

    @property
    def end_chapter(self) -> int:
        """Get the end chapter number."""
        return int(self.end_chapter_input.text() or "0")

    @property
    def use_original_chapters(self) -> bool:
        """Check if using original chapters."""
        return self.original_radio.isChecked()

    @property
    def target_word_count(self) -> int:
        """Get the target word count for restructuring."""
        return int(self.restructure_word_input.text() or "0")

    def set_work_manager(self, work_manager) -> None:
        """Set the work manager for loading works."""
        self.work_manager = work_manager
        self._load_works()

    def set_fanqie_account_manager(self, account_manager: FanqieAccountManager) -> None:
        """Set the fanqie account manager."""
        self.fanqie_account_manager = account_manager
        self._refresh_account_list()
