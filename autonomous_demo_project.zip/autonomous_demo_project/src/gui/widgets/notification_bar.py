"""
Notification bar widget for AI Writer application.

Displays status messages, progress updates, and notifications
at the bottom of the application.
"""
from PyQt6.QtWidgets import QWidget, QHBoxLayout, QLabel
from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QColor


class NotificationBar(QWidget):
    """
    Notification bar widget for displaying status messages.

    Supports different message types with appropriate colors:
    - Info: Blue
    - Success: Green
    - Warning: Orange
    - Error: Red

    Attributes:
        message_label: Label displaying the current message
    """

    # Color codes for different message types (WCAG AA compliant on #ecf0f1 background)
    # All colors selected to meet 4.5:1 contrast ratio minimum
    COLORS = {
        'info': '#1a5276',      # Darker blue (was #3498db)
        'success': '#145a32',   # Darker green (was #27ae60)
        'warning': '#9a5a00',   # Darker amber (was #f39c12)
        'error': '#a02010'      # Darker red (was #e74c3c)
    }

    def __init__(self, parent=None):
        """
        Initialize the notification bar.

        Args:
            parent: Parent widget
        """
        super().__init__(parent)
        self.setObjectName("notificationBar")
        self.setFixedHeight(35)
        self._setup_ui()
        self._setup_timer()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 5, 10, 5)

        self.message_label = QLabel("")
        self.message_label.setAlignment(
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
        )
        self.message_label.setObjectName("notificationMessage")
        layout.addWidget(self.message_label)

        layout.addStretch()

    def _setup_timer(self) -> None:
        """Set up auto-clear timer for temporary messages."""
        self._clear_timer = QTimer(self)
        self._clear_timer.setSingleShot(True)
        self._clear_timer.timeout.connect(self._clear_message)

    def _apply_styles(self) -> None:
        """Apply styles to the notification bar."""
        self.setStyleSheet("""
            #notificationBar {
                background-color: #ecf0f1;
                border-top: 1px solid #bdc3c7;
            }

            #notificationMessage {
                color: #2c3e50;
                font-size: 13px;
                padding: 5px;
            }
        """)

    def show_message(
        self,
        message: str,
        message_type: str = 'info',
        duration: int = 3000
    ) -> None:
        """
        Display a message in the notification bar.

        Args:
            message: Message text to display
            message_type: Type of message (info, success, warning, error)
            duration: Time in milliseconds before auto-clear (0 = persistent)
        """
        color = self.COLORS.get(message_type, self.COLORS['info'])

        self.message_label.setText(message)
        self.message_label.setStyleSheet(
            f"color: {color}; font-size: 13px; padding: 5px;"
        )

        # Stop any existing timer
        self._clear_timer.stop()

        # Start new timer if duration specified
        if duration > 0:
            self._clear_timer.start(duration)

    def show_info(self, message: str, duration: int = 3000) -> None:
        """Show an info message."""
        self.show_message(message, 'info', duration)

    def show_success(self, message: str, duration: int = 3000) -> None:
        """Show a success message."""
        self.show_message(message, 'success', duration)

    def show_warning(self, message: str, duration: int = 5000) -> None:
        """Show a warning message."""
        self.show_message(message, 'warning', duration)

    def show_error(self, message: str, duration: int = 0) -> None:
        """Show an error message (persistent until cleared)."""
        self.show_message(message, 'error', duration)

    def clear(self) -> None:
        """Clear the current message."""
        self._clear_message()

    def _clear_message(self) -> None:
        """Internal method to clear the message."""
        self.message_label.setText("")
        self.message_label.setStyleSheet(
            "color: #2c3e50; font-size: 13px; padding: 5px;"
        )

    def show_progress(self, step: str, word_count: int = 0) -> None:
        """
        Show AI generation progress.

        Args:
            step: Current generation step name
            word_count: Current word count
        """
        message = f"正在生成：{step}"
        if word_count > 0:
            message += f" (当前字数：{word_count})"
        self.show_message(message, 'info', 0)  # Persistent during generation
