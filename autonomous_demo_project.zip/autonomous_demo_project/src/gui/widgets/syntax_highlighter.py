"""
Syntax highlighter for template editor.

Provides syntax highlighting for template placeholders.
"""
from PyQt6.QtGui import QSyntaxHighlighter, QTextCharFormat, QColor, QFont
from PyQt6.QtCore import QRegularExpression
import re


class TemplateSyntaxHighlighter(QSyntaxHighlighter):
    """
    Syntax highlighter for template placeholders.

    Highlights:
    - Valid placeholders: {placeholder_name} in blue
    - Invalid placeholders: {invalid_name} in red
    - Placeholder braces: in gray
    """

    def __init__(self, document, available_placeholders=None):
        """
        Initialize syntax highlighter.

        Args:
            document: QTextDocument to highlight
            available_placeholders: Dict of valid placeholder names
        """
        super().__init__(document)
        self.available_placeholders = available_placeholders or {}

        # Define formats
        self.valid_placeholder_format = QTextCharFormat()
        self.valid_placeholder_format.setForeground(QColor("#27ae60"))  # Green
        self.valid_placeholder_format.setBackground(QColor("#e8f8f0"))  # Light green background
        self.valid_placeholder_format.setFontWeight(QFont.Weight.Bold)

        self.invalid_placeholder_format = QTextCharFormat()
        self.invalid_placeholder_format.setForeground(QColor("#e74c3c"))  # Red
        self.invalid_placeholder_format.setBackground(QColor("#fceceb"))  # Light red background
        self.invalid_placeholder_format.setFontWeight(QFont.Weight.Bold)

        self.brace_format = QTextCharFormat()
        self.brace_format.setForeground(QColor("#7f8c8d"))  # Gray
        self.brace_format.setFontWeight(QFont.Weight.Bold)

        # Placeholder pattern
        self.placeholder_pattern = QRegularExpression(r'\{(\w+)\}')

    def set_available_placeholders(self, placeholders: dict) -> None:
        """
        Update available placeholders.

        Args:
            placeholders: Dict of valid placeholder names
        """
        self.available_placeholders = placeholders
        self.rehighlight()

    def highlightBlock(self, text: str) -> None:
        """
        Highlight a block of text.

        Args:
            text: Text to highlight
        """
        # Find all placeholders using regex
        pattern = r'\{(\w+)\}'
        for match in re.finditer(pattern, text):
            placeholder_name = match.group(1)
            start = match.start()
            end = match.end()

            # Check if placeholder is valid
            if placeholder_name in self.available_placeholders:
                fmt = self.valid_placeholder_format
            else:
                fmt = self.invalid_placeholder_format

            # Apply format to entire placeholder including braces
            self.setFormat(start, end - start, fmt)
