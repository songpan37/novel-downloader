"""
Loading Spinner widget for AI Writer application.

Provides a visual loading indicator with spinning animation
for document load operations and other async tasks.
"""
from PyQt6.QtWidgets import QWidget, QLabel, QVBoxLayout
from PyQt6.QtCore import QPropertyAnimation, QEasingCurve, pyqtProperty, Qt
from PyQt6.QtGui import QPainter, QColor, QPen, QBrush


class LoadingSpinner(QWidget):
    """
    A circular loading spinner widget with rotation animation.

    Displays a spinning circle animation to indicate loading state.
    Can be overlaid on other widgets or used inline.
    """

    def __init__(self, parent=None, size=48, color="#3498db"):
        """
        Initialize loading spinner.

        Args:
            parent: Parent widget
            size: Spinner diameter in pixels
            color: Spinner color (hex string or QColor)
        """
        super().__init__(parent)
        self._rotation_angle = 0
        self._spinner_size = size
        self._spinner_color = QColor(color) if isinstance(color, str) else color
        self._is_spinning = False

        # Set up widget properties
        self.setObjectName("loadingSpinner")
        self.setFixedSize(size, size)

        # Set up rotation animation
        self._setup_animation()

    def _setup_animation(self) -> None:
        """Set up the rotation animation."""
        self._rotation_animation = QPropertyAnimation(self, b"rotationAngle")
        self._rotation_animation.setDuration(1000)  # 1 second per full rotation
        self._rotation_animation.setStartValue(0)
        self._rotation_animation.setEndValue(360 * 8)  # 8 full rotations
        self._rotation_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)
        self._rotation_animation.setLoopCount(-1)  # Infinite loop

    @pyqtProperty(int)
    def rotationAngle(self) -> int:
        """Get current rotation angle."""
        return self._rotation_angle

    @rotationAngle.setter
    def rotationAngle(self, angle: int) -> None:
        """
        Set rotation angle and trigger repaint.

        Args:
            angle: Rotation angle in degrees
        """
        self._rotation_angle = angle % 360
        self.update()

    def start_spinning(self) -> None:
        """Start the spinning animation."""
        if not self._is_spinning:
            self._is_spinning = True
            self._rotation_animation.start()
            self.show()

    def stop_spinning(self) -> None:
        """Stop the spinning animation."""
        if self._is_spinning:
            self._is_spinning = False
            self._rotation_animation.stop()
            self._rotation_angle = 0
            self.update()
            self.hide()

    def is_spinning(self) -> bool:
        """Check if spinner is currently animating."""
        return self._is_spinning

    def paintEvent(self, event) -> None:
        """
        Paint the spinner.

        Args:
            event: Paint event
        """
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Calculate center and radius
        center_x = self.width() // 2
        center_y = self.height() // 2
        radius = min(center_x, center_y) - 4

        # Draw the spinner arc
        pen = QPen(self._spinner_color, 4, Qt.PenStyle.SolidLine)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)

        # Draw arc with gap
        span_angle = 270 * 16  # 270 degrees arc (in 1/16th of degrees)
        start_angle = self._rotation_angle * 16  # Convert to 1/16th of degrees

        painter.drawArc(
            center_x - radius,
            center_y - radius,
            radius * 2,
            radius * 2,
            start_angle,
            span_angle
        )

        painter.end()


class LoadingOverlay(QWidget):
    """
    A semi-transparent overlay with centered loading spinner.

    Can be shown over any widget to indicate loading state.
    Blocks interaction with underlying widget while visible.
    """

    def __init__(self, parent=None, message="加载中..."):
        """
        Initialize loading overlay.

        Args:
            parent: Parent widget to overlay
            message: Loading message to display
        """
        super().__init__(parent)
        self._message = message
        self._is_visible = False

        # Set up widget properties
        self.setObjectName("loadingOverlay")
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, False)

        # Set up layout
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Create spinner
        self.spinner = LoadingSpinner(size=64)
        layout.addWidget(self.spinner, alignment=Qt.AlignmentFlag.AlignCenter)

        # Create message label
        self.message_label = QLabel(message)
        self.message_label.setObjectName("loadingMessage")
        self.message_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.message_label, alignment=Qt.AlignmentFlag.AlignCenter)

        # Apply styles
        self._apply_styles()

        # Initially hide
        self.hide()

    def _apply_styles(self) -> None:
        """Apply styles to the overlay."""
        self.setStyleSheet("""
            #loadingOverlay {
                background-color: rgba(255, 255, 255, 200);
            }

            #loadingMessage {
                font-size: 14px;
                color: #555555;
                margin-top: 16px;
                background-color: transparent;
            }
        """)

    def show_overlay(self, message: str = None) -> None:
        """
        Show the loading overlay.

        Args:
            message: Optional new message to display
        """
        if message:
            self._message = message
            self.message_label.setText(message)

        self._is_visible = True
        self.spinner.start_spinning()
        self.show()
        self.raise_()  # Bring to front

    def hide_overlay(self) -> None:
        """Hide the loading overlay."""
        self._is_visible = False
        self.spinner.stop_spinning()
        self.hide()

    def is_visible(self) -> bool:
        """Check if overlay is currently visible."""
        return self._is_visible

    def resizeEvent(self, event) -> None:
        """
        Handle resize event to match parent size.

        Args:
            event: Resize event
        """
        if self.parent():
            self.setGeometry(self.parent().rect())
        super().resizeEvent(event)

    def paintEvent(self, event) -> None:
        """
        Paint the overlay background.

        Args:
            event: Paint event
        """
        from PyQt6.QtGui import QPainter, QColor, QBrush

        painter = QPainter(self)
        painter.fillRect(
            self.rect(),
            QBrush(QColor(255, 255, 255, 200))
        )
        painter.end()
