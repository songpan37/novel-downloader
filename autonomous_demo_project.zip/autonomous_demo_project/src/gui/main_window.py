"""
Main window for AI Writer application.

Provides the primary application window with navigation menu,
content area, and notification bar.
"""
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QStackedWidget, QListWidget, QListWidgetItem,
    QLabel, QGraphicsOpacityEffect, QMenuBar, QMenu
)
from PyQt6.QtCore import Qt, pyqtSignal, QSize, QPropertyAnimation, QEasingCurve, QUrl
from PyQt6.QtGui import QPalette, QColor, QIcon, QKeySequence, QDesktopServices, QAction
from typing import Optional, Dict, Any
from pathlib import Path
import os

from config.settings import Settings
from core.work_manager import WorkManager
from services.template_service import TemplateService
from services.ai_service import AIService, get_ai_service
from gui.views.workspace_view import WorkspaceView
from gui.views.creation_view import CreationView
from utils.logger import setup_logger, get_logger
from gui.views.publishing_view import PublishingView
from gui.views.template_view import TemplateView
from gui.views.settings_view import SettingsView
from gui.views.work_detail_view import WorkDetailView
from gui.widgets.notification_bar import NotificationBar
from gui.dialogs.new_work_wizard import NewWorkWizard
from gui.dialogs.import_dialog import ImportWorkDialog
from gui.dialogs.about_dialog import AboutDialog
from gui.dialogs.template_edit_dialog import TemplateEditDialog
from gui.dialogs.regenerate_dialog import RegenerateDialog
from gui.session_executor import SessionExecutor


class MainWindow(QMainWindow):
    """
    Main application window for AI Writer.

    Features a left navigation menu, central content area,
    and bottom notification bar.

    Signals:
        page_changed: Emitted when navigation page changes (index)
    """

    page_changed = pyqtSignal(int)

    # Navigation item labels and icon mappings
    NAV_ITEMS = [
        ("作品库", "workspace"),
        ("正在创作", "creating"),
        ("发布中心", "publishing"),
        ("提示词模板", "template"),
        ("设置", "settings")
    ]

    # Icon paths for navigation items (consistent style: 24x24, 2px stroke, #ecf0f1 color)
    NAV_ICONS = {
        "workspace": "icon_workspace.svg",
        "creating": "icon_creating.svg",
        "publishing": "icon_publishing.svg",
        "template": "icon_template.svg",
        "settings": "icon_settings.svg"
    }

    def __init__(self, settings: Settings, parent=None):
        """
        Initialize the main window.

        Args:
            settings: Application settings instance
            parent: Parent widget
        """
        super().__init__(parent)
        self.settings = settings
        self.current_index = 0
        # Setup logger if not already setup, then get it
        self.logger = setup_logger() or get_logger()
        self._transition_animating = False

        # Track currently creating work with state (cleared on app restart)
        # State: None | {"work_id": str, "work_data": dict, "state": "in_progress" | "paused"}
        self.creating_work_id: Optional[str] = None
        self.creating_work_data: Optional[Dict[str, Any]] = None
        self.creating_work_state: str = "not_started"  # "not_started", "in_progress", "paused"

        # Shared browser AI service instance (persists across works)
        self._persistent_browser_service = None

        # Initialize session executor
        self.session_executor = SessionExecutor(self)

        # Initialize work manager
        self.work_manager = WorkManager(self.settings)

        # Initialize fanqie account manager
        from services.fanqie_account_manager import FanqieAccountManager
        self.fanqie_account_manager = FanqieAccountManager(self.settings.storage_root)

        # Initialize template service
        self.template_service = TemplateService(self.settings.templates_dir)

        self._setup_ui()
        self._setup_menu_bar()
        self._setup_navigation()
        self._setup_connections()
        self._apply_styles()
        self._setup_transition_animation()

        # Load works after UI is set up
        self._load_works()

    def _clear_creating_work(self) -> None:
        """Clear the creating work state and update all views."""
        self.creating_work_id = None
        self.creating_work_data = None
        self.creating_work_state = "not_started"
        # Update views
        if hasattr(self, 'workspace_view'):
            self.workspace_view.update_creating_work(None)
        if hasattr(self, 'work_detail_view'):
            self.work_detail_view.update_creating_work(None, "not_started")
        self.logger.info("[CREATION] Creating work state cleared")

    def _update_creating_work_views(self) -> None:
        """Update all views to reflect current creating work state."""
        # Update workspace view (for badge display)
        if hasattr(self, 'workspace_view'):
            self.workspace_view.update_creating_work(self.creating_work_id)
            # Reload works to refresh badges
            self._load_works()
        # Update work detail view (for button state)
        if hasattr(self, 'work_detail_view'):
            self.work_detail_view.update_creating_work(self.creating_work_id, self.creating_work_state)
        self.logger.info(f"[CREATION] Views updated: creating_work_id={self.creating_work_id}, state={self.creating_work_state}")

    def _setup_ui(self) -> None:
        """Set up the basic UI structure."""
        self.setWindowTitle("AI Writer - AI 小说创作助手")
        self.setMinimumSize(900, 650)
        self.resize(1100, 750)

        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Main layout
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Content container (navigation + main area)
        content_container = QWidget()
        content_layout = QHBoxLayout(content_container)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        # Navigation panel
        self._setup_navigation_panel(content_layout)

        # Main content area
        self._setup_content_area(content_layout)

        main_layout.addWidget(content_container)

        # Notification bar
        self.notification_bar = NotificationBar()
        main_layout.addWidget(self.notification_bar)

    def _setup_menu_bar(self) -> None:
        """
        Set up the menu bar with Help menu.

        Creates a menu bar with Help menu containing About action.
        """
        # Create menu bar
        self.menu_bar = self.menuBar()
        self.menu_bar.setObjectName("menuBar")

        # Create Help menu
        help_menu = self.menu_bar.addMenu("帮助 (&H)")
        help_menu.setObjectName("helpMenu")

        # Help Documentation action
        help_doc_action = QAction("帮助文档 (&D)", self)
        help_doc_action.setShortcut("F2")
        help_doc_action.setStatusTip("查看用户文档和键盘快捷键")
        help_doc_action.triggered.connect(self._show_help_dialog)
        help_menu.addAction(help_doc_action)

        # About action
        about_action = QAction("关于 AI Writer (&A)", self)
        about_action.setShortcut("F1")
        about_action.setStatusTip("显示应用程序信息")
        about_action.triggered.connect(self._show_about_dialog)
        help_menu.addAction(about_action)

        # Add separator
        help_menu.addSeparator()

        # Check for Updates action (placeholder for future implementation)
        update_action = QAction("检查更新 (&U)", self)
        update_action.setStatusTip("检查是否有新版本可用")
        update_action.triggered.connect(self._check_for_updates)
        help_menu.addAction(update_action)

        if self.logger:
            self.logger.info("Menu bar with Help menu created successfully")

    def _show_about_dialog(self) -> None:
        """Show the About dialog with version information."""
        dialog = AboutDialog(self)
        dialog.help_requested.connect(self._open_help_documentation)
        dialog.exec()

    def _show_help_dialog(self) -> None:
        """Show the Help dialog with documentation and shortcuts."""
        from gui.dialogs.help_dialog import HelpDialog
        dialog = HelpDialog(self)
        dialog.setModal(False)  # Non-modal for better UX
        dialog.show()

    def _open_help_documentation(self) -> None:
        """Open help documentation in default browser."""
        # For now, show a notification that help docs are coming soon
        # In the future, this could open a local HTML file or online docs
        self.notification_bar.show_message("帮助文档正在准备中...", 'info', 3000)
        self.logger.info("Help documentation requested (not yet implemented)")

    def _check_for_updates(self) -> None:
        """Check for application updates."""
        # Placeholder for future update check implementation
        self.notification_bar.show_message(
            "当前已是最新版本 (v1.0.0)",
            'success',
            3000
        )
        self.logger.info("Update check performed - currently latest version")

    def _setup_navigation_panel(self, parent_layout: QHBoxLayout) -> None:
        """
        Set up the left navigation panel.

        Args:
            parent_layout: Parent layout to add navigation to
        """
        nav_widget = QWidget()
        nav_widget.setObjectName("navigationPanel")
        nav_widget.setFixedWidth(200)
        nav_widget.setMinimumWidth(180)

        nav_layout = QVBoxLayout(nav_widget)
        nav_layout.setContentsMargins(0, 0, 0, 0)
        nav_layout.setSpacing(0)

        # Title
        title_label = QLabel("AI Writer")
        title_label.setObjectName("navTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setFixedHeight(60)
        title_label.setWordWrap(True)
        nav_layout.addWidget(title_label)

        # Navigation list
        self.nav_list = QListWidget()
        self.nav_list.setObjectName("navigationList")
        self.nav_list.setFixedWidth(200)
        self.nav_list.setMinimumWidth(180)
        self.nav_list.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self.nav_list.setSizePolicy(
            self.nav_list.sizePolicy().horizontalPolicy(),
            self.nav_list.sizePolicy().verticalPolicy().Expanding
        )

        # Add navigation items with tooltips and icons
        nav_tooltips = [
            "作品库 - 管理和创建您的作品",
            "正在创作 - 查看当前正在创作的作品",
            "发布中心 - 将作品发布到小说平台",
            "提示词模板 - 自定义 AI 创作提示词",
            "设置 - 配置应用存储路径"
        ]

        # Get the icons directory path - icons are in src/resources/icons
        import os
        # __file__ is src/gui/main_window.py
        # We need to go up one level to src/, then into resources/icons
        icons_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "resources", "icons")

        for i, (label, key) in enumerate(self.NAV_ITEMS):
            item = QListWidgetItem(label)
            item.setSizeHint(QSize(180, 50))
            item.setToolTip(nav_tooltips[i])

            # Load and set icon for this navigation item
            icon_file = self.NAV_ICONS.get(key)
            if icon_file:
                icon_path = os.path.join(icons_dir, icon_file)
                if os.path.exists(icon_path):
                    icon = QIcon(icon_path)
                    item.setIcon(icon)

            self.nav_list.addItem(item)

        nav_layout.addWidget(self.nav_list)
        nav_layout.addStretch()

        parent_layout.addWidget(nav_widget)

    def _setup_content_area(self, parent_layout: QHBoxLayout) -> None:
        """
        Set up the main content area with stacked views.

        Args:
            parent_layout: Parent layout to add content to
        """
        self.content_stack = QStackedWidget()
        self.content_stack.setObjectName("contentStack")

        # Set size policy for responsive layout
        from PyQt6.QtWidgets import QSizePolicy
        self.content_stack.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Expanding
        )

        # Create and add views
        self.workspace_view = WorkspaceView(self.settings)
        self.creation_view = CreationView(self.settings)
        self.publishing_view = PublishingView(
            self.settings,
            work_manager=self.work_manager,
            fanqie_account_manager=self.fanqie_account_manager
        )
        self.template_view = TemplateView(self.settings, self.template_service)
        self.settings_view = SettingsView(self.settings)
        self.work_detail_view = WorkDetailView(self.settings)

        self.content_stack.addWidget(self.workspace_view)
        self.content_stack.addWidget(self.creation_view)
        self.content_stack.addWidget(self.publishing_view)
        self.content_stack.addWidget(self.template_view)
        self.content_stack.addWidget(self.settings_view)
        self.content_stack.addWidget(self.work_detail_view)

        parent_layout.addWidget(self.content_stack)

    def _setup_transition_animation(self) -> None:
        """Set up the page transition animation effect."""
        # Create opacity effect for smooth fade transitions
        self.opacity_effect = QGraphicsOpacityEffect()
        self.opacity_effect.setOpacity(1.0)
        self.content_stack.setGraphicsEffect(self.opacity_effect)

        # Create fade animation
        self.fade_animation = QPropertyAnimation(self.opacity_effect, b"opacity")
        self.fade_animation.setDuration(150)  # 150ms transition
        self.fade_animation.setEasingCurve(QEasingCurve.Type.InOutQuad)

        # Animation state tracking
        self._transition_animating = False
        self._pending_page_index = -1

        # Store references to current animations to prevent garbage collection
        self._current_fade_out = None
        self._current_fade_in = None

    def _setup_navigation(self) -> None:
        """Initialize navigation selection."""
        self.nav_list.setCurrentRow(0)
        # Show initial notification for the first page
        self.notification_bar.show_message(f"已进入{self.NAV_ITEMS[0][0]}")

    def _setup_connections(self) -> None:
        """Connect signals and slots."""
        self.nav_list.currentRowChanged.connect(self._on_navigation_changed)

        # Connect workspace view signals
        self.workspace_view.new_work_requested.connect(self._show_new_work_wizard)
        self.workspace_view.import_work_requested.connect(self._on_import_work_requested)
        self.workspace_view.work_double_clicked.connect(self._on_work_double_clicked)

        # Connect context menu action signals
        self.workspace_view.rename_work_requested.connect(self._on_rename_work_requested)
        self.workspace_view.export_work_requested.connect(self._on_export_work_requested)
        self.workspace_view.delete_work_requested.connect(self._on_delete_work_requested)

        # Connect work detail view signals
        self.work_detail_view.back_to_workspace_requested.connect(self._on_back_to_workspace)
        self.work_detail_view.start_creation_requested.connect(self._on_start_creation)
        self.work_detail_view.work_saved.connect(self._on_work_saved)

        # Connect creation view signals
        self.creation_view.creation_started.connect(self._on_creation_started)
        self.creation_view.creation_paused.connect(self._on_creation_paused)
        self.creation_view.creation_resumed.connect(self._on_creation_resumed)
        self.creation_view.generation_progress.connect(self._on_generation_progress)
        self.creation_view.content_changed.connect(self._on_content_changed)
        self.creation_view.save_requested.connect(self._on_save_requested)
        self.creation_view.go_to_workspace_requested.connect(self._on_go_to_workspace_requested)
        self.creation_view.template_edit_requested.connect(self._on_template_edit_requested)
        self.creation_view.regenerate_requested.connect(self._on_regenerate_requested)

        # Connect publishing view signals
        self.publishing_view.publish_clicked.connect(self._on_publish_clicked)
        self.publishing_view.platform_changed.connect(self._on_platform_changed)
        self.publishing_view.work_changed.connect(self._on_work_selected)

        # Connect settings view signals
        self.settings_view.settings_saved.connect(self._on_settings_saved)

    def _apply_styles(self) -> None:
        """Apply application styles."""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }

            #navigationPanel {
                background-color: #2c3e50;
                border-right: 1px solid #34495e;
            }

            #navTitle {
                font-size: 20px;
                font-weight: bold;
                color: #ecf0f1;
                background-color: #1a252f;
            }

            #navigationList {
                background-color: #2c3e50;
                color: #ecf0f1;
                border: none;
                outline: none;
                font-size: 14px;
                qproperty-iconSize: 20px 20px;
                show-decoration-selected: 1;
            }

            #navigationList::item {
                height: 50px;
                padding-left: 15px;
                border: none;
                outline: none;
            }

            #navigationList::item:hover {
                background-color: #34495e;
                border: none;
                outline: none;
            }

            #navigationList::item:selected {
                background-color: #1a5276;
                color: #ffffff;
                border: none;
                outline: none;
            }

            #navigationList::item:focus {
                background-color: #1a5276;
                color: #ffffff;
                border: none;
                outline: none;
            }

            #contentStack {
                background-color: #f0f0f0;  /* Light gray background */
            }
        """)

    def _on_navigation_changed(self, index: int) -> None:
        """
        Handle navigation item selection.

        Args:
            index: Index of selected navigation item
        """
        # Skip if already on the same page
        if index == self.current_index:
            return

        # If currently animating, queue the navigation
        if self._transition_animating:
            self._pending_page_index = index
            return

        # Handle "正在创作" menu item (index 1) - show empty state or creation content
        if index == 1 and self.NAV_ITEMS[index][1] == "creating":
            # Check if there's a work in progress BEFORE starting transition
            if self.creating_work_id:
                # Load the creating work into view if not already loaded
                if self.creation_view.current_work_id != self.creating_work_id:
                    work = self.work_manager.get_work(self.creating_work_id)
                    if work:
                        self.creation_view.load_work(work.to_dict())
                # Start page transition and show creation content
                self._start_page_transition(index)
                self.creation_view.show_creation_content()
            else:
                # No work in progress - show empty state BEFORE transition
                self.creation_view.show_empty_state()
                self._start_page_transition(index)
            return

        self._start_page_transition(index)

    def _on_go_to_workspace_requested(self) -> None:
        """Handle go to workspace request from creation view."""
        # Switch to workspace view (index 0)
        self.nav_list.blockSignals(True)
        self.nav_list.setCurrentRow(0)
        self.nav_list.blockSignals(False)
        self._start_page_transition(0)

    def _on_template_edit_requested(self, work_id: str, step_id: str, step_name: str) -> None:
        """
        Handle template edit request from creation view.

        Args:
            work_id: The work ID
            step_id: The step ID
            step_name: The step name
        """
        from .dialogs.template_edit_dialog import TemplateEditDialog

        # Load prompt content from steps/ directory
        # This is the rendered prompt with placeholders replaced
        prompt_content = self._load_prompt_from_steps(work_id, step_id)

        # If prompt file doesn't exist in steps/, render template with context as fallback
        if not prompt_content:
            # Get template category for this step
            template_category = self._get_template_category_for_step(step_id)

            # Get work data for context
            work_data = {}
            if work_id:
                work = self.work_manager.get_work(work_id)
                if work:
                    work_data = work.to_dict()

            # Build generation context
            context = self._build_generation_context(work_data, step_id)

            # Build context section (the part with previous steps' output)
            context_section = self._build_context_section(work_id, step_id, context)

            # Render template with context to replace placeholders
            rendered_template, unresolved = self.template_service.render_template(
                template_category, context
            )

            # Use rendered template if available, otherwise fall back to raw template
            if rendered_template:
                template_output = rendered_template
            else:
                # Fallback: try to get raw template content
                template = self.template_service.get_template(template_category)
                if template:
                    template_output = template.content
                else:
                    template_output = self._load_template_from_prompts(step_id)

            # Combine context section + template output to create full prompt
            if context_section:
                prompt_content = context_section + '\n\n' + template_output
            else:
                # Fallback: just use template
                prompt_content = template_output

        # Show template edit dialog
        dialog = TemplateEditDialog(step_name, step_id, prompt_content, self)
        dialog.template_saved.connect(self._on_template_saved)
        dialog.exec()

    def _load_template_from_prompts(self, step_id: str) -> str:
        """
        Load template content from prompts directory.

        Args:
            step_id: The step ID

        Returns:
            Template content or empty string if not found
        """
        # Map step_id to category name (now file names match category names)
        step_to_category_map = {
            'style_setting': '文风设定',
            'book_title': '书名',
            'story_summary': '故事梗概',
            'worldbuilding': '时空设定',
            'character_design': '人物设定',
            'cover_image': '封面图片',
            'volume_outline': '分卷大纲',
            'volume_characters': '分卷人物',
            'chapter_outline': '章节大纲',
            'chapter_content': '章节正文',
            'plot_summary': '剧情总结',
            'character_status': '人物总结',
        }

        # Handle dynamic reference analysis steps: reference_{work}_{start}_{end}
        if step_id.startswith('reference_'):
            category = '拆书参考'
        # Handle dynamic pattern analysis steps: pattern_{works}_{start}_{end}
        elif step_id.startswith('pattern_'):
            category = '创作公式'
        else:
            category = step_to_category_map.get(step_id, step_id)

        # Now use category as file name directly
        file_name = f"{category}.pmpt"

        script_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        prompt_file = os.path.join(script_dir, "prompts", file_name)

        if os.path.exists(prompt_file):
            with open(prompt_file, 'r', encoding='utf-8') as f:
                return f.read()

        return ""

    def _get_template_category_for_step(self, step_id: str) -> str:
        """
        Get template category name for a step ID.

        Args:
            step_id: The step ID

        Returns:
            Template category name
        """
        step_to_category_map = {
            'style_setting': '文风设定',
            'book_title': '书名',
            'story_summary': '故事梗概',
            'worldbuilding': '时空设定',
            'character_design': '人物设定',
            'cover_image': '封面图片',
            'volume_outline': '分卷大纲',
            'volume_characters': '分卷人物',
            'chapter_outline': '章节大纲',
            'chapter_content': '章节正文',
            'plot_summary': '剧情总结',
            'character_status': '人物总结',
        }

        if step_id.startswith('reference_'):
            return '拆书参考'
        elif step_id.startswith('pattern_'):
            return '创作公式'
        else:
            return step_to_category_map.get(step_id, step_id)

    def _load_prompt_from_steps(self, work_id: str, step_id: str) -> Optional[str]:
        """
        Load rendered prompt content from steps/ directory.

        Args:
            work_id: The work ID
            step_id: The step ID

        Returns:
            Prompt content or None if not found
        """
        if not work_id:
            return None

        try:
            # Get work directory
            work_dir = self.work_manager._get_work_dir(work_id)

            # Build path to prompt file
            steps_dir = os.path.join(work_dir, "steps")
            prompt_file = os.path.join(steps_dir, f"{step_id}_prompt.txt")

            if os.path.exists(prompt_file):
                with open(prompt_file, 'r', encoding='utf-8') as f:
                    return f.read()

            self.logger.info(f"[LOAD_PROMPT] Prompt file not found: {prompt_file}")
            return None

        except Exception as e:
            self.logger.error(f"[LOAD_PROMPT] Failed to load prompt from steps: {e}")
            return None

    def _save_prompt_to_steps(self, work_id: str, step_id: str, content: str) -> None:
        """
        Save edited prompt content to steps/ directory.

        Args:
            work_id: The work ID
            step_id: The step ID
            content: Prompt content to save
        """
        if not work_id:
            raise ValueError("work_id is required")

        # Get work directory
        work_dir = self.work_manager._get_work_dir(work_id)

        # Create steps directory if it doesn't exist
        steps_dir = os.path.join(work_dir, "steps")
        os.makedirs(steps_dir, exist_ok=True)

        # Save prompt to file
        prompt_file = os.path.join(steps_dir, f"{step_id}_prompt.txt")
        with open(prompt_file, 'w', encoding='utf-8') as f:
            f.write(content)

        self.logger.info(f"[SAVE_PROMPT] Saved edited prompt to {prompt_file} ({len(content)} chars)")

    def _on_template_saved(self, step_id: str, new_content: str) -> None:
        """
        Handle template saved event.

        Saves the edited prompt to templates/{category}.pmpt file.

        Args:
            step_id: The step ID
            new_content: New template content
        """
        # Get template category for this step
        template_category = self._get_template_category_for_step(step_id)

        # Save to templates directory using TemplateService
        if self.template_service.save_template(template_category, new_content):
            self.notification_bar.show_success(f"提示词已保存：{template_category}")
            self.logger.info(f"[SAVE_TEMPLATE] Saved edited prompt to templates/{template_category}.pmpt")
        else:
            self.notification_bar.show_error(f"提示词保存失败：{template_category}")

    def _on_regenerate_requested(self, work_id: str, step_id: str, step_name: str) -> None:
        """
        Handle regenerate request from creation view.

        Args:
            work_id: The work ID
            step_id: The step ID
            step_name: The step name
        """
        from .dialogs.regenerate_dialog import RegenerateDialog

        # Show regenerate dialog
        dialog = RegenerateDialog(step_name, step_id, work_id, self)
        dialog.regenerate_requested.connect(self._start_regeneration)

        # Store dialog reference for completion notification
        if not hasattr(self, '_active_regen_dialogs'):
            self._active_regen_dialogs = {}
        self._active_regen_dialogs[f"{work_id}_{step_id}"] = dialog

        # Clean up when dialog closes
        dialog.finished.connect(lambda: self._active_regen_dialogs.pop(f"{work_id}_{step_id}", None))

        dialog.exec()

    def _start_regeneration(self, work_id: str, step_id: str) -> None:
        """
        Start regeneration process for a step.

        Uses the prompt from steps/{step_id}_prompt.txt file.

        Args:
            work_id: The work ID
            step_id: The step ID
        """
        self.logger.info(f"[REGENERATE] Starting regeneration for step: {step_id}")

        # Load prompt from steps/ directory
        prompt = self._load_prompt_from_steps(work_id, step_id)

        if not prompt:
            # If prompt file doesn't exist, render template with context
            self.logger.info(f"[REGENERATE] Prompt file not found, rendering template for {step_id}")

            # Get template category for this step
            template_category = self._get_template_category_for_step(step_id)

            # Get work data
            work_data = {}
            if self.creation_view.current_work_id:
                work = self.work_manager.get_work(self.creation_view.current_work_id)
                if work:
                    work_data = work.to_dict()

            # Build generation context
            context = self._build_generation_context(work_data, step_id)

            # Build context section (the part with previous steps' output)
            context_section = self._build_context_section(work_id, step_id, context)

            # Render template with context to replace placeholders
            rendered_template, unresolved = self.template_service.render_template(
                template_category, context
            )

            # Use rendered template if available
            if rendered_template:
                template_output = rendered_template
            else:
                template_output = self._get_default_prompt(template_category, work_data)

            # Combine context section + template output to create full prompt
            if context_section:
                rendered_prompt = context_section + '\n\n' + template_output
            else:
                rendered_prompt = template_output

            # Save rendered prompt for future use
            self._save_rendered_prompt_to_steps(work_id, step_id, rendered_prompt)
            prompt = rendered_prompt

        # Use existing _call_ai_for_step method with new_chat=False for regeneration
        step_name = step_id.replace('_', ' ')
        self.logger.info(f"[REGENERATE] Calling AI for regeneration: {step_name}")

        # Update notification
        self.notification_bar.show_message(f"正在重新生成：{step_name}...", 'info', 0)

        # Create independent worker for regeneration - completely separate from normal generation
        self._start_independent_regeneration(work_id, step_id, step_name, prompt)

    def _start_independent_regeneration(
        self,
        work_id: str,
        step_id: str,
        step_name: str,
        prompt: str
    ) -> None:
        """
        Start independent regeneration process.

        This creates a new browser instance that runs independently from the main generation flow.
        Multiple regenerations can run simultaneously without interfering with each other or
        the normal step generation.

        Args:
            work_id: Work ID
            step_id: Step ID
            step_name: Step display name
            prompt: Prompt to send to AI
        """
        from PyQt6.QtCore import QThread, pyqtSignal
        from services.browser_ai_service import BrowserAIService
        import concurrent.futures

        self.logger.info(f"[INDEPENDENT_REGEN] Starting independent regeneration for {step_name}")

        class IndependentRegenerateWorker(QThread):
            """Independent worker for regeneration - creates its own browser instance."""
            result_ready = pyqtSignal(str, str, str)  # work_id, step_id, content
            error_occurred = pyqtSignal(str, str, str)  # work_id, step_id, error_message
            progress_update = pyqtSignal(str, str, str)  # work_id, step_id, message

            def __init__(self, settings, work_id, step_id, step_name, prompt, max_retries=3):
                super().__init__()
                self.settings = settings
                self.work_id = work_id
                self.step_id = step_id
                self.step_name = step_name
                self.prompt = prompt
                self.max_retries = max_retries
                self.logger = get_logger()

            def run(self):
                """Run regeneration in separate thread with independent browser instance."""
                last_error = None

                for attempt in range(self.max_retries):
                    try:
                        self.logger.info(f"[INDEPENDENT_REGEN] Attempt {attempt + 1}/{self.max_retries} for {self.step_name}")

                        if attempt > 0:
                            self.progress_update.emit(self.work_id, self.step_id, f"第 {attempt + 1} 次重试...")

                        # Get browser provider from settings
                        browser_provider = self.settings.ai_settings.browser_provider
                        browser_phone = self.settings.ai_settings.browser_phone
                        browser_password = self.settings.ai_settings.browser_password  # Get password
                        browser_chrome_path = self.settings.ai_settings.browser_chrome_path

                        self.logger.info(f"[INDEPENDENT_REGEN] Creating independent BrowserAIService instance")

                        # Create independent browser service instance for this regeneration
                        # This runs completely in this thread - no asyncio needed
                        browser_service = BrowserAIService(
                            provider=browser_provider,
                            phone_number=browser_phone,
                            password=browser_password,  # Pass password for DeepSeek password login
                            chrome_path=browser_chrome_path,
                            headless=False,
                            slow_mo=500,
                        )

                        # Connect to browser and send message - all in this thread
                        self.logger.info(f"[INDEPENDENT_REGEN] Connecting to browser...")
                        if not browser_service.connect():
                            raise Exception("浏览器连接失败")

                        self.logger.info(f"[INDEPENDENT_REGEN] Sending message...")
                        content = browser_service.send_message(
                            self.prompt,
                            False,  # Don't need new chat for regeneration
                            wait_timeout=180.0  # 3 minutes timeout
                        )

                        self.logger.info(f"[INDEPENDENT_REGEN] Received response: {len(content) if content else 0} chars")

                        # Close browser after completion
                        try:
                            browser_service.close()
                        except Exception as close_error:
                            self.logger.warning(f"[INDEPENDENT_REGEN] Browser close warning: {close_error}")

                        # Validate content
                        if not content or len(content.strip()) == 0:
                            raise Exception("AI 返回内容为空")

                        self.result_ready.emit(self.work_id, self.step_id, content)
                        return  # Success

                    except Exception as e:
                        last_error = e
                        self.logger.error(f"[INDEPENDENT_REGEN] Error (attempt {attempt + 1}): {e}")

                        # Don't retry on browser closed errors
                        error_str = str(e).lower()
                        if "浏览器页面已关闭" in error_str or "browser closed" in error_str.lower():
                            self.logger.error("[INDEPENDENT_REGEN] Browser closed, stopping retries")
                            break

                        # Wait before retry
                        if attempt < self.max_retries - 1:
                            wait_time = 5 * (attempt + 1)
                            self.logger.info(f"[INDEPENDENT_REGEN] Waiting {wait_time}s before retry...")
                            import time
                            time.sleep(wait_time)

                # All retries failed
                error_msg = f"重新生成失败（已重试 {self.max_retries} 次）: {str(last_error)}"
                self.error_occurred.emit(self.work_id, self.step_id, error_msg)

        # Create and start independent worker
        worker = IndependentRegenerateWorker(
            self.settings,
            work_id,
            step_id,
            step_name,
            prompt
        )

        # Store worker reference to prevent garbage collection
        if not hasattr(self, '_regen_workers'):
            self._regen_workers = []
        self._regen_workers.append(worker)

        # Connect signals
        worker.result_ready.connect(self._on_independent_regeneration_complete)
        worker.error_occurred.connect(self._on_independent_regeneration_error)
        worker.progress_update.connect(self._on_regeneration_progress)

        # Clean up worker when finished
        worker.finished.connect(lambda w=worker: self._regen_workers.remove(w) if w in self._regen_workers else None)

        self.logger.info(f"[INDEPENDENT_REGEN] Starting independent worker for {step_name}")
        worker.start()

    def _on_regeneration_complete(self, step_id: str, step_name: str, content: str) -> None:
        """
        Handle regeneration completion.
        (Deprecated - kept for backward compatibility)

        Args:
            step_id: Step ID that was regenerated
            step_name: Step display name
            content: Generated content
        """
        self._on_independent_regeneration_complete(step_id, step_id, content)

    def _on_independent_regeneration_complete(
        self,
        work_id: str,
        step_id: str,
        content: str
    ) -> None:
        """
        Handle independent regeneration completion.

        This method is called when an independent regeneration worker completes.
        It updates the work data and saves to disk independently from the main generation flow.

        Args:
            work_id: Work ID
            step_id: Step ID that was regenerated
            content: Generated content
        """
        self.logger.info(f"[INDEPENDENT_REGEN] Regenerated content for {step_id}: {len(content)} chars")

        # Get step name for display
        step_name = step_id.replace('_', ' ')

        # Save to disk
        try:
            self.work_manager.save_step_content(work_id, step_id, content)
            self.logger.info(f"[INDEPENDENT_REGEN] Saved regenerated content for {step_id}")
        except Exception as e:
            self.logger.error(f"[INDEPENDENT_REGEN] Failed to save regenerated content: {e}")

        # Update creation view if visible and showing this work
        if self.creation_view.isVisible() and self.creation_view.current_work_id == work_id:
            self.creation_view.update_step_content(step_id, content, streaming=False)

        # Notify and close the regenerate dialog
        dialog_key = f"{work_id}_{step_id}"
        if hasattr(self, '_active_regen_dialogs') and dialog_key in self._active_regen_dialogs:
            dialog = self._active_regen_dialogs[dialog_key]
            # Use QTimer to close dialog after it returns to event loop
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(0, dialog.accept)

        # Update notification
        self.notification_bar.show_message(f"{step_name} 重新生成完成", 'success', 2000)

    def _on_independent_regeneration_error(
        self,
        work_id: str,
        step_id: str,
        error_message: str
    ) -> None:
        """
        Handle independent regeneration error.

        Args:
            work_id: Work ID
            step_id: Step ID that failed
            error_message: Error message
        """
        self.logger.error(f"[INDEPENDENT_REGEN] Regeneration failed for {step_id}: {error_message}")

        # Notify dialog of error
        dialog_key = f"{work_id}_{step_id}"
        if hasattr(self, '_active_regen_dialogs') and dialog_key in self._active_regen_dialogs:
            dialog = self._active_regen_dialogs[dialog_key]
            # Update dialog to show error
            dialog.show_error(error_message)
        else:
            self.notification_bar.show_message(f"重新生成失败：{error_message}", 'error', 5000)

    def _on_regeneration_progress(
        self,
        work_id: str,
        step_id: str,
        message: str
    ) -> None:
        """
        Handle regeneration progress update.

        Args:
            work_id: Work ID
            step_id: Step ID being regenerated
            message: Progress message
        """
        self.logger.info(f"[INDEPENDENT_REGEN] Progress for {step_id}: {message}")
        # Optionally show progress in notification bar
        self.notification_bar.show_message(f"重新生成中：{message}", 'info', 3000)

    def _on_regeneration_error(self, step_id: str, error_message: str) -> None:
        """
        Handle regeneration error.

        Args:
            step_id: Step ID that failed
            error_message: Error message
        """
        self.logger.error(f"[REGENERATE] Regeneration failed for {step_id}: {error_message}")
        self.notification_bar.show_message(f"重新生成失败：{error_message}", 'error', 5000)

    def _start_page_transition(self, index: int) -> None:
        """
        Start page transition animation to the target page.

        The page state is changed immediately, then a fade animation
        provides visual feedback. This ensures tests and programmatic
        access see the correct state immediately.

        Args:
            index: Target page index
        """
        self._transition_animating = True

        # Update state immediately for synchronous access
        self.current_index = index
        self.content_stack.setCurrentIndex(index)

        # Update notification bar with page name
        page_name = self.NAV_ITEMS[index][0]
        self.notification_bar.show_message(f"已进入{page_name}")

        # Emit page changed signal
        self.page_changed.emit(index)

        # Force immediate viewport update
        self.content_stack.repaint()

        # Create fade out animation for visual effect
        fade_out = QPropertyAnimation(self.opacity_effect, b"opacity")
        fade_out.setDuration(100)
        fade_out.setEasingCurve(QEasingCurve.Type.InOutQuad)
        fade_out.setStartValue(1.0)
        fade_out.setEndValue(0.0)

        # Store reference to prevent garbage collection
        self._current_fade_out = fade_out

        # Connect finished signal to fade back in
        fade_out.finished.connect(
            lambda: self._on_fade_out_complete(fade_out)
        )
        fade_out.start()

    def _on_fade_out_complete(self, fade_out_anim: QPropertyAnimation) -> None:
        """
        Handle fade out completion and fade back in.

        Args:
            fade_out_anim: The fade out animation instance
        """
        # Clear reference to fade out animation
        self._current_fade_out = None

        # Create fade in animation
        fade_in = QPropertyAnimation(self.opacity_effect, b"opacity")
        fade_in.setDuration(100)
        fade_in.setEasingCurve(QEasingCurve.Type.InOutQuad)
        fade_in.setStartValue(0.0)
        fade_in.setEndValue(1.0)

        # Store reference to prevent garbage collection
        self._current_fade_in = fade_in

        fade_in.finished.connect(lambda: self._on_fade_in_complete(fade_in))
        fade_in.start()

    def _on_fade_in_complete(self, fade_in_anim: QPropertyAnimation) -> None:
        """Handle fade in completion."""
        self._transition_animating = False

        # Disconnect signal
        try:
            fade_in_anim.finished.disconnect()
        except TypeError:
            pass

        # Clear reference to fade in animation
        self._current_fade_in = None

        # Check if there's a pending navigation
        if self._pending_page_index >= 0:
            pending_index = self._pending_page_index
            self._pending_page_index = -1
            self._start_page_transition(pending_index)

    def switch_to_page(self, index: int) -> None:
        """
        Programmatically switch to a page with animation.

        Args:
            index: Index of page to switch to
        """
        if 0 <= index < self.content_stack.count() and index != self.current_index:
            self.nav_list.setCurrentRow(index)

    def get_current_view(self) -> QWidget:
        """Get the currently displayed view."""
        return self.content_stack.currentWidget()

    def closeEvent(self, event) -> None:
        """
        Handle window close event.

        Args:
            event: Close event
        """
        # Save any pending data
        self.settings.save()
        event.accept()

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()
        modifier = event.modifiers()

        # Escape key - only handle if no dialog is open
        if key == Qt.Key.Key_Escape:
            # Check if any dialog is currently open
            for widget in self.findChildren(QDialog):
                if widget.isVisible():
                    # Let the dialog handle Escape
                    return
            # No dialog open, close the main window
            self.close()
            return

        # Alt + number keys for quick navigation (Alt+1, Alt+2, etc.)
        if modifier == Qt.KeyboardModifier.AltModifier:
            if key == Qt.Key.Key_1:
                self.nav_list.setCurrentRow(0)
                return
            elif key == Qt.Key.Key_2:
                self.nav_list.setCurrentRow(1)
                return
            elif key == Qt.Key.Key_3:
                self.nav_list.setCurrentRow(2)
                return
            elif key == Qt.Key.Key_4:
                self.nav_list.setCurrentRow(3)
                return

        # F1 key - Show About dialog
        if key == Qt.Key.Key_F1:
            self._show_about_dialog()
            return

        # F2 key - Show Help dialog
        if key == Qt.Key.Key_F2:
            self._show_help_dialog()
            return

        # Let the base class handle other keys
        super().keyPressEvent(event)

    def _show_new_work_wizard(self) -> None:
        """Show the new work wizard dialog."""
        dialog = NewWorkWizard(self.settings, self)
        dialog.work_created.connect(self._on_work_created)
        dialog.exec()

    def _on_work_created(self, work_data: dict) -> None:
        """
        Handle work creation from wizard.

        Args:
            work_data: Dictionary containing work creation parameters
        """
        try:
            # Create the work using work manager
            work = self.work_manager.create_work(work_data)

            # Show success message
            self.notification_bar.show_message(f"作品已创建：{work.get_display_title()}")

            # Refresh the workspace view
            self._load_works()

        except Exception as e:
            self.logger.error(f"Failed to create work: {e}")
            self.notification_bar.show_message(f"创建作品失败：{str(e)}")

    def _load_works(self) -> None:
        """Load and display all works in the workspace view."""
        try:
            works = self.work_manager.get_all_works()
            works_data = [work.to_dict() for work in works]
            self.workspace_view.load_works(works_data)
        except Exception as e:
            self.logger.error(f"Failed to load works: {e}")
            self.workspace_view._show_empty_state()

    def _on_import_work_requested(self) -> None:
        """Handle import work request."""
        dialog = ImportWorkDialog(self.settings, self)
        dialog.work_imported.connect(self._on_work_imported)
        dialog.exec()

    def _on_work_imported(self, work_data: dict) -> None:
        """
        Handle work import.

        Args:
            work_data: Dictionary containing import parameters
        """
        try:
            import_path = work_data.get("import_path", "")
            import_method = work_data.get("import_method", "")

            if import_method == "zip":
                # Import from ZIP file
                work = self.work_manager.import_work_from_zip(import_path)
            elif import_method == "directory":
                # Import from directory
                work = self.work_manager.import_work_from_directory(import_path)
            else:
                raise ValueError(f"Unknown import method: {import_method}")

            # Show success message
            self.notification_bar.show_message(f"作品已导入：{work.get_display_title()}")

            # Refresh the workspace view
            self._load_works()

        except Exception as e:
            self.logger.error(f"Failed to import work: {e}")
            self.notification_bar.show_message(f"导入作品失败：{str(e)}")

    def _on_work_double_clicked(self, work_id: str) -> None:
        """
        Handle double-click on work card.

        Args:
            work_id: ID of the double-clicked work
        """
        try:
            # Get the work data
            work = self.work_manager.get_work(work_id)
            if work:
                # Load work data into detail view
                self.work_detail_view.load_work(work.to_dict())
                # Update creating work state in detail view
                self.work_detail_view.update_creating_work(self.creating_work_id, self.creating_work_state)

                # Switch to work detail view directly
                # Note: Work detail view is not in navigation menu, so we use
                # content_stack.setCurrentIndex directly instead of nav_list.setCurrentRow
                detail_index = self.content_stack.indexOf(self.work_detail_view)
                if detail_index >= 0:
                    self.content_stack.setCurrentIndex(detail_index)
                    self.notification_bar.show_message(f"正在查看：{work.get_display_title()}")
            else:
                # Work not found - file may have been deleted
                self.logger.warning(f"Work not found: {work_id}")

                # Get work title from cache if available for display
                work_title = "未知作品"
                cached_work = self.work_manager._works_cache.get(work_id)
                if cached_work:
                    work_title = cached_work.get_display_title() if hasattr(cached_work, 'get_display_title') else str(cached_work)

                # Show file not found dialog with option to remove
                from .dialogs.file_not_found_dialog import show_file_not_found_dialog

                should_remove = show_file_not_found_dialog(
                    work_title=work_title,
                    work_id=work_id,
                    parent=self
                )

                if should_remove:
                    # Remove the stale entry from cache and refresh
                    self._remove_stale_work_entry(work_id, work_title)

        except Exception as e:
            self.logger.error(f"Error opening work detail: {e}")
            self.notification_bar.show_message(f"打开作品详情失败：{str(e)}")

    def _remove_stale_work_entry(self, work_id: str, work_title: str) -> None:
        """
        Remove a stale work entry from cache and refresh the workspace view.

        Args:
            work_id: ID of the work to remove
            work_title: Title of the work for display
        """
        try:
            # Remove from cache
            if work_id in self.work_manager._works_cache:
                del self.work_manager._works_cache[work_id]

            # Refresh workspace view
            self._load_works()

            # Show success notification
            self.notification_bar.show_message(f"已从列表中移除：{work_title}", 'success', 3000)

            self.logger.info(f"Removed stale work entry: {work_id}")

        except Exception as e:
            self.logger.error(f"Failed to remove stale work entry: {e}")
            self.notification_bar.show_message(f"移除失败：{str(e)}", 'error', 3000)

    def _on_back_to_workspace(self) -> None:
        """Handle back to workspace request."""
        # Switch back to workspace view (index 0) with animation
        self.nav_list.blockSignals(True)  # Block signals to avoid recursive calls
        self.nav_list.setCurrentRow(0)
        self.nav_list.blockSignals(False)
        self._start_page_transition(0)
        self.notification_bar.show_message("已进入作品库")

    def _on_start_creation(self, work_id: str) -> None:
        """
        Handle start creation request.

        Logic:
        1. If this work is already being created (paused), show creation view
        2. If another work is being created, switch to new work (old work state is cleared)
        3. Otherwise, start normal creation flow

        Args:
            work_id: ID of work to start creation for
        """
        from gui.dialogs.volume_range_dialog import VolumeRangeDialog

        try:
            # Get the work data
            work = self.work_manager.get_work(work_id)
            if not work:
                self.logger.warning(f"Work not found: {work_id}")
                self.notification_bar.show_message("作品不存在")
                return

            # Check if this same work is already being created
            if self.creating_work_id == work_id:
                self.logger.info(f"[CREATION] Work {work_id} is already being created, showing creation view")
                # Load work data into creation view
                self.creation_view.load_work(work.to_dict())
                # Switch to creation view
                self.creation_view.show_creation_content()
                creation_index = self.content_stack.indexOf(self.creation_view)
                if creation_index >= 0:
                    self.content_stack.setCurrentIndex(creation_index)
                    self.notification_bar.show_message(f"正在创作：{work.get_display_title()}")
                return

            # If another work is being created, clear its state (user is switching works)
            if self.creating_work_id and self.creating_work_id != work_id:
                self.logger.info(f"[CREATION] Switching from work {self.creating_work_id} to work {work_id}")
                # The old work's state is simply replaced - no need to explicitly clear

            # Record the currently creating work (in memory only)
            self.creating_work_id = work_id
            self.creating_work_data = work.to_dict()
            self.creating_work_state = "not_started"

            # Update workspace view to show creating badge
            self.workspace_view.update_creating_work(work_id)
            # Reload works to refresh badges
            self._load_works()

            # Update work detail view to disable start button
            self.work_detail_view.update_creating_work(work_id, "in_progress")

            # Load work data into creation view
            self.creation_view.load_work(work.to_dict())

            # Switch to creation view and show creation content
            self.creation_view.show_creation_content()
            creation_index = self.content_stack.indexOf(self.creation_view)
            if creation_index >= 0:
                self.content_stack.setCurrentIndex(creation_index)
                self.notification_bar.show_message(f"正在创作：{work.get_display_title()}")

                # Use singleShot to show dialog after UI switch is complete
                from PyQt6.QtCore import QTimer
                QTimer.singleShot(
                    100,
                    lambda: self._show_volume_range_dialog(work_id)
                )
        except Exception as e:
            self.logger.error(f"Error opening creation view: {e}")
            self.notification_bar.show_message(f"打开创作管理失败：{str(e)}")

    def _show_volume_range_dialog(self, work_id: str) -> None:
        """
        Show volume range dialog for creation.

        Args:
            work_id: ID of work to create
        """
        from gui.dialogs.volume_range_dialog import VolumeRangeDialog

        # Get the work
        work = self.work_manager.get_work(work_id)
        if not work:
            self.logger.warning(f"Work not found for creation: {work_id}")
            self.notification_bar.show_message("作品不存在")
            # Reset creation state
            self.creation_view.creation_state = "not_started"
            self.creation_view._update_creation_state()
            return

        # Show volume range dialog (non-blocking)
        dialog = VolumeRangeDialog(self, max_volumes=100)
        dialog.range_confirmed.connect(lambda start, end: self._on_volume_range_confirmed(work_id, start, end))
        dialog.rejected.connect(lambda: self._on_volume_range_cancelled(work_id))
        dialog.exec()

    def _on_rename_work_requested(self, work_id: str) -> None:
        """
        Handle rename work request.

        Args:
            work_id: ID of work to rename
        """
        from PyQt6.QtWidgets import QInputDialog

        # Get the work
        work = self.work_manager.get_work(work_id)
        if not work:
            self.notification_bar.show_message("作品不存在")
            return

        # Show rename dialog
        current_title = work.title if work.title else work.get_display_title()
        new_title, ok = QInputDialog.getText(
            self,
            "重命名作品",
            "请输入新的书名：",
            text=current_title
        )

        if ok and new_title and new_title.strip():
            try:
                # Update work title
                work.title = new_title.strip()
                self.work_manager.update_work(work)

                # Show success message
                self.notification_bar.show_message(f"作品已重命名为：{new_title.strip()}")

                # Refresh the workspace view
                self._load_works()

            except Exception as e:
                self.logger.error(f"Failed to rename work: {e}")
                self.notification_bar.show_message(f"重命名失败：{str(e)}")

    def _on_export_work_requested(self, work_id: str) -> None:
        """
        Handle export work request.

        Args:
            work_id: ID of work to export
        """
        from PyQt6.QtWidgets import QFileDialog

        # Get the work
        work = self.work_manager.get_work(work_id)
        if not work:
            self.notification_bar.show_message("作品不存在")
            return

        # Get default filename
        default_filename = f"{work.get_display_title()}.zip"

        # Show save dialog
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "导出作品",
            default_filename,
            "ZIP 文件 (*.zip)"
        )

        if file_path:
            try:
                # Ensure .zip extension
                if not file_path.lower().endswith('.zip'):
                    file_path += '.zip'

                # Export the work
                self.work_manager.export_work_to_zip(work_id, file_path)

                # Show success message
                self.notification_bar.show_message(f"作品已导出到：{file_path}")

            except Exception as e:
                self.logger.error(f"Failed to export work: {e}")
                self.notification_bar.show_message(f"导出失败：{str(e)}")

    def _on_delete_work_requested(self, work_id: str) -> None:
        """
        Handle delete work request.

        Args:
            work_id: ID of work to delete
        """
        try:
            # Delete the work
            self.work_manager.delete_work(work_id)

            # Show success message
            self.notification_bar.show_message("作品已删除")

            # Refresh the workspace view
            self._load_works()

        except Exception as e:
            self.logger.error(f"Failed to delete work: {e}")
            self.notification_bar.show_message(f"删除失败：{str(e)}")

    def _on_work_saved(self, work_data: dict) -> None:
        """
        Handle work saved from detail view.

        Args:
            work_data: Updated work data dictionary
        """
        try:
            work_id = work_data.get('id')
            if not work_id:
                return

            work = self.work_manager.get_work(work_id)
            if work:
                # Update work with all edited fields from work_data
                work.title = work_data.get('title', work.title)
                work.author = work_data.get('author', work.author)
                work.cover_url = work_data.get('cover_url', work.cover_url)
                work.reference_works = work_data.get('reference_works', work.reference_works)
                work.creation_guide = work_data.get('creation_guide', work.creation_guide)
                work.chapters_per_volume = work_data.get('chapters_per_volume', work.chapters_per_volume)
                work.words_per_chapter = work_data.get('words_per_chapter', work.words_per_chapter)

                # Save the work
                self.work_manager.update_work(work)

                # Refresh workspace view to show updated info
                self._load_works()

                self.notification_bar.show_message("作品信息已保存")
            else:
                self.logger.error(f"Work not found: {work_id}")
                self.notification_bar.show_message("保存失败：作品不存在")

        except Exception as e:
            self.logger.error(f"Failed to save work: {e}")
            self.notification_bar.show_message(f"保存失败：{str(e)}")

        except Exception as e:
            self.logger.error(f"Failed to save work: {e}")
            self.notification_bar.show_message(f"保存失败：{str(e)}")

    def _on_creation_started(self, work_id: str) -> None:
        """
        Handle creation started signal.

        Opens the volume range dialog to let user select which volumes to generate.

        Args:
            work_id: ID of work that creation started for
        """
        from gui.dialogs.volume_range_dialog import VolumeRangeDialog

        self.logger.info(f"[CREATION] Creation started signal received for work {work_id}")
        self.logger.info(f"[CREATION] creating_work_id={self.creating_work_id}, current index={self.content_stack.currentIndex()}")

        # Get the work
        work = self.work_manager.get_work(work_id)
        if not work:
            self.logger.warning(f"Work not found for creation: {work_id}")
            self.notification_bar.show_message("作品不存在")
            # Reset creation state
            self.creation_view.creation_state = "not_started"
            self.creation_view._update_creation_state()
            return

        self.logger.info(f"[CREATION] Work found: {work.get_display_title()}, showing volume range dialog")

        # Show volume range dialog (non-blocking)
        dialog = VolumeRangeDialog(self, max_volumes=100)
        dialog.range_confirmed.connect(lambda start, end: self._on_volume_range_confirmed(work_id, start, end))
        dialog.rejected.connect(lambda: self._on_volume_range_cancelled(work_id))
        dialog.exec()

        self.logger.info(f"[CREATION] Volume range dialog closed")

    def _on_volume_range_cancelled(self, work_id: str) -> None:
        """
        Handle volume range dialog cancellation.

        Args:
            work_id: ID of work for which creation was cancelled
        """
        self.logger.info(f"Volume range selection cancelled for work {work_id}")
        # Reset creation state
        self.creation_view.creation_state = "not_started"
        self.creation_view._update_creation_state()

    def _create_creation_task(
        self,
        work_id: str,
        start_volume: int,
        end_volume: int
    ) -> None:
        """
        创建创作任务结构体并初始化会话管理器

        Args:
            work_id: 作品 ID
            start_volume: 起始卷号
            end_volume: 结束卷号
        """
        try:
            # Ensure logger is available
            if not self.logger:
                from utils.logger import setup_logger
                self.logger = setup_logger()

            self.logger.info(f"[CREATE_TASK_STEP] Step 1: Getting work data")
            # 获取作品数据
            work = self.work_manager.get_work(work_id)
            if not work:
                self.logger.warning(f"Work not found: {work_id}")
                return

            work_data = work.to_dict()
            self.logger.info(f"[CREATE_TASK_STEP] Step 2: Creating task in CreationView")

            # 在 CreationView 中创建任务
            self.creation_view.create_creation_task(work_id, work_data, start_volume, end_volume)
            self.logger.info(f"[CREATE_TASK_STEP] Step 3: Building flow tree from task")

            # 从任务结构体重建 UI 树
            self.creation_view._build_flow_tree_from_task()
            self.logger.info(f"[CREATE_TASK_STEP] Step 4: Task created successfully")

            self.logger.info(f"[CREATE_TASK] Creation task created for work {work_id}")

        except Exception as e:
            import traceback
            error_trace = traceback.format_exc()
            self.logger.error(f"[CREATE_TASK_ERROR] Failed to create creation task: {e}")
            self.logger.error(f"[CREATE_TASK_ERROR] Traceback: {error_trace}")

    def _on_volume_range_confirmed(
        self,
        work_id: str,
        start_volume: int,
        end_volume: int
    ) -> None:
        """
        Handle volume range confirmation.

        Starts the actual AI generation flow.

        Args:
            work_id: ID of work being created
            start_volume: Starting volume number
            end_volume: Ending volume number
        """
        try:
            self.logger.info(f"[CREATION] Volume range confirmed: work={work_id}, volumes={start_volume}-{end_volume}")

            # If another work is being created, pause it first and switch to new work
            if self.creating_work_id and self.creating_work_id != work_id:
                self.logger.info(f"[CREATION] Another work ({self.creating_work_id}) is being created, switching to new work {work_id}")

            # Record the currently creating work (in memory only, cleared on app restart)
            self.creating_work_id = work_id
            self.creating_work_data = self.work_manager.get_work(work_id).to_dict()
            self.creating_work_state = "in_progress"

            # Create creation task structure (this will also build the flow tree from task)
            self._create_creation_task(work_id, start_volume, end_volume)

            # Show progress message
            self.notification_bar.show_message(
                f"开始创作：第{start_volume}卷 - 第{end_volume}卷",
                'info',
                0  # Persistent during creation
            )

            # Update button to show pause state
            self.creation_view.creation_state = "in_progress"
            self.creation_view._update_creation_state()

            # Update all views to reflect creating state
            self._update_creating_work_views()

            # Switch to "正在创作" menu item (index 1)
            self.nav_list.blockSignals(True)
            self.nav_list.setCurrentRow(1)
            self.nav_list.blockSignals(False)
            self._start_page_transition(1)

            # Start the AI generation flow
            self.logger.info(
                f"Creation started for work {work_id}: volumes {start_volume}-{end_volume}"
            )

            # Check configuration based on mode
            ai_settings = self.settings.ai_settings
            self.logger.info(f"[CREATION] AI call mode: {ai_settings.call_mode}")

            if ai_settings.call_mode == "browser":
                # Browser mode: check phone number
                self.logger.info(f"[CREATION] Browser mode - phone: {ai_settings.browser_phone}, provider: {ai_settings.browser_provider}")
                if not ai_settings.browser_phone:
                    self.notification_bar.show_message("请先在设置中配置手机号（用于浏览器自动化登录）", 'error', 5000)
                    self.creation_view.creation_state = "paused"
                    self.creation_view._update_creation_state()
                    self.creating_work_state = "paused"
                    return
            else:
                # API mode: check API key
                self.logger.info(f"[CREATION] API mode - provider: {ai_settings.api_provider}")
                if not ai_settings.api_key:
                    self.notification_bar.show_message("请先在设置中配置 API Key", 'error', 5000)
                    self.creation_view.creation_state = "paused"
                    self.creation_view._update_creation_state()
                    self.creating_work_state = "paused"
                    return

            # Start the generation flow
            self.logger.info(f"[CREATION] Starting AI generation flow")
            self._start_ai_generation_flow(work_id, start_volume, end_volume, ai_settings.api_key)

        except Exception as e:
            self.logger.error(f"Failed to start creation flow: {e}")
            self.notification_bar.show_message(f"开始创作失败：{str(e)}")
            # Reset creation state
            self.creation_view.creation_state = "not_started"
            self.creation_view._update_creation_state()
            self._clear_creating_work()

    def _start_ai_generation_flow(
        self,
        work_id: str,
        start_volume: int,
        end_volume: int,
        api_key: str
    ) -> None:
        """
        Start the AI generation flow for creating novel content.

        Uses SessionExecutor to execute sessions with hardcoded flow.

        Args:
            work_id: ID of work being created
            start_volume: Starting volume number
            end_volume: Ending volume number
            api_key: API key for AI service
        """
        try:
            self.logger.info(f"[CREATION] Starting AI generation flow for work {work_id}")

            # Get work data
            work = self.work_manager.get_work(work_id)
            if not work:
                self.logger.error(f"[CREATION] Work not found: {work_id}")
                self.notification_bar.show_message(f"作品不存在：{work_id}")
                return
            work_data = work.to_dict()

            # Create or reuse AI service instance
            from services.ai_service import (
                AIService, AIServiceMode
            )

            ai_settings = self.settings.ai_settings

            # Determine mode and create service
            if ai_settings.call_mode == "browser":
                # Always close existing browser service first to avoid bad state
                if self._persistent_browser_service is not None:
                    self.logger.info(f"[CREATION] Closing existing browser service before creating new one")
                    self._close_persistent_browser()

                self.logger.info(f"[CREATION] Creating new browser AI service - provider: {ai_settings.browser_provider}, phone: {ai_settings.browser_phone}")
                self._persistent_browser_service = AIService(
                    mode=AIServiceMode.BROWSER,
                    browser_provider=ai_settings.browser_provider,
                    browser_phone=ai_settings.browser_phone,
                    browser_password=ai_settings.browser_password,
                    browser_chrome_path=ai_settings.browser_chrome_path,
                )
            else:
                # API mode - create AIService for API calls
                self.logger.info(f"[CREATION] Creating API AI service - provider: {ai_settings.api_provider}")
                self._persistent_browser_service = AIService(
                    mode=AIServiceMode.API,
                    api_provider=ai_settings.api_provider,
                    api_url=ai_settings.api_url,
                    api_key=ai_settings.api_key,
                    api_model=ai_settings.api_model,
                )

            # Store parameters for session execution
            self._creation_start_volume = start_volume
            self._creation_end_volume = end_volume
            self._creation_chapters_per_volume = work_data.get('chapters_per_volume', 5)

            # Start the hardcoded session flow via SessionExecutor
            self.logger.info(f"[SESSION_FLOW] Starting hardcoded session flow")

            # Find the first incomplete session and start from there
            session_type, vol_num, total_sessions = self.session_executor._find_first_incomplete_session()

            if session_type == 'completed':
                self.logger.info(f"[SESSION_FLOW] All sessions already completed, skipping AI generation")
                self._on_creation_completed()
                return
            elif session_type == 'basic_info':
                current_session = 1
                self.logger.info(f"[SESSION_FLOW] Starting from basic_info session ({current_session}/{total_sessions})")
                self.session_executor._execute_basic_info_session()
            elif session_type == 'creation_reference':
                current_session = 2
                self.logger.info(f"[SESSION_FLOW] Starting from creation_reference session ({current_session}/{total_sessions})")
                self.session_executor._execute_creation_reference_session(current_session, total_sessions)
            elif session_type == 'volume':
                # Calculate session number: 2 (basic + reference) + (vol_num - start_volume)
                current_session = 2 + (vol_num - start_volume) + 1
                self.logger.info(f"[SESSION_FLOW] Starting from volume_{vol_num} session ({current_session}/{total_sessions})")
                self.session_executor._execute_volume_session(vol_num, current_session, total_sessions)
            elif session_type == 'chapter':
                # Calculate session number: 2 (basic + reference) + total_volumes + (vol_num - start_volume)
                total_volumes = end_volume - start_volume + 1
                current_session = 2 + total_volumes + (vol_num - start_volume) + 1
                self.logger.info(f"[SESSION_FLOW] Starting from chapter_{vol_num} session ({current_session}/{total_sessions})")
                self.session_executor._execute_chapter_session(vol_num, current_session, total_sessions)

        except Exception as e:
            self.logger.error(f"Failed to start AI generation: {e}")
            self.notification_bar.show_message(f"AI 生成失败：{str(e)}")


    def _on_creation_completed(self) -> None:
        """
        Called when all sessions are completed.
        """
        self.logger.info(f"[CREATION_COMPLETE] 创作流程完成 - 已处理卷 {self._creation_start_volume}-{self._creation_end_volume}")

        # Do NOT close browser - keep it open for user to decide

        self.notification_bar.show_message("创作完成！", 'success', 3000)

        # Update UI state
        if hasattr(self, 'creation_view'):
            self.creation_view.creation_state = "not_started"
            self.creation_view._update_creation_state()

        # Clear creating work state
        self._clear_creating_work()

        # Update all views
        self._update_creating_work_views()

    def _get_ai_service_for_step(self):
        """
        Get AI service for current step.

        Returns shared browser service if available, otherwise returns None.
        In new session-based flow, AI service is created in _start_ai_generation_flow.
        """
        # Return the shared browser service if available
        if hasattr(self, '_persistent_browser_service') and self._persistent_browser_service:
            return self._persistent_browser_service
        return None

    def _close_persistent_browser(self) -> None:
        """Close persistent browser service."""
        if hasattr(self, '_persistent_browser_service') and self._persistent_browser_service:
            self.logger.info(f"[BROWSER] Closing browser service")
            try:
                self._persistent_browser_service.close()
            except Exception as e:
                self.logger.warning(f"[BROWSER] Error closing browser service: {e}")
            self._persistent_browser_service = None
        # Always reset the executor to ensure clean state
        from services.ai_service import _reset_browser_executor
        _reset_browser_executor()

    def _get_template_category_for_step(self, step_id: str) -> str:
        """
        Get the template category for a step ID.

        Args:
            step_id: Step ID

        Returns:
            Template category string
        """
        # Map step ID patterns to template categories
        # Note: patterns are checked in order, more specific patterns should come first
        template_map = [
            ('chapter_*_*_outline', '章节大纲'),
            ('chapter_*_*_content', '章节正文'),
            ('volume_*_summary_plot', '分卷剧情总结'),
            ('volume_*_summary_character', '分卷人物总结'),
            ('volume_*_characters', '分卷人物'),
            ('volume_*', '分卷大纲'),
            ('reference_*', '拆书参考'),
            ('pattern_*', '创作公式'),
            ('style_setting', '文风设定'),
            ('book_title', '书名'),
            ('story_summary', '故事梗概'),
            ('worldbuilding', '时空设定'),
            ('character_design', '人物设定'),
            ('cover_image', '封面图片'),
        ]

        import fnmatch
        for pattern, category in template_map:
            if fnmatch.fnmatch(step_id, pattern):
                return category

        # Default to step ID
        return step_id


    # ========== Session-based flow methods above ==========
    # Session execution flow moved to SessionExecutor (src/gui/session_executor.py)
    # Methods moved to SessionExecutor:
    # - _send_context_input_with_callback()
    # - _execute_output_step_with_callback()
    # - _read_file_safe()
    # - _write_file_safe()
    # - _create_persistent_browser()
    # - _close_persistent_browser()
    # - _execute_basic_info_session()
    # - _execute_creation_reference_session()
    # - _execute_volume_session()
    # - _execute_chapter_session()
    # - All input/output phase methods for each session type

    def _save_rendered_prompt_to_steps(
        self,
        work_id: str,
        step_id: str,
        rendered_prompt: str
    ) -> None:
        """
        Save rendered prompt (with placeholders replaced) to steps/ directory.

        The prompt is saved to {work_dir}/steps/{step_id}_prompt.txt
        This file is used for:
        - Display when user clicks the prompt button
        - Editing and saving by user
        - Regeneration using the edited prompt

        Args:
            work_id: Work identifier
            step_id: Step identifier
            rendered_prompt: Prompt content with placeholders replaced
        """
        if not work_id:
            self.logger.warning("[SAVE_PROMPT] work_id is empty")
            return

        try:
            # Get work directory
            work_dir = self.work_manager._get_work_dir(work_id)

            # Create steps directory if it doesn't exist
            steps_dir = os.path.join(work_dir, "steps")
            os.makedirs(steps_dir, exist_ok=True)

            # Save prompt to file
            prompt_file = os.path.join(steps_dir, f"{step_id}_prompt.txt")
            with open(prompt_file, 'w', encoding='utf-8') as f:
                f.write(rendered_prompt)

            self.logger.info(f"[SAVE_PROMPT] Saved rendered prompt to {prompt_file} ({len(rendered_prompt)} chars)")

        except Exception as e:
            self.logger.error(f"[SAVE_PROMPT] Failed to save rendered prompt: {e}")

    def _get_latest_reference_analysis(self, work_data: dict) -> str:
        """
        Get the latest reference analysis content from work_data or disk.

        For dynamic reference steps, find the most recent reference_analysis content
        by looking for files matching the pattern reference_*_{start}_{end}.txt

        Args:
            work_data: Work data dictionary

        Returns:
            Reference analysis content string
        """
        work_id = work_data.get('id', '')
        if not work_id:
            return ''

        # Get reference works and chapter range from work_data
        reference_works = work_data.get('reference_works', [])
        chapters_per_volume = work_data.get('chapters_per_volume', 5)
        start_volume = work_data.get('start_volume', 1)
        end_volume = work_data.get('end_volume', 1)

        # Calculate chapter range based on volumes
        # Formula: chapter_range = volume_range * chapters_per_volume
        start_chapter = (start_volume - 1) * chapters_per_volume + 1
        end_chapter = end_volume * chapters_per_volume

        # Try to load from the first reference work's analysis file
        if reference_works:
            safe_work_name = reference_works[0].replace('/', '_').replace('\\', '_').replace(':', '_')
            step_id = f"reference_{safe_work_name}_{start_chapter}_{end_chapter}"
            content = self.work_manager.load_step_content(work_id, step_id)
            if content:
                return content

        return ''

    def _get_latest_pattern_analysis(self, work_data: dict) -> str:
        """
        Get the latest pattern analysis content from work_data or disk.

        For dynamic pattern steps, find the pattern content by looking for files
        matching the pattern pattern_{works}_{start}_{end}.txt

        Args:
            work_data: Work data dictionary

        Returns:
            Pattern analysis content string
        """
        work_id = work_data.get('id', '')
        if not work_id:
            return ''

        # Get reference works and chapter range from work_data
        reference_works = work_data.get('reference_works', [])
        chapters_per_volume = work_data.get('chapters_per_volume', 5)
        start_volume = work_data.get('start_volume', 1)
        end_volume = work_data.get('end_volume', 1)

        # Calculate chapter range based on volumes
        # Formula: chapter_range = volume_range * chapters_per_volume
        start_chapter = (start_volume - 1) * chapters_per_volume + 1
        end_chapter = end_volume * chapters_per_volume

        # Try to load from the pattern analysis file
        if reference_works:
            # Extract second part after '/' first, then truncate to 10 chars
            short_names = []
            for w in reference_works[:3]:
                if '/' in w:
                    short_names.append(w.split('/')[1][:10])
                else:
                    short_names.append(w[:10])
            work_names_short = '_'.join(short_names)
            if len(reference_works) > 3:
                work_names_short += f"_etc{len(reference_works)-3}"

            step_id = f"pattern_{work_names_short}_{start_chapter}_{end_chapter}"
            content = self.work_manager.load_step_content(work_id, step_id)
            if content:
                return content

        return ''

    def _load_reference_work_chapters(self, work_data: dict, work_name: str, start_chapter: int, end_chapter: int) -> str:
        """
        Load chapter content from a reference work.

        Args:
            work_data: Work data dictionary
            work_name: Name of the reference work (format: {category}/{work_name} or just {work_name})
            start_chapter: Starting chapter number
            end_chapter: Ending chapter number

        Returns:
            Combined chapter content string
        """
        if not self.settings.storage_root:
            return ''

        # Parse category and work name from work_name parameter
        # Format: {category}/{work_name} or just {work_name} (for backward compatibility)
        if '/' in work_name:
            parts = work_name.split('/', 1)
            category = parts[0]
            actual_work_name = parts[1]
        else:
            # Backward compatibility: use work_data's category if no category in work_name
            category = work_data.get('category', '')
            actual_work_name = work_name

        if not category:
            return ''

        # Build path to reference work
        work_dir = os.path.join(self.settings.storage_root, 'references', category, actual_work_name)
        if not os.path.exists(work_dir):
            self.logger.warning(f"[REFERENCE] Reference work directory not found: {work_dir}")
            return ''

        # Get chapter files
        # Support both formats: with .txt extension and without extension
        chapter_files = [
            f for f in os.listdir(work_dir)
            if (f.endswith('.txt') or not '.' in f) and os.path.isfile(os.path.join(work_dir, f))
        ]

        # Load chapters in range by matching chapter number in filename
        # Filename format: 第 x 章章节名称.txt
        content_parts = []
        import re

        for chapter_num in range(start_chapter, end_chapter + 1):
            # Try to find a file that matches this chapter number
            for chapter_file in chapter_files:
                # Extract chapter number from filename using regex
                # Filename format: 第 x 章章节名称.txt (no spaces)
                match = re.match(r'\u7b2c(\d+)\u7ae0', chapter_file)
                if match:
                    file_chapter_num = int(match.group(1))
                    if file_chapter_num == chapter_num:
                        # Found matching file, load it
                        chapter_path = os.path.join(work_dir, chapter_file)
                        try:
                            with open(chapter_path, 'r', encoding='utf-8') as f:
                                content_parts.append(f.read())
                            self.logger.info(f"[REFERENCE] Loaded chapter {chapter_num}: {chapter_file}")
                        except IOError as e:
                            self.logger.warning(f"[REFERENCE] Failed to load chapter {chapter_num}: {e}")
                        break
            else:
                # Chapter file not found, skip it (don't log every missing chapter to avoid spam)
                self.logger.debug(f"[REFERENCE] Chapter {chapter_num} not found in {actual_work_name}")

        if not content_parts:
            self.logger.warning(f"[REFERENCE] No chapters found in range {start_chapter}-{end_chapter} for {actual_work_name}")

        return '\n\n'.join(content_parts)

    def _build_generation_context(
        self,
        work_data: dict,
        current_step_id: str,
        state: dict = None
    ) -> dict:
        """
        Build context dictionary for template rendering.

        Args:
            work_data: Work data dictionary
            current_step_id: Current step ID being generated
            state: Generation state dictionary (optional, for checking continuation)

        Returns:
            Context dictionary with all available data
        """
        # Parse current step info to get volume and chapter numbers
        vol_num = 1
        chap_num = 1
        total_volumes = work_data.get('total_volumes', 1)
        chapters_per_volume = work_data.get('chapters_per_volume', 5)

        if 'volume_' in current_step_id and '_summary' not in current_step_id:
            parts = current_step_id.split('_')
            if len(parts) >= 2:
                try:
                    vol_num = int(parts[1])
                except (ValueError, IndexError):
                    pass

        if 'chapter_' in current_step_id:
            parts = current_step_id.split('_')
            if len(parts) >= 3:
                try:
                    vol_num = int(parts[1])
                    chap_num = int(parts[2].replace('outline', '').replace('content', ''))
                except (ValueError, IndexError):
                    pass

        # Build base context with all basic info fields
        context = {
            # Basic info
            "novel_type": work_data.get('category', ''),
            "novel_name": work_data.get('title', ''),
            "book_title": work_data.get('title', ''),
            "author_name": work_data.get('author', 'AI 作者'),
            "reference_works": work_data.get('reference_works', ''),
            "creation_guide": work_data.get('creation_guide', ''),
            "literary_style_category": work_data.get('literary_style_category', ''),

            # AI-generated content fields - load from steps/ directory files
            # Each step's generated content is saved to steps/{step_id}.txt
            # We read from these files to populate the context for template rendering
            "style_setting": "",
            "literary_style": "",
            "story_summary": "",
            "worldbuilding": "",
            "character_design": "",
            "characters": "",

            # Volume and chapter settings
            "total_volumes": str(total_volumes),
            "current_volume": str(vol_num),
            "vol_num": str(vol_num),  # Template placeholder name
            "chapters_per_volume": str(chapters_per_volume),
            "words_per_chapter": str(work_data.get('words_per_chapter', 3000)),

            # Chapter-specific context
            "chapter_index": str(chap_num),
            "chapter_num": str(chap_num),  # Template placeholder name
            "previous_chapter_index": str(max(0, chap_num - 1)),
            "start_chapter": "1",
            "end_chapter": str(chapters_per_volume),

            # Category for compatibility
            "category": work_data.get('category', ''),
        }

        # Load previous steps' content from steps/ directory files
        # This is the source of truth - each step's generated content is saved to a file
        work_id = work_data.get('id', '')
        if work_id:
            # Load style_setting from steps/style_setting.txt
            style_content = self.work_manager.load_step_content(work_id, 'style_setting')
            if style_content:
                context["style_setting"] = style_content
                context["literary_style"] = style_content

            # Load book_title from steps/book_title.txt and extract the actual title
            title_content = self.work_manager.load_step_content(work_id, 'book_title')
            if title_content:
                import re
                # Try to extract from recommended TOP5 first (format: 1. 《书名》- 说明)
                match = re.search(r'推荐 TOP5.*?1\. 《([^》]+)》', title_content, re.DOTALL)
                if not match:
                    # Fallback: try to extract from 书名 section
                    match = re.search(r'## 书名\s*\n(.+)', title_content)
                if match:
                    book_title = match.group(1).strip()
                    context["book_title"] = book_title
                    context["novel_name"] = book_title

            # Load story_summary from steps/story_summary.txt
            summary_content = self.work_manager.load_step_content(work_id, 'story_summary')
            if summary_content:
                context["story_summary"] = summary_content

            # Load worldbuilding from steps/worldbuilding.txt
            world_content = self.work_manager.load_step_content(work_id, 'worldbuilding')
            if world_content:
                context["worldbuilding"] = world_content

            # Load character_design from steps/character_design.txt
            char_content = self.work_manager.load_step_content(work_id, 'character_design')
            if char_content:
                context["character_design"] = char_content
                context["characters"] = char_content

        # Log context for cover_image step debugging
        if current_step_id == 'cover_image':
            self.logger.info(f"[CONTEXT] Cover image step - story_summary len={len(context['story_summary'])}, worldbuilding len={len(context['worldbuilding'])}, character_design len={len(context['character_design'])}, book_title='{context['book_title']}'")
            if not context['story_summary'] or not context['worldbuilding'] or not context['character_design']:
                self.logger.warning(f"[CONTEXT] Cover image - CRITICAL: Previous step files are MISSING or EMPTY!")

        # Load reference_analysis and pattern_analysis from work_data or disk
        # For dynamic steps, we need to find the actual step content
        ref_analysis_content = self._get_latest_reference_analysis(work_data)
        pattern_content = self._get_latest_pattern_analysis(work_data)
        context["reference_analysis"] = ref_analysis_content
        context["pattern_analysis"] = pattern_content
        context["book_reference"] = ref_analysis_content

        # Handle reference analysis steps - load chapter content from reference work
        if current_step_id.startswith('reference_'):
            # Parse step_id: reference_{work_name}_{start}_{end}
            parts = current_step_id.split('_')
            if len(parts) >= 4:
                # Extract work name (may contain underscores, so join middle parts)
                # Format: reference_{work_name}_{start}_{end}
                # work_name is everything between 'reference' and the last two numeric parts
                try:
                    end_chapter = int(parts[-1])
                    start_chapter = int(parts[-2])
                    work_name = '_'.join(parts[1:-2])

                    # Restore original work name format: convert _ back to /
                    # Original format: {category}/{work_name} -> stored as: {category}_{work_name}
                    # We need to restore the first / only (in case work name has underscores)
                    # Strategy: find the first _ that was originally a / and restore it
                    # Since category doesn't contain _, we look for the pattern xxx_yyy where xxx is a known category
                    if '_' in work_name and '/' not in work_name:
                        # Try to restore category/work_name format
                        # Common categories: 玄幻，都市，武侠，仙侠，科幻，历史，军事，游戏，体育，玄幻
                        known_categories = {'玄幻', '都市', '武侠', '仙侠', '科幻', '历史', '军事', '游戏', '体育', '言情', '奇幻', '悬疑', '恐怖', '同人'}
                        for category in known_categories:
                            if work_name.startswith(category + '_'):
                                work_name = category + '/' + work_name[len(category) + 1:]
                                break

                    context["start_chapter"] = str(start_chapter)
                    context["end_chapter"] = str(end_chapter)

                    # Load chapter content from reference work
                    novel_content = self._load_reference_work_chapters(work_data, work_name, start_chapter, end_chapter)
                    context["novel_content"] = novel_content

                    # Set novel_number for pattern analysis (1 for each reference work)
                    context["novel_number"] = "1"

                    self.logger.info(f"[CONTEXT] Reference analysis step: work={work_name}, chapters={start_chapter}-{end_chapter}, content_len={len(novel_content)}")
                except (ValueError, IndexError) as e:
                    self.logger.warning(f"[CONTEXT] Failed to parse reference step_id '{current_step_id}': {e}")

        # Handle pattern analysis steps - combine all reference analysis results
        if current_step_id.startswith('pattern_'):
            # Parse step_id: pattern_{work_names}_{start}_{end}
            parts = current_step_id.split('_')
            if len(parts) >= 4:
                try:
                    end_chapter = int(parts[-1])
                    start_chapter = int(parts[-2])

                    context["start_chapter"] = str(start_chapter)
                    context["end_chapter"] = str(end_chapter)

                    # Get number of reference works
                    reference_works = work_data.get('reference_works', [])
                    context["novel_number"] = str(len(reference_works))

                    # Combine all reference analysis results
                    plot_summaries = []
                    for work_name in reference_works:
                        safe_work_name = work_name.replace('/', '_').replace('\\', '_').replace(':', '_')
                        ref_step_id = f"reference_{safe_work_name}_{start_chapter}_{end_chapter}"
                        ref_content = self.work_manager.load_step_content(work_data.get('id', ''), ref_step_id)
                        if ref_content:
                            plot_summaries.append(f"## {work_name}\n{ref_content}")

                    combined_reference = '\n\n'.join(plot_summaries)
                    context["summarized_plot"] = combined_reference
                    # Override book_reference with combined results for pattern analysis
                    context["book_reference"] = combined_reference

                    self.logger.info(f"[CONTEXT] Pattern analysis step: {len(reference_works)} works, chapters={start_chapter}-{end_chapter}")
                except (ValueError, IndexError) as e:
                    self.logger.warning(f"[CONTEXT] Failed to parse pattern step_id '{current_step_id}': {e}")

        # Determine if this is a continuation of previous volume generation
        # (i.e., previous volume was generated in the same session)
        is_continuing_volume = False
        if state and vol_num > 1:
            steps = state.get('steps', [])
            current_index = state.get('current_step_index', 0) - 1

            # Find the previous volume's outline and characters step IDs
            prev_vol_outline_id = f'volume_{vol_num-1}'
            prev_vol_chars_id = f'volume_{vol_num-1}_characters'

            # Find indices of previous volume steps and current step
            prev_vol_outline_idx = None
            prev_vol_chars_idx = None
            current_step_idx = None

            for i, (s_id, _, _) in enumerate(steps):
                if s_id == prev_vol_outline_id:
                    prev_vol_outline_idx = i
                elif s_id == prev_vol_chars_id:
                    prev_vol_chars_idx = i
                elif s_id == current_step_id:
                    current_step_idx = i

            # Check if previous volume's characters step has been processed (completed)
            # This means we're continuing from previous volume in the same session
            if prev_vol_chars_idx is not None and current_step_idx is not None:
                if current_step_idx > prev_vol_chars_idx:
                    is_continuing_volume = True
                    self.logger.info(f"[CONTEXT] Volume {vol_num} is a continuation - previous volume {vol_num-1} was generated in same session")

        # Add volume-specific context for volume steps
        if 'volume_' in current_step_id and '_summary' not in current_step_id:
            # Add flag for continuation
            context['is_continuing_volume'] = '是' if is_continuing_volume else '否'

            # Add current volume outline - try work_data first, then disk
            volume_outline_key = f'volume_{vol_num}'
            volume_outline = work_data.get(volume_outline_key, '')
            if not volume_outline and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                volume_outline = self._load_volume_outline_from_disk(vol_num)
            context['current_volume_outline'] = volume_outline
            context['volume_outline'] = volume_outline

            # Add current volume characters - try work_data first, then disk
            volume_chars_key = f'volume_{vol_num}_characters'
            volume_chars = work_data.get(volume_chars_key, '')
            if not volume_chars and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                volume_chars = self._load_volume_characters_from_disk(vol_num)
            context['current_volume_characters'] = volume_chars
            context['volume_characters'] = volume_chars

            # Add previous volume outline if exists
            if vol_num > 1:
                prev_vol_outline = work_data.get(f'volume_{vol_num-1}', '')
                prev_vol_chars = work_data.get(f'volume_{vol_num-1}_characters', '')

                # If previous volume info is not in work_data (not generated in this session),
                # try to load from disk (steps directory)
                if not prev_vol_outline and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                    prev_vol_outline = self._load_volume_outline_from_disk(vol_num - 1)
                if not prev_vol_chars and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                    prev_vol_chars = self._load_volume_characters_from_disk(vol_num - 1)

                context['previous_volume_outline'] = prev_vol_outline
                context['previous_volume_characters'] = prev_vol_chars

            # Add previous 3 volumes' plot summary and character status for volume steps
            # This is used for "前 3 卷剧情总结" and "前 3 卷人物总结" placeholders
            previous_volumes_plot_summaries = []
            previous_volumes_character_statuses = []

            # Load up to 3 previous volumes' summaries
            for prev_vol in range(vol_num - 1, max(0, vol_num - 4), -1):
                prev_vol_summary = self._load_previous_volume_plot_summary_from_disk(prev_vol)
                if prev_vol_summary:
                    previous_volumes_plot_summaries.append(f"=== 第{prev_vol}卷 剧情总结 ===\n{prev_vol_summary}")
                    self.logger.info(f"[CONTEXT] Loaded volume {prev_vol} plot summary for volume step ({len(prev_vol_summary)} chars)")

                prev_vol_char_status = self._load_previous_volume_character_status_from_disk(prev_vol)
                if prev_vol_char_status:
                    previous_volumes_character_statuses.append(f"=== 第{prev_vol}卷 人物总结 ===\n{prev_vol_char_status}")
                    self.logger.info(f"[CONTEXT] Loaded volume {prev_vol} character status for volume step ({len(prev_vol_char_status)} chars)")

            # Combine previous 3 volumes' summaries
            if previous_volumes_plot_summaries:
                previous_volumes_plot_summary = "\n\n".join(previous_volumes_plot_summaries)
                self.logger.info(f"[CONTEXT] Combined {len(previous_volumes_plot_summaries)} previous volumes' plot summaries ({len(previous_volumes_plot_summary)} chars)")
            else:
                previous_volumes_plot_summary = ''

            if previous_volumes_character_statuses:
                previous_volumes_character_status = "\n\n".join(previous_volumes_character_statuses)
                self.logger.info(f"[CONTEXT] Combined {len(previous_volumes_character_statuses)} previous volumes' character statuses ({len(previous_volumes_character_status)} chars)")
            else:
                previous_volumes_character_status = ''

            context['previous_volumes_plot_summary'] = previous_volumes_plot_summary
            context['previous_volumes_character_status'] = previous_volumes_character_status

        # Add chapter-specific context for chapter steps
        if 'chapter_' in current_step_id:
            # Load previous chapter content if exists (within same volume)
            if chap_num > 1:
                # Try to load previous chapter content from current volume
                prev_chapter_content = work_data.get(f'volume_{vol_num}_chapter_{chap_num-1}_content', '')
                if not prev_chapter_content and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                    prev_chapter_content = self._load_chapter_content_from_disk(vol_num, chap_num - 1)
                context['previous_chapter_content'] = prev_chapter_content
                context['chapter_content'] = prev_chapter_content  # For template compatibility

                prev_chapter_outline = work_data.get(f'volume_{vol_num}_chapter_{chap_num-1}_outline', '')
                if not prev_chapter_outline and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                    prev_chapter_outline = self._load_chapter_outline_from_disk(vol_num, chap_num - 1)
                context['previous_chapter_outline'] = prev_chapter_outline

            # Add current chapter outline for chapter content steps
            if 'content' in current_step_id:
                chapter_outline_key = f'volume_{vol_num}_chapter_{chap_num}_outline'
                chapter_outline = work_data.get(chapter_outline_key, '')
                if not chapter_outline and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                    chapter_outline = self._load_chapter_outline_from_disk(vol_num, chap_num)
                context['chapter_outline'] = chapter_outline

            # Add volume outline and characters for chapter steps
            volume_outline_key = f'volume_{vol_num}'
            volume_outline = work_data.get(volume_outline_key, '')
            if not volume_outline and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                volume_outline = self._load_volume_outline_from_disk(vol_num)
            context['volume_outline'] = volume_outline

            volume_chars_key = f'volume_{vol_num}_characters'
            volume_chars = work_data.get(volume_chars_key, '')
            if not volume_chars and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                volume_chars = self._load_volume_characters_from_disk(vol_num)
            context['volume_characters'] = volume_chars

            # Load all previously generated chapters in current volume for context continuity
            # This is used for "断点续传" - when resuming from a midpoint, include all prior chapters
            if chap_num > 1:
                all_prior_chapters_content = self._load_current_volume_all_chapters_content(vol_num, chap_num - 1)
                if all_prior_chapters_content:
                    context['volume_all_chapters_content'] = all_prior_chapters_content
                    self.logger.info(f"[CONTEXT] Volume {vol_num} has {chap_num-1} prior chapters, loaded {len(all_prior_chapters_content)} chars for context")

        # Add plot summary and character status for chapter steps
        # This is used for "前序章节剧情梗概" and "前序章节人物状态" placeholders
        # Logic: Always load previous 3 volumes' summaries for maximum context continuity
        if 'chapter_' in current_step_id or '_summary_' in current_step_id:
            # Load previous 3 volumes' plot summaries
            previous_plot_summaries = []
            previous_character_statuses = []

            # Load up to 3 previous volumes' summaries
            for prev_vol in range(vol_num - 1, max(0, vol_num - 4), -1):
                prev_vol_summary = self._load_previous_volume_plot_summary_from_disk(prev_vol)
                if prev_vol_summary:
                    previous_plot_summaries.append(f"=== 第{prev_vol}卷 剧情总结 ===\n{prev_vol_summary}")
                    self.logger.info(f"[CONTEXT] Loaded volume {prev_vol} plot summary ({len(prev_vol_summary)} chars)")

                prev_vol_char_status = self._load_previous_volume_character_status_from_disk(prev_vol)
                if prev_vol_char_status:
                    previous_character_statuses.append(f"=== 第{prev_vol}卷 人物总结 ===\n{prev_vol_char_status}")
                    self.logger.info(f"[CONTEXT] Loaded volume {prev_vol} character status ({len(prev_vol_char_status)} chars)")

            # Combine previous 3 volumes' summaries
            if previous_plot_summaries:
                plot_summary = "\n\n".join(previous_plot_summaries)
                self.logger.info(f"[CONTEXT] Combined {len(previous_plot_summaries)} previous volumes' plot summaries ({len(plot_summary)} chars)")
            else:
                # Fallback to single previous volume or empty
                plot_summary = work_data.get('plot_summary', '')
                if not plot_summary and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                    plot_summary = self._load_plot_summary_from_disk()

            context['plot_summary'] = plot_summary
            context['previous_plot_summary'] = plot_summary

            if previous_character_statuses:
                char_status = "\n\n".join(previous_character_statuses)
                self.logger.info(f"[CONTEXT] Combined {len(previous_character_statuses)} previous volumes' character statuses ({len(char_status)} chars)")
            else:
                # Fallback to single previous volume or empty
                char_status = work_data.get('character_status', '')
                if not char_status and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                    char_status = self._load_character_status_from_disk()

            context['character_status'] = char_status
            context['previous_character_status'] = char_status

            # For summary steps (plot_summary, character_status), also need current chapter content
            # Load current chapter content for summary steps
            if current_step_id in ('plot_summary', 'character_status'):
                current_chapter_content = work_data.get(f'volume_{vol_num}_chapter_{chap_num}_content', '')
                if not current_chapter_content and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                    current_chapter_content = self._load_chapter_content_from_disk(vol_num, chap_num)
                context['chapter_content'] = current_chapter_content

            # For volume summary steps (volume_X_summary_plot, volume_X_summary_character),
            # need to load ALL chapters from the current volume and concatenate them
            if '_summary_' in current_step_id and 'volume_' in current_step_id:
                # Parse volume number from step_id: volume_X_summary_plot or volume_X_summary_character
                parts = current_step_id.split('_')
                if len(parts) >= 3:
                    try:
                        summary_vol_num = int(parts[1])
                        all_chapters_content = self._load_volume_all_chapters_content(summary_vol_num, chapters_per_volume)
                        context['chapter_content'] = all_chapters_content
                        context['volume_all_chapters_content'] = all_chapters_content
                    except (ValueError, IndexError):
                        pass

        # Add volume summary-specific context
        if '_summary_' in current_step_id:
            parts = current_step_id.split('_')
            if len(parts) >= 3:
                try:
                    vol_num = int(parts[1])
                    context['volume_number'] = str(vol_num)
                    context['current_volume'] = str(vol_num)

                    # Add current volume outline
                    volume_outline_key = f'volume_{vol_num}'
                    context['current_volume_outline'] = work_data.get(volume_outline_key, '')
                    context['volume_outline'] = work_data.get(volume_outline_key, '')

                    # Add previous volume summary if exists
                    if vol_num > 1:
                        # Try to load plot summary from disk
                        prev_vol_summary = self._load_previous_volume_plot_summary_from_disk(vol_num - 1)
                        context['previous_volume_summary'] = prev_vol_summary
                        # For character summary step, also add previous volume character status
                        if 'character' in current_step_id:
                            prev_vol_char_status = self._load_previous_volume_character_status_from_disk(vol_num - 1)
                            context['previous_volume_character_status'] = prev_vol_char_status
                except (ValueError, IndexError):
                    pass

        return context

    def _build_context_section(
        self,
        work_id: str,
        step_id: str,
        context: dict
    ) -> str:
        """
        Build context section string for a step type.

        This builds the part of the prompt that contains previous step outputs
        (like 文风设定, 故事梗概, etc.) that are used as context for the current step.

        Args:
            work_id: Work ID
            step_id: Step ID
            context: Generation context dictionary (from _build_generation_context)

        Returns:
            Context section string (e.g., "## 小说基本设定\\n小说类型：xxx\\n\\n## 已完成设定\\n...")
        """
        import re

        # Parse step type from step_id
        step_type = self._get_step_type_from_id(step_id)
        vol_num = context.get('current_volume', '1')
        chap_num = context.get('chapter_index', '1')
        try:
            vol_num_int = int(vol_num)
        except (ValueError, TypeError):
            vol_num_int = 1
        try:
            chap_num_int = int(chap_num)
        except (ValueError, TypeError):
            chap_num_int = 1

        lines = []

        # === 基本设定会话 ===
        if step_type == 'basic_style_setting':
            lines.append(f"# 任务：生成小说语言风格设定报告")
            lines.append("")
            lines.append("## 小说基本设定")
            lines.append("")
            lines.append(f"小说类型：{context.get('novel_type', '')}")
            if context.get('creation_guide'):
                lines.append(f"创作指导：{context.get('creation_guide', '')}")
            return '\n'.join(lines)

        if step_type == 'basic_story_summary':
            lines.append("# 任务：生成小说故事梗概")
            lines.append("")
            lines.append("## 小说基本设定")
            lines.append(f"小说类型：{context.get('novel_type', '')}")
            if context.get('creation_guide'):
                lines.append(f"创作指导：{context.get('creation_guide', '')}")
            lines.append("")
            lines.append("## 已完成设定")
            lines.append("")
            lines.append("文风设定：")
            lines.append(context.get('style_setting', ''))
            return '\n'.join(lines)

        if step_type == 'basic_worldbuilding':
            lines.append("# 任务：生成小说时空设定报告")
            lines.append("")
            lines.append("## 小说基本设定")
            lines.append(f"小说类型：{context.get('novel_type', '')}")
            if context.get('creation_guide'):
                lines.append(f"创作指导：{context.get('creation_guide', '')}")
            lines.append("")
            lines.append("## 已完成设定")
            lines.append("")
            lines.append("文风设定：")
            lines.append(context.get('style_setting', ''))
            lines.append("")
            lines.append("故事梗概：")
            lines.append(context.get('story_summary', ''))
            return '\n'.join(lines)

        if step_type == 'basic_character_design':
            lines.append("# 任务：生成小说人物设定报告")
            lines.append("")
            lines.append("## 小说基本设定")
            lines.append(f"小说类型：{context.get('novel_type', '')}")
            if context.get('creation_guide'):
                lines.append(f"创作指导：{context.get('creation_guide', '')}")
            lines.append("")
            lines.append("## 已完成设定")
            lines.append("")
            lines.append("文风设定：")
            lines.append(context.get('style_setting', ''))
            lines.append("")
            lines.append("故事梗概：")
            lines.append(context.get('story_summary', ''))
            lines.append("")
            lines.append("时空设定：")
            lines.append(context.get('worldbuilding', ''))
            return '\n'.join(lines)

        if step_type == 'basic_book_title':
            lines.append("# 任务：生成小说书名")
            lines.append("")
            lines.append("## 小说基本设定")
            lines.append(f"小说类型：{context.get('novel_type', '')}")
            lines.append("")
            lines.append("## 已完成设定")
            lines.append("")
            lines.append("文风设定：")
            lines.append(context.get('style_setting', ''))
            lines.append("")
            lines.append("故事梗概：")
            lines.append(context.get('story_summary', ''))
            lines.append("")
            lines.append("时空设定：")
            lines.append(context.get('worldbuilding', ''))
            lines.append("")
            lines.append("人物设定：")
            lines.append(context.get('character_design', ''))
            return '\n'.join(lines)

        if step_type == 'basic_cover_image':
            lines.append("# 任务：生成小说封面图片描述")
            lines.append("")
            lines.append("## 小说基本设定")
            lines.append(f"小说类型：{context.get('novel_type', '')}")
            lines.append("")
            lines.append("## 已完成设定")
            lines.append("")
            lines.append("文风设定：")
            lines.append(context.get('style_setting', ''))
            lines.append("")
            lines.append("故事梗概：")
            lines.append(context.get('story_summary', ''))
            lines.append("")
            lines.append("时空设定：")
            lines.append(context.get('worldbuilding', ''))
            lines.append("")
            lines.append("人物设定：")
            lines.append(context.get('character_design', ''))
            lines.append("")
            lines.append("书名：")
            lines.append(context.get('book_title', ''))
            return '\n'.join(lines)

        # === 拆书参考 ===
        if step_type == 'reference':
            parts = step_id.split('_')
            if len(parts) >= 4:
                try:
                    end_chapter = parts[-1]
                    start_chapter = parts[-2]
                    work_name = '_'.join(parts[1:-2])
                    # Restore original format
                    work_name = work_name.replace('_', '/')
                except (ValueError, IndexError):
                    work_name = '未知作品'
                    start_chapter = '1'
                    end_chapter = '15'
            else:
                work_name = '未知作品'
                start_chapter = '1'
                end_chapter = '15'

            lines.append(f"# 任务：分析参考作品第{start_chapter}-{end_chapter}章的创作规律")
            lines.append("")
            lines.append("## 参考作品信息")
            lines.append(f"作品名称：{work_name}")
            lines.append("")
            lines.append("## 参考作品内容")
            lines.append(context.get('novel_content', ''))
            return '\n'.join(lines)

        # === 创作公式 ===
        if step_type == 'pattern':
            lines.append("# 任务：基于拆书分析结果，总结创作公式")
            lines.append("")
            lines.append("## 参考作品分析结果")
            lines.append(context.get('summarized_plot', ''))
            return '\n'.join(lines)

        # === 分卷大纲 ===
        if step_type == 'volume':
            lines.append(f"# 任务：生成第{vol_num_int}卷的详细分卷大纲")
            lines.append("")
            lines.append("## 小说基本设定")
            lines.append(f"小说类型：{context.get('novel_type', '')}")
            lines.append("")
            lines.append("## 已完成设定")
            lines.append("")
            lines.append("故事梗概：")
            lines.append(context.get('story_summary', ''))
            lines.append("")
            lines.append("时空设定：")
            lines.append(context.get('worldbuilding', ''))
            lines.append("")
            lines.append("人物设定：")
            lines.append(context.get('character_design', ''))
            lines.append("")
            lines.append("创作公式：")
            lines.append(context.get('pattern_analysis', ''))
            lines.append("")
            lines.append("## 前序卷剧情总结（最多前3卷）")

            for prev_vol in range(max(1, vol_num_int - 3), vol_num_int):
                plot_key = f'volume_{prev_vol}_summary_plot'
                char_key = f'volume_{prev_vol}_summary_character'
                if context.get(plot_key):
                    lines.append("")
                    lines.append(f"=== 第{prev_vol}卷 剧情总结 ===")
                    lines.append(context.get(plot_key, ''))
                    lines.append(f"=== 第{prev_vol}卷 人物总结 ===")
                    lines.append(context.get(char_key, ''))

            return '\n'.join(lines)

        # === 分卷人物 ===
        if step_type == 'volume_characters':
            lines.append(f"# 任务：生成第{vol_num_int}卷的分卷人物设定")
            lines.append("")
            lines.append("## 小说基本设定")
            lines.append(f"小说类型：{context.get('novel_type', '')}")
            lines.append("")
            lines.append("## 已完成设定")
            lines.append("")
            lines.append("故事梗概：")
            lines.append(context.get('story_summary', ''))
            lines.append("")
            lines.append("时空设定：")
            lines.append(context.get('worldbuilding', ''))
            lines.append("")
            lines.append("人物设定：")
            lines.append(context.get('character_design', ''))
            lines.append("")
            lines.append("创作公式：")
            lines.append(context.get('pattern_analysis', ''))
            lines.append("")
            lines.append("## 前序卷剧情和人物总结（最多前3卷）")

            for prev_vol in range(max(1, vol_num_int - 3), vol_num_int):
                plot_key = f'volume_{prev_vol}_summary_plot'
                char_key = f'volume_{prev_vol}_summary_character'
                if context.get(plot_key):
                    lines.append("")
                    lines.append(f"=== 第{prev_vol}卷 剧情总结 ===")
                    lines.append(context.get(plot_key, ''))
                    lines.append(f"=== 第{prev_vol}卷 人物总结 ===")
                    lines.append(context.get(char_key, ''))

            lines.append("")
            lines.append("## 本卷大纲")
            lines.append(context.get('volume_outline', ''))
            return '\n'.join(lines)

        # === 章节大纲 ===
        if step_type == 'chapter_outline':
            lines.append(f"# 任务：生成第{vol_num_int}卷第{chap_num_int}章的章节大纲")
            lines.append("")
            lines.append("## 小说基本设定")
            lines.append(f"小说类型：{context.get('novel_type', '')}")
            lines.append("")
            lines.append("## 已完成设定")
            lines.append("")
            lines.append("故事梗概：")
            lines.append(context.get('story_summary', ''))
            lines.append("")
            lines.append("时空设定：")
            lines.append(context.get('worldbuilding', ''))
            lines.append("")
            lines.append("人物设定：")
            lines.append(context.get('character_design', ''))
            lines.append("")
            lines.append("创作公式：")
            lines.append(context.get('pattern_analysis', ''))
            lines.append("")
            lines.append("## 前序卷剧情和人物总结（最多前3卷）")

            for prev_vol in range(max(1, vol_num_int - 3), vol_num_int):
                plot_key = f'volume_{prev_vol}_summary_plot'
                char_key = f'volume_{prev_vol}_summary_character'
                if context.get(plot_key):
                    lines.append("")
                    lines.append(f"=== 第{prev_vol}卷 剧情总结 ===")
                    lines.append(context.get(plot_key, ''))
                    lines.append(f"=== 第{prev_vol}卷 人物总结 ===")
                    lines.append(context.get(char_key, ''))

            lines.append("")
            lines.append("## 本卷分卷大纲和人物")
            lines.append("")
            lines.append(f"=== 第{vol_num_int}卷 分卷大纲 ===")
            lines.append(context.get('volume_outline', ''))
            lines.append(f"=== 第{vol_num_int}卷 分卷人物 ===")
            lines.append(context.get('volume_characters', ''))
            lines.append("")
            lines.append("## 前序章节信息")

            if context.get('previous_chapter_outline'):
                lines.append(f"=== 第{vol_num_int}卷 第{chap_num_int-1}章 章节大纲 ===")
                lines.append(context.get('previous_chapter_outline', ''))
                lines.append(f"=== 第{vol_num_int}卷 第{chap_num_int-1}章 章节正文 ===")
                lines.append(context.get('previous_chapter_content', ''))

            return '\n'.join(lines)

        # === 章节正文 ===
        if step_type == 'chapter_content':
            lines.append(f"# 任务：生成第{vol_num_int}卷第{chap_num_int}章的章节正文")
            lines.append("")
            lines.append("## 小说基本设定")
            lines.append(f"小说类型：{context.get('novel_type', '')}")
            lines.append("")
            lines.append("## 已完成设定")
            lines.append("")
            lines.append("故事梗概：")
            lines.append(context.get('story_summary', ''))
            lines.append("")
            lines.append("时空设定：")
            lines.append(context.get('worldbuilding', ''))
            lines.append("")
            lines.append("人物设定：")
            lines.append(context.get('character_design', ''))
            lines.append("")
            lines.append("创作公式：")
            lines.append(context.get('pattern_analysis', ''))
            lines.append("")
            lines.append("## 前序卷剧情和人物总结（最多前3卷）")

            for prev_vol in range(max(1, vol_num_int - 3), vol_num_int):
                plot_key = f'volume_{prev_vol}_summary_plot'
                char_key = f'volume_{prev_vol}_summary_character'
                if context.get(plot_key):
                    lines.append("")
                    lines.append(f"=== 第{prev_vol}卷 剧情总结 ===")
                    lines.append(context.get(plot_key, ''))
                    lines.append(f"=== 第{prev_vol}卷 人物总结 ===")
                    lines.append(context.get(char_key, ''))

            lines.append("")
            lines.append("## 本卷分卷大纲和人物")
            lines.append("")
            lines.append(f"=== 第{vol_num_int}卷 分卷大纲 ===")
            lines.append(context.get('volume_outline', ''))
            lines.append(f"=== 第{vol_num_int}卷 分卷人物 ===")
            lines.append(context.get('volume_characters', ''))
            lines.append("")
            lines.append("## 前序章节信息")

            if context.get('previous_chapter_outline'):
                lines.append(f"=== 第{vol_num_int}卷 第{chap_num_int-1}章 章节大纲 ===")
                lines.append(context.get('previous_chapter_outline', ''))
                lines.append(f"=== 第{vol_num_int}卷 第{chap_num_int-1}章 章节正文 ===")
                lines.append(context.get('previous_chapter_content', ''))

            lines.append("")
            lines.append("## 本章章节大纲")
            lines.append(context.get('chapter_outline', ''))
            return '\n'.join(lines)

        # === 章节标题 ===
        if step_type == 'chapter_title':
            lines.append(f"# 任务：生成第{vol_num_int}卷第{chap_num_int}章的章节标题")
            lines.append("")
            lines.append("## 本章章节正文")
            lines.append(context.get('chapter_content', ''))
            return '\n'.join(lines)

        # === 剧情总结 ===
        if step_type == 'summary_plot':
            lines.append(f"# 任务：生成第{vol_num_int}卷的剧情总结")
            lines.append("")
            lines.append("## 小说基本设定")
            lines.append(f"小说类型：{context.get('novel_type', '')}")
            lines.append("")
            lines.append("## 已完成设定")
            lines.append("")
            lines.append("故事梗概：")
            lines.append(context.get('story_summary', ''))
            lines.append("")
            lines.append("时空设定：")
            lines.append(context.get('worldbuilding', ''))
            lines.append("")
            lines.append("人物设定：")
            lines.append(context.get('character_design', ''))
            lines.append("")
            lines.append("创作公式：")
            lines.append(context.get('pattern_analysis', ''))
            lines.append("")
            lines.append("## 前序卷剧情和人物总结（最多前3卷）")

            for prev_vol in range(max(1, vol_num_int - 3), vol_num_int):
                plot_key = f'volume_{prev_vol}_summary_plot'
                char_key = f'volume_{prev_vol}_summary_character'
                if context.get(plot_key):
                    lines.append("")
                    lines.append(f"=== 第{prev_vol}卷 剧情总结 ===")
                    lines.append(context.get(plot_key, ''))
                    lines.append(f"=== 第{prev_vol}卷 人物总结 ===")
                    lines.append(context.get(char_key, ''))

            lines.append("")
            lines.append("## 本卷分卷大纲和人物")
            lines.append("")
            lines.append(f"=== 第{vol_num_int}卷 分卷大纲 ===")
            lines.append(context.get('volume_outline', ''))
            lines.append(f"=== 第{vol_num_int}卷 分卷人物 ===")
            lines.append(context.get('volume_characters', ''))
            lines.append("")
            lines.append("## 本卷所有章节")

            chapters = context.get('all_chapters', [])
            for ch in chapters:
                lines.append(f"=== 第{vol_num_int}卷 第{ch['num']}章 大纲 ===")
                lines.append(ch['outline'])
                lines.append(f"=== 第{vol_num_int}卷 第{ch['num']}章 正文 ===")
                lines.append(ch['content'])

            return '\n'.join(lines)

        # === 人物总结 ===
        if step_type == 'summary_character':
            lines.append(f"# 任务：生成第{vol_num_int}卷的人物状态总结")
            lines.append("")
            lines.append("## 小说基本设定")
            lines.append(f"小说类型：{context.get('novel_type', '')}")
            lines.append("")
            lines.append("## 已完成设定")
            lines.append("")
            lines.append("故事梗概：")
            lines.append(context.get('story_summary', ''))
            lines.append("")
            lines.append("时空设定：")
            lines.append(context.get('worldbuilding', ''))
            lines.append("")
            lines.append("人物设定：")
            lines.append(context.get('character_design', ''))
            lines.append("")
            lines.append("创作公式：")
            lines.append(context.get('pattern_analysis', ''))
            lines.append("")
            lines.append("## 前序卷剧情和人物总结（最多前3卷）")

            for prev_vol in range(max(1, vol_num_int - 3), vol_num_int):
                plot_key = f'volume_{prev_vol}_summary_plot'
                char_key = f'volume_{prev_vol}_summary_character'
                if context.get(plot_key):
                    lines.append("")
                    lines.append(f"=== 第{prev_vol}卷 剧情总结 ===")
                    lines.append(context.get(plot_key, ''))
                    lines.append(f"=== 第{prev_vol}卷 人物总结 ===")
                    lines.append(context.get(char_key, ''))

            lines.append("")
            lines.append("## 本卷分卷大纲和人物")
            lines.append("")
            lines.append(f"=== 第{vol_num_int}卷 分卷大纲 ===")
            lines.append(context.get('volume_outline', ''))
            lines.append(f"=== 第{vol_num_int}卷 分卷人物 ===")
            lines.append(context.get('volume_characters', ''))
            lines.append("")
            lines.append("## 本卷所有章节")

            chapters = context.get('all_chapters', [])
            for ch in chapters:
                lines.append(f"=== 第{vol_num_int}卷 第{ch['num']}章 大纲 ===")
                lines.append(ch['outline'])
                lines.append(f"=== 第{vol_num_int}卷 第{ch['num']}章 正文 ===")
                lines.append(ch['content'])

            return '\n'.join(lines)

        # Default: return empty string
        return ""

    def _get_step_type_from_id(self, step_id: str) -> str:
        """
        Determine step type from step_id.

        Args:
            step_id: Step identifier

        Returns:
            Step type string (e.g., 'basic_style_setting', 'chapter_outline', etc.)
        """
        import re

        # Basic steps
        if step_id in ['style_setting', 'book_title', 'story_summary', 'worldbuilding', 'character_design', 'cover_image']:
            if step_id == 'style_setting':
                return 'basic_style_setting'
            elif step_id == 'story_summary':
                return 'basic_story_summary'
            elif step_id == 'worldbuilding':
                return 'basic_worldbuilding'
            elif step_id == 'character_design':
                return 'basic_character_design'
            elif step_id == 'book_title':
                return 'basic_book_title'
            elif step_id == 'cover_image':
                return 'basic_cover_image'

        # Reference and pattern
        if step_id.startswith('reference_'):
            return 'reference'
        if step_id.startswith('pattern_'):
            return 'pattern'

        # Volume steps
        if '_characters' in step_id and step_id.startswith('volume_'):
            return 'volume_characters'
        if '_summary_plot' in step_id:
            return 'summary_plot'
        if '_summary_character' in step_id:
            return 'summary_character'
        if step_id.startswith('volume_'):
            return 'volume'

        # Chapter steps
        if '_title' in step_id:
            return 'chapter_title'
        if '_outline' in step_id:
            return 'chapter_outline'
        if '_content' in step_id:
            return 'chapter_content'

        return 'unknown'

    def _load_volume_outline_from_disk(self, vol_num: int) -> str:
        """
        Load volume outline from disk (steps directory).

        Args:
            vol_num: Volume number to load outline for

        Returns:
            Volume outline content or empty string if not found
        """
        if not hasattr(self, 'creation_view') or not self.creation_view.current_work_id:
            return ''

        try:
            from pathlib import Path
            work_dir = Path(self.settings.works_dir) / self.creation_view.current_work_id
            steps_dir = work_dir / 'steps'
            outline_file = steps_dir / f'volume_{vol_num}.txt'

            if outline_file.exists():
                with open(outline_file, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                self.logger.info(f"[LOAD_VOLUME] Loaded volume {vol_num} outline from disk ({len(content)} chars)")
                return content
        except Exception as e:
            self.logger.error(f"[LOAD_VOLUME] Failed to load volume outline: {e}")

        return ''

    def _load_volume_characters_from_disk(self, vol_num: int) -> str:
        """
        Load volume characters from disk (steps directory).

        Args:
            vol_num: Volume number to load characters for

        Returns:
            Volume characters content or empty string if not found
        """
        if not hasattr(self, 'creation_view') or not self.creation_view.current_work_id:
            return ''

        try:
            from pathlib import Path
            work_dir = Path(self.settings.works_dir) / self.creation_view.current_work_id
            steps_dir = work_dir / 'steps'
            characters_file = steps_dir / f'volume_{vol_num}_characters.txt'

            if characters_file.exists():
                with open(characters_file, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                self.logger.info(f"[LOAD_VOLUME] Loaded volume {vol_num} characters from disk ({len(content)} chars)")
                return content
        except Exception as e:
            self.logger.error(f"[LOAD_VOLUME] Failed to load volume characters: {e}")

        return ''

    def _load_chapter_outline_from_disk(self, vol_num: int, chap_num: int) -> str:
        """
        Load chapter outline from disk (steps directory).

        Args:
            vol_num: Volume number
            chap_num: Chapter number

        Returns:
            Chapter outline content or empty string if not found
        """
        if not hasattr(self, 'creation_view') or not self.creation_view.current_work_id:
            return ''

        try:
            from pathlib import Path
            work_dir = Path(self.settings.works_dir) / self.creation_view.current_work_id
            steps_dir = work_dir / 'steps'
            # File format: chapter_{vol_num}_{chap_num}_outline.txt
            outline_file = steps_dir / f'chapter_{vol_num}_{chap_num}_outline.txt'

            if outline_file.exists():
                with open(outline_file, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                self.logger.info(f"[LOAD_CHAPTER] Loaded volume {vol_num} chapter {chap_num} outline from disk ({len(content)} chars)")
                return content
        except Exception as e:
            self.logger.error(f"[LOAD_CHAPTER] Failed to load chapter outline: {e}")

        return ''

    def _load_chapter_content_from_disk(self, vol_num: int, chap_num: int) -> str:
        """
        Load chapter content from disk (steps directory).

        Args:
            vol_num: Volume number
            chap_num: Chapter number

        Returns:
            Chapter content or empty string if not found
        """
        if not hasattr(self, 'creation_view') or not self.creation_view.current_work_id:
            return ''

        try:
            from pathlib import Path
            work_dir = Path(self.settings.works_dir) / self.creation_view.current_work_id
            steps_dir = work_dir / 'steps'
            # File format: chapter_{vol_num}_{chap_num}_content.txt
            content_file = steps_dir / f'chapter_{vol_num}_{chap_num}_content.txt'

            if content_file.exists():
                with open(content_file, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                self.logger.info(f"[LOAD_CHAPTER] Loaded volume {vol_num} chapter {chap_num} content from disk ({len(content)} chars)")
                return content
        except Exception as e:
            self.logger.error(f"[LOAD_CHAPTER] Failed to load chapter content: {e}")

        return ''

    def _load_plot_summary_from_disk(self) -> str:
        """
        Load plot summary from disk (steps directory).

        Returns:
            Plot summary content or empty string if not found
        """
        if not hasattr(self, 'creation_view') or not self.creation_view.current_work_id:
            return ''

        try:
            from pathlib import Path
            work_dir = Path(self.settings.works_dir) / self.creation_view.current_work_id
            steps_dir = work_dir / 'steps'
            summary_file = steps_dir / 'plot_summary.txt'

            if summary_file.exists():
                with open(summary_file, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                self.logger.info(f"[LOAD_SUMMARY] Loaded plot summary from disk ({len(content)} chars)")
                return content
        except Exception as e:
            self.logger.error(f"[LOAD_SUMMARY] Failed to load plot summary: {e}")

        return ''

    def _load_character_status_from_disk(self) -> str:
        """
        Load character status from disk (steps directory).

        Returns:
            Character status content or empty string if not found
        """
        if not hasattr(self, 'creation_view') or not self.creation_view.current_work_id:
            return ''

        try:
            from pathlib import Path
            work_dir = Path(self.settings.works_dir) / self.creation_view.current_work_id
            steps_dir = work_dir / 'steps'
            status_file = steps_dir / 'character_status.txt'

            if status_file.exists():
                with open(status_file, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                self.logger.info(f"[LOAD_SUMMARY] Loaded character status from disk ({len(content)} chars)")
                return content
        except Exception as e:
            self.logger.error(f"[LOAD_SUMMARY] Failed to load character status: {e}")

        return ''

    def _load_volume_all_chapters_content(self, vol_num: int, chapters_per_volume: int) -> str:
        """
        Load all chapters content from a volume and concatenate them.

        Args:
            vol_num: Volume number
            chapters_per_volume: Number of chapters in the volume

        Returns:
            Concatenated content of all chapters in the volume, or empty string if not found
        """
        if not hasattr(self, 'creation_view') or not self.creation_view.current_work_id:
            return ''

        try:
            from pathlib import Path
            work_dir = Path(self.settings.works_dir) / self.creation_view.current_work_id
            steps_dir = work_dir / 'steps'

            chapter_contents = []
            for chap_num in range(1, chapters_per_volume + 1):
                # File format: chapter_{vol_num}_{chap_num}_content.txt
                content_file = steps_dir / f'chapter_{vol_num}_{chap_num}_content.txt'
                if content_file.exists():
                    with open(content_file, 'r', encoding='utf-8') as f:
                        content = f.read().strip()
                    if content:
                        chapter_contents.append(f"=== 第{vol_num}卷 第{chap_num}章 ===\n{content}")
                        self.logger.info(f"[LOAD_VOLUME_CONTENT] Loaded volume {vol_num} chapter {chap_num} ({len(content)} chars)")

            all_content = "\n\n".join(chapter_contents)
            self.logger.info(f"[LOAD_VOLUME_CONTENT] Volume {vol_num} total {len(chapter_contents)} chapters, {len(all_content)} chars")
            return all_content
        except Exception as e:
            self.logger.error(f"[LOAD_VOLUME_CONTENT] Failed to load volume content: {e}")

        return ''

    def _load_current_volume_all_chapters_content(self, vol_num: int, up_to_chapter: int) -> str:
        """
        Load all chapters content from current volume up to specified chapter.

        This is used for "断点续传" - when resuming generation from a midpoint,
        include all prior chapters in the current volume for context continuity.

        Args:
            vol_num: Volume number
            up_to_chapter: Load chapters from 1 to this chapter (inclusive)

        Returns:
            Concatenated content of chapters 1 to up_to_chapter, or empty string if not found
        """
        if not hasattr(self, 'creation_view') or not self.creation_view.current_work_id:
            return ''

        try:
            from pathlib import Path
            work_dir = Path(self.settings.works_dir) / self.creation_view.current_work_id
            steps_dir = work_dir / 'steps'

            chapter_contents = []
            for chap_num in range(1, up_to_chapter + 1):
                # File format: chapter_{vol_num}_{chap_num}_content.txt
                content_file = steps_dir / f'chapter_{vol_num}_{chap_num}_content.txt'
                if content_file.exists():
                    with open(content_file, 'r', encoding='utf-8') as f:
                        content = f.read().strip()
                    if content:
                        chapter_contents.append(f"=== 第{vol_num}卷 第{chap_num}章 ===\n{content}")
                        self.logger.info(f"[LOAD_CURRENT_VOLUME_CONTENT] Loaded volume {vol_num} chapter {chap_num} ({len(content)} chars)")

            if not chapter_contents:
                self.logger.info(f"[LOAD_CURRENT_VOLUME_CONTENT] Volume {vol_num} has no chapters 1-{up_to_chapter} yet")
                return ''

            all_content = "\n\n".join(chapter_contents)
            self.logger.info(f"[LOAD_CURRENT_VOLUME_CONTENT] Volume {vol_num} loaded {len(chapter_contents)}/{up_to_chapter} chapters, {len(all_content)} chars")
            return all_content
        except Exception as e:
            self.logger.error(f"[LOAD_CURRENT_VOLUME_CONTENT] Failed to load current volume content: {e}")

        return ''

    def _load_previous_volume_plot_summary_from_disk(self, vol_num: int) -> str:
        """
        Load previous volume plot summary from disk (steps directory).

        Args:
            vol_num: Volume number to load summary for

        Returns:
            Previous volume plot summary content or empty string if not found
        """
        if not hasattr(self, 'creation_view') or not self.creation_view.current_work_id:
            return ''

        try:
            from pathlib import Path
            work_dir = Path(self.settings.works_dir) / self.creation_view.current_work_id
            steps_dir = work_dir / 'steps'
            summary_file = steps_dir / f'volume_{vol_num}_summary_plot.txt'

            if summary_file.exists():
                with open(summary_file, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                self.logger.info(f"[LOAD_VOLUME_SUMMARY] Loaded volume {vol_num} plot summary from disk ({len(content)} chars)")
                return content
        except Exception as e:
            self.logger.error(f"[LOAD_VOLUME_SUMMARY] Failed to load volume plot summary: {e}")

        return ''

    def _load_previous_volume_character_status_from_disk(self, vol_num: int) -> str:
        """
        Load previous volume character status from disk (steps directory).

        Args:
            vol_num: Volume number to load character status for

        Returns:
            Previous volume character status content or empty string if not found
        """
        if not hasattr(self, 'creation_view') or not self.creation_view.current_work_id:
            return ''

        try:
            from pathlib import Path
            work_dir = Path(self.settings.works_dir) / self.creation_view.current_work_id
            steps_dir = work_dir / 'steps'
            status_file = steps_dir / f'volume_{vol_num}_summary_character.txt'

            if status_file.exists():
                with open(status_file, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                self.logger.info(f"[LOAD_VOLUME_STATUS] Loaded volume {vol_num} character status from disk ({len(content)} chars)")
                return content
        except Exception as e:
            self.logger.error(f"[LOAD_VOLUME_STATUS] Failed to load volume character status: {e}")

        return ''

    def _build_volume_input_context(self, work_data: dict, current_vol: int, state: dict = None, step_id: str = None) -> dict:
        """
        Build context dictionary for volume input step.

        This method gathers all necessary context for the volume input step:
        - Novel basic settings (type, title, story summary, worldbuilding, characters)
        - Previous 3 volumes' plot summaries and character statuses
        - Volume range information

        Args:
            work_data: Work data dictionary
            current_vol: Current volume number being generated
            state: Generation state dictionary (optional, for start/end_volume)

        Returns:
            Context dictionary for volume input message
        """
        # Get volume range from work_data or state
        start_volume = work_data.get('start_volume') or (state.get('start_volume') if state else None) or 1
        end_volume = work_data.get('end_volume') or (state.get('end_volume') if state else None) or 1

        # Build context with basic novel settings
        context = {
            'novel_type': work_data.get('category', ''),
            'book_title': work_data.get('title', ''),
            'story_summary': '',
            'worldbuilding': '',
            'characters': '',
            'start_volume': start_volume,
            'end_volume': end_volume,
            'previous_volumes_plot_summary': '',
            'previous_volumes_character_status': '',
        }

        # Load story summary from disk
        if hasattr(self, 'creation_view') and self.creation_view.current_work_id:
            summary_content = self.work_manager.load_step_content(
                self.creation_view.current_work_id, 'story_summary'
            )
            if summary_content:
                context['story_summary'] = summary_content

            # Load worldbuilding from disk
            world_content = self.work_manager.load_step_content(
                self.creation_view.current_work_id, 'worldbuilding'
            )
            if world_content:
                context['worldbuilding'] = world_content

            # Load character design from disk
            char_content = self.work_manager.load_step_content(
                self.creation_view.current_work_id, 'character_design'
            )
            if char_content:
                context['characters'] = char_content

        # Load previous 3 volumes' summaries for context continuity
        previous_volumes_plot_summaries = []
        previous_volumes_character_statuses = []

        for prev_vol in range(current_vol - 1, max(0, current_vol - 4), -1):
            prev_vol_summary = self._load_previous_volume_plot_summary_from_disk(prev_vol)
            if prev_vol_summary:
                previous_volumes_plot_summaries.append(
                    f"=== 第{prev_vol}卷 剧情总结 ===\n{prev_vol_summary}"
                )

            prev_vol_char_status = self._load_previous_volume_character_status_from_disk(prev_vol)
            if prev_vol_char_status:
                previous_volumes_character_statuses.append(
                    f"=== 第{prev_vol}卷 人物总结 ===\n{prev_vol_char_status}"
                )

        if previous_volumes_plot_summaries:
            context['previous_volumes_plot_summary'] = "\n\n".join(previous_volumes_plot_summaries)

        if previous_volumes_character_statuses:
            context['previous_volumes_character_status'] = "\n\n".join(previous_volumes_character_statuses)

        # Load completed volume outlines and characters within the task range
        # This is for 断点续传 - when resuming from volume_X_characters, we need to include
        # previously generated volume info (volume_1, volume_1_characters, volume_2, etc.)
        completed_volume_infos = []
        for vol in range(start_volume, end_volume + 1):
            # Check volume outline
            if vol < current_vol or (vol == current_vol and step_id.endswith('_characters')):
                # This volume's outline should be included (already generated or will be generated before current step)
                vol_outline_id = f"volume_{vol}"
                vol_outline_content = work_data.get(vol_outline_id, '')

                # Load from disk if not in work_data
                if not vol_outline_content and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                    vol_outline_content = self.work_manager.load_step_content(
                        self.creation_view.current_work_id, vol_outline_id
                    )

                if vol_outline_content:
                    completed_volume_infos.append(f"=== 第{vol}卷 分卷大纲 ===\n{vol_outline_content}")

                # Check volume characters (only if this is NOT the current step)
                if vol < current_vol or not step_id.endswith('_characters'):
                    vol_chars_id = f"volume_{vol}_characters"
                    vol_chars_content = work_data.get(vol_chars_id, '')

                    # Load from disk if not in work_data
                    if not vol_chars_content and hasattr(self, 'creation_view') and self.creation_view.current_work_id:
                        vol_chars_content = self.work_manager.load_step_content(
                            self.creation_view.current_work_id, vol_chars_id
                        )

                    if vol_chars_content:
                        completed_volume_infos.append(f"=== 第{vol}卷 分卷人物 ===\n{vol_chars_content}")

        if completed_volume_infos:
            context['completed_volume_infos'] = "\n\n".join(completed_volume_infos)
        else:
            context['completed_volume_infos'] = ''

        self.logger.info(
            f"[VOLUME_INPUT] Built context for volume {current_vol}: "
            f"story_summary={len(context['story_summary'])} chars, "
            f"worldbuilding={len(context['worldbuilding'])} chars, "
            f"characters={len(context['characters'])} chars, "
            f"previous_volumes_plot_summary={len(context['previous_volumes_plot_summary'])} chars, "
            f"previous_volumes_character_status={len(context['previous_volumes_character_status'])} chars, "
            f"completed_volume_infos={len(context['completed_volume_infos'])} chars"
        )

        return context

    def _build_chapter_input_context(self, work_data: dict, chapter_vol: int, chapter_num: int, state: dict) -> dict:
        """
        Build context dictionary for chapter input step.

        This method gathers all necessary context for the chapter input step:
        - Novel basic settings (type, title, worldbuilding)
        - Volume outline and characters
        - Previous chapters context (plot summary, character status, or prior chapters content)

        Args:
            work_data: Work data dictionary
            chapter_vol: Volume number for the chapter
            chapter_num: Chapter number being generated
            state: Generation state dictionary

        Returns:
            Context dictionary for chapter input message
        """
        total_volumes = work_data.get('total_volumes', 1)

        # Build context with basic novel settings
        context = {
            'novel_type': work_data.get('category', ''),
            'book_title': work_data.get('title', ''),
            'worldbuilding': '',
            'total_volumes': str(total_volumes),
            'current_volume': str(chapter_vol),
            'chapter_index': str(chapter_num),
            'previous_chapter_index': str(max(0, chapter_num - 1)),
            'chapters_per_volume': str(work_data.get('chapters_per_volume', 20)),
            'volume_outline': '',
            'volume_characters': '',
            'plot_summary': '',
            'character_status': '',
            'volume_all_chapters_content': '',
        }

        # Load worldbuilding from disk
        if hasattr(self, 'creation_view') and self.creation_view.current_work_id:
            world_content = self.work_manager.load_step_content(
                self.creation_view.current_work_id, 'worldbuilding'
            )
            if world_content:
                context['worldbuilding'] = world_content

            # Load volume outline from disk
            volume_outline = self._load_volume_outline_from_disk(chapter_vol)
            if volume_outline:
                context['volume_outline'] = volume_outline

            # Load volume characters from disk
            volume_chars = self._load_volume_characters_from_disk(chapter_vol)
            if volume_chars:
                context['volume_characters'] = volume_chars

        # Determine if this is the first chapter of the volume or a midpoint resume
        is_first_chapter = (chapter_num == 1)

        if is_first_chapter:
            # For first chapter, load previous volume's summaries
            if chapter_vol > 1:
                prev_vol_summary = self._load_previous_volume_plot_summary_from_disk(chapter_vol - 1)
                if prev_vol_summary:
                    context['plot_summary'] = prev_vol_summary

                prev_vol_char_status = self._load_previous_volume_character_status_from_disk(chapter_vol - 1)
                if prev_vol_char_status:
                    context['character_status'] = prev_vol_char_status
        else:
            # For midpoint resume, load current volume's prior chapters content
            if chapter_num > 1:
                prior_chapters_content = self._load_current_volume_all_chapters_content(chapter_vol, chapter_num - 1)
                if prior_chapters_content:
                    context['volume_all_chapters_content'] = prior_chapters_content

                # Also load plot summary and character status from previous volume
                if chapter_vol > 1:
                    prev_vol_summary = self._load_previous_volume_plot_summary_from_disk(chapter_vol - 1)
                    if prev_vol_summary:
                        context['plot_summary'] = prev_vol_summary

                    prev_vol_char_status = self._load_previous_volume_character_status_from_disk(chapter_vol - 1)
                    if prev_vol_char_status:
                        context['character_status'] = prev_vol_char_status

        self.logger.info(
            f"[CHAPTER_INPUT] Built context for volume {chapter_vol} chapter {chapter_num}: "
            f"worldbuilding={len(context['worldbuilding'])} chars, "
            f"volume_outline={len(context['volume_outline'])} chars, "
            f"volume_characters={len(context['volume_characters'])} chars, "
            f"plot_summary={len(context['plot_summary'])} chars, "
            f"character_status={len(context['character_status'])} chars, "
            f"volume_all_chapters_content={len(context['volume_all_chapters_content'])} chars"
        )

        return context

    def _build_simple_output_prompt(self, step_id: str, step_name: str, template_category: str) -> str:
        """
        Build simple output prompt for volume/chapter steps.

        For volume and chapter output steps, the context has already been sent
        in the input phase. So the output prompt only needs to specify what to
        generate and the format requirements from the template.

        Args:
            step_id: Step ID
            step_name: Step name
            template_category: Template category

        Returns:
            Simple prompt string
        """
        # Parse volume and chapter numbers from step_id
        vol_num = 1
        chap_num = 1

        if 'volume_' in step_id and '_summary' not in step_id:
            parts = step_id.split('_')
            if len(parts) >= 2:
                try:
                    vol_num = int(parts[1])
                except (ValueError, IndexError):
                    pass

        if 'chapter_' in step_id:
            parts = step_id.split('_')
            if len(parts) >= 3:
                try:
                    vol_num = int(parts[1])
                    chap_num = int(parts[2].replace('outline', '').replace('content', ''))
                except (ValueError, IndexError):
                    pass

        # Get template content to extract format requirements
        template = self.template_service.get_template(template_category)
        template_content = template.content if template else ""

        # Extract output format section from template
        format_section = self._extract_format_section(template_content)

        # Build context for placeholder replacement
        context = self._build_simple_context(vol_num, chap_num)

        # Replace placeholders in format section
        format_section = self._replace_placeholders(format_section, context)

        # Build simple prompts based on template category
        if template_category == '分卷大纲':
            return f"""请基于以上上下文信息，生成第{vol_num}卷的分卷大纲。

{format_section}"""

        elif template_category == '分卷人物':
            return f"""请基于以上上下文信息，生成第{vol_num}卷的分卷人物设定。

{format_section}"""

        elif template_category == '章节大纲':
            return f"""请基于以上上下文信息，生成第{vol_num}卷第{chap_num}章的章节大纲。

{format_section}"""

        elif template_category == '章节正文':
            return f"""请基于以上上下文信息，生成第{vol_num}卷第{chap_num}章的章节正文。

{format_section}"""

        elif template_category == '分卷剧情总结':
            return f"""请基于以上上下文信息，生成第{vol_num}卷的剧情总结。

{format_section}"""

        elif template_category == '分卷人物总结':
            return f"""请基于以上上下文信息，生成第{vol_num}卷的人物总结。

{format_section}"""

        # Default fallback
        return f"""请基于以上上下文信息，完成{step_name}。

输出格式要求：
- 纯文本格式
- 不要有 Markdown 标记"""

    def _build_simple_context(self, vol_num: int, chap_num: int) -> dict:
        """
        Build simple context for placeholder replacement.

        Args:
            vol_num: Volume number
            chap_num: Chapter number

        Returns:
            Context dictionary for placeholder replacement
        """
        # Get work data from creation task
        work_data = {}
        if hasattr(self, 'creation_view') and self.creation_view:
            if self.creation_view.creation_task:
                work_data = self.creation_view.creation_task.work_data

        total_volumes = work_data.get('total_volumes', 1)
        chapters_per_volume = work_data.get('chapters_per_volume', 5)

        # Calculate start and end chapter for current volume
        start_chapter = (vol_num - 1) * chapters_per_volume + 1
        end_chapter = vol_num * chapters_per_volume

        return {
            'current_volume': str(vol_num),
            'total_volumes': str(total_volumes),
            'chapter_index': str(chap_num),
            'previous_chapter_index': str(max(0, chap_num - 1)),
            'start_chapter': str(start_chapter),
            'end_chapter': str(end_chapter),
            'book_title': work_data.get('title', ''),
            'novel_type': work_data.get('category', ''),
        }

    def _replace_placeholders(self, text: str, context: dict) -> str:
        """
        Replace placeholders in text with context values.

        Args:
            text: Text containing placeholders
            context: Context dictionary

        Returns:
            Text with placeholders replaced
        """
        if not text or not context:
            return text

        # Replace {key} placeholders with context values
        for key, value in context.items():
            placeholder = '{' + key + '}'
            if placeholder in text:
                text = text.replace(placeholder, value)

        return text

    def _extract_format_section(self, template_content: str) -> str:
        """
        Extract output format section from template content.

        Args:
            template_content: Full template content

        Returns:
            Format section string
        """
        if not template_content:
            return "输出格式要求：使用纯文本格式，不要有 Markdown 标记。"

        # Try to find "# 输出格式" section
        format_markers = [
            "# 输出格式",
            "## 输出格式",
            "# 输出要求",
            "## 输出要求",
        ]

        format_start = -1
        for marker in format_markers:
            idx = template_content.find(marker)
            if idx != -1:
                format_start = idx
                break

        if format_start != -1:
            # Extract from format marker to end or to "现在请开始" section
            format_section = template_content[format_start:]

            # Cut off at "现在请开始你的创作" or similar
            end_markers = [
                "现在请开始你的创作",
                "现在请开始你的设计",
                "现在请开始你的摘要更新",
            ]

            for end_marker in end_markers:
                end_idx = format_section.find(end_marker)
                if end_idx != -1:
                    format_section = format_section[:end_idx].strip()
                    break

            return format_section

        # If no format section found, return default
        return "输出格式要求：使用纯文本格式，不要有 Markdown 标记。"

    def _get_default_prompt(self, template_category: str, work_data: dict) -> str:
        """
        Get a default prompt for a template category.

        Args:
            template_category: Template category name
            work_data: Work data dictionary

        Returns:
            Default prompt string

        Note: For steps that depend on previous AI-generated content
              (story_summary, worldbuilding, character_design), the prompt
              should be built in _build_generation_context where step files
              are loaded, not here.
        """
        prompts = {
            "文风设定": f"请为小说类型：{work_data.get('category', '')}，文风类别：{work_data.get('literary_style_category', '')} 生成一份语言风格设定报告。",
            "书名": f"请为小说生成一个吸引人的书名。类型：{work_data.get('category', '')}，参考作品：{work_data.get('reference_works', [])}，创作指导：{work_data.get('creation_guide', '')}",
            "故事梗概": f"请为小说《{work_data.get('title', '')}》生成一个精彩的故事梗概（500 字左右）。类型：{work_data.get('category', '')}，文风类别：{work_data.get('literary_style_category', '')}",
            "时空设定": f"请为小说《{work_data.get('title', '')}》构建一个详细的时空设定（1000 字左右）。类型：{work_data.get('category', '')}",
            "人物设定": f"请为小说《{work_data.get('title', '')}》设计主要人物设定（至少 3 个角色，每个角色 300 字左右）。",
            "封面图片": f"请为小说《{work_data.get('title', '')}》（作者：{work_data.get('author', 'AI 作者')}）生成一段 AI 绘图提示词用于封面生成。类型：{work_data.get('category', '')}",
            "拆书参考": f"请对参考作品进行拆书分析。类型：{work_data.get('category', '')}，分析范围：第{work_data.get('start_chapter', '1')}章到第{work_data.get('end_chapter', '1')}章",
            "创作公式": f"请根据拆书分析报告，提炼创作公式。类型：{work_data.get('category', '')}，分析范围：第{work_data.get('start_chapter', '1')}章到第{work_data.get('end_chapter', '1')}章",
            "分卷大纲": f"请为小说《{work_data.get('title', '')}》生成分卷大纲。第{work_data.get('current_volume', '1')}卷，每卷约{work_data.get('chapters_per_volume', 20)}章，每章约{work_data.get('words_per_chapter', 3000)}字",
            "分卷人物": f"请为小说第{work_data.get('current_volume', '1')}卷设计分卷人物设定。",
            "章节大纲": f"请为小说生成章节大纲。第{work_data.get('chapter_index', '1')}章",
            "章节正文": f"请根据章节大纲生成小说正文。第{work_data.get('chapter_index', '1')}章，约{work_data.get('words_per_chapter', 3000)}字",
            "剧情总结": f"请为小说生成剧情总结。截至第{work_data.get('chapter_index', '1')}章",
            "人物总结": f"请为小说生成人物状态总结。截至第{work_data.get('chapter_index', '1')}章",
        }
        return prompts.get(template_category, "请生成小说内容。")

    def _call_ai_for_step(
        self,
        state: dict,
        step_id: str,
        step_name: str,
        prompt: str,
        new_chat: bool = True,
        callback=None
    ) -> None:
        """
        Call AI service to generate content for a step.

        For volume steps (volume_X, volume_X_characters):
        - First volume step (volume_1): Send input context first (role definition, task definition, novel settings, previous volume summaries)
        - Then send the actual generation prompt in the same session

        For other steps:
        - Direct generation with rendered prompt

        Args:
            state: Generation state dictionary
            step_id: Step ID
            step_name: Step display name
            prompt: Prompt to send to AI
            new_chat: Whether to start a new chat session
        """
        import asyncio
        from PyQt6.QtCore import QThread, pyqtSignal
        from utils.logger import get_logger

        self.logger.info(f"[CREATION] Calling AI for step: {step_name}, new_chat={new_chat}")

        # For volume steps, check if this is the first volume step in its session
        # and we need to send input context first
        is_volume_step = step_id.startswith('volume_') and '_summary' not in step_id

        # Parse volume number from step_id
        current_vol = 1
        if is_volume_step:
            parts = step_id.split('_')
            if len(parts) >= 2:
                try:
                    current_vol = int(parts[1])
                except (ValueError, IndexError):
                    pass

        # Check if we need to send volume input context first
        # Use new_chat flag - if True, we're starting a new session and need input
        need_volume_input = False
        volume_input_context = {}

        if is_volume_step and new_chat:
            # Build volume input context
            work_data = state.get('work_data', {})
            volume_input_context = self._build_volume_input_context(work_data, current_vol, state, step_id)
            self.logger.info(f"[CREATION] Volume input context needed for volume {current_vol}")

        # For chapter steps, check if we need to send chapter input context first
        # Use new_chat flag - if True, we're starting a new session and need input
        is_chapter_step = step_id.startswith('chapter_') and ('_outline' in step_id or '_content' in step_id)
        need_chapter_input = False
        chapter_input_context = {}

        if is_chapter_step and new_chat:
            # Parse volume and chapter number from step_id
            parts = step_id.split('_')
            chapter_vol = 1
            chapter_num = 1
            if len(parts) >= 4:
                try:
                    chapter_vol = int(parts[1])
                    chapter_num = int(parts[2])
                except (ValueError, IndexError):
                    pass

            work_data = state.get('work_data', {})
            chapter_input_context = self._build_chapter_input_context(work_data, chapter_vol, chapter_num, state)
            self.logger.info(f"[CREATION] Chapter input context needed for volume {chapter_vol} chapter {chapter_num}")

        # Create a worker thread for async AI call
        class AIWorker(QThread):
            result_ready = pyqtSignal(str, str, str)  # step_id, step_name, content
            error_occurred = pyqtSignal(str, str)  # step_id, error_message
            retry_progress = pyqtSignal(str, str)  # step_id, retry_message
            input_context_sent = pyqtSignal(str, str)  # step_id, confirmation_message

            def __init__(self, ai_service, prompt, step_id, step_name, logger, new_chat=True, max_retries=3,
                        need_volume_input=False, volume_input_context=None,
                        need_chapter_input=False, chapter_input_context=None,
                        callback=None):
                super().__init__()
                self.ai_service = ai_service
                self.prompt = prompt
                self.step_id = step_id
                self.step_name = step_name
                self.logger = logger
                self.new_chat = new_chat
                self.max_retries = max_retries
                self.need_volume_input = need_volume_input
                self.volume_input_context = volume_input_context or {}
                self.need_chapter_input = need_chapter_input
                self.chapter_input_context = chapter_input_context or {}
                self.generation_new_chat = new_chat  # Default to original new_chat value
                self.callback = callback  # Optional callback function

            def run(self):
                last_error = None

                for attempt in range(self.max_retries):
                    try:
                        self.logger.info(f"[CREATION] AIWorker run started for step {self.step_name} (attempt {attempt + 1}/{self.max_retries})")

                        # Notify about retry progress
                        if attempt > 0:
                            self.retry_progress.emit(self.step_id, f"第 {attempt + 1} 次重试...")

                        # For volume steps with input context, send input in 5 steps
                        if self.need_volume_input and self.volume_input_context and attempt == 0:
                            self.logger.info(f"[CREATION] ========== VOLUME INPUT START ==========")
                            self.logger.info(f"[CREATION] Sending volume input context in 5 steps...")
                            ctx = self.volume_input_context
                            self.logger.info(f"[CREATION] Volume context: start={ctx.get('start_volume')}, end={ctx.get('end_volume')}, has_story_summary={bool(ctx.get('story_summary'))}")

                            # Create new chat session for volume input
                            loop = asyncio.new_event_loop()
                            asyncio.set_event_loop(loop)

                            # Step 1: Define role
                            self.logger.info(f"[CREATION] >>> Volume input step 1/5: Sending role definition...")
                            step1_msg = self._build_volume_input_step1_role()
                            self.logger.info(f"[CREATION] Step 1 message preview: {step1_msg[:100]}...")
                            context_response = loop.run_until_complete(
                                self.ai_service.chat(
                                    messages=[{"role": "user", "content": step1_msg}],
                                    max_tokens=200,
                                    new_chat=True,
                                    on_retry=lambda attempt, msg: self.retry_progress.emit(self.step_id, msg)
                                )
                            )
                            self.logger.info(f"[CREATION] <<< Step 1 complete - AI confirmed role: {len(context_response)} chars")
                            self.logger.info(f"[CREATION] AI response preview: {context_response[:100]}...")

                            # Step 2: Define task
                            self.logger.info(f"[CREATION] >>> Volume input step 2/5: Sending task definition...")
                            step2_msg = self._build_volume_input_step2_task(ctx)
                            self.logger.info(f"[CREATION] Step 2 message preview: {step2_msg[:100]}...")
                            context_response = loop.run_until_complete(
                                self.ai_service.chat(
                                    messages=[{"role": "user", "content": step2_msg}],
                                    max_tokens=200,
                                    new_chat=False,  # Same session
                                    on_retry=lambda attempt, msg: self.retry_progress.emit(self.step_id, msg)
                                )
                            )
                            self.logger.info(f"[CREATION] <<< Step 2 complete - AI confirmed task: {len(context_response)} chars")
                            self.logger.info(f"[CREATION] AI response preview: {context_response[:100]}...")

                            # Step 3: Input novel settings
                            self.logger.info(f"[CREATION] >>> Volume input step 3/5: Sending novel settings...")
                            step3_msg = self._build_volume_input_step3_novel_settings(ctx)
                            self.logger.info(f"[CREATION] Step 3 message preview: {step3_msg[:100]}...")
                            context_response = loop.run_until_complete(
                                self.ai_service.chat(
                                    messages=[{"role": "user", "content": step3_msg}],
                                    max_tokens=200,
                                    new_chat=False,  # Same session
                                    on_retry=lambda attempt, msg: self.retry_progress.emit(self.step_id, msg)
                                )
                            )
                            self.logger.info(f"[CREATION] <<< Step 3 complete - AI confirmed novel settings: {len(context_response)} chars")
                            self.logger.info(f"[CREATION] AI response preview: {context_response[:100]}...")

                            # Step 4: Input volume range
                            self.logger.info(f"[CREATION] >>> Volume input step 4/5: Sending volume range...")
                            step4_msg = self._build_volume_input_step4_volume_range(ctx)
                            self.logger.info(f"[CREATION] Step 4 message preview: {step4_msg[:100]}...")
                            context_response = loop.run_until_complete(
                                self.ai_service.chat(
                                    messages=[{"role": "user", "content": step4_msg}],
                                    max_tokens=200,
                                    new_chat=False,  # Same session
                                    on_retry=lambda attempt, msg: self.retry_progress.emit(self.step_id, msg)
                                )
                            )
                            self.logger.info(f"[CREATION] <<< Step 4 complete - AI confirmed volume range: {len(context_response)} chars")
                            self.logger.info(f"[CREATION] AI response preview: {context_response[:100]}...")

                            # Step 5: Input previous context
                            self.logger.info(f"[CREATION] >>> Volume input step 5/5: Sending previous context...")
                            step5_msg = self._build_volume_input_step5_previous_context(ctx)
                            self.logger.info(f"[CREATION] Step 5 message preview: {step5_msg[:100]}...")
                            context_response = loop.run_until_complete(
                                self.ai_service.chat(
                                    messages=[{"role": "user", "content": step5_msg}],
                                    max_tokens=200,
                                    new_chat=False,  # Same session
                                    on_retry=lambda attempt, msg: self.retry_progress.emit(self.step_id, msg)
                                )
                            )
                            self.logger.info(f"[CREATION] <<< Step 5 complete - AI confirmed previous context: {len(context_response)} chars")
                            self.logger.info(f"[CREATION] AI response preview: {context_response[:100]}...")

                            loop.close()

                            self.logger.info(f"[CREATION] ========== VOLUME INPUT COMPLETE ==========")
                            self.logger.info(f"[CREATION] All 5 input steps completed successfully")

                            # Emit confirmation
                            self.input_context_sent.emit(self.step_id, "上下文输入完成，开始生成...")

                            # After sending input context, generation should use same session (new_chat=False)
                            # and use simplified generation prompt (not the full context again)
                            self.generation_new_chat = False

                            # Build simplified generation prompt for volume output steps
                            # The context has already been sent in the input phase
                            self.prompt = self._build_volume_generation_prompt(self.step_id, ctx)
                            self.logger.info(f"[CREATION] Simplified generation prompt for volume output: {len(self.prompt)} chars")

                        # For chapter steps with input context, send input in 5 steps
                        if self.need_chapter_input and self.chapter_input_context and attempt == 0:
                            self.logger.info(f"[CREATION] ========== CHAPTER INPUT START ==========")
                            self.logger.info(f"[CREATION] Sending chapter input context in 5 steps...")
                            self.logger.info(f"[CREATION] Chapter context: vol={self.chapter_input_context.get('current_volume')}, chapter={self.chapter_input_context.get('chapter_index')}")

                            # Create new chat session for chapter input
                            loop = asyncio.new_event_loop()
                            asyncio.set_event_loop(loop)

                            # Step 1: Define role
                            self.logger.info(f"[CREATION] >>> Chapter input step 1/5: Sending role definition...")
                            step1_msg = self._build_chapter_input_step1_role()
                            self.logger.info(f"[CREATION] Step 1 message preview: {step1_msg[:100]}...")
                            context_response = loop.run_until_complete(
                                self.ai_service.chat(
                                    messages=[{"role": "user", "content": step1_msg}],
                                    max_tokens=200,
                                    new_chat=True,
                                    on_retry=lambda attempt, msg: self.retry_progress.emit(self.step_id, msg)
                                )
                            )
                            self.logger.info(f"[CREATION] <<< Step 1 complete - AI confirmed role: {len(context_response)} chars")
                            self.logger.info(f"[CREATION] AI response preview: {context_response[:100]}...")

                            # Step 2: Define task
                            self.logger.info(f"[CREATION] >>> Chapter input step 2/5: Sending task definition...")
                            step2_msg = self._build_chapter_input_step2_task()
                            self.logger.info(f"[CREATION] Step 2 message preview: {step2_msg[:100]}...")
                            context_response = loop.run_until_complete(
                                self.ai_service.chat(
                                    messages=[{"role": "user", "content": step2_msg}],
                                    max_tokens=200,
                                    new_chat=False,  # Same session
                                    on_retry=lambda attempt, msg: self.retry_progress.emit(self.step_id, msg)
                                )
                            )
                            self.logger.info(f"[CREATION] <<< Step 2 complete - AI confirmed task: {len(context_response)} chars")
                            self.logger.info(f"[CREATION] AI response preview: {context_response[:100]}...")

                            # Step 3: Input novel settings
                            self.logger.info(f"[CREATION] >>> Chapter input step 3/5: Sending novel settings...")
                            step3_msg = self._build_chapter_input_step3_novel_settings()
                            self.logger.info(f"[CREATION] Step 3 message preview: {step3_msg[:100]}...")
                            context_response = loop.run_until_complete(
                                self.ai_service.chat(
                                    messages=[{"role": "user", "content": step3_msg}],
                                    max_tokens=200,
                                    new_chat=False,  # Same session
                                    on_retry=lambda attempt, msg: self.retry_progress.emit(self.step_id, msg)
                                )
                            )
                            self.logger.info(f"[CREATION] <<< Step 3 complete - AI confirmed novel settings: {len(context_response)} chars")
                            self.logger.info(f"[CREATION] AI response preview: {context_response[:100]}...")

                            # Step 4: Input volume info
                            self.logger.info(f"[CREATION] >>> Chapter input step 4/5: Sending volume info...")
                            step4_msg = self._build_chapter_input_step4_volume_info()
                            self.logger.info(f"[CREATION] Step 4 message preview: {step4_msg[:100]}...")
                            context_response = loop.run_until_complete(
                                self.ai_service.chat(
                                    messages=[{"role": "user", "content": step4_msg}],
                                    max_tokens=200,
                                    new_chat=False,  # Same session
                                    on_retry=lambda attempt, msg: self.retry_progress.emit(self.step_id, msg)
                                )
                            )
                            self.logger.info(f"[CREATION] <<< Step 4 complete - AI confirmed volume info: {len(context_response)} chars")
                            self.logger.info(f"[CREATION] AI response preview: {context_response[:100]}...")

                            # Step 5: Input previous context
                            self.logger.info(f"[CREATION] >>> Chapter input step 5/5: Sending previous context...")
                            step5_msg = self._build_chapter_input_step5_previous_context()
                            self.logger.info(f"[CREATION] Step 5 message preview: {step5_msg[:100]}...")
                            context_response = loop.run_until_complete(
                                self.ai_service.chat(
                                    messages=[{"role": "user", "content": step5_msg}],
                                    max_tokens=200,
                                    new_chat=False,  # Same session
                                    on_retry=lambda attempt, msg: self.retry_progress.emit(self.step_id, msg)
                                )
                            )
                            self.logger.info(f"[CREATION] <<< Step 5 complete - AI confirmed previous context: {len(context_response)} chars")
                            self.logger.info(f"[CREATION] AI response preview: {context_response[:100]}...")

                            loop.close()

                            self.logger.info(f"[CREATION] ========== CHAPTER INPUT COMPLETE ==========")
                            self.logger.info(f"[CREATION] All 5 input steps completed successfully")

                            # Emit confirmation
                            self.input_context_sent.emit(self.step_id, "上下文输入完成，开始生成...")

                            # After sending input context, generation should use same session (new_chat=False)
                            # and use simplified generation prompt (not the full context again)
                            self.generation_new_chat = False

                            # Build simplified generation prompt for chapter output steps
                            # The context has already been sent in the input phase
                            ctx = self.chapter_input_context
                            self.prompt = self._build_chapter_generation_prompt(self.step_id, ctx)
                            self.logger.info(f"[CREATION] Simplified generation prompt for chapter output: {len(self.prompt)} chars")

                        # Run async chat in event loop
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                        # Use generation_new_chat if set (for steps after input), otherwise use self.new_chat
                        new_chat_value = self.generation_new_chat if hasattr(self, 'generation_new_chat') else self.new_chat
                        self.logger.info(f"[CREATION] Calling ai_service.chat() with new_chat={new_chat_value}...")
                        content = loop.run_until_complete(
                            self.ai_service.chat(
                                messages=[{"role": "user", "content": self.prompt}],
                                max_tokens=4096,
                                new_chat=new_chat_value,  # Same session for generation after input context
                                on_retry=lambda attempt, msg: self.retry_progress.emit(self.step_id, msg)
                            )
                        )
                        self.logger.info(f"[CREATION] AIWorker received response: {len(content)} chars")
                        loop.close()

                        # Validate content
                        if not content or len(content.strip()) == 0:
                            raise Exception("AI 返回内容为空")

                        self.result_ready.emit(self.step_id, self.step_name, content)
                        return  # Success, exit retry loop

                    except Exception as e:
                        last_error = e
                        self.logger.error(f"[CREATION] AIWorker error (attempt {attempt + 1}/{self.max_retries}): {e}")

                        # Don't retry on certain errors
                        error_str = str(e).lower()
                        if "浏览器页面已关闭" in error_str or "browser closed" in error_str.lower():
                            self.logger.error("[CREATION] Browser closed, stopping retries")
                            break

                        # Wait before retry (if not last attempt)
                        if attempt < self.max_retries - 1:
                            wait_time = 5 * (attempt + 1)  # 5s, 10s, 15s
                            self.logger.info(f"[CREATION] Waiting {wait_time}s before retry...")
                            import time
                            time.sleep(wait_time)
                        else:
                            self.logger.error(f"[CREATION] All {self.max_retries} attempts failed")

                # All retries failed
                error_msg = f"AI 生成失败（已重试 {self.max_retries} 次）: {last_error}"
                self.error_occurred.emit(self.step_id, error_msg)

            def _build_volume_input_message(self) -> str:
                """Build the volume input context message (all-in-one for compatibility)."""
                ctx = self.volume_input_context

                message = """# 角色定义
你是一位资深网文编辑和情节架构师，擅长将整体故事拆解为结构清晰、节奏合理、爽点密集的分卷大纲和人物设定。

# 任务描述
你将根据提供的小说设定和前序剧情，按顺序创作指定卷数的分卷信息。
对于每一卷，你需要先输出分卷大纲，然后输出分卷人物设定。

# 小说基本设定
- 小说类型：{novel_type}
- 书名：{book_title}

- 故事梗概：
```
{story_summary}
```

- 时空设定：
```
{worldbuilding}
```

- 人物设定：
```
{characters}
```

# 前序分卷剧情（前 3 卷总结）
""".format(
                    novel_type=ctx.get('novel_type', ''),
                    book_title=ctx.get('book_title', ''),
                    story_summary=ctx.get('story_summary', ''),
                    worldbuilding=ctx.get('worldbuilding', ''),
                    characters=ctx.get('characters', '')
                )

                if ctx.get('previous_volumes_plot_summary'):
                    message += f"""
- 前序剧情总结：
```
{ctx.get('previous_volumes_plot_summary', '')}
```
"""
                else:
                    message += "\n（无前序剧情，这是第 1 卷）\n"

                if ctx.get('previous_volumes_character_status'):
                    message += f"""
- 前序人物总结：
```
{ctx.get('previous_volumes_character_status', '')}
```
"""
                else:
                    message += "\n（无前序人物总结）\n"

                message += f"""
# 创作任务
请为第 {ctx.get('start_volume', 1)} 卷 到第 {ctx.get('end_volume', 1)} 卷 生成分卷大纲和分卷人物设定。

请确认你已理解上述信息，并准备开始创作。
"""
                return message

            def _build_volume_input_step1_role(self) -> str:
                """Step 1: Define AI role."""
                return """# 角色定义
你是一位资深网文编辑和情节架构师，擅长将整体故事拆解为结构清晰、节奏合理、爽点密集的分卷大纲和人物设定。

**注意：本阶段仅为输入和确认，请不要生成任何内容。只需回复'已确认'或'已理解'即可。**

请确认你已理解这个角色定位。"""

            def _build_volume_input_step2_task(self, ctx: dict) -> str:
                """Step 2: Define task."""
                return f"""# 任务描述
你将根据提供的小说设定和前序剧情，按顺序创作第 {ctx.get('start_volume', 1)} 卷 到第 {ctx.get('end_volume', 1)} 卷 的分卷信息。

**创作流程：**
对于每一卷：
1. 分卷大纲 → 2. 分卷人物设定

全部卷数完成后，继续后续章节创作。

**注意：本阶段仅为输入和确认，请不要生成任何内容。只需回复'已确认'或'已理解'即可。**

请确认你已理解这个任务流程。"""

            def _build_volume_input_step3_novel_settings(self, ctx: dict) -> str:
                """Step 3: Input novel basic settings."""
                message = """# 小说基本设定
- 小说类型：{novel_type}
- 书名：{book_title}
""".format(
                    novel_type=ctx.get('novel_type', ''),
                    book_title=ctx.get('book_title', '')
                )

                # Add story summary if available
                if ctx.get('story_summary'):
                    message += f"""
- 故事梗概：
```
{ctx.get('story_summary', '')}
```
"""
                # Add worldbuilding if available
                if ctx.get('worldbuilding'):
                    message += f"""
- 时空设定：
```
{ctx.get('worldbuilding', '')}
```
"""
                # Add characters if available
                if ctx.get('characters'):
                    message += f"""
- 人物设定：
```
{ctx.get('characters', '')}
```
"""
                message += "\n**注意：本阶段仅为输入和确认，请不要生成任何内容。只需回复'已确认'或'已理解'即可。**\n\n请确认你已理解上述小说设定。"
                return message

            def _build_volume_input_step4_volume_range(self, ctx: dict) -> str:
                """Step 4: Input volume range."""
                return f"""# 创作范围
请为第 {ctx.get('start_volume', 1)} 卷 到第 {ctx.get('end_volume', 1)} 卷 生成分卷大纲和分卷人物设定。

**注意：本阶段仅为输入和确认，请不要生成任何内容。只需回复'已确认'或'已理解'即可。**

请确认你已理解创作范围。"""

            def _build_volume_input_step5_previous_context(self, ctx: dict) -> str:
                """Step 5: Input previous volumes context."""
                message = "# 前序分卷剧情（前 3 卷总结）\n"

                if ctx.get('previous_volumes_plot_summary'):
                    message += f"""
- 前序剧情总结：
```
{ctx.get('previous_volumes_plot_summary', '')}
```
"""
                else:
                    message += "\n（无前序剧情，这是第 1 卷）\n"

                if ctx.get('previous_volumes_character_status'):
                    message += f"""
- 前序人物总结：
```
{ctx.get('previous_volumes_character_status', '')}
```
"""
                else:
                    message += "\n（无前序人物总结）\n"

                # Add completed volume infos within the task range (断点续传)
                if ctx.get('completed_volume_infos'):
                    message += f"""

# 本任务范围内已完成的分卷信息

{ctx.get('completed_volume_infos', '')}
"""

                message += "\n**注意：本阶段仅为输入和确认，请不要生成任何内容。只需回复'已确认'或'已理解'即可。**\n\n请确认你已理解上述前序剧情上下文。"
                return message

            def _build_volume_generation_prompt(self, step_id: str, ctx: dict) -> str:
                """Build simplified generation prompt for volume output steps.

                After the 5-step input phase, the AI already has all the context.
                This method builds a simple prompt specifying what to output.
                """
                # Parse volume number from step_id
                # Format: volume_X or volume_X_characters
                current_vol = 1
                parts = step_id.split('_')
                if len(parts) >= 2:
                    try:
                        current_vol = int(parts[1])
                    except (ValueError, IndexError):
                        pass

                if step_id.endswith('_characters'):
                    # Volume characters step
                    return f"""请生成第 {current_vol} 卷的分卷人物设定。

**输出格式：**

# 分卷人物设定 - 第{current_vol}卷

## 主要人物

### [姓名]
- 外貌：[外貌特征]
- 性格：[性格特征]
- 背景：[成长背景]
- 喜恶：[喜好和厌恶]
- 技能：[特殊技能或能力]
- 财产：[个人财产或重要物品]
- 角色弧光：
  - 概括：[在本卷中的使命/目标]
  - 动机：[表面动机/深层动机]
  - 目标：[本卷具体想要什么]
  - 冲突：[本卷受到的阻碍]
  - 感悟：[本卷的改变或成长]
- 本卷剧情：[简要概括该人物在本卷内的剧情]
- 人物故事：[从该人物视角出发的人生故事]

## 次要人物
[同上格式]

## 阶段性人物/功能性人物/背景人物
[同上格式]

请直接输出内容，无需重复前序信息。"""
                else:
                    # Volume outline step
                    return f"""请生成第 {current_vol} 卷的分卷大纲。

**输出格式：**

# 分卷大纲 - 第{current_vol}卷

## 本卷基本信息
- 卷数：第{current_vol}卷
- 卷名：[为本卷拟定一个有吸引力的名称]
- 覆盖章节：[本章数范围]
- 核心主题：[本卷的核心主题]
- 情绪基调：[本卷的整体情绪基调]

## 本卷在整部作品中的定位
[描述本卷在整个故事中的位置和作用]

## 情节单元划分

### 单元一：[单元标题]
- 覆盖章节：第 X 章 - 第 Y 章
- 功能定位：[功能]
- 核心情节：[每章 5W1H 简述]
- 关键人物与关系变化：[描述]
- 主角目标与进展：[描述]
- 冲突与转折：[描述]
- 伏笔与钩子：[描述]

### 单元二：[单元标题]
（同上格式）

## 本卷爽点设计
1. [爽点 1]：[位置和设计方式]
2. [爽点 2]：[位置和设计方式]
3. [爽点 3]：[位置和设计方式]

## 本卷伏笔清单
1. [伏笔 1]：[埋设位置，预计揭示位置]
2. [伏笔 2]：[埋设位置，预计揭示位置]

请直接输出内容，无需重复前序信息。"""

            def _build_chapter_generation_prompt(self, step_id: str, ctx: dict) -> str:
                """Build simplified generation prompt for chapter output steps.

                After the 5-step input phase, the AI already has all the context.
                This method builds a simple prompt specifying what to output.
                """
                chapter_vol = ctx.get('current_volume', 1)
                chapter_num = ctx.get('chapter_index', 1)

                if '_outline' in step_id:
                    # Chapter outline step
                    return f"""请生成第 {chapter_vol} 卷第 {chapter_num} 章的章节大纲。

**输出格式：**

# 章节细纲 - 第{chapter_num}章

## 基本信息
- 章节号：第{chapter_num}章
- 章节名：[为本章拟定一个有吸引力的名称]
- 核心功能：[引入主角/建立目标/升级能力/结识盟友/树立敌人/情感发展/铺垫伏笔/小型高潮/过渡衔接]
- 时间/地点：[明确的时间段和地点]

## 本章目标（主角）
[主角在本章的主要人物要实现的直接、具体的目标]

## 情绪基调
[例如：绝望与错愕交织 -> 冰冷的急迫感]

## 本章出场人物
- [人物 1]：[在本章的作用]
- [人物 2]：[在本章的作用]

## 场景序列与情节推演

### 场景 1：[场景名]
- 开端：[场景如何开始，初始状态]
- 发展与冲突：[情节如何推进，遇到什么冲突]
- 转折/结果：[如何转折，最终结果是什么]
- 关键细节/风格提示：[必须包含的具体动作、对话、内心独白或环境细节]

### 场景 2：[场景名]
（同上格式）

## 伏笔与后续关联
- 本章埋下的伏笔：[明确列出]
- 与后续章节的关联：[预期在哪个章节呼应]

## 爽点设计
- 爽点位置：[第几个场景]
- 爽点类型：[打脸/碾压/反转/揭示等]
- 设计方式：[如何设计这个爽点]

请直接输出内容，无需重复前序信息。"""
                else:
                    # Chapter content step
                    words_per_chapter = ctx.get('words_per_chapter', 2000)
                    return f"""请生成第 {chapter_vol} 卷第 {chapter_num} 章的章节正文。

**输出格式：**
- 直接输出正文内容，不要加章节名
- 字数约{words_per_chapter}字以上
- 使用纯文本格式，不要使用 markdown 格式
- 开篇要有钩子，用动作、对话、悬念或强烈情绪开场
- 场景之间用空行区分
- 语言流畅，情节连贯，符合小说风格

请直接输出章节正文内容。"""

            def _build_chapter_input_message(self) -> str:
                """Build the chapter input context message (all-in-one for compatibility)."""
                ctx = self.chapter_input_context

                message = """# 角色定义
你是一位顶尖的网文作家和情节架构师，擅长根据大纲创作引人入胜的章节内容。

# 任务描述
你将根据提供的小说设定、分卷大纲和前序剧情，按顺序创作当前卷的所有章节内容。
对于每一章，你需要先输出章节大纲，然后输出章节正文。
全部章节完成后，输出本卷的剧情总结和人物状态总结。

# 小说基本设定
- 小说类型：{novel_type}
- 书名：{book_title}

- 时空设定：
```
{worldbuilding}
```

# 当前分卷信息
- 总卷数：{total_volumes}
- 当前卷数：{current_volume}
- 当前章节：第 {chapter_index} 章
""".format(
                    novel_type=ctx.get('novel_type', ''),
                    book_title=ctx.get('book_title', ''),
                    worldbuilding=ctx.get('worldbuilding', ''),
                    total_volumes=ctx.get('total_volumes', '1'),
                    current_volume=ctx.get('current_volume', '1'),
                    chapter_index=ctx.get('chapter_index', '1')
                )

                # Add previous chapter index if exists
                if ctx.get('previous_chapter_index') and ctx.get('previous_chapter_index') != '0':
                    message += f"- 上一章章节：第 {ctx.get('previous_chapter_index')} 章\n"

                # Add volume outline and characters
                if ctx.get('volume_outline'):
                    message += f"""
# 分卷大纲：
```
{ctx.get('volume_outline', '')}
```
"""
                if ctx.get('volume_characters'):
                    message += f"""
# 分卷人物设定：
```
{ctx.get('volume_characters', '')}
```
"""

                # Add previous chapters context
                if ctx.get('plot_summary'):
                    message += f"""
# 前序章节剧情梗概：
```
{ctx.get('plot_summary', '')}
```
"""
                if ctx.get('character_status'):
                    message += f"""
# 前序章节人物状态：
```
{ctx.get('character_status', '')}
```
"""

                # Add current volume's prior chapters content (for 断点续传)
                if ctx.get('volume_all_chapters_content'):
                    message += f"""
# 本卷已生成章节内容：
```
{ctx.get('volume_all_chapters_content', '')}
```
"""

                message += """
# 创作任务
请按照以下顺序创作当前章节：
1. 章节大纲：包含章节名称、核心情节、出场人物、场景描写要点
2. 章节正文：根据大纲创作约 3000 字的正文内容

请确认你已理解上述信息，并准备开始创作。
"""
                return message

            def _build_chapter_input_step1_role(self) -> str:
                """Step 1: Define AI role."""
                return """# 角色定义
你是一位顶尖的网文作家和情节架构师，擅长根据大纲创作引人入胜的章节内容。

**注意：本阶段仅为输入和确认，请不要生成任何内容。只需回复'已确认'或'已理解'即可。**

请确认你已理解这个角色定位。"""

            def _build_chapter_input_step2_task(self) -> str:
                """Step 2: Define task."""
                return """# 任务描述
你将根据提供的小说设定、分卷大纲和前序剧情，按顺序创作当前卷的所有章节内容。

**创作流程：**
1. 章节大纲 → 章节正文（循环所有章节）
2. 本卷剧情总结
3. 本卷人物状态总结

**输出要求：**
- 每个步骤单独输出，明确标注是哪一章的什么内容
- 章节正文约 3000 字
- 大纲包含章节名称、核心情节、出场人物、场景描写要点

**注意：本阶段仅为输入和确认，请不要生成任何内容。只需回复'已确认'或'已理解'即可。**

请确认你已理解这个任务流程。"""

            def _build_chapter_input_step3_novel_settings(self) -> str:
                """Step 3: Input novel basic settings."""
                ctx = self.chapter_input_context

                message = """# 小说基本设定
- 小说类型：{novel_type}
- 书名：{book_title}

- 时空设定：
```
{worldbuilding}
```

**注意：本阶段仅为输入和确认，请不要生成任何内容。只需回复'已确认'或'已理解'即可。**

请确认你已理解上述小说设定。""".format(
                    novel_type=ctx.get('novel_type', ''),
                    book_title=ctx.get('book_title', ''),
                    worldbuilding=ctx.get('worldbuilding', '')
                )
                return message

            def _build_chapter_input_step4_volume_info(self) -> str:
                """Step 4: Input volume info."""
                ctx = self.chapter_input_context

                message = """# 当前分卷信息
- 总卷数：{total_volumes}
- 当前卷数：{current_volume}
- 本卷章节范围：第 1 章 - 第{total_chapters}章
""".format(
                    total_volumes=ctx.get('total_volumes', '1'),
                    current_volume=ctx.get('current_volume', '1'),
                    total_chapters=ctx.get('chapters_per_volume', '20')
                )

                # Add volume outline and characters
                if ctx.get('volume_outline'):
                    message += f"""
# 分卷大纲：
```
{ctx.get('volume_outline', '')}
```
"""
                if ctx.get('volume_characters'):
                    message += f"""
# 分卷人物设定：
```
{ctx.get('volume_characters', '')}
```
"""
                message += "\n**注意：本阶段仅为输入和确认，请不要生成任何内容。只需回复'已确认'或'已理解'即可。**\n\n请确认你已理解上述分卷信息。"
                return message

            def _build_chapter_input_step5_previous_context(self) -> str:
                """Step 5: Input previous context."""
                ctx = self.chapter_input_context
                message = "# 前序剧情上下文\n"

                is_first_chapter = ctx.get('chapter_index', '1') == '1'

                if is_first_chapter:
                    # For first chapter, load previous volume's summaries
                    if ctx.get('plot_summary'):
                        message += f"""
# 前一卷剧情总结：
```
{ctx.get('plot_summary', '')}
```
"""
                    if ctx.get('character_status'):
                        message += f"""
# 前一卷人物状态：
```
{ctx.get('character_status', '')}
```
"""
                    if not ctx.get('plot_summary') and not ctx.get('character_status'):
                        message += "\n（这是第 1 卷，无前序剧情）\n"
                else:
                    # For midpoint resume, load current volume's prior chapters
                    if ctx.get('volume_all_chapters_content'):
                        message += f"""
# 本卷已生成章节内容：
```
{ctx.get('volume_all_chapters_content', '')}
```
"""
                    # Also include previous volume summaries if available
                    if ctx.get('plot_summary'):
                        message += f"""
# 前一卷剧情总结：
```
{ctx.get('plot_summary', '')}
```
"""
                    if ctx.get('character_status'):
                        message += f"""
# 前一卷人物状态：
```
{ctx.get('character_status', '')}
```
"""
                    if not ctx.get('volume_all_chapters_content'):
                        message += "\n（无本卷已生成章节内容）\n"

                message += "\n**注意：本阶段仅为输入和确认，请不要生成任何内容。只需回复'已确认'或'已理解'即可。**\n\n请确认你已理解上述前序剧情上下文。"
                return message

        self._current_ai_worker = AIWorker(
            state['ai_service'],
            prompt,
            step_id,
            step_name,
            self.logger,
            new_chat=new_chat,
            need_volume_input=need_volume_input,
            volume_input_context=volume_input_context,
            need_chapter_input=need_chapter_input,
            chapter_input_context=chapter_input_context,
            callback=callback
        )
        self._current_ai_worker.result_ready.connect(self._on_ai_generation_complete)
        self._current_ai_worker.error_occurred.connect(self._on_ai_generation_error)
        self._current_ai_worker.retry_progress.connect(self._on_ai_generation_retry)
        self._current_ai_worker.input_context_sent.connect(self._on_volume_input_context_sent)
        self.logger.info(f"[CREATION] Starting AIWorker thread")
        self._current_ai_worker.start()

    def _on_ai_generation_complete(self, step_id: str, step_name: str, content: str) -> None:
        """
        Handle AI generation completion.

        Args:
            step_id: Step ID that was generated
            step_name: Step display name
            content: Generated content
        """
        self.logger.info(f"Generated content for {step_name}: {len(content)} chars")

        # Callback-based flow via SessionExecutor
        if hasattr(self, '_step_callbacks') and step_id in self._step_callbacks:
            callback = self._step_callbacks.pop(step_id)
            callback(step_id, content, True)
            return

        # If no callback found, log warning
        # If no callback found, log warning
        self.logger.warning(f"[AI_DONE] No callback found for step {step_id}, content will not be processed")

    def _on_ai_generation_error(self, step_id: str, error_message: str) -> None:
        """
        Handle AI generation error.

        Args:
            step_id: Step ID that failed
            error_message: Error message
        """
        self.logger.error(f"AI generation failed for {step_id}: {error_message}")
        self.notification_bar.show_message(f"生成失败：{error_message}", 'error', 5000)

        # Pause generation
        if self.creation_view.session_manager:
            self.creation_view.creation_state = "paused"
            self.creation_view._update_creation_state()

    def _on_ai_generation_retry(self, step_id: str, retry_message: str) -> None:
        """
        Handle AI generation retry progress.

        Args:
            step_id: Step ID being retried
            retry_message: Retry progress message
        """
        self.logger.info(f"AI generation retry for {step_id}: {retry_message}")
        self.notification_bar.show_message(f"生成重试：{retry_message}", 'warning', 3000)

    def _on_volume_input_context_sent(self, step_id: str, confirmation_message: str) -> None:
        """
        Handle volume input context sent signal.

        This is called when the volume input context has been successfully sent
        to the AI and the AI has confirmed understanding.

        Args:
            step_id: Step ID for which context was sent
            confirmation_message: Confirmation message to display
        """
        self.logger.info(f"[VOLUME_INPUT] Context sent for step {step_id}: {confirmation_message}")
        self.notification_bar.show_message(f"上下文输入完成：{confirmation_message}", 'info', 3000)

    def _on_creation_paused(self, work_id: str) -> None:
        """
        Handle creation paused signal.

        Sets creation state to paused. The browser thread will detect the pause
        during its polling loop and stop generation automatically.

        Args:
            work_id: ID of work that creation was paused for
        """
        self.logger.info(f"Creation paused for work {work_id}")

        # Update creation state to paused
        # The browser thread will detect this and stop generation automatically
        self.creating_work_state = "paused"

        # Update views to reflect paused state
        if hasattr(self, 'workspace_view'):
            self.workspace_view.update_creating_work(work_id)
        if hasattr(self, 'work_detail_view'):
            self.work_detail_view.update_creating_work(work_id, "paused")

        # Show success message
        self.notification_bar.show_message("创作已暂停，可点击继续创作按钮恢复", 'success', 5000)

        self.logger.info(f"[PAUSE] Creation paused for work {work_id}, state preserved for resume")

    def _on_creation_resumed(self, work_id: str) -> None:
        """
        Handle creation resumed signal.

        Shows volume range dialog for user to reselect range, then resumes generation
        using the existing browser instance (no re-login).

        Args:
            work_id: ID of work that creation was resumed for
        """
        self.logger.info(f"Creation resumed for work {work_id}")
        self.notification_bar.show_message("请选择创作范围，将继续使用已登录的浏览器实例", 'info', 5000)

        # Update creating work state
        self.creating_work_id = work_id
        self.creating_work_state = "in_progress"

        # Get work data if not already set
        if self.creating_work_data is None:
            work = self.work_manager.get_work(work_id)
            if work:
                self.creating_work_data = work.to_dict()

        # Update views to show creating state
        self._update_creating_work_views()

        # Show volume range dialog for user to reselect range
        # Browser instance will be preserved and reused
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(
            100,
            lambda: self._show_volume_range_dialog(work_id)
        )

        self.logger.info("[RESUME] Volume range dialog shown, browser instance preserved")

    def _on_generation_progress(self, step_name: str, word_count: int) -> None:
        """
        Handle generation progress update.

        Args:
            step_name: Name of the current generation step
            word_count: Current word count
        """
        self.notification_bar.show_progress(step_name, word_count)

    def _on_content_changed(self, step_id: str, new_content: str) -> None:
        """
        Handle content change in creation view.

        Saves the edited content to the current work's generation data.

        Args:
            step_id: ID of the step that was edited
            new_content: New content value
        """
        if not self.creation_view.current_work_id:
            return

        self.logger.info(f"Content changed for step {step_id}: {len(new_content)} chars")
        # Content is already saved to _content_map in creation_view
        # Here we can add persistence to work data if needed
        # For now, just show a brief success notification
        self.notification_bar.show_message("已保存", 'success', 1500)

    def _on_save_requested(self, work_id: str, step_id: str, content: str) -> None:
        """
        Handle manual save request from creation view.

        Saves the step content to disk and shows success notification.

        Args:
            work_id: ID of work being saved
            step_id: ID of the step being saved
            content: Content to save
        """
        try:
            # Save the content using work manager
            self.work_manager.save_step_content(work_id, step_id, content)

            # Show success notification
            self.notification_bar.show_message("内容已保存", 'success', 2000)

            self.logger.info(f"Manual save completed for work {work_id}, step {step_id}")

        except Exception as e:
            self.logger.error(f"Failed to save step content: {e}")
            self.notification_bar.show_message(f"保存失败：{str(e)}", 'error', 3000)

    def _on_publish_clicked(self) -> None:
        """
        Handle publish button click.

        Shows a notification that publishing process has started.
        """
        try:
            # Get current publishing settings
            platform = self.publishing_view.current_platform
            work_id = self.publishing_view.current_work_id

            if not work_id:
                self.notification_bar.show_error("请先选择要发布的作品")
                return

            if not platform:
                self.notification_bar.show_error("请先选择发布平台")
                return

            # Show publishing started notification
            work = self.work_manager.get_work(work_id)
            work_title = work.get_display_title() if work else "未知作品"

            start_message = f"开始发布：{work_title}"
            self.notification_bar.show_message(start_message, 'info', 0)

            if self.logger:
                self.logger.info(
                    f"Publishing started: platform={platform}, work={work_title}"
                )

        except Exception as e:
            if self.logger:
                self.logger.error(f"Failed to start publishing: {e}")
            self.notification_bar.show_error(f"发布失败：{str(e)}")

    def _on_platform_changed(self, platform: str) -> None:
        """
        Handle platform selection change.

        Args:
            platform: Selected platform name
        """
        self.logger.info(f"Platform changed to: {platform}")

    def _on_work_selected(self, work_id: str) -> None:
        """
        Handle work selection change in publishing view.

        Args:
            work_id: ID of selected work
        """
        if self.logger:
            self.logger.info(f"Work selected for publishing: {work_id}")

    def _on_settings_saved(self) -> None:
        """Handle settings saved - reload data from new storage paths."""
        self.logger.info("Settings saved, reloading data from new storage paths")

        # Reload work manager to pick up new works directory
        self.work_manager.reload()

        # Reload fanqie accounts from new storage path
        self.fanqie_account_manager.reload()

        # Refresh workspace view to show works from new location
        if hasattr(self, 'workspace_view'):
            self._load_works()

        # Refresh publishing view if it has work data cached
        if hasattr(self, 'publishing_view'):
            self.publishing_view.refresh()

        self.logger.info("Data reload complete after settings change")
