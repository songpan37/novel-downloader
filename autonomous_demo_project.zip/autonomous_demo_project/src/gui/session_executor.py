"""
Session Executor for AI Writer application.

Handles the execution of AI generation sessions with hardcoded flow and dynamic parameters.
Supports 4 session types: basic_info, creation_reference, volume_{vol_num}, chapter_{vol_num}.

New design principles:
- Hardcoded session flow with dynamic parameters (vol_num, chapter_num)
- Callback chain drives execution (each method calls next on completion)
- Step completion status determined by disk file existence
- Persistent browser service within session
"""
from typing import Optional, Dict, Any, Callable
from pathlib import Path
import os
import json

from PyQt6.QtCore import QThread, pyqtSignal


class SessionExecutor:
    """
    Session executor for AI Writer.

    Executes AI generation sessions using callback chains.
    Each session type has its own method with hardcoded flow.
    """

    def __init__(self, main_window):
        """
        Initialize session executor.

        Args:
            main_window: MainWindow instance (parent)
        """
        self.main_window = main_window
        self.logger = main_window.logger
        self.settings = main_window.settings
        self._persistent_browser_service = None
        self._is_paused = False

    def set_paused(self, paused: bool) -> None:
        """Set pause state."""
        self._is_paused = paused

    def is_paused(self) -> bool:
        """Check if paused."""
        return self._is_paused

    # ==================== Helper Methods ====================

    def _get_completed_steps(self) -> Dict[str, str]:
        """
        Get completed step contents from disk.

        Returns:
            Dictionary mapping step names to their content
        """
        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        completed = {}

        # Read basic info steps
        step_files = {
            'style_setting': 'style_setting.txt',
            'book_title': 'book_title.txt',
            'story_summary': 'story_summary.txt',
            'worldbuilding': 'worldbuilding.txt',
            'character_design': 'character_design.txt',
            'cover_image': 'cover_image.txt',
        }

        for key, file_name in step_files.items():
            file_path = f"{steps_dir}/{file_name}"
            content = self._read_file_safe(file_path)
            if content:
                completed[key] = content

        # Read pattern analysis (创作公式)
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}
        reference_works = work_data.get('reference_works', [])
        if reference_works:
            chapters_per_volume = self.main_window._creation_chapters_per_volume
            start_chapter = (self.main_window._creation_start_volume - 1) * chapters_per_volume + 1
            end_chapter = self.main_window._creation_end_volume * chapters_per_volume
            # Extract second part after '/' first, then truncate to 10 chars
            short_names = []
            for w in reference_works[:3]:
                if '/' in w:
                    short_names.append(w.split('/')[1][:10])
                else:
                    short_names.append(w[:10])
            work_names_short = '_'.join(short_names)
            pattern_file = f"{steps_dir}/pattern_{work_names_short}_{start_chapter}_{end_chapter}.txt"
            pattern_content = self._read_file_safe(pattern_file)
            if pattern_content:
                completed['pattern_analysis'] = pattern_content

        # Read volume summaries based on user's selected range
        start_volume = self.main_window._creation_start_volume
        end_volume = self.main_window._creation_end_volume

        for vol_num in range(start_volume, end_volume + 1):
            plot_file = f"{steps_dir}/volume_{vol_num}_summary_plot.txt"
            char_file = f"{steps_dir}/volume_{vol_num}_summary_character.txt"
            plot_content = self._read_file_safe(plot_file)
            char_content = self._read_file_safe(char_file)
            if plot_content:
                completed[f'volume_{vol_num}_summary_plot'] = plot_content
            if char_content:
                completed[f'volume_{vol_num}_summary_character'] = char_content

        # Read previous 3 volumes plot summaries and character status
        previous_plots = []
        previous_chars = []
        for vol_num in range(1, min(start_volume, 4)):  # Read volumes 1-3 (or up to start_volume-1)
            plot_file = f"{steps_dir}/volume_{vol_num}_summary_plot.txt"
            char_file = f"{steps_dir}/volume_{vol_num}_summary_character.txt"
            plot_content = self._read_file_safe(plot_file)
            char_content = self._read_file_safe(char_file)
            if plot_content:
                previous_plots.append(f"=== 第{vol_num}卷 剧情总结 ===\n{plot_content}")
            if char_content:
                previous_chars.append(f"=== 第{vol_num}卷 人物总结 ===\n{char_content}")

        if previous_plots:
            completed['previous_volumes_plot_summary'] = '\n\n'.join(previous_plots)
        if previous_chars:
            completed['previous_volumes_character_status'] = '\n\n'.join(previous_chars)

        return completed

    def _send_context_input_with_callback(self, prompt: str, new_chat: bool, next_method) -> None:
        """
        Send context input to AI with callback chain.

        Args:
            prompt: Input prompt to send
            new_chat: Whether to click "开启新对话" button
            next_method: Callback method to invoke on confirmation
        """
        # Log the prompt being sent
        self.logger.info(f"[INPUT_PROMPT] Input prompt ({len(prompt)} chars):")
        self.logger.info(f"    ---")
        for line in prompt.split('\n')[:10]:
            self.logger.info(f"    {line}")
        if len(prompt.split('\n')) > 10:
            self.logger.info(f"    ... ({len(prompt.split(chr(10))) - 10} more lines)")
        self.logger.info(f"    ---")

        ai_service = self._get_ai_service_for_step()
        if not ai_service:
            self.logger.error(f"[INPUT_SEND] AI service not found")
            next_method()
            return

        # Create browser service for first input
        if new_chat:
            self._create_persistent_browser()

        class InputWorker(QThread):
            confirmed = pyqtSignal()
            error = pyqtSignal(str)

            def __init__(self, ai_service, prompt, logger, browser_service=None, new_chat=False, main_window=None):
                super().__init__()
                self.ai_service = ai_service
                self.prompt = prompt
                self.logger = logger
                self.new_chat = new_chat
                self.browser_service = browser_service
                self.main_window = main_window

            def run(self):
                try:
                    self.logger.info(f"[INPUT_SEND] Sending context input, new_chat={self.new_chat}")
                    import asyncio
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)

                    # Build pause check function
                    pause_fn = None
                    if self.main_window:
                        def pause_check():
                            try:
                                return self.main_window.creation_view.is_paused()
                            except Exception:
                                return False
                        pause_fn = pause_check

                    response = loop.run_until_complete(
                        self.ai_service.chat(
                            messages=[{"role": "user", "content": self.prompt}],
                            max_tokens=500,
                            new_chat=self.new_chat,
                            persistent_browser_service=self.browser_service,
                            pause_check_fn=pause_fn,
                        )
                    )
                    loop.close()

                    self.logger.info(f"[INPUT_RESPONSE] AI response received ({len(response)} chars):")
                    self.logger.info(f"    {response[:500]}")
                    if len(response) > 500:
                        self.logger.info(f"    ... ({len(response) - 500} more chars)")
                    self.confirmed.emit()

                except InterruptedError:
                    # Pause interrupt - do NOT emit signal, flow stops here
                    self.logger.info("[InputWorker] Generation interrupted by pause")
                    return
                except Exception as e:
                    self.logger.error(f"[INPUT_WORKER] Error: {e}")
                    self.error.emit(str(e))

        worker = InputWorker(ai_service, prompt, self.logger,
                             getattr(self.main_window, '_persistent_browser_service', None), new_chat, self.main_window)

        # Wrap next_method to check pause status before proceeding
        def on_confirmed():
            if self.main_window.creation_view.is_paused():
                self.logger.info(f"[INPUT_PAUSED] Pause detected after input, stopping flow")
                # Do NOT call next_method() - stop the flow here
                return
            next_method()

        worker.confirmed.connect(on_confirmed)
        worker.error.connect(lambda e: self.logger.error(f"[INPUT_ERROR] {e}") or next_method())
        worker.start()

    def _execute_output_step_with_callback(self, step_id: str, step_name: str, file_path: str,
                                            prompt: str, new_chat: bool, next_method) -> None:
        """
        Execute an output step with callback chain.

        Args:
            step_id: Step ID for logging
            step_name: Step display name for logging
            file_path: Disk file path to save content
            prompt: AI prompt for generation
            new_chat: Whether to start new chat (always False for output steps)
            next_method: Callback method to invoke on completion
        """
        # Step-level file existence check
        self.logger.info(f"[STEP_CHECK] {step_name}: 检查文件 {file_path}")

        if os.path.exists(file_path):
            content = self._read_file_safe(file_path)
            if content and len(content.strip()) > 0:
                self.logger.info(f"[STEP_LOADED] {step_name}: 从磁盘加载完成 - {len(content)}字")
                self.logger.info(f"[STEP_SKIPPED] {step_name}: 已存在，跳过")
                # Update UI: mark as completed
                self._update_step_status_in_ui(step_id, step_name, "completed")
                next_method()
                return

        # Update UI: mark as executing before starting generation
        self._update_step_status_in_ui(step_id, step_name, "executing")

        # File not exists or empty, generate with AI
        self.logger.info(f"[STEP_GENERATING] {step_name}: AI 生成中...")

        # Log input prompt
        self.logger.info(f"[STEP_INPUT] {step_name}: 输入提示词:")
        self.logger.info(f"    ---")
        for line in prompt.split('\n')[:10]:
            self.logger.info(f"    {line}")
        if len(prompt.split('\n')) > 10:
            self.logger.info(f"    ... ({len(prompt.split(chr(10))) - 10} more lines)")
        self.logger.info(f"    ---")

        ai_service = self._get_ai_service_for_step()
        if not ai_service:
            self.logger.error(f"[STEP_GENERATING] AI service not found")
            self._update_step_status_in_ui(step_id, step_name, "pending")
            next_method()
            return

        class OutputWorker(QThread):
            generated = pyqtSignal(str)
            error = pyqtSignal(str)

            def __init__(self, ai_service, prompt, logger, browser_service=None, main_window=None, pause_check_fn=None):
                super().__init__()
                self.ai_service = ai_service
                self.prompt = prompt
                self.logger = logger
                self.browser_service = browser_service
                self.main_window = main_window
                self.pause_check_fn = pause_check_fn

            def run(self):
                try:
                    import asyncio
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)

                    # Build pause check function if not provided
                    pause_fn = self.pause_check_fn
                    if pause_fn is None and self.main_window:
                        # Default: check creation_view.is_paused()
                        def pause_check():
                            try:
                                return self.main_window.creation_view.is_paused()
                            except Exception:
                                return False
                        pause_fn = pause_check

                    response = loop.run_until_complete(
                        self.ai_service.chat(
                            messages=[{"role": "user", "content": self.prompt}],
                            max_tokens=4000,
                            new_chat=False,
                            persistent_browser_service=self.browser_service,
                            pause_check_fn=pause_fn,
                        )
                    )
                    loop.close()

                    self.generated.emit(response if response else "")

                except InterruptedError:
                    # Pause interrupt - do NOT emit signal, flow stops here
                    self.logger.info("[OutputWorker] Generation interrupted by pause")
                    return
                except Exception as e:
                    self.logger.error(f"[STEP_GENERATING] Error: {e}")
                    self.error.emit(str(e))

        def on_generated(content: str):
            # Check pause status BEFORE processing the generated content
            if self.main_window.creation_view.is_paused():
                self.logger.info(f"[STEP_PAUSED] {step_name}: Pause detected, discarding generated content")
                # Update UI to show paused state
                self._update_step_status_in_ui(step_id, step_name, "paused")
                # Do NOT save content, do NOT call next_method() - stop the flow here
                return

            if content:
                self.logger.info(f"[STEP_OUTPUT] {step_name}: AI 生成完成 ({len(content)}字)")
                self.logger.info(f"    ---")
                for line in content.split('\n')[:10]:
                    self.logger.info(f"    {line}")
                if len(content.split('\n')) > 10:
                    self.logger.info(f"    ... ({len(content.split(chr(10))) - 10} more lines)")
                self.logger.info(f"    ---")

                # Save to disk
                self._write_file_safe(file_path, content)
                self.logger.info(f"[STEP_SAVED] {step_name}: 已保存到 {file_path}")

                # Update UI: mark as completed
                self._update_step_status_in_ui(step_id, step_name, "completed", content)
            else:
                self.logger.warning(f"[STEP_OUTPUT] {step_name}: AI 生成内容为空")
                # Update UI: mark as pending (empty content)
                self._update_step_status_in_ui(step_id, step_name, "pending")

            next_method()

        worker = OutputWorker(
            ai_service, prompt, self.logger,
            getattr(self.main_window, '_persistent_browser_service', None),
            self.main_window
        )
        worker.generated.connect(on_generated)
        worker.error.connect(lambda e: (
            self.logger.error(f"[STEP_ERROR] {e}"),
            self._update_step_status_in_ui(step_id, step_name, "pending"),
            next_method()
        ))
        worker.start()

    def _read_file_safe(self, file_path: str) -> str:
        """Safely read file with encoding handling."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except:
            return ""

    def _write_file_safe(self, file_path: str, content: str) -> None:
        """Safely write file with directory creation."""
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)

    def _create_persistent_browser(self) -> None:
        """Create persistent browser service for session."""
        from services.ai_service import AIService, AIServiceMode

        ai_settings = self.settings.ai_settings

        if ai_settings.call_mode == "browser":
            if self._persistent_browser_service is None:
                self.logger.info(f"[BROWSER] Creating new browser AI service")
                self._persistent_browser_service = AIService(
                    mode=AIServiceMode.BROWSER,
                    browser_provider=ai_settings.browser_provider,
                    browser_phone=ai_settings.browser_phone,
                    browser_password=ai_settings.browser_password,
                    browser_chrome_path=ai_settings.browser_chrome_path,
                )
            else:
                self.logger.info(f"[BROWSER] Reusing existing browser AI service")
        else:
            self.logger.info(f"[BROWSER] API mode - no browser needed")

    def _close_persistent_browser(self) -> None:
        """Close persistent browser service."""
        if self._persistent_browser_service:
            self.logger.info(f"[BROWSER] Closing browser service")
            self._persistent_browser_service = None

    def _get_templates_dir(self) -> Optional[str]:
        """Get user's templates directory path."""
        return getattr(self.settings, 'templates_dir', None)

    def _get_ai_service_for_step(self):
        """Get AI service for current step."""
        return self.main_window._get_ai_service_for_step()

    def _update_step_status_in_ui(self, step_id: str, step_name: str, status: str, content: str = "") -> None:
        """
        Update step status in CreationView UI.

        Args:
            step_id: Step ID
            step_name: Step display name (without icon prefix)
            status: One of 'pending', 'executing', 'completed'
            content: Optional content for completed steps
        """
        # Clean step name (remove any icon prefixes)
        clean_name = step_name.lstrip("⟳ ✓ ")

        if status == "executing":
            # Mark as executing - will show spinning icon and blue highlight
            self.main_window.creation_view.set_step_status(step_id, "executing", clean_name)
            # Start content streaming mode
            self.main_window.creation_view.start_content_stream(step_id)
            self.logger.info(f"[UI_UPDATE] {step_name}: status=executing")

        elif status == "completed":
            # Update content in view
            if content:
                self.main_window.creation_view.update_step_content(step_id, content, streaming=False)
            # Stop streaming and mark as completed - will show green checkmark
            self.main_window.creation_view.stop_content_stream(mark_completed=True)
            self.logger.info(f"[UI_UPDATE] {step_name}: status=completed, word_count={len(content)}")

        elif status == "pending":
            # Mark as pending - gray color
            self.main_window.creation_view.set_step_status(step_id, "pending", clean_name)
            self.logger.info(f"[UI_UPDATE] {step_name}: status=pending")

    def _mark_first_incomplete_step_in_session(self, session_type: str, vol_num: int = 0) -> None:
        """
        在会话开始时，找到第一个未完成的步骤并标记为 executing。

        Args:
            session_type: One of 'basic', 'reference', 'volume', 'chapter'
            vol_num: Volume number (for volume and chapter sessions)
        """
        work_id = self.main_window.creating_work_id
        works_dir = self.settings.works_dir

        if session_type == 'basic':
            # Check basic info steps in order
            basic_steps = [
                ('style_setting', '文风设定', 'style_setting.txt'),
                ('story_summary', '故事梗概', 'story_summary.txt'),
                ('worldbuilding', '时空设定', 'worldbuilding.txt'),
                ('character_design', '人物设定', 'character_design.txt'),
                ('book_title', '书名', 'book_title.txt'),
                ('cover_image', '封面图片', 'cover_image.txt'),
            ]
            for step_id, step_name, file_name in basic_steps:
                file_path = f"{works_dir}/{work_id}/steps/{file_name}"
                if not os.path.exists(file_path):
                    self._update_step_status_in_ui(step_id, step_name, "executing")
                    return
                content = self._read_file_safe(file_path)
                if not content or len(content.strip()) == 0:
                    self._update_step_status_in_ui(step_id, step_name, "executing")
                    return

        elif session_type == 'reference':
            work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}
            reference_works = work_data.get('reference_works', [])
            start_chapter = self.main_window._creation_start_volume * self.main_window._creation_chapters_per_volume - self.main_window._creation_chapters_per_volume + 1
            end_chapter = self.main_window._creation_end_volume * self.main_window._creation_chapters_per_volume

            # Check reference works
            for work_name in reference_works:
                safe_name = work_name.replace('/', '_').replace('\\', '_').replace(':', '_')
                step_id = f'reference_{safe_name}_{start_chapter}_{end_chapter}'
                file_path = f"{works_dir}/{work_id}/steps/{step_id}.txt"
                if '/' in work_name:
                    work_name_only = work_name.split('/')[1]
                else:
                    work_name_only = work_name
                step_name = f'{work_name_only}({start_chapter}-{end_chapter}章拆书)'
                if not os.path.exists(file_path):
                    self._update_step_status_in_ui(step_id, step_name, "executing")
                    return
                content = self._read_file_safe(file_path)
                if not content or len(content.strip()) == 0:
                    self._update_step_status_in_ui(step_id, step_name, "executing")
                    return

            # Check pattern analysis
            # Extract second part after '/' first, then truncate to 10 chars
            short_names = []
            for w in reference_works[:3]:
                if '/' in w:
                    short_names.append(w.split('/')[1][:10])
                else:
                    short_names.append(w[:10])
            safe_names = '_'.join(short_names)
            step_id = f'pattern_{safe_names}_{start_chapter}_{end_chapter}'
            file_path = f"{works_dir}/{work_id}/steps/{step_id}.txt"
            step_name = f'创作公式({start_chapter}-{end_chapter}章)'
            if not os.path.exists(file_path):
                self._update_step_status_in_ui(step_id, step_name, "executing")
                return
            content = self._read_file_safe(file_path)
            if not content or len(content.strip()) == 0:
                self._update_step_status_in_ui(step_id, step_name, "executing")
                return

        elif session_type == 'volume':
            # Loop through all volumes to find the first incomplete one
            for v in range(self.main_window._creation_start_volume, self.main_window._creation_end_volume + 1):
                # Check volume outline
                file_path = f"{works_dir}/{work_id}/steps/volume_{v}.txt"
                if not os.path.exists(file_path):
                    self._update_step_status_in_ui(f'volume_{v}', f'第{v}卷 分卷大纲', "executing")
                    return
                content = self._read_file_safe(file_path)
                if not content or len(content.strip()) == 0:
                    self._update_step_status_in_ui(f'volume_{v}', f'第{v}卷 分卷大纲', "executing")
                    return

                # Check volume characters
                file_path = f"{works_dir}/{work_id}/steps/volume_{v}_characters.txt"
                if not os.path.exists(file_path):
                    self._update_step_status_in_ui(f'volume_{v}_characters', f'第{v}卷 分卷人物', "executing")
                    return
                content = self._read_file_safe(file_path)
                if not content or len(content.strip()) == 0:
                    self._update_step_status_in_ui(f'volume_{v}_characters', f'第{v}卷 分卷人物', "executing")
                    return

        elif session_type == 'chapter':
            chapters_per_volume = self.main_window._creation_chapters_per_volume

            # Check chapters in order
            for chapter_num in range(1, chapters_per_volume + 1):
                # Check outline
                file_path = f"{works_dir}/{work_id}/steps/chapter_{vol_num}_{chapter_num}_outline.txt"
                if not os.path.exists(file_path):
                    self._update_step_status_in_ui(f'chapter_{vol_num}_{chapter_num}_outline', f'第{chapter_num}章 大纲', "executing")
                    return
                content = self._read_file_safe(file_path)
                if not content or len(content.strip()) == 0:
                    self._update_step_status_in_ui(f'chapter_{vol_num}_{chapter_num}_outline', f'第{chapter_num}章 大纲', "executing")
                    return

                # Check title
                file_path = f"{works_dir}/{work_id}/steps/chapter_{vol_num}_{chapter_num}_title.txt"
                if not os.path.exists(file_path):
                    self._update_step_status_in_ui(f'chapter_{vol_num}_{chapter_num}_title', f'第{chapter_num}章 章节标题', "executing")
                    return
                content = self._read_file_safe(file_path)
                if not content or len(content.strip()) == 0:
                    self._update_step_status_in_ui(f'chapter_{vol_num}_{chapter_num}_title', f'第{chapter_num}章 章节标题', "executing")
                    return

                # Check content
                file_path = f"{works_dir}/{work_id}/steps/chapter_{vol_num}_{chapter_num}_content.txt"
                if not os.path.exists(file_path):
                    self._update_step_status_in_ui(f'chapter_{vol_num}_{chapter_num}_content', f'第{chapter_num}章 正文', "executing")
                    return
                content = self._read_file_safe(file_path)
                if not content or len(content.strip()) == 0:
                    self._update_step_status_in_ui(f'chapter_{vol_num}_{chapter_num}_content', f'第{chapter_num}章 正文', "executing")
                    return

            # Check volume summary plot
            file_path = f"{works_dir}/{work_id}/steps/volume_{vol_num}_summary_plot.txt"
            if not os.path.exists(file_path):
                self._update_step_status_in_ui(f'volume_{vol_num}_summary_plot', '剧情总结', "executing")
                return
            content = self._read_file_safe(file_path)
            if not content or len(content.strip()) == 0:
                self._update_step_status_in_ui(f'volume_{vol_num}_summary_plot', '剧情总结', "executing")
                return

            # Check volume summary character
            file_path = f"{works_dir}/{work_id}/steps/volume_{vol_num}_summary_character.txt"
            if not os.path.exists(file_path):
                self._update_step_status_in_ui(f'volume_{vol_num}_summary_character', '人物总结', "executing")
                return
            content = self._read_file_safe(file_path)
            if not content or len(content.strip()) == 0:
                self._update_step_status_in_ui(f'volume_{vol_num}_summary_character', '人物总结', "executing")
                return

    def _find_first_incomplete_session(self) -> tuple[str, int, int]:
        """
        Find the first incomplete session and the first incomplete step within it.

        Returns:
            Tuple of (session_method_name, current_session, total_sessions)

        Session order:
        1. basic_info (基本设定)
        2. creation_reference (创作参考)
        3. volume_{vol_num} (分卷信息，每卷一个)
        4. chapter_{vol_num} (章节信息，每卷一个，包含分卷总结)
        """
        works_dir = self.settings.works_dir
        work_id = self.main_window.creating_work_id
        start_volume = self.main_window._creation_start_volume
        end_volume = self.main_window._creation_end_volume
        chapters_per_volume = self.main_window._creation_chapters_per_volume

        total_sessions = 1 + 1 + (end_volume - start_volume + 1) + (end_volume - start_volume + 1)  # basic + reference + volumes + chapters

        # 1. Check basic_info session (6 output steps)
        basic_steps = ['style_setting', 'story_summary', 'worldbuilding', 'character_design', 'book_title', 'cover_image']
        for step_name in basic_steps:
            file_path = f"{works_dir}/{work_id}/steps/{step_name}.txt"
            if not os.path.exists(file_path):
                self.logger.info(f"[SESSION_FLOW] First incomplete session: basic_info (step {step_name} not found)")
                return ('basic_info', 1, total_sessions)
            content = self._read_file_safe(file_path)
            if not content or len(content.strip()) == 0:
                self.logger.info(f"[SESSION_FLOW] First incomplete session: basic_info (step {step_name} is empty)")
                return ('basic_info', 1, total_sessions)

        self.logger.info(f"[SESSION_FLOW] basic_info session: all steps completed")

        # 2. Check creation_reference session
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}
        reference_works = work_data.get('reference_works', [])
        start_chapter = start_volume * chapters_per_volume - chapters_per_volume + 1
        end_chapter = end_volume * chapters_per_volume

        # Check reference works
        for work_name in reference_works:
            safe_name = work_name.replace('/', '_').replace('\\', '_').replace(':', '_')
            file_path = f"{works_dir}/{work_id}/steps/reference_{safe_name}_{start_chapter}_{end_chapter}.txt"
            if not os.path.exists(file_path):
                self.logger.info(f"[SESSION_FLOW] First incomplete session: creation_reference (reference {work_name} not found)")
                return ('creation_reference', 2, total_sessions)
            content = self._read_file_safe(file_path)
            if not content or len(content.strip()) == 0:
                self.logger.info(f"[SESSION_FLOW] First incomplete session: creation_reference (reference {work_name} is empty)")
                return ('creation_reference', 2, total_sessions)

        # Check pattern analysis
        # Extract second part after '/' first, then truncate to 10 chars
        short_names = []
        for w in reference_works[:3]:
            if '/' in w:
                short_names.append(w.split('/')[1][:10])
            else:
                short_names.append(w[:10])
        safe_names = '_'.join(short_names)
        file_path = f"{works_dir}/{work_id}/steps/pattern_{safe_names}_{start_chapter}_{end_chapter}.txt"
        if not os.path.exists(file_path):
            self.logger.info(f"[SESSION_FLOW] First incomplete session: creation_reference (pattern_analysis not found)")
            return ('creation_reference', 2, total_sessions)
        content = self._read_file_safe(file_path)
        if not content or len(content.strip()) == 0:
            self.logger.info(f"[SESSION_FLOW] First incomplete session: creation_reference (pattern_analysis is empty)")
            return ('creation_reference', 2, total_sessions)

        self.logger.info(f"[SESSION_FLOW] creation_reference session: all steps completed")

        # 3. Check volume sessions (one per volume)
        for vol_num in range(start_volume, end_volume + 1):
            # Check volume outline
            file_path = f"{works_dir}/{work_id}/steps/volume_{vol_num}.txt"
            if not os.path.exists(file_path):
                self.logger.info(f"[SESSION_FLOW] First incomplete session: volume_{vol_num} (outline not found)")
                return ('volume', vol_num, total_sessions)
            content = self._read_file_safe(file_path)
            if not content or len(content.strip()) == 0:
                self.logger.info(f"[SESSION_FLOW] First incomplete session: volume_{vol_num} (outline is empty)")
                return ('volume', vol_num, total_sessions)

            # Check volume characters
            file_path = f"{works_dir}/{work_id}/steps/volume_{vol_num}_characters.txt"
            if not os.path.exists(file_path):
                self.logger.info(f"[SESSION_FLOW] First incomplete session: volume_{vol_num} (characters not found)")
                return ('volume', vol_num, total_sessions)
            content = self._read_file_safe(file_path)
            if not content or len(content.strip()) == 0:
                self.logger.info(f"[SESSION_FLOW] First incomplete session: volume_{vol_num} (characters is empty)")
                return ('volume', vol_num, total_sessions)

            self.logger.info(f"[SESSION_FLOW] volume_{vol_num} session: all steps completed")

        # 4. Check chapter sessions (one per volume, includes volume summary)
        for vol_num in range(start_volume, end_volume + 1):
            # Check all chapters in this volume
            for chapter_num in range(1, chapters_per_volume + 1):
                # Check chapter outline, title and content in steps directory
                txt_outline_path = f"{works_dir}/{work_id}/steps/chapter_{vol_num}_{chapter_num}_outline.txt"
                txt_title_path = f"{works_dir}/{work_id}/steps/chapter_{vol_num}_{chapter_num}_title.txt"
                txt_content_path = f"{works_dir}/{work_id}/steps/chapter_{vol_num}_{chapter_num}_content.txt"

                # Check outline exists and is non-empty
                if not os.path.exists(txt_outline_path):
                    self.logger.info(f"[SESSION_FLOW] First incomplete session: chapter_{vol_num} (chapter {chapter_num} outline not found)")
                    return ('chapter', vol_num, total_sessions)

                outline_content = self._read_file_safe(txt_outline_path)
                if not outline_content or len(outline_content.strip()) == 0:
                    self.logger.info(f"[SESSION_FLOW] First incomplete session: chapter_{vol_num} (chapter {chapter_num} outline is empty)")
                    return ('chapter', vol_num, total_sessions)

                # Check title exists and is non-empty
                if not os.path.exists(txt_title_path):
                    self.logger.info(f"[SESSION_FLOW] First incomplete session: chapter_{vol_num} (chapter {chapter_num} title not found)")
                    return ('chapter', vol_num, total_sessions)

                title_content = self._read_file_safe(txt_title_path)
                if not title_content or len(title_content.strip()) == 0:
                    self.logger.info(f"[SESSION_FLOW] First incomplete session: chapter_{vol_num} (chapter {chapter_num} title is empty)")
                    return ('chapter', vol_num, total_sessions)

                # Check content exists and is non-empty
                if not os.path.exists(txt_content_path):
                    self.logger.info(f"[SESSION_FLOW] First incomplete session: chapter_{vol_num} (chapter {chapter_num} content not found)")
                    return ('chapter', vol_num, total_sessions)

                content_content = self._read_file_safe(txt_content_path)
                if not content_content or len(content_content.strip()) == 0:
                    self.logger.info(f"[SESSION_FLOW] First incomplete session: chapter_{vol_num} (chapter {chapter_num} content is empty)")
                    return ('chapter', vol_num, total_sessions)

            # Check volume summary plot
            file_path = f"{works_dir}/{work_id}/steps/volume_{vol_num}_summary_plot.txt"
            if not os.path.exists(file_path):
                self.logger.info(f"[SESSION_FLOW] First incomplete session: chapter_{vol_num} (volume summary plot not found)")
                return ('chapter', vol_num, total_sessions)
            content = self._read_file_safe(file_path)
            if not content or len(content.strip()) == 0:
                self.logger.info(f"[SESSION_FLOW] First incomplete session: chapter_{vol_num} (volume summary plot is empty)")
                return ('chapter', vol_num, total_sessions)

            # Check volume summary character
            file_path = f"{works_dir}/{work_id}/steps/volume_{vol_num}_summary_character.txt"
            if not os.path.exists(file_path):
                self.logger.info(f"[SESSION_FLOW] First incomplete session: chapter_{vol_num} (volume summary character not found)")
                return ('chapter', vol_num, total_sessions)
            content = self._read_file_safe(file_path)
            if not content or len(content.strip()) == 0:
                self.logger.info(f"[SESSION_FLOW] First incomplete session: chapter_{vol_num} (volume summary character is empty)")
                return ('chapter', vol_num, total_sessions)

            self.logger.info(f"[SESSION_FLOW] chapter_{vol_num} session: all steps completed")

        # All sessions completed
        self.logger.info(f"[SESSION_FLOW] All sessions completed")
        return ('completed', 0, total_sessions)

    # ==================== Basic Info Session ====================

    def _execute_basic_info_session(self, current_session: int = 1, total_sessions: int = 4) -> None:
        """
        Basic info session - 4 input steps + 6 output steps.

        Input phase (only first step uses new_chat=True):
        1. 定义角色 (new_chat=True)
        2. 定义任务 (new_chat=False)
        3. 已完成步骤结果 (new_chat=False)
        4. 小说基本设定 (new_chat=False)

        Output phase (all use new_chat=False):
        1. 文风设定
        2. 故事梗概
        3. 时空设定
        4. 人物设定
        5. 书名
        6. 封面图片

        Note: Each step checks its file before execution. If file exists, step is skipped.
        """
        # Calculate total_sessions if not provided (for backward compatibility)
        if total_sessions == 4:
            start_volume = self.main_window._creation_start_volume
            end_volume = self.main_window._creation_end_volume
            total_sessions = 2 + 2 * (end_volume - start_volume + 1)  # basic + reference + volumes + chapters

        self.logger.info(f"[SESSION_START][基本设定会话 ({current_session}/{total_sessions})] 开始基本设定会话")

        # Mark first incomplete step as executing
        self._mark_first_incomplete_step_in_session('basic')

        # Input phase - first step uses new_chat=True, rest use new_chat=False
        self._basic_input_define_role(current_session, total_sessions)

    def _basic_input_define_role(self, current_session: int, total_sessions: int) -> None:
        """Input step 1: 定义角色 (new_chat=True)"""
        prompt = """【上下文输入 - 定义角色】

你将协助我进行小说创作。

在这个对话中，你的角色是：
1. 专业的小说创作者
2. 熟悉网络文学的叙事节奏和情节推进
3. 能够根据设定生成符合人物性格和故事走向的内容

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你理解了这个角色定位。"""
        self.logger.info(f"[STEP_INPUT][基本设定会话 {current_session}/{total_sessions}] 步骤 1/4: 定义角色")
        self._send_context_input_with_callback(prompt, True,
            lambda: self._basic_input_define_task(current_session, total_sessions))

    def _basic_input_define_task(self, current_session: int, total_sessions: int) -> None:
        """Input step 2: 定义任务 (new_chat=False)"""
        prompt = """【上下文输入 - 定义任务】

本次创作任务的目标是：根据提供的设定，生成小说的基本设定信息，包括：
1. 文风设定 - 确定小说的叙事风格和语言特色
2. 书名 - 为小说创作一个吸引人的标题
3. 故事梗概 - 构思故事的主线情节
4. 时空设定 - 建立故事发生的世界观和背景
5. 人物设定 - 设计主要角色的性格和特征
6. 封面图片 - 构思小说封面的视觉元素

我会分步骤提供上下文信息，请在收到所有信息后再开始创作。

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你理解了这个任务目标。"""
        self.logger.info(f"[STEP_INPUT][基本设定会话 {current_session}/{total_sessions}] 步骤 2/4: 定义任务")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._basic_input_basic_settings(current_session, total_sessions))

    def _basic_input_completed_info(self, current_session: int, total_sessions: int) -> None:
        """Input step 4: 已完成步骤结果 (new_chat=False) - for resume from break"""
        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        # Read completed basic info steps from disk
        completed_parts = []
        step_files = {
            'style_setting': '文风设定',
            'book_title': '书名',
            'story_summary': '故事梗概',
            'worldbuilding': '时空设定',
            'character_design': '人物设定',
            'cover_image': '封面图片',
        }
        for step_id, step_name in step_files.items():
            file_path = f"{steps_dir}/{step_id}.txt"
            content = self._read_file_safe(file_path)
            if content and content.strip():
                completed_parts.append(f"=== {step_name} ===\n{content}")

        if not completed_parts:
            # No completed basic info steps, go directly to output phase
            self.logger.info(f"[STEP_INPUT][基本设定会话 {current_session}/{total_sessions}] 步骤 4/4: 已完成步骤（无）")
            self._basic_start_output_phase(current_session, total_sessions)
            return

        prompt = """【上下文输入 - 已完成步骤结果】

以下是本次会话中已经完成的步骤结果，请确认你已经接收到所有信息：

"""
        prompt += "\n\n".join(completed_parts)
        prompt += """
【重要提示】
- 请仔细阅读并理解以上已完成的设定结果
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会开始输出创作，请等待指令

请确认你已理解所有已完成信息。"""

        self.logger.info(f"[STEP_INPUT][基本设定会话 {current_session}/{total_sessions}] 步骤 4/4: 已完成步骤结果")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._basic_start_output_phase(current_session, total_sessions))

    def _basic_input_basic_settings(self, current_session: int, total_sessions: int) -> None:
        """Input step 3: 小说基本设定 - 包含作品类型和创作指导 (new_chat=False)"""
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}
        novel_type = work_data.get('novel_type', '玄幻')
        creation_guide = work_data.get('creation_guide', '')

        prompt = f"""【上下文输入 - 小说基本设定】

以下是小说的基本设定：

=== 小说类型 ===
{novel_type}
"""
        if creation_guide and creation_guide.strip():
            prompt += f"""
=== 创作指导 ===
{creation_guide}
"""
        prompt += """
【重要提示】
- 请仔细阅读并理解以上内容
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已理解小说的基本设定。"""
        self.logger.info(f"[STEP_INPUT][基本设定会话 {current_session}/{total_sessions}] 步骤 3/4: 小说基本设定")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._basic_input_completed_info(current_session, total_sessions))

    def _basic_start_output_phase(self, current_session: int, total_sessions: int) -> None:
        """Start output phase - generate 6 outputs."""
        self.logger.info(f"[OUTPUT_PHASE][基本设定会话 {current_session}/{total_sessions}] 开始输出阶段")
        self._basic_generate_style_setting(current_session, total_sessions)

    def _basic_generate_style_setting(self, current_session: int, total_sessions: int) -> None:
        """Output step 1: 文风设定"""
        from models.template import get_default_template
        # Get templates directory from settings
        templates_dir = self._get_templates_dir()
        template = get_default_template('文风设定', templates_dir)
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}

        prompt = template.render({
            'novel_type': work_data.get('novel_type', '玄幻'),
            'literary_style_category': work_data.get('literary_style_category', ''),
        })
        file_path = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/style_setting.txt"

        self.logger.info(f"[STEP_OUTPUT][基本设定会话 {current_session}/{total_sessions}] 步骤 1/6: 文风设定")
        self._execute_output_step_with_callback(
            'style_setting', '文风设定', file_path, prompt, False,
            lambda: self._basic_generate_story_summary(current_session, total_sessions))

    def _basic_generate_book_title(self, current_session: int, total_sessions: int) -> None:
        """Output step 5: 书名"""
        from models.template import get_default_template
        # Get templates directory from settings
        templates_dir = self._get_templates_dir()
        template = get_default_template('书名', templates_dir)

        # Get work basic info
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}

        # Get completed steps from disk
        completed_steps = self._get_completed_steps()

        # Build context for template
        context = {
            'novel_type': work_data.get('novel_type', '玄幻'),
            'story_summary': completed_steps.get('story_summary', ''),
            'worldbuilding': completed_steps.get('worldbuilding', ''),
            'character_design': completed_steps.get('character_design', ''),
        }

        prompt = template.render(context)
        file_path = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/book_title.txt"

        self.logger.info(f"[STEP_OUTPUT][基本设定会话 {current_session}/{total_sessions}] 步骤 5/6: 书名")
        self._execute_output_step_with_callback(
            'book_title', '书名', file_path, prompt, False,
            lambda: self._basic_generate_cover_image(current_session, total_sessions))

    def _basic_generate_story_summary(self, current_session: int, total_sessions: int) -> None:
        """Output step 2: 故事梗概"""
        from models.template import get_default_template
        # Get templates directory from settings
        templates_dir = self._get_templates_dir()
        template = get_default_template('故事梗概', templates_dir)

        # Get work basic info
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}

        # Build context for template
        context = {
            'novel_type': work_data.get('novel_type', '玄幻'),
            'literary_style_category': work_data.get('literary_style_category', ''),
            'creation_guide': '',  # No creation guide needed for story summary
        }

        prompt = template.render(context)
        file_path = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/story_summary.txt"

        self.logger.info(f"[STEP_OUTPUT][基本设定会话 {current_session}/{total_sessions}] 步骤 2/6: 故事梗概")
        self._execute_output_step_with_callback(
            'story_summary', '故事梗概', file_path, prompt, False,
            lambda: self._basic_generate_worldbuilding(current_session, total_sessions))

    def _basic_generate_worldbuilding(self, current_session: int, total_sessions: int) -> None:
        """Output step 3: 时空设定"""
        from models.template import get_default_template
        # Get templates directory from settings
        templates_dir = self._get_templates_dir()
        template = get_default_template('时空设定', templates_dir)

        # Get work basic info
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}

        # Get completed steps from disk
        completed_steps = self._get_completed_steps()

        # Build context for template
        context = {
            'novel_type': work_data.get('novel_type', '玄幻'),
            'story_summary': completed_steps.get('story_summary', ''),
            'literary_style_category': work_data.get('literary_style_category', ''),
        }

        prompt = template.render(context)
        file_path = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/worldbuilding.txt"

        self.logger.info(f"[STEP_OUTPUT][基本设定会话 {current_session}/{total_sessions}] 步骤 3/6: 时空设定")
        self._execute_output_step_with_callback(
            'worldbuilding', '时空设定', file_path, prompt, False,
            lambda: self._basic_generate_character_design(current_session, total_sessions))

    def _basic_generate_character_design(self, current_session: int, total_sessions: int) -> None:
        """Output step 5: 人物设定"""
        from models.template import get_default_template
        # Get templates directory from settings
        templates_dir = self._get_templates_dir()
        template = get_default_template('人物设定', templates_dir)

        # Get work basic info
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}

        # Get completed steps from disk
        completed_steps = self._get_completed_steps()

        # Build context for template
        context = {
            'novel_type': work_data.get('novel_type', '玄幻'),
            'story_summary': completed_steps.get('story_summary', ''),
            'worldbuilding': completed_steps.get('worldbuilding', ''),
        }

        prompt = template.render(context)
        file_path = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/character_design.txt"

        self.logger.info(f"[STEP_OUTPUT][基本设定会话 {current_session}/{total_sessions}] 步骤 4/6: 人物设定")
        self._execute_output_step_with_callback(
            'character_design', '人物设定', file_path, prompt, False,
            lambda: self._basic_generate_book_title(current_session, total_sessions))

    def _basic_generate_cover_image(self, current_session: int, total_sessions: int) -> None:
        """Output step 6: 封面图片"""
        from models.template import get_default_template
        # Get templates directory from settings
        templates_dir = self._get_templates_dir()
        template = get_default_template('封面图片', templates_dir)

        # Get work basic info
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}

        # Get completed steps from disk
        completed_steps = self._get_completed_steps()

        # Build context for template
        context = {
            'novel_type': work_data.get('novel_type', '玄幻'),
            'book_title': completed_steps.get('book_title', ''),
            'author_name': work_data.get('author_name', ''),
            'story_summary': completed_steps.get('story_summary', ''),
            'worldbuilding': completed_steps.get('worldbuilding', ''),
            'characters': completed_steps.get('character_design', ''),
        }

        prompt = template.render(context)
        file_path = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/cover_image.txt"

        self.logger.info(f"[STEP_OUTPUT][基本设定会话 {current_session}/{total_sessions}] 步骤 6/6: 封面图片")
        self._execute_output_step_with_callback(
            'cover_image', '封面图片', file_path, prompt, False,
            lambda: self._basic_session_complete(current_session, total_sessions))

    def _basic_session_complete(self, current_session: int, total_sessions: int) -> None:
        """Basic info session complete."""
        self.logger.info(f"[SESSION_COMPLETE][基本设定会话 {current_session}/{total_sessions}] 会话完成 - 6/6 步骤")
        # Start next session: creation reference
        self._execute_creation_reference_session(current_session, total_sessions)

    # ==================== Creation Reference Session ====================

    def _execute_creation_reference_session(self, current_session: int, total_sessions: int) -> None:
        """
        Creation reference session - 3 input steps + reference analysis + pattern generation.

        Input phase (only first step uses new_chat=True):
        1. 定义角色 (new_chat=True)
        2. 定义任务 (new_chat=False)
        3. 已完成步骤结果 (new_chat=False) - for resume from break

        Output phase (all use new_chat=False):
        1. 拆书参考 1 (每个参考作品一个步骤，正文包含在提示词中)
        2. 拆书参考 2
        3. ... (更多参考作品)
        4. 创作公式 (based on the completed book reference analyses)
        """
        # Check if all reference outputs are already completed
        if self._is_reference_output_completed():
            self.logger.info(f"[SESSION_FLOW] Reference session output already completed, skipping to volume sessions")
            self.logger.info(f"[SESSION_FLOW] 开始处理卷 {self.main_window._creation_start_volume}-{self.main_window._creation_end_volume} (共{self.main_window._creation_end_volume - self.main_window._creation_start_volume + 1}卷)")
            self._execute_volume_sessions_loop(current_session, total_sessions, self.main_window._creation_start_volume)
            return

        self.logger.info(f"[SESSION_START][创作参考会话 ({current_session}/{total_sessions})] 开始创作参考会话")

        # Mark first incomplete step as executing
        self._mark_first_incomplete_step_in_session('reference')

        # Input phase - first step uses new_chat=True, rest use new_chat=False
        self._reference_input_define_role(current_session, total_sessions)

    def _is_reference_output_completed(self) -> bool:
        """Check if all reference outputs (拆书参考 + 创作公式) are completed."""
        work_id = self.main_window.creating_work_id
        works_dir = self.settings.works_dir
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}
        reference_works = work_data.get('reference_works', [])

        start_volume = self.main_window._creation_start_volume
        end_volume = self.main_window._creation_end_volume
        chapters_per_volume = work_data.get('chapters_per_volume', 5)
        start_chapter = start_volume * chapters_per_volume - chapters_per_volume + 1
        end_chapter = end_volume * chapters_per_volume

        # Check reference works
        for work_name in reference_works:
            safe_name = work_name.replace('/', '_').replace('\\', '_').replace(':', '_')
            file_path = f"{works_dir}/{work_id}/steps/reference_{safe_name}_{start_chapter}_{end_chapter}.txt"
            if not os.path.exists(file_path):
                self.logger.info(f"[REF_CHECK] Reference file not found: {file_path}")
                return False
            content = self._read_file_safe(file_path)
            if not content or len(content.strip()) == 0:
                self.logger.info(f"[REF_CHECK] Reference file is empty: {file_path}")
                return False

        # Check pattern analysis
        short_names = []
        for w in reference_works[:3]:
            if '/' in w:
                short_names.append(w.split('/')[1][:10])
            else:
                short_names.append(w[:10])
        safe_names = '_'.join(short_names)
        file_path = f"{works_dir}/{work_id}/steps/pattern_{safe_names}_{start_chapter}_{end_chapter}.txt"
        if not os.path.exists(file_path):
            self.logger.info(f"[REF_CHECK] Pattern file not found: {file_path}")
            return False
        content = self._read_file_safe(file_path)
        if not content or len(content.strip()) == 0:
            self.logger.info(f"[REF_CHECK] Pattern file is empty: {file_path}")
            return False

        self.logger.info(f"[REF_CHECK] All reference outputs completed")
        return True

    def _reference_input_define_role(self, current_session: int, total_sessions: int) -> None:
        """Input step 1: 定义角色 (new_chat=True)"""
        prompt = """【上下文输入 - 定义角色】

你将协助我进行小说创作分析。

在这个对话中，你的角色是：
1. 专业的文学分析师
2. 熟悉网络文学的创作模式和套路
3. 能够从优秀作品中提取创作规律和公式

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你理解了这个角色定位。"""
        self.logger.info(f"[SESSION_START][创作参考会话 ({current_session}/{total_sessions})][定义角色 (1/3)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, True,
            lambda: self._reference_input_define_task(current_session, total_sessions))

    def _reference_input_define_task(self, current_session: int, total_sessions: int) -> None:
        """Input step 2: 定义任务 (new_chat=False)"""
        prompt = """【上下文输入 - 定义任务】

本次创作任务的目标是：分析参考作品，提取创作公式和模式。

我会分步骤提供上下文信息，请在收到所有信息后再开始创作。

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你理解了这个任务目标。"""
        self.logger.info(f"[SESSION_START][创作参考会话 ({current_session}/{total_sessions})][定义任务 (2/3)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._reference_input_completed_info(current_session, total_sessions))

    def _reference_input_completed_info(self, current_session: int, total_sessions: int) -> None:
        """Input step 3: 已完成步骤结果 (new_chat=False) - for resume from break"""
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}
        reference_works = work_data.get('reference_works', [])
        start_chapter = self.main_window._creation_start_volume * self.main_window._creation_chapters_per_volume - self.main_window._creation_chapters_per_volume + 1
        end_chapter = self.main_window._creation_end_volume * self.main_window._creation_chapters_per_volume
        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        # Directly read reference work analysis results from disk
        completed_ref_parts = []
        for work_name in reference_works:
            safe_name = work_name.replace('/', '_').replace('\\', '_').replace(':', '_')
            ref_file = f"{steps_dir}/reference_{safe_name}_{start_chapter}_{end_chapter}.txt"
            ref_content = self._read_file_safe(ref_file)
            if ref_content and ref_content.strip():
                completed_ref_parts.append(f"=== {work_name} 拆书分析 ===\n{ref_content}")

        if not completed_ref_parts:
            # No completed reference analyses, go directly to output phase
            self.logger.info(f"[SESSION_START][创作参考会话 ({current_session}/{total_sessions})][已完成信息 (3/3)][STEP_INPUT]: 没有已完成步骤，直接进入输出阶段")
            self._reference_start_output_phase(current_session, total_sessions)
            return

        prompt = """【上下文输入 - 已完成步骤结果】

以下是本次会话中已经完成的步骤结果，请确认你已经接收到所有信息：

"""
        prompt += "\n\n".join(completed_ref_parts)
        prompt += """
【重要提示】
- 请仔细阅读并理解以上已完成的分析结果
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会开始输出创作，请等待指令

请确认你已理解所有已完成信息。"""

        self.logger.info(f"[SESSION_START][创作参考会话 ({current_session}/{total_sessions})][已完成信息 (3/3)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._reference_start_output_phase(current_session, total_sessions))

    def _reference_start_output_phase(self, current_session: int, total_sessions: int) -> None:
        """Start output phase - analyze reference works and generate pattern."""
        self.logger.info(f"[SESSION_START][创作参考会话 ({current_session}/{total_sessions})] 开始输出阶段")
        self._reference_analyze_works(current_session, total_sessions, 0)

    def _reference_analyze_works(self, current_session: int, total_sessions: int, work_index: int) -> None:
        """Analyze reference works one by one."""
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}
        reference_works = work_data.get('reference_works', [])

        if work_index >= len(reference_works):
            # All reference works analyzed, generate pattern
            self._reference_generate_pattern(current_session, total_sessions)
            return

        work_name = reference_works[work_index]
        start_chapter = self.main_window._creation_start_volume * self.main_window._creation_chapters_per_volume - self.main_window._creation_chapters_per_volume + 1
        end_chapter = self.main_window._creation_end_volume * self.main_window._creation_chapters_per_volume

        # Construct step_name
        if '/' in work_name:
            work_name_only = work_name.split('/')[1]
        else:
            work_name_only = work_name
        step_name = f'{work_name_only}({start_chapter}-{end_chapter}章拆书)'

        self.logger.info(f"[SESSION_START][创作参考会话 ({current_session}/{total_sessions})][{step_name} ({work_index + 1}/{len(reference_works) + 1})][STEP_GENERATING]: AI 生成中...")

        from models.template import get_default_template
        templates_dir = self._get_templates_dir()
        template = get_default_template('拆书参考', templates_dir)
        prompt = template.render({
            'work_name': work_name,
            'start_chapter': start_chapter,
            'end_chapter': end_chapter,
            'novel_type': work_data.get('novel_type', '玄幻')
        })

        # Add reference novel content directly to prompt
        from pathlib import Path
        category = work_data.get('category', '')
        # ref_work format is "category/work_name"
        if '/' in work_name:
            category_name, work_name_only = work_name.split('/', 1)
        else:
            category_name = category
            work_name_only = work_name

        # Read reference novel content from references directory
        ref_dir = Path(self.settings.storage_root) / "references" / category_name / work_name_only
        if ref_dir.exists():
            novel_content = ""
            for chap_num in range(start_chapter, end_chapter + 1):
                # 用前缀匹配查找文件，因为文件名可能是 "第xx章 xxxx" 格式
                prefix = f"第{chap_num}章"
                matching_files = [f for f in ref_dir.iterdir() if f.name.startswith(prefix)]
                if matching_files:
                    chap_path = matching_files[0]
                    content = chap_path.read_text(encoding='utf-8').strip()
                    if content:
                        novel_content += f"\n===《{work_name_only}》第{chap_num}章 ===\n{content}\n\n"

            # Add novel content to prompt
            if novel_content:
                prompt = prompt + "\n" + novel_content + "现在开始分析。"

        safe_name = work_name.replace('/', '_').replace('\\', '_').replace(':', '_')
        step_id = f'reference_{safe_name}_{start_chapter}_{end_chapter}'
        file_path = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/{step_id}.txt"
        step_name = f'{work_name_only}({start_chapter}-{end_chapter}章拆书)'

        self._execute_output_step_with_callback(
            step_id, step_name, file_path, prompt, False,
            lambda: self._reference_analyze_works(current_session, total_sessions, work_index + 1))

    def _reference_generate_pattern(self, current_session: int, total_sessions: int) -> None:
        """Generate pattern analysis from reference works."""
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}
        reference_works = work_data.get('reference_works', [])
        start_chapter = self.main_window._creation_start_volume * self.main_window._creation_chapters_per_volume - self.main_window._creation_chapters_per_volume + 1
        end_chapter = self.main_window._creation_end_volume * self.main_window._creation_chapters_per_volume
        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        self.logger.info(f"[SESSION_START][创作参考会话 ({current_session}/{total_sessions})][创作公式({start_chapter}-{end_chapter}章) ({len(reference_works) + 1}/{len(reference_works) + 1})][STEP_GENERATING]: AI 生成中...")

        from models.template import get_default_template
        templates_dir = self._get_templates_dir()
        template = get_default_template('创作公式', templates_dir)

        # Read completed reference analyses from disk
        book_reference_parts = []
        for work_name in reference_works:
            safe_name = work_name.replace('/', '_').replace('\\', '_').replace(':', '_')
            ref_file = f"{steps_dir}/reference_{safe_name}_{start_chapter}_{end_chapter}.txt"
            ref_content = self._read_file_safe(ref_file)
            if ref_content:
                book_reference_parts.append(f"=== {work_name} 拆书分析 ===\n{ref_content}")

        prompt = template.render({
            'novel_type': work_data.get('novel_type', '玄幻'),
            'novel_number': len(reference_works),
            'reference_works': ', '.join(reference_works),
            'start_chapter': start_chapter,
            'end_chapter': end_chapter,
            'book_reference': '\n\n'.join(book_reference_parts) if book_reference_parts else ''
        })

        # Extract second part after '/' first, then truncate to 10 chars
        short_names = []
        for w in reference_works[:3]:
            if '/' in w:
                short_names.append(w.split('/')[1][:10])
            else:
                short_names.append(w[:10])
        safe_names = '_'.join(short_names)
        step_id = f'pattern_{safe_names}_{start_chapter}_{end_chapter}'
        file_path = f"{self.settings.works_dir}/{work_id}/steps/{step_id}.txt"
        step_name = f'创作公式({start_chapter}-{end_chapter}章)'

        self._execute_output_step_with_callback(
            step_id, step_name, file_path, prompt, False,
            lambda: self._reference_session_complete(current_session, total_sessions))

    def _reference_session_complete(self, current_session: int, total_sessions: int) -> None:
        """Creation reference session complete."""
        self.logger.info(f"[SESSION_COMPLETE][创作参考会话 ({current_session}/{total_sessions})] 会话完成")
        # Start volume sessions
        self.logger.info(f"[SESSION_FLOW] 开始处理卷 {self.main_window._creation_start_volume}-{self.main_window._creation_end_volume} (共{self.main_window._creation_end_volume - self.main_window._creation_start_volume + 1}卷)")
        self._execute_volume_sessions_loop(current_session, total_sessions, self.main_window._creation_start_volume)

    def _execute_volume_sessions_loop(self, current_session: int, total_sessions: int, vol_num: int) -> None:
        """Loop through volumes."""
        if vol_num > self.main_window._creation_end_volume:
            # All volumes completed, start chapter sessions
            self._execute_chapter_sessions_loop(current_session, total_sessions, self.main_window._creation_start_volume)
            return

        # Check if volume output is already completed
        if self._is_volume_output_completed(vol_num):
            self.logger.info(f"[SESSION_FLOW] Volume {vol_num} output already completed, skipping to next volume")
            self._execute_volume_sessions_loop(current_session, total_sessions, vol_num + 1)
            return

        self._execute_volume_session(vol_num, current_session, total_sessions)

    def _is_volume_output_completed(self, vol_num: int) -> bool:
        """Check if volume output (outline + characters) is completed."""
        work_id = self.main_window.creating_work_id
        works_dir = self.settings.works_dir

        # Check outline
        outline_file = f"{works_dir}/{work_id}/steps/volume_{vol_num}.txt"
        if not os.path.exists(outline_file):
            return False
        outline_content = self._read_file_safe(outline_file)
        if not outline_content or not outline_content.strip():
            return False

        # Check characters
        char_file = f"{works_dir}/{work_id}/steps/volume_{vol_num}_characters.txt"
        if not os.path.exists(char_file):
            return False
        char_content = self._read_file_safe(char_file)
        if not char_content or not char_content.strip():
            return False

        return True

    # ==================== Volume Session Methods ====================

    def _execute_volume_session(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """
        Volume session - input phase once, then output phase loops through all volumes.

        Input phase (only first step uses new_chat=True):
        1. 定义角色 (new_chat=True)
        2. 定义任务 (new_chat=False)
        3. 小说基本设定 (new_chat=False)
        4. 创作公式 (new_chat=False)
        5. 前序剧情 (new_chat=False)
        6. 已完成分卷信息 (new_chat=False)

        Output phase loops through all volumes (skips completed ones):
        For each volume: 分卷大纲 -> 分卷人物
        """
        self.logger.info(f"[SESSION_START][分卷信息会话 ({current_session}/{total_sessions})] 开始分卷信息会话")

        # Mark first incomplete step as executing
        self._mark_first_incomplete_step_in_session('volume', vol_num)

        # Input phase - first step uses new_chat=True, rest use new_chat=False
        self._volume_input_define_role(vol_num, current_session, total_sessions)

    def _volume_input_define_role(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 1: 定义角色 (new_chat=True)"""
        prompt = """【上下文输入 - 定义角色】

你将协助我进行小说分卷创作。

在这个对话中，你的角色是：
1. 专业的小说创作者
2. 熟悉网络文学的叙事节奏和情节推进
3. 能够根据设定生成符合人物性格和故事走向的内容

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你理解了这个角色定位。"""
        self.logger.info(f"[SESSION_START][分卷信息会话 ({current_session}/{total_sessions})][定义角色 (1/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, True,
            lambda: self._volume_input_define_task(vol_num, current_session, total_sessions))

    def _volume_input_define_task(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 2: 定义任务 (new_chat=False)"""
        prompt = """【上下文输入 - 定义任务】

本次创作任务的目标是：根据分卷大纲和人物设定，创作详细的章节大纲和正文内容。

我会分步骤提供上下文信息，请在收到所有信息后再开始创作。

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你理解了这个任务目标。"""
        self.logger.info(f"[SESSION_START][分卷信息会话 ({current_session}/{total_sessions})][定义任务 (2/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._volume_input_basic_settings(vol_num, current_session, total_sessions))

    def _volume_input_basic_settings(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 3: 小说基本设定 (new_chat=False)"""
        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        # Read from disk files directly
        story_summary = self._read_file_safe(f"{steps_dir}/story_summary.txt")
        worldbuilding = self._read_file_safe(f"{steps_dir}/worldbuilding.txt")
        character_design = self._read_file_safe(f"{steps_dir}/character_design.txt")

        prompt = f"""【上下文输入 - 小说基本设定】

以下是小说的基本设定：

=== 故事梗概 ===
{story_summary}

=== 时空设定 ===
{worldbuilding}

=== 人物设定 ===
{character_design}

【重要提示】
- 请仔细阅读并理解以上内容
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已理解小说的基本设定。"""
        self.logger.info(f"[SESSION_START][分卷信息会话 ({current_session}/{total_sessions})][小说基本设定 (3/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._volume_input_pattern_analysis(vol_num, current_session, total_sessions))

    def _volume_input_pattern_analysis(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 4: 创作公式 (new_chat=False)"""
        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        # Read pattern analysis (创作公式)
        work_data = self.main_window.creating_work_data if hasattr(self.main_window, 'creating_work_data') else {}
        reference_works = work_data.get('reference_works', [])
        pattern_analysis = ''
        if reference_works:
            chapters_per_volume = self.main_window._creation_chapters_per_volume
            start_chapter = (self.main_window._creation_start_volume - 1) * chapters_per_volume + 1
            end_chapter = self.main_window._creation_end_volume * chapters_per_volume
            short_names = []
            for w in reference_works[:3]:
                if '/' in w:
                    short_names.append(w.split('/')[1][:10])
                else:
                    short_names.append(w[:10])
            work_names_short = '_'.join(short_names)
            pattern_file = f"{steps_dir}/pattern_{work_names_short}_{start_chapter}_{end_chapter}.txt"
            pattern_analysis = self._read_file_safe(pattern_file)

        if not pattern_analysis:
            prompt = """【上下文输入 - 创作公式】

没有找到创作公式内容，将跳过此步骤。

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认。"""
        else:
            prompt = f"""【上下文输入 - 创作公式】

以下是参考作品分析得出的创作公式：

=== 创作公式 ===
{pattern_analysis}

【重要提示】
- 请仔细阅读并理解以上创作公式
- 这是从参考作品中提炼的核心创作模式和规律
- 在后续创作中，请参考这个公式来保持风格的连贯性
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已理解创作公式。"""

        self.logger.info(f"[SESSION_START][分卷信息会话 ({current_session}/{total_sessions})][创作公式 (4/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._volume_input_previous_plot(vol_num, current_session, total_sessions))

    def _volume_input_previous_plot(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 4: 前序剧情 (new_chat=False)"""
        # Get previous volume summaries (both plot and character)
        vol_summaries = []
        vol_chars = []
        for i in range(1, vol_num):
            # Load plot summary
            plot_file = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/volume_{i}_summary_plot.txt"
            plot_content = self._read_file_safe(plot_file)
            if plot_content:
                vol_summaries.append(f"=== 第{i}卷 剧情总结 ===\n{plot_content}")

            # Load character summary
            char_file = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/volume_{i}_summary_character.txt"
            char_content = self._read_file_safe(char_file)
            if char_content:
                vol_chars.append(f"=== 第{i}卷 人物总结 ===\n{char_content}")

        if not vol_summaries and not vol_chars:
            prompt = """【上下文输入 - 前序剧情】

这是第一卷，没有前序剧情。

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作"""
        else:
            # Combine plot and character summaries
            all_summaries = vol_summaries + vol_chars
            prompt = f"""【上下文输入 - 前序剧情】

以下是前序卷的剧情总结和人物总结：

{'\n\n'.join(all_summaries)}

【重要提示】
- 请仔细阅读并理解以上内容
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已理解前序剧情发展和人物状态变化。"""

        self.logger.info(f"[SESSION_START][分卷信息会话 ({current_session}/{total_sessions})][前序剧情 (5/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._volume_input_completed_info(vol_num, current_session, total_sessions))

    def _volume_input_completed_info(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 6: 已完成分卷信息 (new_chat=False)"""
        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        # Check for ALL volumes' completed steps
        completed_info = []

        for v in range(self.main_window._creation_start_volume, self.main_window._creation_end_volume + 1):
            outline_file = f"{steps_dir}/volume_{v}.txt"
            char_file = f"{steps_dir}/volume_{v}_characters.txt"

            outline_content = self._read_file_safe(outline_file)
            char_content = self._read_file_safe(char_file)

            if outline_content:
                completed_info.append(f"=== 第{v}卷 分卷大纲 ===\n{outline_content}")
            if char_content:
                completed_info.append(f"=== 第{v}卷 分卷人物 ===\n{char_content}")

        if not completed_info:
            prompt = """【上下文输入 - 已完成分卷信息】

这是本阶段第一批创作，没有已完成的分卷信息。

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已了解。"""
        else:
            prompt = """【上下文输入 - 已完成分卷信息】

"""
            prompt += "\n\n".join(completed_info)
            prompt += """

【重要提示】
- 请仔细阅读并理解以上本卷已完成的内容
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已了解。"""

        self.logger.info(f"[SESSION_START][分卷信息会话 ({current_session}/{total_sessions})][已完成分卷信息 (6/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._volume_output_loop(current_session, total_sessions))

    def _volume_output_loop(self, current_session: int, total_sessions: int) -> None:
        """
        输出阶段入口 - 按卷顺序处理所有卷的大纲和人物生成。

        流程：
        对 vol_num 从 start 到 end:
            1. 检查大纲是否存在？不存在则生成
            2. 检查人物是否存在？不存在则生成
            3. 完成后继续下一卷
        所有卷完成后进入章节会话。
        """
        vol_num = self.main_window._creation_start_volume
        self.logger.info(f"[SESSION_START][分卷信息会话 ({current_session}/{total_sessions})] 开始输出阶段，处理第{vol_num}-{self.main_window._creation_end_volume}卷")
        self._volume_output_check_and_generate(vol_num, current_session, total_sessions)

    def _volume_output_check_and_generate(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """
        检查当前卷的状态并决定下一步操作。

        可能的操作：
        1. 大纲不存在 → 生成大纲 → 完成后回调继续检查人物
        2. 大纲存在但人物不存在 → 生成人物 → 完成后回调继续下一卷
        3. 大纲和人物都存在 → 继续下一卷
        """
        # 检查所有卷是否已完成
        if vol_num > self.main_window._creation_end_volume:
            self.logger.info(f"[VOLUME_OUTPUT] 所有分卷信息已完成")
            next_session = current_session + 1
            self._execute_chapter_sessions_loop(next_session, total_sessions, self.main_window._creation_start_volume)
            return

        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        # 检查大纲是否存在
        outline_file = f"{steps_dir}/volume_{vol_num}.txt"
        outline_content = self._read_file_safe(outline_file)
        outline_exists = outline_content and outline_content.strip()

        # 检查人物是否存在
        char_file = f"{steps_dir}/volume_{vol_num}_characters.txt"
        char_content = self._read_file_safe(char_file)
        char_exists = char_content and char_content.strip()

        if outline_exists and char_exists:
            # 该卷已完成，继续下一卷
            self.logger.info(f"[VOLUME_OUTPUT] 第{vol_num}卷大纲和人物都存在，跳过")
            self._volume_output_check_and_generate(vol_num + 1, current_session, total_sessions)
        elif outline_exists:
            # 大纲存在，生成人物
            self.logger.info(f"[VOLUME_OUTPUT] 第{vol_num}卷大纲已存在，开始生成人物")
            self._volume_generate_characters(vol_num, current_session, total_sessions)
        else:
            # 大纲不存在，先生成大纲
            self.logger.info(f"[VOLUME_OUTPUT] 第{vol_num}卷大纲不存在，开始生成大纲")
            self._volume_generate_outline(vol_num, current_session, total_sessions)

    def _volume_generate_outline(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Output step 1: 分卷大纲"""
        from models.template import get_default_template

        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"
        work_data = getattr(self.main_window, 'creating_work_data', None) or {}

        # Check if outline file already exists
        outline_file = f"{steps_dir}/volume_{vol_num}.txt"
        outline_content = self._read_file_safe(outline_file)
        if outline_content and outline_content.strip():
            self.logger.info(f"[VOLUME_OUTPUT] 第{vol_num}卷大纲文件已存在，跳过")
            # 直接生成人物
            self._volume_generate_characters(vol_num, current_session, total_sessions)
            return

        # Calculate chapter range
        chapters_per_volume = work_data.get('chapters_per_volume', 5)
        start_chapter = (vol_num - 1) * chapters_per_volume + 1
        end_chapter = vol_num * chapters_per_volume

        # Get completed steps from disk
        completed_steps = self._get_completed_steps()

        # Get template from user's templates directory
        templates_dir = self._get_templates_dir()
        template = get_default_template('分卷大纲', templates_dir)

        # Build context for template
        context = {
            'novel_type': work_data.get('novel_type', '玄幻'),
            'vol_num': vol_num,
            'start_chapter': start_chapter,
            'end_chapter': end_chapter,
            'story_summary': completed_steps.get('story_summary', ''),
            'worldbuilding': completed_steps.get('worldbuilding', ''),
            'character_design': completed_steps.get('character_design', ''),
            'pattern_analysis': completed_steps.get('pattern_analysis', ''),
        }

        prompt = template.render(context)
        file_path = f"{steps_dir}/volume_{vol_num}.txt"

        self.logger.info(f"[STEP_OUTPUT][第{vol_num}卷分卷信息会话 ({current_session}/{total_sessions})] 步骤 1/2: 分卷大纲")
        self._execute_output_step_with_callback(
            f'volume_{vol_num}', f'第{vol_num}卷 分卷大纲', file_path, prompt, False,
            lambda: self._volume_generate_characters(vol_num, current_session, total_sessions))

    def _volume_generate_characters(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Output step 2: 分卷人物"""
        from models.template import get_default_template

        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"
        work_data = getattr(self.main_window, 'creating_work_data', None) or {}

        # Check if characters file already exists
        char_file = f"{steps_dir}/volume_{vol_num}_characters.txt"
        char_content = self._read_file_safe(char_file)
        if char_content and char_content.strip():
            self.logger.info(f"[VOLUME_OUTPUT] 第{vol_num}卷人物文件已存在，跳过")
            self._volume_after_characters_complete(vol_num, current_session, total_sessions)
            return

        # Get completed steps from disk
        completed_steps = self._get_completed_steps()

        # Get template from user's templates directory
        templates_dir = self._get_templates_dir()
        template = get_default_template('分卷人物', templates_dir)

        # Build context for template
        context = {
            'novel_type': work_data.get('novel_type', '玄幻'),
            'vol_num': vol_num,
            'story_summary': completed_steps.get('story_summary', ''),
            'worldbuilding': completed_steps.get('worldbuilding', ''),
            'character_design': completed_steps.get('character_design', ''),
            'volume_outline': completed_steps.get(f'volume_{vol_num}', ''),
        }

        prompt = template.render(context)
        file_path = f"{steps_dir}/volume_{vol_num}_characters.txt"

        self.logger.info(f"[STEP_OUTPUT][分卷信息会话 ({current_session}/{total_sessions})] 生成第{vol_num}卷: 分卷人物")
        self._execute_output_step_with_callback(
            f'volume_{vol_num}_characters', f'第{vol_num}卷 分卷人物', file_path, prompt, False,
            lambda: self._volume_after_characters_complete(vol_num, current_session, total_sessions))

    def _volume_after_characters_complete(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """人物生成完成后的回调：继续检查下一卷或完成"""
        self.logger.info(f"[VOLUME_OUTPUT] 第{vol_num}卷人物生成完成")
        # 继续检查下一卷
        self._volume_output_check_and_generate(vol_num + 1, current_session, total_sessions)

    # ==================== Chapter Session Methods ====================

    def _execute_chapter_sessions_loop(self, current_session: int, total_sessions: int, vol_num: int) -> None:
        """Loop through volumes for chapter sessions."""
        if vol_num > self.main_window._creation_end_volume:
            # All chapters completed, finish creation
            self.main_window._on_creation_completed()
            return

        # Check if this volume's output phase is already completed
        if self._is_chapter_output_completed(vol_num):
            self.logger.info(f"[SESSION_FLOW] Chapter {vol_num} output already completed, skipping to next volume")
            # Continue to next volume
            self._execute_chapter_sessions_loop(current_session, total_sessions, vol_num + 1)
            return

        self._execute_chapter_session(vol_num, current_session, total_sessions)

    def _is_chapter_output_completed(self, vol_num: int) -> bool:
        """Check if all output steps for a chapter volume are completed."""
        work_id = self.main_window.creating_work_id
        works_dir = self.settings.works_dir
        chapters_per_volume = self.main_window._creation_chapters_per_volume

        # Check all chapter outline, title, content
        for chapter_num in range(1, chapters_per_volume + 1):
            outline_file = f"{works_dir}/{work_id}/steps/chapter_{vol_num}_{chapter_num}_outline.txt"
            title_file = f"{works_dir}/{work_id}/steps/chapter_{vol_num}_{chapter_num}_title.txt"
            content_file = f"{works_dir}/{work_id}/steps/chapter_{vol_num}_{chapter_num}_content.txt"

            # Check outline
            if not os.path.exists(outline_file):
                return False
            outline_content = self._read_file_safe(outline_file)
            if not outline_content or not outline_content.strip():
                return False

            # Check title
            if not os.path.exists(title_file):
                return False
            title_content = self._read_file_safe(title_file)
            if not title_content or not title_content.strip():
                return False

            # Check content
            if not os.path.exists(content_file):
                return False
            content = self._read_file_safe(content_file)
            if not content or not content.strip():
                return False

        # Check volume summary plot
        plot_file = f"{works_dir}/{work_id}/steps/volume_{vol_num}_summary_plot.txt"
        if not os.path.exists(plot_file):
            return False
        plot_content = self._read_file_safe(plot_file)
        if not plot_content or not plot_content.strip():
            return False

        # Check volume summary character
        char_file = f"{works_dir}/{work_id}/steps/volume_{vol_num}_summary_character.txt"
        if not os.path.exists(char_file):
            return False
        char_content = self._read_file_safe(char_file)
        if not char_content or not char_content.strip():
            return False

        return True

    def _execute_chapter_session(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """
        Chapter session - 6 input steps + chapter generation loop + volume summary.

        Input phase (only first step uses new_chat=True):
        1. 定义角色 (new_chat=True)
        2. 定义任务 (new_chat=False)
        3. 小说基本设定 (new_chat=False)
        4. 前序剧情 (new_chat=False)
        5. 分卷大纲和人物 (new_chat=False)
        6. 已完成章节信息 (new_chat=False)

        Output phase (all use new_chat=False):
        1. 第 1 章大纲
        2. 第 1 章正文
        3. 第 2 章大纲
        4. 第 2 章正文
        5. ... (循环至该卷最后一章)
        6. 最后一章正文
        7. 剧情总结
        8. 人物总结
        """
        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})] 开始第{vol_num}卷章节创作会话")

        # Mark first incomplete step as executing
        self._mark_first_incomplete_step_in_session('chapter', vol_num)

        # Input phase - first step uses new_chat=True, rest use new_chat=False
        self._chapter_input_define_role(vol_num, current_session, total_sessions)

    def _chapter_input_define_role(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 1: 定义角色 (new_chat=True)"""
        prompt = """【上下文输入 - 定义角色】

你将协助我进行小说章节大纲和正文的创作。

在这个对话中，你的角色是：
1. 专业的小说创作助手
2. 熟悉网络文学的叙事节奏和情节推进
3. 能够根据大纲生成符合人物性格和故事走向的正文内容

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你理解了这个角色定位。"""
        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})][定义角色 (1/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, True,
            lambda: self._chapter_input_define_task(vol_num, current_session, total_sessions))

    def _chapter_input_define_task(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 2: 定义任务 (new_chat=False)"""
        prompt = """【上下文输入 - 定义任务】

本次创作任务的目标是：根据分卷大纲和人物设定，为每一章创作详细的章节大纲和正文内容。

我会分步骤提供上下文信息，请在收到所有信息后再开始创作。

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你理解了这个任务目标。"""
        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})][定义任务 (2/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._chapter_input_basic_settings(vol_num, current_session, total_sessions))

    def _chapter_input_basic_settings(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 3: 小说基本设定 (new_chat=False)"""
        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        # Read from disk files directly
        story_summary = self._read_file_safe(f"{steps_dir}/story_summary.txt")
        worldbuilding = self._read_file_safe(f"{steps_dir}/worldbuilding.txt")
        character_design = self._read_file_safe(f"{steps_dir}/character_design.txt")

        prompt = f"""【上下文输入 - 小说基本设定】

以下是小说的基本设定：

=== 故事梗概 ===
{story_summary}

=== 时空设定 ===
{worldbuilding}

=== 人物设定 ===
{character_design}

【重要提示】
- 请仔细阅读并理解以上内容
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已理解小说的基本设定。"""
        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})][小说基本设定 (3/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._chapter_input_previous_plot(vol_num, current_session, total_sessions))

    def _chapter_input_previous_plot(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 5: 前序剧情 (new_chat=False)"""
        # Get previous volume summaries (both plot and character)
        vol_summaries = []
        vol_chars = []
        for i in range(1, vol_num):
            # Load plot summary
            plot_file = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/volume_{i}_summary_plot.txt"
            plot_content = self._read_file_safe(plot_file)
            if plot_content:
                vol_summaries.append(f"=== 第{i}卷 剧情总结 ===\n{plot_content}")

            # Load character summary
            char_file = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/volume_{i}_summary_character.txt"
            char_content = self._read_file_safe(char_file)
            if char_content:
                vol_chars.append(f"=== 第{i}卷 人物总结 ===\n{char_content}")

        if not vol_summaries and not vol_chars:
            prompt = """【上下文输入 - 前序剧情】

这是第一卷，没有前序剧情。

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作"""
        else:
            # Combine plot and character summaries
            all_summaries = vol_summaries + vol_chars
            prompt = f"""【上下文输入 - 前序剧情】

以下是前序卷的剧情总结和人物总结：

{'\n\n'.join(all_summaries)}

【重要提示】
- 请仔细阅读并理解以上内容
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已理解前序剧情发展和人物状态变化。"""

        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})][前序剧情 (4/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._chapter_input_volume_info(vol_num, current_session, total_sessions))

    def _chapter_input_volume_info(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 6: 分卷大纲和人物 (new_chat=False)"""
        # Get volume outline and characters
        outline_file = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/volume_{vol_num}.txt"
        char_file = f"{self.settings.works_dir}/{self.main_window.creating_work_id}/steps/volume_{vol_num}_characters.txt"
        outline_content = self._read_file_safe(outline_file)
        char_content = self._read_file_safe(char_file)

        if not outline_content:
            outline_content = f"第{vol_num}卷大纲 (未找到)"
        if not char_content:
            char_content = "分卷人物 (未找到)"

        prompt = f"""【上下文输入 - 分卷大纲和人物】

以下是本卷的分卷信息：

=== 第{vol_num}卷 分卷大纲 ===
{outline_content}

=== 第{vol_num}卷 分卷人物 ===
{char_content}

【重要提示】
- 请仔细阅读并理解以上内容
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已理解分卷大纲和人物设定。"""
        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})][分卷大纲和人物 (5/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._chapter_input_previous_3_chapters(vol_num, current_session, total_sessions))

    def _chapter_input_completed_info(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 7: 已完成章节信息 (new_chat=False)"""
        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        # Get completed chapters for this volume - 使用完整内容，不截断
        completed_chapters = []

        for chap in range(1, self.main_window._creation_chapters_per_volume + 1):
            txt_outline = f"{steps_dir}/chapter_{vol_num}_{chap}_outline.txt"
            txt_content = f"{steps_dir}/chapter_{vol_num}_{chap}_content.txt"

            outline_content = self._read_file_safe(txt_outline)
            content_content = self._read_file_safe(txt_content)

            if outline_content:
                completed_chapters.append(f"=== 第{vol_num}卷 第{chap}章 大纲 ===\n{outline_content}")
            if content_content:
                completed_chapters.append(f"=== 第{vol_num}卷 第{chap}章 正文 ===\n{content_content}")

        if not completed_chapters:
            prompt = """【上下文输入 - 已完成章节信息】

这是本阶段第一批创作，没有已完成的章节信息。

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已了解。"""
        else:
            prompt = f"""【上下文输入 - 已完成章节信息】

以下是已完成的章节：

{'\n\n'.join(completed_chapters)}

【重要提示】
- 请仔细阅读并理解以上内容
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已了解已完成的章节内容。"""

        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})][已完成章节信息 (6/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._chapter_start_output_phase(vol_num, current_session, total_sessions))

    def _chapter_input_previous_3_chapters(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Input step 6: 上一卷最后 3 章正文内容 (new_chat=False) - 用于保持剧情连贯性"""
        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        # Get previous volume's last 3 chapters content
        previous_vol = vol_num - 1
        previous_3_chapters = []

        if previous_vol >= 1:
            # 读取上一卷最后 3 章正文内容
            start_chap = max(1, self.main_window._creation_chapters_per_volume - 2)
            for chap in range(start_chap, self.main_window._creation_chapters_per_volume + 1):
                content_file = f"{steps_dir}/chapter_{previous_vol}_{chap}_content.txt"
                content = self._read_file_safe(content_file)
                if content:
                    previous_3_chapters.append(f"=== 第{previous_vol}卷 第{chap}章 正文 ===\n{content}")

        if not previous_3_chapters:
            prompt = """【上下文输入 - 上一卷最后 3 章正文】

没有上一卷的正文内容可供参考（可能是第一卷，或上一卷正文尚未创作）。
将从本卷第 1 章开始创作，请确保与前序剧情保持连贯。

【重要提示】
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**
- 接下来我会逐步提供更多信息，请等待所有信息接收完成后再开始创作

请确认你已了解。"""
        else:
            prompt = f"""【上下文输入 - 上一卷最后 3 章正文】

以下是上一卷最后 3 章的正文内容，请仔细阅读，确保本卷创作与上一卷结尾保持剧情连贯：

{'\n\n'.join(previous_3_chapters)}

【重要提示】
- 请仔细阅读并理解以上内容的剧情发展、人物对话、场景描写
- 本卷第 1 章需要紧接着上一卷最后一章的剧情继续创作，**不能有割裂感**
- **一定不要重复**上一卷结尾已经写过的剧情内容
- 只需回复"已理解"或简要确认，**不需要生成任何创作内容**

请确认你已理解上一卷结尾的剧情。"""

        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})][上一卷最后 3 章正文 (6/6)][STEP_INPUT]: 发送输入提示词")
        self._send_context_input_with_callback(prompt, False,
            lambda: self._chapter_input_completed_info(vol_num, current_session, total_sessions))

    def _chapter_start_output_phase(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Start output phase - generate all chapters."""
        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})] 开始输出阶段 - 章节创作")
        self._chapter_generate_all_chapters(vol_num, current_session, total_sessions, 1)

    def _chapter_generate_all_chapters(self, vol_num: int, current_session: int, total_sessions: int, chapter_num: int) -> None:
        """Generate all chapters one by one."""
        if chapter_num > self.main_window._creation_chapters_per_volume:
            # All chapters completed, start volume summary
            self._chapter_generate_volume_summary_plot(vol_num, current_session, total_sessions)
            return

        # Generate chapter outline first, then content
        self._chapter_generate_single_chapter_outline(vol_num, chapter_num, current_session, total_sessions)

    def _chapter_generate_single_chapter_outline(self, vol_num: int, chapter_num: int, current_session: int, total_sessions: int) -> None:
        """Generate single chapter outline."""
        from models.template import get_default_template

        # Calculate step number: outline=1, title=2, content=3, per chapter
        chapters_per_volume = self.main_window._creation_chapters_per_volume
        total_steps = chapters_per_volume * 3 + 2  # +2 for plot and character summary
        step_num = chapter_num * 3 - 2
        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})][第{chapter_num}章 章节大纲 ({step_num}/{total_steps})][STEP_GENERATING]: AI 生成中...")

        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"
        work_data = getattr(self.main_window, 'creating_work_data', None) or {}

        # Check if outline already exists
        outline_file = f"{steps_dir}/chapter_{vol_num}_{chapter_num}_outline.txt"
        outline_content = self._read_file_safe(outline_file)
        if outline_content and outline_content.strip():
            self.logger.info(f"[CHAPTER_OUTPUT] 第{chapter_num}章大纲已存在，跳过")
            # 直接生成标题
            self._chapter_generate_single_chapter_title(vol_num, chapter_num, current_session, total_sessions)
            return

        # Get completed steps from disk
        completed_steps = self._get_completed_steps()

        # Get template from user's templates directory
        templates_dir = self._get_templates_dir()
        template = get_default_template('章节大纲', templates_dir)

        # Build context for template
        context = {
            'novel_type': work_data.get('novel_type', '玄幻'),
            'vol_num': vol_num,
            'chapter_num': chapter_num,
            'story_summary': completed_steps.get('story_summary', ''),
            'worldbuilding': completed_steps.get('worldbuilding', ''),
            'character_design': completed_steps.get('character_design', ''),
            'volume_outline': completed_steps.get(f'volume_{vol_num}', ''),
            'volume_characters': completed_steps.get(f'volume_{vol_num}_characters', ''),
        }

        prompt = template.render(context)
        file_path = f"{steps_dir}/chapter_{vol_num}_{chapter_num}_outline.txt"

        self._execute_output_step_with_callback(
            f'chapter_{vol_num}_{chapter_num}_outline', f'第{chapter_num}章 章节大纲', file_path, prompt, False,
            lambda: self._chapter_generate_single_chapter_title(vol_num, chapter_num, current_session, total_sessions))

    def _chapter_generate_single_chapter_title(self, vol_num: int, chapter_num: int, current_session: int, total_sessions: int) -> None:
        """Generate single chapter title (only title, no content)."""
        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        # Check if title already exists
        title_file = f"{steps_dir}/chapter_{vol_num}_{chapter_num}_title.txt"
        title_content = self._read_file_safe(title_file)
        if title_content and title_content.strip():
            self.logger.info(f"[CHAPTER_OUTPUT] 第{chapter_num}章标题已存在，跳过")
            # 直接生成正文
            self._chapter_generate_single_chapter_content(vol_num, chapter_num, current_session, total_sessions)
            return

        # Calculate step number
        chapters_per_volume = self.main_window._creation_chapters_per_volume
        total_steps = chapters_per_volume * 3 + 2
        step_num = chapter_num * 3 - 1

        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})][第{chapter_num}章 章节标题 ({step_num}/{total_steps})][STEP_GENERATING]: AI 生成中...")

        # Build prompt for chapter title
        prompt = f"""【生成章节标题】

请为第{chapter_num}章生成一个简短、有吸引力的章节标题。

要求：
1. 只输出章节标题，不要输出任何其他内容
2. 标题应该简洁明了，体现本章核心内容
3. 不需要包含章节号（已经标注为第{chapter_num}章）

请直接输出标题："""

        file_path = f"{steps_dir}/chapter_{vol_num}_{chapter_num}_title.txt"

        self._execute_output_step_with_callback(
            f'chapter_{vol_num}_{chapter_num}_title', f'第{chapter_num}章 章节标题', file_path, prompt, False,
            lambda: self._chapter_generate_single_chapter_content(vol_num, chapter_num, current_session, total_sessions))

    def _chapter_generate_single_chapter_content(self, vol_num: int, chapter_num: int, current_session: int, total_sessions: int) -> None:
        """Generate single chapter content."""
        from models.template import get_default_template

        # Calculate step number
        chapters_per_volume = self.main_window._creation_chapters_per_volume
        total_steps = chapters_per_volume * 3 + 2
        step_num = chapter_num * 3

        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"
        work_data = getattr(self.main_window, 'creating_work_data', None) or {}

        # Check if content already exists
        content_file = f"{steps_dir}/chapter_{vol_num}_{chapter_num}_content.txt"
        content = self._read_file_safe(content_file)
        if content and content.strip():
            self.logger.info(f"[CHAPTER_OUTPUT] 第{chapter_num}章正文已存在，跳过")
            # 读取标题并更新步骤显示
            title_file = f"{steps_dir}/chapter_{vol_num}_{chapter_num}_title.txt"
            chapter_title = self._read_file_safe(title_file) or ""
            display_title = chapter_title.strip() if chapter_title.strip() else "章节正文"
            if chapter_title.strip():
                self.main_window.creation_view.set_step_status(
                    f'chapter_{vol_num}_{chapter_num}_content', 'completed', f'第{chapter_num}章 {display_title}')
            # 继续下一章
            self._chapter_generate_all_chapters(vol_num, current_session, total_sessions, chapter_num + 1)
            return

        # Get chapter title for template context
        title_file = f"{steps_dir}/chapter_{vol_num}_{chapter_num}_title.txt"
        chapter_title = self._read_file_safe(title_file) or ""

        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})][第{chapter_num}章 章节正文 ({step_num}/{total_steps})][STEP_GENERATING]: AI 生成中...")

        # Get completed steps from disk
        completed_steps = self._get_completed_steps()

        # Get template from user's templates directory
        templates_dir = self._get_templates_dir()
        template = get_default_template('章节正文', templates_dir)

        # Build context for template
        context = {
            'novel_type': work_data.get('novel_type', '玄幻'),
            'vol_num': vol_num,
            'chapter_num': chapter_num,
            'chapter_title': chapter_title,
            'chapter_outline': completed_steps.get(f'chapter_{vol_num}_{chapter_num}_outline', ''),
        }

        prompt = template.render(context)
        file_path = f"{steps_dir}/chapter_{vol_num}_{chapter_num}_content.txt"

        # 完成后更新的回调：读取标题并更新步骤显示
        def on_chapter_content_complete():
            if chapter_title.strip():
                self.main_window.creation_view.set_step_status(
                    f'chapter_{vol_num}_{chapter_num}_content', 'completed', f'第{chapter_num}章 {chapter_title.strip()}')
            self._chapter_generate_all_chapters(vol_num, current_session, total_sessions, chapter_num + 1)

        self._execute_output_step_with_callback(
            f'chapter_{vol_num}_{chapter_num}_content', f'第{chapter_num}章 章节正文', file_path, prompt, False,
            on_chapter_content_complete)

    def _chapter_generate_volume_summary_plot(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Generate volume summary plot."""
        from models.template import get_default_template

        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})][剧情总结 ({self.main_window._creation_chapters_per_volume * 3 + 1}/{self.main_window._creation_chapters_per_volume * 3 + 2})][STEP_GENERATING]: AI 生成中...")

        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"
        work_data = getattr(self.main_window, 'creating_work_data', None) or {}

        # Get all chapter contents for this volume
        chapter_contents = []
        for chap in range(1, self.main_window._creation_chapters_per_volume + 1):
            content_file = f"{steps_dir}/chapter_{vol_num}_{chap}_content.txt"
            content = self._read_file_safe(content_file)
            if content:
                chapter_contents.append(f"=== 第{vol_num}卷 第{chap}章 ===\n{content}")

        # Get template from user's templates directory
        templates_dir = self._get_templates_dir()
        template = get_default_template('剧情总结', templates_dir)

        # Build context for template
        context = {
            'vol_num': vol_num,
            'chapter_index': self.main_window._creation_chapters_per_volume,
            'all_chapters_content': '\n\n'.join(chapter_contents),
        }

        prompt = template.render(context)
        file_path = f"{steps_dir}/volume_{vol_num}_summary_plot.txt"

        self._execute_output_step_with_callback(
            f'volume_{vol_num}_summary_plot', f'剧情总结', file_path, prompt, False,
            lambda: self._chapter_generate_volume_summary_character(vol_num, current_session, total_sessions))

    def _chapter_generate_volume_summary_character(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Generate volume summary character."""
        from models.template import get_default_template

        self.logger.info(f"[SESSION_START][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})][人物总结 ({self.main_window._creation_chapters_per_volume * 3 + 2}/{self.main_window._creation_chapters_per_volume * 3 + 2})][STEP_GENERATING]: AI 生成中...")

        work_id = self.main_window.creating_work_id
        steps_dir = f"{self.settings.works_dir}/{work_id}/steps"

        # Get template from user's templates directory
        templates_dir = self._get_templates_dir()
        template = get_default_template('人物总结', templates_dir)

        # Build context for template
        context = {
            'vol_num': vol_num,
            'chapter_index': self.main_window._creation_chapters_per_volume,
        }

        prompt = template.render(context)
        file_path = f"{steps_dir}/volume_{vol_num}_summary_character.txt"

        self._execute_output_step_with_callback(
            f'volume_{vol_num}_summary_character', f'人物总结', file_path, prompt, False,
            lambda: self._chapter_session_complete(vol_num, current_session, total_sessions))

    def _chapter_session_complete(self, vol_num: int, current_session: int, total_sessions: int) -> None:
        """Chapter session complete."""
        self.logger.info(f"[SESSION_COMPLETE][第{vol_num}卷章节 + 总结会话 ({current_session}/{total_sessions})] 会话完成 - {self.main_window._creation_chapters_per_volume * 3 + 2}/{self.main_window._creation_chapters_per_volume * 3 + 2} 步骤")
        # Continue to next volume
        self._execute_chapter_sessions_loop(current_session, total_sessions, vol_num + 1)

    def _read_chapter_file(self, file_path: str) -> dict:
        """Read chapter JSON file safely."""
        import json
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}