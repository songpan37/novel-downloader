"""
Multi-Title Dialog for AI Writer application.

Allows users to select from multiple AI-generated book titles.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QListWidget, QListWidgetItem,
    QTextEdit, QMessageBox
)
from PyQt6.QtCore import Qt, pyqtSignal
from typing import Optional, List


class MultiTitleDialog(QDialog):
    """
    Dialog for selecting from multiple AI-generated book titles.

    Shows a list of generated titles and allows the user to
    select one or generate more options.

    Signals:
        title_selected: Emitted when user selects a title (selected_title)
        generate_more_requested: Emitted when user requests more titles
    """

    title_selected = pyqtSignal(str)  # selected_title
    generate_more_requested = pyqtSignal()

    def __init__(self, parent=None, current_title: str = "", work_category: str = ""):
        """
        Initialize multi-title dialog.

        Args:
            parent: Parent widget
            current_title: Current work title (if any)
            work_category: Work category for context
        """
        super().__init__(parent)
        self.current_title = current_title
        self.work_category = work_category
        self._generated_titles: List[str] = []
        self._selected_index: int = -1
        self.setObjectName("multiTitleDialog")
        self._setup_ui()
        self._setup_connections()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        self.setWindowTitle("AI 生成多书名")
        self.setModal(True)
        self.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.setMinimumSize(500, 450)
        self.setFixedSize(500, 450)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Title
        title_label = QLabel("AI 生成多书名")
        title_label.setObjectName("dialogTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Subtitle
        subtitle_label = QLabel("以下是 AI 为您的小说生成的书名，请选择一个或点击'生成更多'")
        subtitle_label.setObjectName("dialogSubtitle")
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle_label.setWordWrap(True)
        layout.addWidget(subtitle_label)

        # Generated titles list
        list_container = QFrame()
        list_container.setObjectName("listContainer")
        list_layout = QVBoxLayout(list_container)
        list_layout.setSpacing(10)

        # Section label
        list_label = QLabel("生成的书名列表:")
        list_label.setObjectName("sectionLabel")
        list_layout.addWidget(list_label)

        # Title list
        self.title_list = QListWidget()
        self.title_list.setObjectName("titleList")
        self.title_list.setAlternatingRowColors(True)
        self.title_list.setMinimumHeight(200)
        list_layout.addWidget(self.title_list)

        layout.addWidget(list_container)

        # Current title display (if exists)
        if self.current_title:
            current_container = QFrame()
            current_container.setObjectName("currentContainer")
            current_layout = QVBoxLayout(current_container)

            current_label = QLabel(f"当前书名：{self.current_title}")
            current_label.setObjectName("currentLabel")
            current_layout.addWidget(current_label)

            layout.addWidget(current_container)

        # Action buttons
        self._setup_action_buttons(layout)

        # Status label
        self.status_label = QLabel("")
        self.status_label.setObjectName("statusLabel")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

    def _setup_action_buttons(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up action buttons section.

        Args:
            parent_layout: Layout to add section to
        """
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)
        button_layout.addStretch()

        self.btn_generate_more = QPushButton("生成更多")
        self.btn_generate_more.setObjectName("generateMoreBtn")
        self.btn_generate_more.setFixedWidth(120)
        button_layout.addWidget(self.btn_generate_more)

        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.setObjectName("cancelBtn")
        self.btn_cancel.setFixedWidth(100)
        button_layout.addWidget(self.btn_cancel)

        self.btn_select = QPushButton("选用此书")
        self.btn_select.setObjectName("selectBtn")
        self.btn_select.setFixedWidth(120)
        self.btn_select.setEnabled(False)  # Disabled until selection
        button_layout.addWidget(self.btn_select)

        parent_layout.addLayout(button_layout)

    def _setup_connections(self) -> None:
        """Connect signals and slots."""
        self.btn_select.clicked.connect(self._on_select)
        self.btn_cancel.clicked.connect(self.reject)
        self.btn_generate_more.clicked.connect(self._on_generate_more)
        self.title_list.itemClicked.connect(self._on_title_clicked)
        self.title_list.itemDoubleClicked.connect(self._on_title_double_clicked)

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            #multiTitleDialog {
                background-color: #f5f5f5;
            }

            #dialogTitle {
                font-size: 20px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 5px;
            }

            #dialogSubtitle {
                font-size: 13px;
                color: #7f8c8d;
                margin-bottom: 15px;
            }

            #listContainer, #currentContainer {
                background-color: #ffffff;
                border-radius: 10px;
                padding: 15px;
            }

            #sectionLabel {
                font-size: 14px;
                font-weight: bold;
                color: #34495e;
            }

            #titleList {
                border: 1px solid #e0e0e0;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
                background-color: #fafafa;
            }

            #titleList::item {
                padding: 10px;
                border-radius: 4px;
                margin: 2px 0;
            }

            #titleList::item:selected {
                background-color: #3498db;
                color: white;
            }

            #titleList::item:hover {
                background-color: #e3f2fd;
            }

            #currentLabel {
                font-size: 13px;
                color: #7f8c8d;
                font-style: italic;
            }

            #statusLabel {
                font-size: 13px;
                color: #27ae60;
                margin-top: 5px;
            }

            #generateMoreBtn {
                background-color: #9b59b6;
                color: white;
                border: none;
                padding: 10px 16px;
                border-radius: 5px;
                font-size: 14px;
            }

            #generateMoreBtn:hover {
                background-color: #8e44ad;
            }

            #cancelBtn {
                padding: 10px 16px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                background-color: #ffffff;
                font-size: 14px;
            }

            #cancelBtn:hover {
                background-color: #ecf0f1;
            }

            #selectBtn {
                background-color: #3498db;
                color: white;
                border: none;
                padding: 10px 16px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
            }

            #selectBtn:hover {
                background-color: #2980b9;
            }

            #selectBtn:disabled {
                background-color: #95a5a6;
            }
        """)

    def _on_title_clicked(self, item: QListWidgetItem) -> None:
        """Handle title item click."""
        self._selected_index = self.title_list.row(item)
        self.btn_select.setEnabled(True)
        self.status_label.setText("")

    def _on_title_double_clicked(self, item: QListWidgetItem) -> None:
        """Handle title item double-click (auto-select)."""
        self._selected_index = self.title_list.row(item)
        self._on_select()

    def _on_select(self) -> None:
        """Handle select button click."""
        if self._selected_index >= 0 and self._selected_index < len(self._generated_titles):
            selected_title = self._generated_titles[self._selected_index]
            self.title_selected.emit(selected_title)
            self.accept()
        else:
            QMessageBox.warning(
                self,
                "提示",
                "请先选择一个书名"
            )

    def _on_generate_more(self) -> None:
        """Handle generate more button click."""
        self.generate_more_requested.emit()

    def set_generated_titles(self, titles: List[str]) -> None:
        """
        Set the list of generated titles to display.

        Args:
            titles: List of generated book titles
        """
        self._generated_titles = titles
        self.title_list.clear()

        for i, title in enumerate(titles):
            item = QListWidgetItem(f"{i + 1}. {title}")
            self.title_list.addItem(item)

        if titles:
            self.status_label.setText(f"已生成 {len(titles)} 个书名选项")
        else:
            self.status_label.setText("")

    def get_selected_title(self) -> Optional[str]:
        """
        Get the selected title.

        Returns:
            Selected title or None if no selection
        """
        if self._selected_index >= 0 and self._selected_index < len(self._generated_titles):
            return self._generated_titles[self._selected_index]
        return None

    def clear_selection(self) -> None:
        """Clear the current selection."""
        self._selected_index = -1
        self.btn_select.setEnabled(False)
        self.title_list.clearSelection()

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()

        # Escape key - close dialog without saving
        if key == Qt.Key.Key_Escape:
            self.reject()
            return

        # Let the base class handle other keys
        super().keyPressEvent(event)
