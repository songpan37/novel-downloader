"""
Multi-Cover Dialog for AI Writer application.

Allows users to select from multiple AI-generated book covers.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QListWidget, QListWidgetItem,
    QMessageBox, QScrollArea, QWidget
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QPixmap, QIcon
from typing import Optional, List, Dict
import random


class MultiCoverDialog(QDialog):
    """
    Dialog for selecting from multiple AI-generated book covers.

    Shows a grid of generated cover images and allows the user
    to select one or generate more options.

    Signals:
        cover_selected: Emitted when user selects a cover (cover_url)
        generate_more_requested: Emitted when user requests more covers
    """

    cover_selected = pyqtSignal(str)  # cover_url
    generate_more_requested = pyqtSignal()

    def __init__(self, parent=None, current_cover_url: str = "", work_category: str = "", work_title: str = ""):
        """
        Initialize multi-cover dialog.

        Args:
            parent: Parent widget
            current_cover_url: Current cover URL (if any)
            work_category: Work category for context
            work_title: Work title for cover generation context
        """
        super().__init__(parent)
        self.current_cover_url = current_cover_url
        self.work_category = work_category
        self.work_title = work_title
        self._generated_covers: List[Dict[str, str]] = []
        self._selected_index: int = -1
        self.setObjectName("multiCoverDialog")
        self._setup_ui()
        self._setup_connections()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        self.setWindowTitle("AI 生成多封面")
        self.setModal(True)
        self.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.setMinimumSize(600, 550)
        self.setFixedSize(600, 550)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Title
        title_label = QLabel("AI 生成多封面")
        title_label.setObjectName("dialogTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Subtitle
        subtitle_label = QLabel("以下是 AI 为您的小说生成的封面，请选择一个或点击'生成更多'")
        subtitle_label.setObjectName("dialogSubtitle")
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle_label.setWordWrap(True)
        layout.addWidget(subtitle_label)

        # Cover preview area with scroll
        scroll = QScrollArea()
        scroll.setObjectName("coverScroll")
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        # Container for covers
        self.covers_container = QWidget()
        self.covers_container.setObjectName("coversContainer")
        self.covers_layout = QVBoxLayout(self.covers_container)
        self.covers_layout.setSpacing(15)

        scroll.setWidget(self.covers_container)
        layout.addWidget(scroll)

        # Current cover display (if exists)
        if self.current_cover_url:
            current_container = QFrame()
            current_container.setObjectName("currentContainer")
            current_layout = QVBoxLayout(current_container)

            current_label = QLabel(f"当前封面：{self.current_cover_url}")
            current_label.setObjectName("currentLabel")
            current_layout.addWidget(current_label)

            layout.addWidget(current_container)

        # Action buttons
        self._setup_action_buttons(layout)

        # Status label
        self.status_label = QLabel("")
        self.status_label.setObjectName("statusLabel")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

    def _setup_action_buttons(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up action buttons section.

        Args:
            parent_layout: Layout to add section to
        """
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)
        button_layout.addStretch()

        self.btn_generate_more = QPushButton("生成更多")
        self.btn_generate_more.setObjectName("generateMoreBtn")
        self.btn_generate_more.setFixedWidth(120)
        button_layout.addWidget(self.btn_generate_more)

        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.setObjectName("cancelBtn")
        self.btn_cancel.setFixedWidth(100)
        button_layout.addWidget(self.btn_cancel)

        self.btn_select = QPushButton("选用此封面")
        self.btn_select.setObjectName("selectBtn")
        self.btn_select.setFixedWidth(120)
        self.btn_select.setEnabled(False)  # Disabled until selection
        button_layout.addWidget(self.btn_select)

        parent_layout.addLayout(button_layout)

    def _setup_connections(self) -> None:
        """Connect signals and slots."""
        self.btn_select.clicked.connect(self._on_select)
        self.btn_cancel.clicked.connect(self.reject)
        self.btn_generate_more.clicked.connect(self._on_generate_more)

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            #multiCoverDialog {
                background-color: #f5f5f5;
            }

            #dialogTitle {
                font-size: 20px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 5px;
            }

            #dialogSubtitle {
                font-size: 13px;
                color: #7f8c8d;
                margin-bottom: 15px;
            }

            #coversContainer {
                background-color: #ffffff;
                border-radius: 10px;
                padding: 15px;
            }

            #coverScroll {
                border: 1px solid #e0e0e0;
                border-radius: 5px;
                background-color: #fafafa;
            }

            .coverItem {
                background-color: #ffffff;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 10px;
            }

            .coverItem:selected {
                border-color: #3498db;
                background-color: #e3f2fd;
            }

            #currentContainer {
                background-color: #ffffff;
                border-radius: 10px;
                padding: 15px;
                margin-top: 10px;
            }

            #currentLabel {
                font-size: 13px;
                color: #7f8c8d;
                font-style: italic;
            }

            #statusLabel {
                font-size: 13px;
                color: #27ae60;
                margin-top: 5px;
            }

            #generateMoreBtn {
                background-color: #9b59b6;
                color: white;
                border: none;
                padding: 10px 16px;
                border-radius: 5px;
                font-size: 14px;
            }

            #generateMoreBtn:hover {
                background-color: #8e44ad;
            }

            #cancelBtn {
                padding: 10px 16px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                background-color: #ffffff;
                font-size: 14px;
            }

            #cancelBtn:hover {
                background-color: #ecf0f1;
            }

            #selectBtn {
                background-color: #3498db;
                color: white;
                border: none;
                padding: 10px 16px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
            }

            #selectBtn:hover {
                background-color: #2980b9;
            }

            #selectBtn:disabled {
                background-color: #95a5a6;
            }
        """)

    def _create_cover_item(self, cover_data: Dict[str, str], index: int) -> QFrame:
        """
        Create a cover item widget.

        Args:
            cover_data: Dict with 'url' and 'description' keys
            index: Index of the cover

        Returns:
            QFrame widget containing cover info
        """
        item = QFrame()
        item.setObjectName(f"coverItem_{index}")
        item.setProperty("class", "coverItem")
        item.setCursor(Qt.CursorShape.PointingHandCursor)

        layout = QHBoxLayout(item)
        layout.setContentsMargins(10, 10, 10, 10)

        # Cover placeholder (color-coded by category)
        cover_placeholder = QLabel()
        cover_placeholder.setObjectName(f"coverPlaceholder_{index}")
        cover_placeholder.setFixedSize(80, 100)
        cover_placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Generate a color based on category and index
        colors = {
            "玄幻": ["#e74c3c", "#c0392b", "#e67e22", "#d35400", "#f39c12"],
            "都市": ["#3498db", "#2980b9", "#1abc9c", "#16a085", "#00bcd4"],
            "科幻": ["#9b59b6", "#8e44ad", "#34495e", "#2c3e50", "#607d8b"],
            "武侠": ["#27ae60", "#229954", "#1e8449", "#196f3d", "#145a32"],
            "历史": ["#d35400", "#ba4a00", "#a04000", "#873600", "#6e2c00"],
            "言情": ["#e91e63", "#c2185b", "#ad1457", "#880e4f", "#f06292"],
            "悬疑": ["#424242", "#212121", "#616161", "#757575", "#9e9e9e"],
            "网游": ["#ff5722", "#f4511e", "#e64a19", "#d84315", "#bf360c"],
            "其他": ["#607d8b", "#546e7a", "#455a64", "#37474f", "#263238"]
        }
        category_colors = colors.get(self.work_category, colors["其他"])
        color = category_colors[index % len(category_colors)]

        cover_placeholder.setStyleSheet(f"""
            background-color: {color};
            border-radius: 4px;
            color: white;
            font-size: 32px;
            font-weight: bold;
        """)

        # Show first character of title
        if self.work_title:
            cover_placeholder.setText(self.work_title[0] if self.work_title else "?")

        layout.addWidget(cover_placeholder)

        # Cover info
        info_layout = QVBoxLayout()

        url_label = QLabel(f"封面 {index + 1}")
        url_label.setObjectName("coverUrlLabel")
        url_label.setStyleSheet("font-weight: bold; font-size: 14px;")
        info_layout.addWidget(url_label)

        desc_label = QLabel(cover_data.get("description", "AI 生成封面"))
        desc_label.setObjectName("coverDescLabel")
        desc_label.setWordWrap(True)
        desc_label.setStyleSheet("color: #7f8c8d; font-size: 12px;")
        info_layout.addWidget(desc_label)

        url_text = QLabel(f"URL: {cover_data.get('url', '')}")
        url_text.setObjectName("coverUrlText")
        url_text.setWordWrap(True)
        url_text.setStyleSheet("color: #1a5276; font-size: 12px; font-family: Consolas, monospace;")
        info_layout.addWidget(url_text)

        layout.addLayout(info_layout)

        return item

    def set_generated_covers(self, covers: List[Dict[str, str]]) -> None:
        """
        Set the list of generated covers to display.

        Args:
            covers: List of dicts with 'url' and 'description' keys
        """
        self._generated_covers = covers

        # Clear existing items
        while self.covers_layout.count():
            child = self.covers_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        # Add cover items
        for i, cover in enumerate(covers):
            cover_item = self._create_cover_item(cover, i)
            cover_item.mousePressEvent = lambda e, idx=i: self._on_cover_clicked(idx)
            cover_item.mouseDoubleClickEvent = lambda e, idx=i: self._on_cover_double_clicked(idx)
            self.covers_layout.addWidget(cover_item)

        if covers:
            self.status_label.setText(f"已生成 {len(covers)} 个封面选项")
        else:
            self.status_label.setText("")

    def _on_cover_clicked(self, index: int) -> None:
        """Handle cover item click."""
        self._selected_index = index
        self.btn_select.setEnabled(True)

        # Visual feedback - highlight selected
        for i in range(self.covers_layout.count()):
            item = self.covers_layout.itemAt(i).widget()
            if i == index:
                item.setStyleSheet("""
                    background-color: #e3f2fd;
                    border: 2px solid #3498db;
                    border-radius: 8px;
                """)
            else:
                item.setStyleSheet("""
                    background-color: #ffffff;
                    border: 2px solid #e0e0e0;
                    border-radius: 8px;
                """)

        self.status_label.setText(f"已选择封面 {index + 1}")

    def _on_cover_double_clicked(self, index: int) -> None:
        """Handle cover item double-click (auto-select)."""
        self._selected_index = index
        self._on_select()

    def _on_select(self) -> None:
        """Handle select button click."""
        if self._selected_index >= 0 and self._selected_index < len(self._generated_covers):
            selected_cover = self._generated_covers[self._selected_index]
            self.cover_selected.emit(selected_cover.get("url", ""))
            self.accept()
        else:
            QMessageBox.warning(
                self,
                "提示",
                "请先选择一个封面"
            )

    def _on_generate_more(self) -> None:
        """Handle generate more button click."""
        self.generate_more_requested.emit()

    def get_selected_cover(self) -> Optional[Dict[str, str]]:
        """
        Get the selected cover.

        Returns:
            Selected cover dict or None if no selection
        """
        if self._selected_index >= 0 and self._selected_index < len(self._generated_covers):
            return self._generated_covers[self._selected_index]
        return None

    def clear_selection(self) -> None:
        """Clear the current selection."""
        self._selected_index = -1
        self.btn_select.setEnabled(False)

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()

        # Escape key - close dialog without saving
        if key == Qt.Key.Key_Escape:
            self.reject()
            return

        # Let the base class handle other keys
        super().keyPressEvent(event)
