"""
Recovery dialog for corrupted JSON files.

Provides a user-friendly dialog when corrupted data is detected,
with options to restore from backup or view file details.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QWidget, QFrame, QTextEdit, QGroupBox, QFormLayout
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont


class RecoveryDialog(QDialog):
    """
    Dialog shown when a corrupted JSON file is detected.

    Offers the user options to:
    - Restore from backup (if available)
    - View file details
    - Cancel and keep the corrupted file

    Attributes:
        restore_clicked: Signal emitted when restore is selected
        cancel_clicked: Signal emitted when cancel is selected
    """

    restore_clicked = pyqtSignal()
    cancel_clicked = pyqtSignal()

    def __init__(
        self,
        file_path: str,
        error_message: str,
        backup_available: bool = False,
        backup_info: dict = None,
        parent=None
    ):
        """
        Initialize the recovery dialog.

        Args:
            file_path: Path to the corrupted file
            error_message: Error message describing the corruption
            backup_available: Whether a backup file exists
            backup_info: Dictionary with backup file information
            parent: Parent widget
        """
        super().__init__(parent)
        self.setWindowTitle("数据文件损坏")
        self.setModal(True)
        self.setMinimumWidth(500)
        self.setMinimumHeight(350)

        self.file_path = file_path
        self.error_message = error_message
        self.backup_available = backup_available
        self.backup_info = backup_info or {}

        self._setup_ui()

    def _setup_ui(self) -> None:
        """Set up the dialog UI."""
        layout = QVBoxLayout()
        layout.setSpacing(16)
        layout.setContentsMargins(24, 24, 24, 24)
        self.setLayout(layout)

        # Icon and title
        icon_label = QLabel("⚠️")
        icon_label.setFont(QFont("Segoe UI Emoji", 24))
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(icon_label)

        # Title
        title_label = QLabel("数据文件损坏")
        title_label.setFont(QFont("Microsoft YaHei", 14, QFont.Weight.Bold))
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Error message
        error_group = QGroupBox("错误详情")
        error_layout = QVBoxLayout()
        error_group.setLayout(error_layout)

        error_text = QTextEdit()
        error_text.setPlainText(self.error_message)
        error_text.setReadOnly(True)
        error_text.setMaximumHeight(80)
        error_text.setStyleSheet("""
            QTextEdit {
                background-color: #fff3f3;
                border: 1px solid #ffcdd2;
                border-radius: 4px;
                padding: 8px;
                color: #c62828;
                font-family: Consolas, Monaco, monospace;
                font-size: 12px;
            }
        """)
        error_layout.addWidget(error_text)
        layout.addWidget(error_group)

        # File info
        info_group = QGroupBox("文件信息")
        info_layout = QFormLayout()
        info_group.setLayout(info_layout)

        # File path (truncated if too long)
        display_path = self.file_path
        if len(display_path) > 60:
            display_path = "..." + display_path[-57:]
        info_layout.addRow("文件路径:", QLabel(display_path))

        # Backup status
        if self.backup_available:
            backup_label = QLabel("✓ 可用")
            backup_label.setStyleSheet("color: #27ae60; font-weight: bold;")
            info_layout.addRow("备份状态:", backup_label)

            if self.backup_info.get('exists'):
                size = self.backup_info.get('size', 0)
                size_str = f"{size / 1024:.1f} KB" if size < 1024*1024 else f"{size / (1024*1024):.1f} MB"
                info_layout.addRow("备份大小:", QLabel(size_str))

                if self.backup_info.get('modified_time'):
                    time_str = self.backup_info['modified_time'].replace('T', ' ')[:19]
                    info_layout.addRow("备份时间:", QLabel(time_str))
        else:
            backup_label = QLabel("✗ 无备份")
            backup_label.setStyleSheet("color: #e74c3c; font-weight: bold;")
            info_layout.addRow("备份状态:", backup_label)

        layout.addWidget(info_group)

        # Suggestion
        suggestion_label = QLabel()
        if self.backup_available:
            suggestion_label.setText("建议：检测到可用的备份文件，您可以尝试从备份恢复数据。")
        else:
            suggestion_label.setText("建议：文件已损坏且无备份，需要手动修复或重新创建。")
        suggestion_label.setWordWrap(True)
        suggestion_label.setStyleSheet("color: #555; padding: 8px; background-color: #f8f9fa; border-radius: 4px;")
        layout.addWidget(suggestion_label)

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(12)

        # View backup button (only if backup available)
        if self.backup_available:
            self.view_backup_btn = QPushButton("查看备份内容")
            self.view_backup_btn.setStyleSheet("""
                QPushButton {
                    background-color: #ecf0f1;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 4px;
                    color: #2c3e50;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #bdc3c7;
                }
            """)
            self.view_backup_btn.clicked.connect(self._on_view_backup)
            button_layout.addWidget(self.view_backup_btn)

        # Restore button
        self.restore_btn = QPushButton("从备份恢复")
        self.restore_btn.setEnabled(self.backup_available)
        self.restore_btn.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                border: none;
                padding: 10px 20px;
                border-radius: 4px;
                color: white;
                font-weight: bold;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #2ecc71;
            }
            QPushButton:disabled {
                background-color: #bdc3c7;
                color: #7f8c8d;
            }
        """)
        self.restore_btn.clicked.connect(self._on_restore)
        button_layout.addWidget(self.restore_btn)

        # Cancel button
        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #e74c3c;
                border: none;
                padding: 10px 20px;
                border-radius: 4px;
                color: white;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #c0392b;
            }
        """)
        self.cancel_btn.clicked.connect(self._on_cancel)
        button_layout.addWidget(self.cancel_btn)

        layout.addLayout(button_layout)

    def _on_restore(self) -> None:
        """Handle restore button click."""
        self.restore_clicked.emit()
        self.accept()

    def _on_cancel(self) -> None:
        """Handle cancel button click."""
        self.cancel_clicked.emit()
        self.reject()

    def _on_view_backup(self) -> None:
        """Handle view backup button click."""
        # This could open a file viewer or show backup content
        # For now, just open the backup file in default editor
        import os
        from PyQt6.QtCore import QUrl
        from PyQt6.QtGui import QDesktopServices

        if self.backup_info.get('backup_path'):
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.backup_info['backup_path']))


def show_recovery_dialog(
    parent,
    file_path: str,
    error_message: str,
    backup_available: bool = False,
    backup_info: dict = None
) -> tuple:
    """
    Show a recovery dialog and return the user's choice.

    Args:
        parent: Parent widget
        file_path: Path to corrupted file
        error_message: Error message
        backup_available: Whether backup is available
        backup_info: Backup file information

    Returns:
        Tuple of (action, dialog) where action is 'restore' or 'cancel'
    """
    dialog = RecoveryDialog(
        file_path=file_path,
        error_message=error_message,
        backup_available=backup_available,
        backup_info=backup_info,
        parent=parent
    )

    # Use open() instead of exec() to avoid blocking in test environments
    # The dialog is still modal, but open() allows the event loop to continue
    dialog.open()

    # For synchronous return, we need to wait for the dialog to close
    # This is a limitation - in production, use the dialog's signals instead
    return 'restore', dialog
