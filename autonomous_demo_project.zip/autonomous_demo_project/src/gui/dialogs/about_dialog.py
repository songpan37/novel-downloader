"""
About dialog for AI Writer application.

Displays application version information, copyright, and credits.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QSizePolicy
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont, QPixmap, QIcon

from config.constants import (
    VERSION, APP_NAME, APP_FULL_NAME, APP_DESCRIPTION,
    APP_COPYRIGHT, APP_AUTHORS, BUILD_NUMBER, BUILD_DATE,
    SHORTCUT_ABOUT
)


class AboutDialog(QDialog):
    """
    About dialog showing application information.

    Displays version number, copyright, authors, and build information
    in a clean, centered layout.
    """

    help_requested = pyqtSignal()  # Emitted when user requests help docs

    def __init__(self, parent=None):
        """
        Initialize the About dialog.

        Args:
            parent: Parent widget
        """
        super().__init__(parent)
        self.setWindowTitle("关于")
        self.setModal(True)
        self.setFixedSize(500, 400)
        self.setWindowFlags(
            self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint
        )

        self._setup_ui()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the dialog UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 20, 30, 20)
        layout.setSpacing(15)

        # App icon placeholder (colored rectangle with first letter)
        icon_label = QLabel("A")
        icon_label.setObjectName("appIcon")
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_label.setFixedSize(80, 80)
        layout.addWidget(icon_label, alignment=Qt.AlignmentFlag.AlignHCenter)

        # App name with version
        title_label = QLabel(f"{APP_NAME}")
        title_label.setObjectName("appTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label, alignment=Qt.AlignmentFlag.AlignHCenter)

        # Version number
        version_label = QLabel(f"版本 {VERSION}")
        version_label.setObjectName("versionLabel")
        version_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(version_label, alignment=Qt.AlignmentFlag.AlignHCenter)

        # Separator line
        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        separator.setFrameShadow(QFrame.Shadow.Sunken)
        separator.setObjectName("separator")
        layout.addWidget(separator)

        # Description
        desc_label = QLabel(APP_DESCRIPTION)
        desc_label.setObjectName("descriptionLabel")
        desc_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        desc_label.setWordWrap(True)
        layout.addWidget(desc_label, alignment=Qt.AlignmentFlag.AlignHCenter)

        # Build information
        build_info = QLabel(f"构建版本：{BUILD_NUMBER} | 构建日期：{BUILD_DATE}")
        build_info.setObjectName("buildInfo")
        build_info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(build_info, alignment=Qt.AlignmentFlag.AlignHCenter)

        # Copyright
        copyright_label = QLabel(APP_COPYRIGHT)
        copyright_label.setObjectName("copyrightLabel")
        copyright_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(copyright_label, alignment=Qt.AlignmentFlag.AlignHCenter)

        # Spacer
        layout.addStretch()

        # Authors section
        authors_layout = QHBoxLayout()
        authors_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        authors_label = QLabel("开发团队：")
        authors_label.setObjectName("authorsLabel")
        authors_layout.addWidget(authors_label)
        authors_text = QLabel(", ".join(APP_AUTHORS))
        authors_text.setObjectName("authorsText")
        authors_layout.addWidget(authors_text)
        layout.addLayout(authors_layout)

        # Spacer
        layout.addStretch()

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)

        # Help button
        help_btn = QPushButton("帮助文档")
        help_btn.setObjectName("helpButton")
        help_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        help_btn.clicked.connect(self._on_help_clicked)
        button_layout.addWidget(help_btn)

        button_layout.addStretch()

        # Close button
        close_btn = QPushButton("关闭")
        close_btn.setObjectName("closeButton")
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.clicked.connect(self.accept)
        close_btn.setDefault(True)
        close_btn.setFocus()
        button_layout.addWidget(close_btn)

        layout.addLayout(button_layout)

    def _apply_styles(self) -> None:
        """Apply dialog styles."""
        self.setStyleSheet("""
            QDialog {
                background-color: #ffffff;
            }

            #appIcon {
                background-color: #3498db;
                color: #ffffff;
                font-size: 36px;
                font-weight: bold;
                border-radius: 15px;
            }

            #appTitle {
                font-size: 24px;
                font-weight: bold;
                color: #2c3e50;
                margin-top: 10px;
            }

            #versionLabel {
                font-size: 14px;
                color: #7f8c8d;
                margin-bottom: 5px;
            }

            #separator {
                border-top: 1px solid #ecf0f1;
                margin: 10px 0;
            }

            #descriptionLabel {
                font-size: 13px;
                color: #555555;
                margin: 5px 0;
            }

            #buildInfo {
                font-size: 12px;
                color: #95a5a6;
                margin: 5px 0;
            }

            #copyrightLabel {
                font-size: 11px;
                color: #bdc3c7;
                margin-top: 10px;
            }

            #authorsLabel {
                font-size: 12px;
                color: #555555;
            }

            #authorsText {
                font-size: 12px;
                color: #2c3e50;
            }

            QPushButton {
                background-color: #ecf0f1;
                color: #2c3e50;
                border: 1px solid #bdc3c7;
                border-radius: 4px;
                padding: 8px 20px;
                font-size: 13px;
            }

            QPushButton:hover {
                background-color: #bdc3c7;
            }

            QPushButton:pressed {
                background-color: #95a5a6;
            }

            #helpButton {
                background-color: #3498db;
                color: #ffffff;
                border: 1px solid #2980b9;
            }

            #helpButton:hover {
                background-color: #2980b9;
            }

            #closeButton {
                background-color: #3498db;
                color: #ffffff;
                border: 1px solid #2980b9;
                min-width: 80px;
            }

            #closeButton:hover {
                background-color: #2980b9;
            }
        """)

    def _on_help_clicked(self) -> None:
        """Handle help button click."""
        self.help_requested.emit()
        # Close the dialog after emitting signal
        self.accept()


def show_about_dialog(parent=None) -> None:
    """
    Show the About dialog.

    Args:
        parent: Parent widget
    """
    dialog = AboutDialog(parent)
    dialog.exec()
