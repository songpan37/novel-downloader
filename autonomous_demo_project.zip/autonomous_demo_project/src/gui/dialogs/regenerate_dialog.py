"""
Regenerate Dialog for AI Writer application.

Provides a dialog for confirming and executing content regeneration for a specific step.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QMessageBox, QGroupBox, QProgressBar
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QFont


class RegenerateDialog(QDialog):
    """
    Dialog for regenerating content for a step.

    Features:
    - Confirm regeneration action
    - Show regeneration progress
    - Display regeneration result
    """

    # Signals
    regenerate_requested = pyqtSignal(str, str)  # work_id, step_id
    regenerate_completed = pyqtSignal()  # Regeneration completed
    regenerate_cancelled = pyqtSignal()

    def __init__(self, step_name: str, step_id: str, work_id: str = None, parent=None):
        """
        Initialize regenerate dialog.

        Args:
            step_name: Name of the step (for display)
            step_id: Step identifier (for regeneration)
            work_id: Work ID (optional, can be set later)
            parent: Parent widget
        """
        super().__init__(parent)
        self.step_name = step_name
        self.step_id = step_id
        self.work_id = work_id
        self.regenerating = False

        self.setObjectName("regenerateDialog")
        self.setWindowTitle(f"重新生成 - {step_name}")
        self.setMinimumSize(500, 400)  # Increased height to show progress bar fully
        self._setup_ui()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # Title
        title_label = QLabel(f"重新生成：{self.step_name}")
        title_label.setObjectName("dialogTitle")
        layout.addWidget(title_label)

        # Warning message
        warning_group = QGroupBox()
        warning_layout = QVBoxLayout(warning_group)

        warning_label = QLabel(
            "⚠️ 注意：重新生成将覆盖当前步骤的内容，原有内容将丢失。\n"
            "请确保您已保存需要保留的内容。"
        )
        warning_label.setObjectName("warningLabel")
        warning_label.setWordWrap(True)
        warning_layout.addWidget(warning_label)
        layout.addWidget(warning_group)

        # Progress section (hidden initially)
        self.progress_group = QGroupBox("生成进度")
        progress_layout = QVBoxLayout(self.progress_group)
        progress_layout.setSpacing(12)

        self.progress_label = QLabel("正在连接 AI 服务...")
        self.progress_label.setObjectName("progressLabel")
        self.progress_label.setWordWrap(True)
        progress_layout.addWidget(self.progress_label)

        self.progress_bar = QProgressBar()
        self.progress_bar.setObjectName("progressBar")
        self.progress_bar.setRange(0, 0)  # Indeterminate progress
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(20)  # Increased height for better visibility
        self.progress_bar.setMinimumWidth(400)  # Ensure adequate width
        progress_layout.addWidget(self.progress_bar)

        self.progress_detail = QLabel("")
        self.progress_detail.setObjectName("progressDetail")
        self.progress_detail.setWordWrap(True)
        self.progress_detail.setMinimumHeight(50)  # Reserve space for detail text
        progress_layout.addWidget(self.progress_detail)

        self.progress_group.setVisible(False)
        layout.addWidget(self.progress_group)

        # Result section (hidden initially)
        self.result_group = QGroupBox("生成结果")
        result_layout = QVBoxLayout(self.result_group)

        self.result_label = QLabel("")
        self.result_label.setObjectName("resultLabel")
        self.result_label.setWordWrap(True)
        result_layout.addWidget(self.result_label)

        self.result_group.setVisible(False)
        layout.addWidget(self.result_group)

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch()

        # Cancel button
        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.setObjectName("btnCancel")
        self.btn_cancel.clicked.connect(self._on_cancel_clicked)
        button_layout.addWidget(self.btn_cancel)

        # Regenerate button
        self.btn_regenerate = QPushButton("确认重新生成")
        self.btn_regenerate.setObjectName("btnRegenerate")
        self.btn_regenerate.setDefault(True)
        self.btn_regenerate.clicked.connect(self._on_regenerate_clicked)
        button_layout.addWidget(self.btn_regenerate)

        # Close button (hidden initially)
        self.btn_close = QPushButton("关闭")
        self.btn_close.setObjectName("btnClose")
        self.btn_close.setVisible(False)
        self.btn_close.clicked.connect(self.accept)
        button_layout.addWidget(self.btn_close)

        layout.addLayout(button_layout)

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            QDialog#regenerateDialog {
                background-color: #ffffff;
            }

            #dialogTitle {
                font-size: 18px;
                font-weight: bold;
                color: #e74c3c;
                margin-bottom: 10px;
            }

            QGroupBox {
                font-weight: bold;
                border: 1px solid #ecf0f1;
                border-radius: 6px;
                margin-top: 10px;
                padding-top: 10px;
                font-weight: normal;
            }

            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
                color: #2c3e50;
            }

            #warningLabel {
                color: #d35400;
                font-size: 13px;
                padding: 10px;
                background-color: #fef9e7;
                border-left: 4px solid #f39c12;
                border-radius: 4px;
            }

            #progressLabel {
                color: #2980b9;
                font-size: 14px;
                font-weight: bold;
            }

            #progressDetail {
                color: #7f8c8d;
                font-size: 12px;
            }

            #progressBar {
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                background-color: #ecf0f1;
            }

            #progressBar::chunk {
                background-color: #3498db;
                border-radius: 5px;
            }

            #resultLabel {
                color: #27ae60;
                font-size: 14px;
                padding: 10px;
                background-color: #e9f7ef;
                border-left: 4px solid #27ae60;
                border-radius: 4px;
            }

            #resultLabel.error {
                color: #e74c3c;
                background-color: #fdedec;
                border-left-color: #e74c3c;
            }

            #btnRegenerate {
                background-color: #e74c3c;
                color: white;
                border: none;
                padding: 10px 24px;
                border-radius: 4px;
                font-weight: bold;
                min-width: 120px;
            }

            #btnRegenerate:hover {
                background-color: #c0392b;
            }

            #btnRegenerate:disabled {
                background-color: #bdc3c7;
            }

            #btnCancel {
                background-color: #ecf0f1;
                color: #2c3e50;
                border: 1px solid #bdc3c7;
                padding: 10px 20px;
                border-radius: 4px;
            }

            #btnCancel:hover {
                background-color: #d5dbdb;
            }

            #btnClose {
                background-color: #27ae60;
                color: white;
                border: none;
                padding: 10px 24px;
                border-radius: 4px;
                font-weight: bold;
            }

            #btnClose:hover {
                background-color: #1e8449;
            }
        """)

    def _on_cancel_clicked(self) -> None:
        """Handle cancel button click."""
        if self.regenerating:
            self.regenerate_cancelled.emit()
        self.reject()

    def _on_regenerate_clicked(self) -> None:
        """Handle regenerate button click."""
        # Start regeneration directly (already confirmed by opening dialog)
        self._start_regeneration()

    def _start_regeneration(self) -> None:
        """Start the regeneration process."""
        self.regenerating = True
        self.btn_regenerate.setEnabled(False)
        self.btn_cancel.setEnabled(True)
        self.btn_cancel.setVisible(True)
        self.btn_close.setVisible(False)

        # Show progress
        self.progress_group.setVisible(True)
        self.result_group.setVisible(False)

        # Emit signal to start regeneration
        if self.work_id:
            self.regenerate_requested.emit(self.work_id, self.step_id)
        else:
            # No work_id, show error
            self._show_error("请先选择要重新生成的作品")

    def set_work_id(self, work_id: str) -> None:
        """Set the work ID for regeneration."""
        self.work_id = work_id

    def update_progress(self, message: str, detail: str = "") -> None:
        """
        Update progress display.

        Args:
            message: Progress message
            detail: Optional detail message
        """
        self.progress_label.setText(message)
        self.progress_detail.setText(detail)

    def show_success(self, message: str) -> None:
        """
        Show success result.

        Args:
            message: Success message
        """
        self.regenerating = False
        self.progress_group.setVisible(False)
        self.result_group.setVisible(True)
        self.result_label.setText(message)
        self.result_label.setStyleSheet(self.result_label.styleSheet().replace("error", ""))

        self.btn_regenerate.setVisible(False)
        self.btn_cancel.setVisible(False)
        self.btn_close.setVisible(True)

    def show_error(self, message: str) -> None:
        """
        Show error result.

        Args:
            message: Error message
        """
        self.regenerating = False
        self.progress_group.setVisible(False)
        self.result_group.setVisible(True)
        self.result_label.setText(message)
        self.result_label.setProperty("class", "error")
        self.result_label.setStyleSheet("""
            QLabel#resultLabel {
                color: #e74c3c;
                font-size: 14px;
                padding: 10px;
                background-color: #fdedec;
                border-left: 4px solid #e74c3c;
                border-radius: 4px;
            }
        """)

        self.btn_regenerate.setEnabled(True)
        self.btn_regenerate.setVisible(True)
        self.btn_cancel.setVisible(True)
        self.btn_close.setVisible(False)
