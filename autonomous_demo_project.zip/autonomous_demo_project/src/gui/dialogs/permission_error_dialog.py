"""
Permission Error Dialog for AI Writer application.

Provides a user-friendly dialog when storage permission errors occur,
with suggestions to choose a different directory.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QWidget
)
from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtGui import QIcon


class PermissionErrorDialog(QDialog):
    """
    Dialog shown when a permission error occurs.

    Provides options to:
    - Choose a different directory
    - Dismiss the dialog

    Attributes:
        retry_requested: Signal emitted when user chooses to select a new directory
    """

    retry_requested = pyqtSignal()  # No arguments - just signal to retry

    def __init__(
        self,
        path: str,
        action: str = "access",
        message: str = None,
        parent: QWidget = None
    ):
        """
        Initialize the permission error dialog.

        Args:
            path: The path that caused the permission error
            action: The action that was denied (read/write/access)
            message: Optional custom message
            parent: Parent widget
        """
        super().__init__(parent)
        self.path = path
        self.action = action
        self.custom_message = message

        self.setWindowTitle("权限不足")
        self.setMinimumWidth(450)
        self.setModal(True)

        self._setup_ui()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the dialog UI."""
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        layout.setContentsMargins(30, 30, 30, 30)

        # Icon and message section
        icon_layout = QHBoxLayout()
        icon_layout.setSpacing(15)

        # Error icon
        icon_label = QLabel()
        icon_label.setFixedSize(48, 48)
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_label.setStyleSheet("""
            QLabel {
                background-color: #e74c3c;
                border-radius: 24px;
                color: white;
                font-size: 28px;
                font-weight: bold;
            }
        """)
        icon_label.setText("!")
        icon_layout.addWidget(icon_label)

        # Message label
        message_widget = QWidget()
        message_layout = QVBoxLayout(message_widget)
        message_layout.setContentsMargins(0, 0, 0, 0)
        message_layout.setSpacing(8)

        # Title
        title_label = QLabel("权限不足")
        title_label.setObjectName("titleLabel")
        title_label.setWordWrap(True)
        message_layout.addWidget(title_label)

        # Details - build appropriate message
        action_text = {
            "read": "读取",
            "write": "写入",
            "access": "访问"
        }.get(self.action, "访问")

        if self.custom_message:
            details = self.custom_message
        else:
            details = (
                f"程序没有{action_text}以下目录的权限：\n\n"
                f"<b>{self.path}</b>\n\n"
                f"可能的原因：\n"
                f"• 目录位于受保护的系统区域（如 C:\\Program Files）\n"
                f"• 当前用户没有该目录的{action_text}权限\n"
                f"• 目录被其他程序占用或锁定\n\n"
                f"建议选择其他目录（如文档、桌面等用户目录）作为存储路径。"
            )

        details_label = QLabel(details)
        details_label.setObjectName("detailsLabel")
        details_label.setWordWrap(True)
        details_label.setTextFormat(Qt.TextFormat.RichText)
        message_layout.addWidget(details_label)

        icon_layout.addWidget(message_widget, 1)
        layout.addLayout(icon_layout)

        # Button section
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)

        # Retry button (primary action)
        self.btn_retry = QPushButton("选择其他目录")
        self.btn_retry.setObjectName("btnRetry")
        self.btn_retry.setFixedWidth(150)
        self.btn_retry.clicked.connect(self._on_retry_clicked)
        button_layout.addWidget(self.btn_retry)

        # Close button
        self.btn_close = QPushButton("关闭")
        self.btn_close.setObjectName("btnClose")
        self.btn_close.setFixedWidth(100)
        self.btn_close.clicked.connect(self.reject)
        button_layout.addWidget(self.btn_close)

        button_layout.addStretch()
        layout.addLayout(button_layout)

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            QDialog {
                background-color: #ffffff;
            }

            QLabel#titleLabel {
                font-size: 18px;
                font-weight: bold;
                color: #e74c3c;
            }

            QLabel#detailsLabel {
                font-size: 14px;
                color: #555555;
                line-height: 1.6;
            }

            QLabel#detailsLabel b {
                color: #c0392b;
                font-size: 13px;
            }

            QPushButton#btnRetry {
                background-color: #3498db;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
            }

            QPushButton#btnRetry:hover {
                background-color: #2980b9;
            }

            QPushButton#btnClose {
                background-color: #ecf0f1;
                color: #2c3e50;
                border: 1px solid #bdc3c7;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
            }

            QPushButton#btnClose:hover {
                background-color: #bdc3c7;
            }
        """)

    def _on_retry_clicked(self) -> None:
        """Handle retry button click."""
        self.retry_requested.emit()
        self.accept()

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()

        # Escape key - close dialog without saving
        if key == Qt.Key.Key_Escape:
            self.reject()
            return

        # Let the base class handle other keys
        super().keyPressEvent(event)


def show_permission_error_dialog(
    path: str,
    action: str = "access",
    message: str = None,
    parent: QWidget = None
) -> bool:
    """
    Show a permission error dialog.

    This is a convenience function that creates and shows the dialog.

    Args:
        path: The path that caused the permission error
        action: The action that was denied (read/write/access)
        message: Optional custom message
        parent: Parent widget

    Returns:
        True if user chose to select a different directory, False otherwise
    """
    dialog = PermissionErrorDialog(path, action, message, parent)
    result = dialog.exec()
    return result == QDialog.DialogCode.Accepted
