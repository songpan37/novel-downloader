"""
New Work Wizard Dialog for AI Writer application.

Provides a step-by-step wizard for creating new works with
category selection, reference works, and configuration.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QComboBox, QCheckBox,
    QScrollArea, QFrame, QGroupBox, QTextEdit,
    QSpinBox, QListWidget, QWidget,
    QAbstractItemView, QGridLayout
)
from PyQt6.QtCore import Qt, pyqtSignal, QEvent, QObject
from typing import Optional, List


class NewWorkWizard(QDialog):
    """
    Wizard dialog for creating new works.

    Guides users through the work creation process with
    category selection, reference works, and configuration.

    Signals:
        work_created: Emitted when a new work is successfully created
    """

    work_created = pyqtSignal(dict)  # work data

    def __init__(self, settings, parent=None):
        """
        Initialize the new work wizard.

        Args:
            settings: Application settings instance
            parent: Parent widget
        """
        super().__init__(parent)
        self.settings = settings
        self.current_step = 0  # Track current step
        self.setObjectName("newWorkWizard")
        self.step_labels = []  # Store step label references
        self.form_sections = []  # Store form section references

        # Load categories and reference works dynamically from user's references directory
        self.categories = self.settings.get_reference_works_categories()
        self.reference_works_map = {}  # category -> [works]
        for category in self.categories:
            self.reference_works_map[category] = self.settings.get_reference_works_for_category(category)

        self._setup_ui()
        self._setup_connections()
        self._apply_styles()

    def _setup_step_indicator(self, parent_layout: QVBoxLayout) -> None:
        """
        Set up the step progress indicator.

        Args:
            parent_layout: Layout to add indicator to
        """
        # Step indicator container
        step_container = QFrame()
        step_container.setObjectName("stepIndicatorContainer")
        step_layout = QHBoxLayout(step_container)
        step_layout.setContentsMargins(0, 10, 0, 15)
        step_layout.setSpacing(10)

        # Define steps
        steps = [
            ("1", "作品类别"),
            ("2", "参考作品"),
            ("3", "文风类别"),
            ("4", "创作指导"),
            ("5", "章节设置"),
            ("6", "字数设置")
        ]

        self.step_labels = []  # Reset step labels list

        for i, (step_num, step_name) in enumerate(steps):
            # Create step widget
            step_widget = QWidget()
            step_widget.setObjectName(f"stepWidget_{i}")
            step_layout_inner = QVBoxLayout(step_widget)
            step_layout_inner.setContentsMargins(0, 0, 0, 0)
            step_layout_inner.setSpacing(3)

            # Circle with number
            circle_label = QLabel(step_num)
            circle_label.setObjectName(f"stepCircle_{i}")
            circle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            circle_label.setFixedSize(30, 30)
            step_layout_inner.addWidget(circle_label)

            # Step name
            name_label = QLabel(step_name)
            name_label.setObjectName(f"stepName_{i}")
            name_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            name_label.setWordWrap(True)
            step_layout_inner.addWidget(name_label)

            step_layout.addWidget(step_widget)
            self.step_labels.append((circle_label, name_label))

            # Add connector line (except for last step)
            if i < len(steps) - 1:
                line = QFrame()
                line.setObjectName("stepConnector")
                line.setFixedHeight(2)
                line.setMinimumWidth(40)
                step_layout.addWidget(line)

        parent_layout.addWidget(step_container)

        # Update to show initial step
        self._update_step_indicator(0)

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        self.setWindowTitle("新建作品向导")
        self.setMinimumSize(550, 650)
        self.setModal(True)
        self.setWindowModality(Qt.WindowModality.ApplicationModal)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(25, 25, 25, 25)
        layout.setSpacing(15)

        # Step progress indicator
        self._setup_step_indicator(layout)

        # Title
        title_label = QLabel("新建作品")
        title_label.setObjectName("dialogTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Subtitle
        subtitle_label = QLabel("请填写作品信息，AI 将帮您生成书名、封面等内容")
        subtitle_label.setObjectName("dialogSubtitle")
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle_label)

        # Required field note
        required_note = QLabel("* 标记为必填项")
        required_note.setObjectName("requiredNote")
        required_note.setAlignment(Qt.AlignmentFlag.AlignRight)
        layout.addWidget(required_note)

        # Scrollable form area
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        scroll_area.setObjectName("wizardScrollArea")

        form_widget = QWidget()
        form_layout = QVBoxLayout(form_widget)
        form_layout.setSpacing(15)

        # Category selection
        self.category_group = self._setup_category_section(form_layout)

        # Reference works selection
        self.reference_group = self._setup_reference_works_section(form_layout)

        # Literary style category selection
        self.style_group = self._setup_literary_style_section(form_layout)

        # Creation guide (optional)
        self.guide_group = self._setup_creation_guide_section(form_layout)

        # Chapters per volume
        self.chapters_group = self._setup_chapters_section(form_layout)

        # Words per chapter
        self.words_group = self._setup_words_section(form_layout)

        # Store form sections for step tracking
        self.form_sections = [
            self.category_group,
            self.reference_group,
            self.style_group,
            self.guide_group,
            self.chapters_group,
            self.words_group
        ]

        form_layout.addStretch()
        scroll_area.setWidget(form_widget)
        layout.addWidget(scroll_area)

        # Action buttons
        self._setup_action_buttons(layout)

    def _setup_category_section(
        self,
        parent_layout: QVBoxLayout
    ) -> QGroupBox:
        """
        Set up category selection section.

        Args:
            parent_layout: Layout to add section to

        Returns:
            The group box widget
        """
        group = QGroupBox("作品类别 *")
        group.setObjectName("categoryGroup")
        group_layout = QVBoxLayout(group)

        category_label = QLabel("请选择作品的主要类别：")
        category_label.setObjectName("fieldLabel")
        group_layout.addWidget(category_label)

        self.category_combo = QComboBox()
        self.category_combo.setObjectName("categoryCombo")
        self.category_combo.addItem("")  # Empty item for placeholder
        self.category_combo.addItems(self.categories)
        self.category_combo.setPlaceholderText("选择类别...")
        self.category_combo.setCurrentIndex(0)  # Start with empty selection
        group_layout.addWidget(self.category_combo)

        # Inline error label for category
        self.category_error_label = QLabel("")
        self.category_error_label.setObjectName("inlineErrorLabel")
        self.category_error_label.setWordWrap(True)
        self.category_error_label.setVisible(False)
        group_layout.addWidget(self.category_error_label)

        parent_layout.addWidget(group)
        return group

    def _setup_reference_works_section(
        self,
        parent_layout: QVBoxLayout
    ) -> QGroupBox:
        """
        Set up reference works selection section.

        Args:
            parent_layout: Layout to add section to

        Returns:
            The group box widget
        """
        group = QGroupBox("同类作品参考 *")
        group.setObjectName("referenceGroup")
        group_layout = QVBoxLayout(group)

        ref_label = QLabel("请选择您参考过的同类作品（可多选）：")
        ref_label.setObjectName("fieldLabel")
        group_layout.addWidget(ref_label)

        self.reference_list = QListWidget()
        self.reference_list.setObjectName("referenceList")
        self.reference_list.setMaximumHeight(150)
        group_layout.addWidget(self.reference_list)

        # Inline error label for reference works
        self.reference_error_label = QLabel("")
        self.reference_error_label.setObjectName("inlineErrorLabel")
        self.reference_error_label.setWordWrap(True)
        self.reference_error_label.setVisible(False)
        group_layout.addWidget(self.reference_error_label)

        # Populate with initial items using first category as default
        if self.categories:
            self._update_reference_works(self.categories[0])

        parent_layout.addWidget(group)
        return group

    def _setup_literary_style_section(
        self,
        parent_layout: QVBoxLayout
    ) -> QGroupBox:
        """
        Set up literary style category selection section.

        Args:
            parent_layout: Layout to add section to

        Returns:
            The group box widget
        """
        group = QGroupBox("文风类别 *")
        group.setObjectName("styleGroup")
        group_layout = QVBoxLayout(group)

        style_label = QLabel("请选择或输入作品的文风类别：")
        style_label.setObjectName("fieldLabel")
        group_layout.addWidget(style_label)

        # Common literary style categories
        self.style_categories = [
            "轻松幽默", "热血爽文", "暗黑压抑", "温馨治愈",
            "悬疑烧脑", "浪漫言情", "史诗宏大", "简洁明快",
            "华丽辞藻", "朴实无华", "其他"
        ]

        self.style_combo = QComboBox()
        self.style_combo.setObjectName("styleCombo")
        self.style_combo.setEditable(True)
        self.style_combo.addItem("")  # Empty item for placeholder
        self.style_combo.addItems(self.style_categories)
        self.style_combo.setPlaceholderText("选择或输入文风类别...")
        self.style_combo.setCurrentIndex(0)
        group_layout.addWidget(self.style_combo)

        # Inline error label for style category
        self.style_error_label = QLabel("")
        self.style_error_label.setObjectName("inlineErrorLabel")
        self.style_error_label.setWordWrap(True)
        self.style_error_label.setVisible(False)
        group_layout.addWidget(self.style_error_label)

        parent_layout.addWidget(group)
        return group

    def _setup_creation_guide_section(
        self,
        parent_layout: QVBoxLayout
    ) -> QGroupBox:
        """
        Set up creation guide text section.

        Args:
            parent_layout: Layout to add section to

        Returns:
            The group box widget
        """
        group = QGroupBox("创作指导 (可选)")
        group.setObjectName("guideGroup")
        group_layout = QVBoxLayout(group)

        guide_label = QLabel(
            "简要描述您想要的故事风格、主角设定、世界观等：\n"
            "例如：这是一本关于修仙的小说，主角是一个平凡少年，"
            "偶然获得上古传承，从此踏上修仙之路..."
        )
        guide_label.setObjectName("fieldLabel")
        guide_label.setWordWrap(True)
        group_layout.addWidget(guide_label)

        self.guide_text = QTextEdit()
        self.guide_text.setObjectName("guideText")
        self.guide_text.setPlaceholderText("在此输入您的创作指导...")
        self.guide_text.setMaximumHeight(120)
        group_layout.addWidget(self.guide_text)

        parent_layout.addWidget(group)
        return group

    def _setup_chapters_section(
        self,
        parent_layout: QVBoxLayout
    ) -> QGroupBox:
        """
        Set up chapters per volume section.

        Args:
            parent_layout: Layout to add section to

        Returns:
            The group box widget
        """
        group = QGroupBox("每卷期望章节数 *")
        group.setObjectName("chaptersGroup")
        group_layout = QHBoxLayout(group)

        chapters_label = QLabel("每卷期望章节数：")
        chapters_label.setObjectName("fieldLabel")
        group_layout.addWidget(chapters_label)

        self.chapters_spin = QSpinBox()
        self.chapters_spin.setObjectName("chaptersSpin")
        self.chapters_spin.setRange(1, 100)
        self.chapters_spin.setValue(5)
        self.chapters_spin.setSuffix(" 章")
        group_layout.addWidget(self.chapters_spin)

        group_layout.addStretch()
        parent_layout.addWidget(group)
        return group

    def _setup_words_section(
        self,
        parent_layout: QVBoxLayout
    ) -> QGroupBox:
        """
        Set up words per chapter section.

        Args:
            parent_layout: Layout to add section to

        Returns:
            The group box widget
        """
        group = QGroupBox("每章期望字数 *")
        group.setObjectName("wordsGroup")
        group_layout = QHBoxLayout(group)

        words_label = QLabel("每章期望字数：")
        words_label.setObjectName("fieldLabel")
        group_layout.addWidget(words_label)

        self.words_spin = QSpinBox()
        self.words_spin.setObjectName("wordsSpin")
        self.words_spin.setRange(1000, 10000)
        self.words_spin.setValue(2500)
        self.words_spin.setSingleStep(500)
        self.words_spin.setSuffix(" 字")
        group_layout.addWidget(self.words_spin)

        group_layout.addStretch()
        parent_layout.addWidget(group)
        return group

    def _setup_action_buttons(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up action buttons section.

        Args:
            parent_layout: Layout to add section to
        """
        # Error message label (hidden by default)
        self.error_label = QLabel("")
        self.error_label.setObjectName("errorLabel")
        self.error_label.setWordWrap(True)
        self.error_label.setVisible(False)
        parent_layout.addWidget(self.error_label)

        button_layout = QHBoxLayout()
        button_layout.addStretch()

        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.setObjectName("cancelBtn")
        self.btn_cancel.setFixedWidth(100)
        self.btn_cancel.setToolTip("取消创建作品")
        self.btn_cancel.setAccessibleName("取消")
        self.btn_cancel.setAccessibleDescription("取消创建作品，关闭向导")
        button_layout.addWidget(self.btn_cancel)

        self.btn_create = QPushButton("开始创作")
        self.btn_create.setObjectName("createBtn")
        self.btn_create.setFixedWidth(120)
        self.btn_create.setToolTip("使用以上设置创建新作品")
        self.btn_create.setAccessibleName("开始创作")
        self.btn_create.setAccessibleDescription("使用以上设置创建新作品")
        button_layout.addWidget(self.btn_create)

        parent_layout.addLayout(button_layout)

    def _setup_connections(self) -> None:
        """Connect signals and slots."""
        self.category_combo.currentTextChanged.connect(
            self._update_reference_works
        )
        self.category_combo.currentTextChanged.connect(
            self._clear_category_error
        )
        self.category_combo.focusInEvent = lambda e: self._on_section_focus(0)
        self.reference_list.focusInEvent = lambda e: self._on_section_focus(1)
        self.style_combo.focusInEvent = lambda e: self._on_section_focus(2)
        self.style_combo.currentTextChanged.connect(
            self._clear_style_error
        )
        self.guide_text.focusInEvent = lambda e: self._on_section_focus(3)
        self.chapters_spin.focusInEvent = lambda e: self._on_section_focus(4)
        self.words_spin.focusInEvent = lambda e: self._on_section_focus(5)

        self.reference_list.itemSelectionChanged.connect(
            self._clear_reference_error
        )
        self.btn_cancel.clicked.connect(self.reject)
        self.btn_create.clicked.connect(self._validate_and_create)

        # Install event filters for blur validation
        self.category_combo.installEventFilter(self)
        self.reference_list.installEventFilter(self)
        self.style_combo.installEventFilter(self)

    def _on_section_focus(self, step_index: int) -> None:
        """
        Handle focus change to update step indicator.

        Args:
            step_index: Index of the section that received focus
        """
        self._update_step_indicator(step_index)
        # Clear errors when section receives focus
        if step_index == 0:
            self._clear_category_error()
        elif step_index == 1:
            self._clear_reference_error()
        elif step_index == 2:
            self._clear_style_error()

    def _update_step_indicator(self, current_step: int) -> None:
        """
        Update the step progress indicator to highlight current step.

        Args:
            current_step: Index of the current step (0-based)
        """
        self.current_step = current_step

        for i, (circle_label, name_label) in enumerate(self.step_labels):
            if i < current_step:
                # Completed step
                circle_label.setObjectName(f"stepCircle_{i}_completed")
                name_label.setObjectName(f"stepName_{i}_completed")
                circle_label.setText("✓")
            elif i == current_step:
                # Current step
                circle_label.setObjectName(f"stepCircle_{i}_current")
                name_label.setObjectName(f"stepName_{i}_current")
                circle_label.setText(str(i + 1))
            else:
                # Future step
                circle_label.setObjectName(f"stepCircle_{i}")
                name_label.setObjectName(f"stepName_{i}")
                circle_label.setText(str(i + 1))

        # Reapply styles to update appearance
        self._apply_styles()

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        """
        Filter events for blur validation.

        Args:
            obj: The object being filtered
            event: The event being filtered

        Returns:
            False to continue normal event processing
        """
        if event.type() == QEvent.Type.FocusOut:
            # Validate category when it loses focus
            if obj == self.category_combo:
                self._validate_category_on_blur()
            # Validate reference list when it loses focus
            elif obj == self.reference_list:
                self._validate_reference_on_blur()
            # Validate style category when it loses focus
            elif obj == self.style_combo:
                self._validate_style_on_blur()
        return False  # Continue normal event processing

    def _validate_category_on_blur(self) -> None:
        """
        Validate category field when it loses focus.

        Shows error if no category is selected.
        """
        category = self.category_combo.currentText()
        if not category or category not in self.categories:
            self._show_category_error("请选择作品类别")

    def _validate_reference_on_blur(self) -> None:
        """
        Validate reference works field when it loses focus.

        Shows error if no reference works are selected.
        """
        selected_items = self.reference_list.selectedItems()
        if not selected_items:
            self._show_reference_error("请至少选择一个参考作品")

    def _validate_style_on_blur(self) -> None:
        """
        Validate literary style category field when it loses focus.

        Shows error if no style category is selected or input.
        """
        style_category = self.style_combo.currentText().strip()
        if not style_category:
            self._show_style_error("请选择或输入文风类别")

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            #newWorkWizard {
                background-color: #f5f5f5;
            }

            /* Step Indicator Styles */
            #stepIndicatorContainer {
                background-color: #ecf0f1;
                border-radius: 8px;
                padding: 10px 15px;
            }

            /* Default step circle style */
            QLabel#stepCircle_0, QLabel#stepCircle_1, QLabel#stepCircle_2,
            QLabel#stepCircle_3, QLabel#stepCircle_4, QLabel#stepCircle_5 {
                background-color: #bdc3c7;
                color: #ffffff;
                font-size: 14px;
                font-weight: bold;
                border-radius: 15px;
                min-width: 30px;
                min-height: 30px;
                max-width: 30px;
                max-height: 30px;
            }

            /* Current step circle style */
            QLabel#stepCircle_0_current, QLabel#stepCircle_1_current, QLabel#stepCircle_2_current,
            QLabel#stepCircle_3_current, QLabel#stepCircle_4_current, QLabel#stepCircle_5_current {
                background-color: #1a5276;  /* Darker blue for WCAG AA compliance */
                color: #ffffff;
                font-size: 14px;
                font-weight: bold;
                border-radius: 15px;
                min-width: 30px;
                min-height: 30px;
                max-width: 30px;
                max-height: 30px;
            }

            /* Completed step circle style */
            QLabel#stepCircle_0_completed, QLabel#stepCircle_1_completed, QLabel#stepCircle_2_completed,
            QLabel#stepCircle_3_completed, QLabel#stepCircle_4_completed, QLabel#stepCircle_5_completed {
                background-color: #145a32;  /* Darker green for WCAG AA compliance */
                color: #ffffff;
                font-size: 14px;
                font-weight: bold;
                border-radius: 15px;
                min-width: 30px;
                min-height: 30px;
                max-width: 30px;
                max-height: 30px;
            }

            /* Default step name style */
            QLabel#stepName_0, QLabel#stepName_1, QLabel#stepName_2,
            QLabel#stepName_3, QLabel#stepName_4, QLabel#stepName_5 {
                font-size: 12px;
                color: #7f8c8d;
                font-weight: normal;
                min-width: 60px;
            }

            /* Current step name style */
            QLabel#stepName_0_current, QLabel#stepName_1_current, QLabel#stepName_2_current,
            QLabel#stepName_3_current, QLabel#stepName_4_current, QLabel#stepName_5_current {
                color: #1a5276;  /* Darker blue for WCAG AA */
                font-weight: bold;
            }

            /* Completed step name style */
            QLabel#stepName_0_completed, QLabel#stepName_1_completed, QLabel#stepName_2_completed,
            QLabel#stepName_3_completed, QLabel#stepName_4_completed, QLabel#stepName_5_completed {
                color: #145a32;  /* Darker green for WCAG AA */
                font-weight: bold;
            }

            /* Step connector line */
            #stepConnector {
                background-color: #bdc3c7;
                border-radius: 1px;
                min-height: 2px;
                max-height: 2px;
            }

            #dialogTitle {
                font-size: 22px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 5px;
            }

            #dialogSubtitle {
                font-size: 13px;
                color: #7f8c8d;
                margin-bottom: 15px;
            }

            #requiredNote {
                font-size: 12px;
                color: #e74c3c;
                margin-bottom: 10px;
                font-weight: bold;
            }

            #wizardScrollArea {
                border: none;
                background-color: transparent;
            }

            QGroupBox {
                font-weight: bold;
                font-size: 14px;
                color: #2c3e50;
                border: 1px solid #bdc3c7;
                border-radius: 8px;
                margin-top: 12px;
                padding-top: 10px;
                background-color: #ffffff;
            }

            QGroupBox::title {
                subcontrol-origin: margin;
                left: 15px;
                padding: 0 8px;
                color: #34495e;
            }

            #fieldLabel {
                font-size: 13px;
                color: #34495e;
                margin-bottom: 8px;
            }

            #categoryCombo {
                padding: 10px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                font-size: 14px;
                background-color: #ffffff;
            }

            #categoryCombo:focus {
                border-color: #3498db;
            }

            #styleCombo {
                padding: 10px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                font-size: 14px;
                background-color: #ffffff;
            }

            #styleCombo:focus {
                border-color: #3498db;
            }

            #referenceList {
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                background-color: #ffffff;
                font-size: 13px;
            }

            #referenceList:focus {
                border-color: #3498db;
                outline: 2px solid #f1c40f;
                outline-offset: -2px;
            }

            #referenceList::item:selected {
                background-color: #1a5276;  /* Darker blue for WCAG AA compliance */
                color: #ffffff;
            }

            #guideText {
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                padding: 10px;
                font-size: 13px;
                background-color: #ffffff;
            }

            #guideText:focus {
                border-color: #3498db;
            }

            #chaptersSpin, #wordsSpin {
                padding: 6px 10px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                font-size: 13px;
                min-width: 120px;
                background-color: #ffffff;
            }

            #chaptersSpin:focus, #wordsSpin:focus {
                border-color: #3498db;
            }

            #chaptersSpin::up-button, #wordsSpin::up-button {
                width: 16px;
                height: 10px;
                border: none;
                subcontrol-position: top right;
                margin: 2px 4px;
            }

            #chaptersSpin::up-arrow, #wordsSpin::up-arrow {
                image: none;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-bottom: 5px solid #7f8c8d;
            }

            #chaptersSpin::down-button, #wordsSpin::down-button {
                width: 16px;
                height: 10px;
                border: none;
                subcontrol-position: bottom right;
                margin: 2px 4px;
            }

            #chaptersSpin::down-arrow, #wordsSpin::down-arrow {
                image: none;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-top: 5px solid #7f8c8d;
            }

            #cancelBtn {
                background-color: #95a5a6;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
            }

            #cancelBtn:hover {
                background-color: #7f8c8d;
            }

            #cancelBtn:focus {
                outline: 2px solid #f1c40f;
                outline-offset: -2px;
            }

            #createBtn {
                background-color: #1a5276;  /* Darker blue for WCAG AA compliance */
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
            }

            #createBtn:hover {
                background-color: #154360;  /* Even darker on hover */
            }

            #createBtn:focus {
                outline: 2px solid #f1c40f;
                outline-offset: -2px;
            }

            #errorLabel {
                color: #e74c3c;
                font-size: 13px;
                font-weight: bold;
                background-color: #fdeaea;
                border: 1px solid #e74c3c;
                border-radius: 5px;
                padding: 10px 15px;
                margin-bottom: 10px;
            }

            #inlineErrorLabel {
                color: #e74c3c;
                font-size: 12px;
                font-weight: bold;
                background-color: #fdeaea;
                border: 1px solid #e74c3c;
                border-radius: 4px;
                padding: 6px 10px;
                margin-top: 5px;
            }
        """)

    def _update_reference_works(self, category: str = None) -> None:
        """
        Update reference works list based on selected category.

        Args:
            category: Selected category name
        """
        if category is None:
            category = self.category_combo.currentText()

        self.reference_list.clear()
        works = self.reference_works_map.get(category, [])
        self.reference_list.addItems(works)

        # Enable multi-selection (allow multiple selection without Ctrl/Shift)
        self.reference_list.setSelectionMode(
            QAbstractItemView.SelectionMode.MultiSelection
        )

    def _validate_and_create(self) -> None:
        """Validate form inputs and create work."""
        # Clear all previous error messages
        self._clear_all_errors()

        has_error = False

        # Get selected category
        category = self.category_combo.currentText()
        if not category or category not in self.categories:
            self._show_category_error("请选择作品类别")
            has_error = True

        # Get selected reference works
        selected_items = self.reference_list.selectedItems()
        category = self.category_combo.currentText()
        # Store reference works with category prefix: {category}/{work_name}
        reference_works = [f"{category}/{item.text()}" for item in selected_items]
        if not reference_works:
            self._show_reference_error("请至少选择一个参考作品")
            has_error = True

        # Get literary style category
        style_category = self.style_combo.currentText().strip()
        if not style_category:
            self._show_style_error("请选择或输入文风类别")
            has_error = True

        if has_error:
            return

        # Get creation guide (optional)
        creation_guide = self.guide_text.toPlainText().strip()

        # Get chapters per volume
        chapters_per_volume = self.chapters_spin.value()

        # Get words per chapter
        words_per_chapter = self.words_spin.value()

        # Create work data dictionary
        work_data = {
            "category": category,
            "reference_works": reference_works,
            "literary_style_category": style_category,
            "creation_guide": creation_guide,
            "chapters_per_volume": chapters_per_volume,
            "words_per_chapter": words_per_chapter
        }

        # Emit signal and close dialog
        self.work_created.emit(work_data)
        self.accept()

    def _show_error(self, message: str) -> None:
        """
        Display an error message to the user.

        Args:
            message: Error message to display
        """
        self.error_label.setText(message)
        self.error_label.setVisible(True)

    def _show_category_error(self, message: str) -> None:
        """
        Display an inline error message for category field.

        Args:
            message: Error message to display
        """
        self.category_error_label.setText(message)
        self.category_error_label.setVisible(True)

    def _show_reference_error(self, message: str) -> None:
        """
        Display an inline error message for reference works field.

        Args:
            message: Error message to display
        """
        self.reference_error_label.setText(message)
        self.reference_error_label.setVisible(True)

    def _show_style_error(self, message: str) -> None:
        """
        Display an inline error message for literary style category field.

        Args:
            message: Error message to display
        """
        self.style_error_label.setText(message)
        self.style_error_label.setVisible(True)

    def _clear_category_error(self) -> None:
        """Clear the category error message."""
        self.category_error_label.setVisible(False)

    def _clear_reference_error(self) -> None:
        """Clear the reference works error message."""
        self.reference_error_label.setVisible(False)

    def _clear_style_error(self) -> None:
        """Clear the literary style category error message."""
        self.style_error_label.setVisible(False)

    def _clear_all_errors(self) -> None:
        """Clear all error messages."""
        self.error_label.setVisible(False)
        self.category_error_label.setVisible(False)
        self.reference_error_label.setVisible(False)
        self.style_error_label.setVisible(False)

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()
        modifier = event.modifiers()

        # Escape key - close dialog without saving
        if key == Qt.Key.Key_Escape:
            self.reject()
            return

        # Enter key - activate focused button or move to next field
        if key == Qt.Key.Key_Return or key == Qt.Key.Key_Enter:
            # If focus is on a button, activate it
            focused_widget = self.focusWidget()
            if isinstance(focused_widget, QPushButton):
                focused_widget.click()
                return
            # If focus is on the create/cancel buttons area, activate create
            elif focused_widget == self.btn_create:
                self._validate_and_create()
                return
            elif focused_widget == self.btn_cancel:
                self.reject()
                return
            # Otherwise, just move to next field (default behavior)
            # Let Qt handle tab focus order

        # Let the base class handle other keys
        super().keyPressEvent(event)

    def get_work_data(self) -> dict:
        """
        Get the collected work creation data.

        Returns:
            Dictionary containing all work creation parameters
        """
        category = self.category_combo.currentText()
        return {
            "category": category,
            "reference_works": [
                f"{category}/{item.text()}" for item in self.reference_list.selectedItems()
            ],
            "literary_style_category": self.style_combo.currentText().strip(),
            "creation_guide": self.guide_text.toPlainText().strip(),
            "chapters_per_volume": self.chapters_spin.value(),
            "words_per_chapter": self.words_spin.value()
        }
