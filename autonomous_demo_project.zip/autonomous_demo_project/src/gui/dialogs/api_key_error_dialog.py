"""
API Key Error Dialog for AI Writer application.

Provides a user-friendly dialog for API authentication errors
with a direct link to the settings page.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QPushButton,
    QHBoxLayout, QWidget, QFrame
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont


class APIKeyErrorDialog(QDialog):
    """
    Dialog shown when API key is invalid or missing.

    Provides a clear error message and a button to navigate
    directly to the settings page to fix the issue.

    Signals:
        open_settings_clicked: Emitted when user clicks the settings button
    """

    open_settings_clicked = pyqtSignal()

    def __init__(self, parent=None, message: str = None):
        """
        Initialize the API key error dialog.

        Args:
            parent: Parent widget
            message: Optional custom error message
        """
        super().__init__(parent)
        self.setWindowTitle("API Key 错误")
        self.setModal(True)
        self.setMinimumWidth(400)
        self._setup_ui(message)

    def _setup_ui(self, custom_message: str = None) -> None:
        """
        Set up the user interface.

        Args:
            custom_message: Optional custom error message
        """
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.setContentsMargins(24, 24, 24, 24)

        # Error icon and title section
        title_label = QLabel("⚠️ API 认证失败")
        title_label.setFont(QFont("Microsoft YaHei", 14, QFont.Weight.Bold))
        title_label.setStyleSheet("color: #d32f2f;")
        layout.addWidget(title_label)

        # Error message
        message = custom_message or (
            "检测到您的 API Key 无效或已过期，这会导致 AI 生成功能无法正常使用。\n\n"
            "可能原因：\n"
            "• API Key 未设置或为空\n"
            "• API Key 格式不正确\n"
            "• API Key 已过期或被撤销\n"
            "• 账户余额不足\n\n"
            "请点击下方按钮前往设置页面重新配置 API Key。"
        )
        message_label = QLabel(message)
        message_label.setWordWrap(True)
        message_label.setStyleSheet("color: #424242; font-size: 13px; line-height: 1.6;")
        layout.addWidget(message_label)

        # Separator line
        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        separator.setStyleSheet("background-color: #e0e0e0;")
        layout.addWidget(separator)

        # Action buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(12)

        # Close button
        close_btn = QPushButton("关闭")
        close_btn.setMinimumSize(100, 36)
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: #f5f5f5;
                border: 1px solid #bdbdbd;
                border-radius: 4px;
                color: #424242;
                font-size: 13px;
                padding: 6px 16px;
            }
            QPushButton:hover {
                background-color: #eeeeee;
            }
            QPushButton:pressed {
                background-color: #e0e0e0;
            }
        """)
        close_btn.clicked.connect(self.reject)
        button_layout.addWidget(close_btn)

        # Settings button (primary action)
        settings_btn = QPushButton("⚙️ 前往设置")
        settings_btn.setMinimumSize(140, 36)
        settings_btn.setStyleSheet("""
            QPushButton {
                background-color: #1976d2;
                border: none;
                border-radius: 4px;
                color: white;
                font-size: 13px;
                font-weight: bold;
                padding: 6px 16px;
            }
            QPushButton:hover {
                background-color: #1565c0;
            }
            QPushButton:pressed {
                background-color: #0d47a1;
            }
        """)
        settings_btn.clicked.connect(self._on_settings_clicked)
        button_layout.addWidget(settings_btn)

        # Add stretch to push buttons to the right
        button_layout.addStretch()

        layout.addLayout(button_layout)

    def _on_settings_clicked(self) -> None:
        """Handle settings button click."""
        self.open_settings_clicked.emit()
        self.accept()

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()

        # Escape key - close dialog without saving
        if key == Qt.Key.Key_Escape:
            self.reject()
            return

        # Let the base class handle other keys
        super().keyPressEvent(event)


def show_api_key_error_dialog(
    parent=None,
    message: str = None,
    on_open_settings: callable = None
) -> APIKeyErrorDialog:
    """
    Convenience function to show API key error dialog.

    Args:
        parent: Parent widget
        message: Optional custom message
        on_open_settings: Optional callback when settings is opened

    Returns:
        The dialog instance
    """
    dialog = APIKeyErrorDialog(parent, message)

    if on_open_settings:
        dialog.open_settings_clicked.connect(on_open_settings)

    return dialog
