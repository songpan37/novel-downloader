"""
Template Edit Dialog for AI Writer application.

Provides a dialog for viewing and editing prompt templates for specific steps.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QTextEdit, QMessageBox, QGroupBox
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont


class TemplateEditDialog(QDialog):
    """
    Dialog for editing prompt templates.

    Features:
    - View and edit template content for a specific step
    - Save template changes
    - Reset to default template
    """

    # Signals
    template_saved = pyqtSignal(str, str)  # step_id, new_content
    template_reset = pyqtSignal(str)  # step_id

    def __init__(self, step_name: str, step_id: str, template_content: str, parent=None):
        """
        Initialize template edit dialog.

        Args:
            step_name: Name of the step (for display)
            step_id: Step identifier (for saving)
            template_content: Current template content
            parent: Parent widget
        """
        super().__init__(parent)
        self.step_name = step_name
        self.step_id = step_id
        self.template_content = template_content
        self.modified = False

        self.setObjectName("templateEditDialog")
        self.setWindowTitle(f"编辑提示词模板 - {step_name}")
        self.setMinimumSize(800, 600)
        self._setup_ui()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # Title
        title_label = QLabel(f"提示词模板：{self.step_name}")
        title_label.setObjectName("dialogTitle")
        layout.addWidget(title_label)

        # Subtitle
        subtitle_label = QLabel("您可以编辑此步骤的提示词模板，修改后将保存到模板目录")
        subtitle_label.setObjectName("dialogSubtitle")
        layout.addWidget(subtitle_label)

        # Template editor group
        editor_group = QGroupBox("模板内容")
        editor_layout = QVBoxLayout(editor_group)
        editor_layout.setSpacing(8)

        # Template editor
        self.template_editor = QTextEdit()
        self.template_editor.setObjectName("templateEditor")
        self.template_editor.setPlainText(self.template_content)
        self.template_editor.setAcceptRichText(False)
        self.template_editor.setFont(QFont("Consolas", 11))
        self.template_editor.textChanged.connect(self._on_content_changed)
        editor_layout.addWidget(self.template_editor)

        # Toolbar
        toolbar = QHBoxLayout()

        # Reset button
        self.btn_reset = QPushButton("恢复默认")
        self.btn_reset.setObjectName("btnReset")
        self.btn_reset.setToolTip("将模板恢复到系统默认内容")
        self.btn_reset.clicked.connect(self._on_reset_clicked)
        toolbar.addWidget(self.btn_reset)

        toolbar.addStretch()

        # Cancel button
        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.setObjectName("btnCancel")
        self.btn_cancel.clicked.connect(self.reject)
        toolbar.addWidget(self.btn_cancel)

        # Save button
        self.btn_save = QPushButton("保存")
        self.btn_save.setObjectName("btnSave")
        self.btn_save.setDefault(True)
        self.btn_save.clicked.connect(self._on_save_clicked)
        self.btn_save.setEnabled(False)  # Disabled until content changes
        toolbar.addWidget(self.btn_save)

        editor_layout.addLayout(toolbar)
        layout.addWidget(editor_group)

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            QDialog#templateEditDialog {
                background-color: #ffffff;
            }

            #dialogTitle {
                font-size: 18px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 5px;
            }

            #dialogSubtitle {
                font-size: 12px;
                color: #7f8c8d;
                margin-bottom: 15px;
            }

            QGroupBox {
                font-weight: bold;
                border: 1px solid #ecf0f1;
                border-radius: 6px;
                margin-top: 10px;
                padding-top: 10px;
                font-weight: normal;
            }

            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
                color: #2c3e50;
            }

            #templateEditor {
                border: 1px solid #ecf0f1;
                border-radius: 4px;
                padding: 8px;
                font-family: Consolas, Monaco, monospace;
                font-size: 13px;
                line-height: 1.5;
                min-height: 300px;
            }

            #templateEditor:focus {
                border: 1px solid #3498db;
            }

            #btnSave {
                background-color: #1a5276;
                color: white;
                border: none;
                padding: 8px 20px;
                border-radius: 4px;
                font-weight: bold;
                min-width: 80px;
            }

            #btnSave:hover {
                background-color: #154360;
            }

            #btnSave:disabled {
                background-color: #bdc3c7;
            }

            #btnReset {
                background-color: #95a5a6;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
            }

            #btnReset:hover {
                background-color: #7f8c8d;
            }

            #btnCancel {
                background-color: #ecf0f1;
                color: #2c3e50;
                border: 1px solid #bdc3c7;
                padding: 8px 16px;
                border-radius: 4px;
            }

            #btnCancel:hover {
                background-color: #d5dbdb;
            }
        """)

    def _on_content_changed(self) -> None:
        """Handle content change in editor."""
        self.modified = True
        self.btn_save.setEnabled(True)

    def _on_reset_clicked(self) -> None:
        """Handle reset button click."""
        reply = QMessageBox.question(
            self,
            "确认恢复默认",
            f"确定要将\"{self.step_name}\"的模板恢复到默认内容吗？\n\n当前的修改将会丢失。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            self.template_reset.emit(self.step_id)
            # Load default content (caller should handle this)
            self.accept()

    def _on_save_clicked(self) -> None:
        """Handle save button click."""
        content = self.template_editor.toPlainText()
        self.template_saved.emit(self.step_id, content)
        self.accept()

    def get_template_content(self) -> str:
        """Get the current template content."""
        return self.template_editor.toPlainText()
