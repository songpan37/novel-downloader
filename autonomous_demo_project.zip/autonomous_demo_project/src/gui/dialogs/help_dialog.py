"""
Help dialog for AI Writer application.

Displays user documentation and keyboard shortcuts reference.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTabWidget, QTextEdit, QFrame, QScrollArea, QWidget, QGridLayout
)
from PyQt6.QtCore import Qt, pyqtSignal, QUrl
from PyQt6.QtGui import QFont, QKeySequence, QDesktopServices


class HelpDialog(QDialog):
    """
    Help dialog showing user documentation and keyboard shortcuts.

    Provides two tabs:
    - User Guide: Basic usage instructions
    - Keyboard Shortcuts: List of all keyboard shortcuts
    """

    def __init__(self, parent=None):
        """
        Initialize the Help dialog.

        Args:
            parent: Parent widget
        """
        super().__init__(parent)
        self.setWindowTitle("帮助文档")
        self.setModal(True)
        self.setFixedSize(800, 600)
        self.setWindowFlags(
            self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint
        )

        self._setup_ui()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the dialog UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 15, 20, 15)
        layout.setSpacing(15)

        # Title
        title_label = QLabel("AI Writer 帮助文档")
        title_label.setObjectName("helpTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Tab widget
        self.tabs = QTabWidget()
        self.tabs.setObjectName("helpTabs")

        # User Guide tab
        user_guide_widget = self._create_user_guide_tab()
        self.tabs.addTab(user_guide_widget, "使用指南")

        # Keyboard Shortcuts tab
        shortcuts_widget = self._create_shortcuts_tab()
        self.tabs.addTab(shortcuts_widget, "键盘快捷键")

        layout.addWidget(self.tabs)

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch()

        # Report Issue button
        report_btn = QPushButton("反馈问题")
        report_btn.setObjectName("reportButton")
        report_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        report_btn.clicked.connect(self._on_report_clicked)
        button_layout.addWidget(report_btn)

        # Close button
        close_btn = QPushButton("关闭")
        close_btn.setObjectName("closeButton")
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.clicked.connect(self.accept)
        close_btn.setDefault(True)
        close_btn.setFocus()
        button_layout.addWidget(close_btn)

        layout.addLayout(button_layout)

    def _create_user_guide_tab(self) -> QWidget:
        """Create the user guide tab content."""
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.Shape.NoFrame)

        content_widget = QWidget()
        layout = QVBoxLayout(content_widget)
        layout.setContentsMargins(20, 15, 20, 15)
        layout.setSpacing(20)

        # Welcome section
        welcome = self._create_section_label(
            "欢迎使用 AI Writer",
            "AI Writer 是一款专为网络小说创作者设计的 AI 辅助写作工具，帮助您完成从作品构思到章节正文的全流程创作。"
        )
        layout.addWidget(welcome)

        # Quick Start section
        quick_start = self._create_section_label(
            "快速入门",
            "1. 首次使用时，在设置页面配置存储路径\n"
            "2. 在作品库点击「新建作品」创建新作品\n"
            "3. 选择作品类别和参考作品\n"
            "4. 双击作品卡片进入详情页\n"
            "5. 点击「开始创作」按钮开始 AI 创作"
        )
        layout.addWidget(quick_start)

        # Features section
        features = self._create_section_label(
            "主要功能",
            "• 作品管理：创建、导入、导出、删除作品\n"
            "• AI 创作：自动生成书名、设定、大纲、正文\n"
            "• 提示词模板：自定义 AI 创作提示词\n"
            "• 发布中心：一键发布到多个小说平台\n"
            "• 设置管理：配置存储路径和 API 密钥"
        )
        layout.addWidget(features)

        # Workflow section
        workflow = self._create_section_label(
            "创作流程",
            "1. 基本信息：生成书名、故事梗概、时空设定、人物设定、封面\n"
            "2. 分卷大纲：为每卷生成故事梗概、章节划分、出场人物\n"
            "3. 章节正文：为每章生成章节名、剧情概述、出场人物、场景列表、正文内容\n\n"
            "创作过程中可随时暂停、继续，所有进度自动保存。"
        )
        layout.addWidget(workflow)

        # Tips section
        tips = self._create_section_label(
            "使用技巧",
            "• 使用 Ctrl+Z 撤销编辑，Ctrl+Y 重做\n"
            "• 双击作品卡片快速进入详情\n"
            "• 使用 Alt+1/2/3/4 快速切换页面\n"
            "• 按 F1 快速打开帮助文档\n"
            "• 提示词模板支持占位符引用，如{worldbuilding}"
        )
        layout.addWidget(tips)

        # FAQ section
        faq = self._create_section_label(
            "常见问题",
            "Q: 如何修改存储路径？\n"
            "A: 在设置页面修改存储根目录，其他路径会自动更新。\n\n"
            "Q: AI 生成中断了怎么办？\n"
            "A: 点击「继续创作」按钮，会从上次中断的位置继续。\n\n"
            "Q: 如何导出作品？\n"
            "A: 在作品库右键点击作品卡片，选择「导出」即可。"
        )
        layout.addWidget(faq)

        layout.addStretch()

        scroll_area.setWidget(content_widget)
        return scroll_area

    def _create_shortcuts_tab(self) -> QWidget:
        """Create the keyboard shortcuts tab content."""
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.Shape.NoFrame)

        content_widget = QWidget()
        layout = QVBoxLayout(content_widget)
        layout.setContentsMargins(20, 15, 20, 15)
        layout.setSpacing(15)

        # Title
        title_label = QLabel("键盘快捷键")
        title_label.setObjectName("shortcutsTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Shortcuts grid
        shortcuts_grid = QGridLayout()
        shortcuts_grid.setSpacing(10)

        # Define shortcuts
        shortcuts = [
            ("页面导航", [
                ("Alt + 1", "切换到作品库"),
                ("Alt + 2", "切换到发布中心"),
                ("Alt + 3", "切换到提示词模板"),
                ("Alt + 4", "切换到设置"),
            ]),
            ("通用操作", [
                ("F1", "打开帮助文档"),
                ("Escape", "关闭对话框/退出应用"),
                ("Ctrl + S", "保存当前内容"),
                ("Ctrl + Q", "退出应用"),
            ]),
            ("编辑操作", [
                ("Ctrl + Z", "撤销"),
                ("Ctrl + Y", "重做"),
                ("Ctrl + Shift + Z", "重做 (备选)"),
                ("Ctrl + A", "全选"),
                ("Ctrl + C", "复制"),
                ("Ctrl + V", "粘贴"),
                ("Ctrl + X", "剪切"),
            ]),
            ("作品管理", [
                ("双击作品卡片", "打开作品详情"),
                ("Ctrl + N", "新建作品"),
                ("Ctrl + I", "导入作品"),
            ]),
            ("创作控制", [
                ("Enter", "确认对话框"),
                ("Escape", "取消对话框"),
            ]),
        ]

        row = 0
        for category, items in shortcuts:
            # Category label
            cat_label = QLabel(category)
            cat_label.setObjectName("shortcutCategory")
            shortcuts_grid.addWidget(cat_label, row, 0, 1, 2)
            row += 1

            # Shortcut items
            for shortcut, description in items:
                key_label = QLabel(shortcut)
                key_label.setObjectName("shortcutKey")
                shortcuts_grid.addWidget(key_label, row, 0)

                desc_label = QLabel(description)
                desc_label.setObjectName("shortcutDesc")
                shortcuts_grid.addWidget(desc_label, row, 1)
                row += 1

            # Add spacing between categories
            shortcuts_grid.setRowMinimumHeight(row, 15)
            row += 1

        layout.addLayout(shortcuts_grid)
        layout.addStretch()

        scroll_area.setWidget(content_widget)
        return scroll_area

    def _create_section_label(self, title: str, content: str) -> QLabel:
        """
        Create a styled section label with title and content.

        Args:
            title: Section title
            content: Section content

        Returns:
            Styled QLabel
        """
        # Create HTML formatted label
        html = f"""
        <div style="margin-bottom: 15px;">
            <h3 style="color: #2c3e50; margin-bottom: 8px; font-size: 16px;">{title}</h3>
            <p style="color: #555555; line-height: 1.6; margin: 0; white-space: pre-wrap;">{content}</p>
        </div>
        """
        label = QLabel(html)
        label.setWordWrap(True)
        label.setTextFormat(Qt.TextFormat.RichText)
        return label

    def _apply_styles(self) -> None:
        """Apply dialog styles."""
        self.setStyleSheet("""
            QDialog {
                background-color: #ffffff;
            }

            #helpTitle {
                font-size: 24px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 10px;
            }

            #shortcutsTitle {
                font-size: 20px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 15px;
            }

            #helpTabs {
                background-color: #ffffff;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
            }

            #helpTabs::pane {
                border: none;
                background-color: #fafafa;
                border-radius: 0 0 8px 8px;
            }

            #helpTabs::tab-bar {
                alignment: left;
            }

            QTabBar::tab {
                background-color: #f0f0f0;
                color: #555555;
                padding: 10px 20px;
                margin-right: 2px;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                font-size: 14px;
            }

            QTabBar::tab:selected {
                background-color: #ffffff;
                color: #2c3e50;
                font-weight: bold;
            }

            QTabBar::tab:hover:!selected {
                background-color: #e8e8e8;
            }

            QScrollArea {
                background-color: #fafafa;
            }

            #shortcutCategory {
                font-size: 15px;
                font-weight: bold;
                color: #2c3e50;
                background-color: #e8f4f8;
                padding: 8px 12px;
                border-radius: 4px;
                margin-top: 5px;
            }

            #shortcutKey {
                font-family: Consolas, Monaco, monospace;
                font-size: 13px;
                color: #ffffff;
                background-color: #3498db;
                padding: 4px 10px;
                border-radius: 4px;
                min-width: 120px;
            }

            #shortcutDesc {
                font-size: 13px;
                color: #555555;
                padding-left: 10px;
            }

            QPushButton {
                background-color: #ecf0f1;
                color: #2c3e50;
                border: 1px solid #bdc3c7;
                border-radius: 4px;
                padding: 8px 20px;
                font-size: 13px;
            }

            QPushButton:hover {
                background-color: #bdc3c7;
            }

            QPushButton:pressed {
                background-color: #95a5a6;
            }

            #reportButton {
                background-color: #f39c12;
                color: #ffffff;
                border: 1px solid #d68910;
            }

            #reportButton:hover {
                background-color: #d68910;
            }

            #closeButton {
                background-color: #3498db;
                color: #ffffff;
                border: 1px solid #2980b9;
                min-width: 80px;
            }

            #closeButton:hover {
                background-color: #2980b9;
            }
        """)

    def _on_report_clicked(self) -> None:
        """Handle report issue button click."""
        # Open GitHub issues page in default browser
        url = QUrl("https://github.com/ai-writer/aiwriter-local/issues")
        QDesktopServices.openUrl(url)


def show_help_dialog(parent=None) -> None:
    """
    Show the Help dialog.

    Args:
        parent: Parent widget
    """
    dialog = HelpDialog(parent)
    dialog.exec()
