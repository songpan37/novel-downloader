"""
Retry dialog for API rate limit errors.

Provides a user-friendly dialog when API rate limits are exceeded,
with options to retry or cancel the operation.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QProgressBar, QWidget, QFrame
)
from PyQt6.QtCore import QTimer, pyqtSignal, Qt
from PyQt6.QtGui import QFont


class RetryDialog(QDialog):
    """
    Dialog shown when API rate limit is exceeded.

    Offers the user options to:
    - Wait and retry automatically
    - Retry immediately
    - Cancel the operation

    Attributes:
        retry_clicked: Signal emitted when retry is selected
        cancel_clicked: Signal emitted when cancel is selected
    """

    retry_clicked = pyqtSignal()
    cancel_clicked = pyqtSignal()

    def __init__(
        self,
        parent=None,
        retry_after_seconds: int = 30,
        custom_message: str = None
    ):
        """
        Initialize the retry dialog.

        Args:
            parent: Parent widget
            retry_after_seconds: Seconds until rate limit resets
            custom_message: Optional custom error message
        """
        super().__init__(parent)
        self.setWindowTitle("请求过于频繁")
        self.setModal(True)
        self.setMinimumWidth(400)
        self.setMinimumHeight(200)

        self.retry_after_seconds = retry_after_seconds
        self.remaining_seconds = retry_after_seconds
        self._setup_ui(custom_message)
        self._start_countdown()

    def _setup_ui(self, custom_message: str = None) -> None:
        """
        Set up the dialog UI.

        Args:
            custom_message: Optional custom message to display
        """
        layout = QVBoxLayout()
        layout.setSpacing(16)
        layout.setContentsMargins(24, 24, 24, 24)
        self.setLayout(layout)

        # Icon and title
        icon_label = QLabel("⚠️")
        icon_label.setFont(QFont("Segoe UI Emoji", 24))
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(icon_label)

        # Title
        title_label = QLabel("请求过于频繁")
        title_label.setFont(QFont("Microsoft YaHei", 14, QFont.Weight.Bold))
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Message
        message = custom_message or (
            f"您的请求过于频繁，系统需要稍等一下才能继续。\n"
            f"这将帮助我们避免对服务造成过大压力。"
        )
        message_label = QLabel(message)
        message_label.setFont(QFont("Microsoft YaHei", 10))
        message_label.setWordWrap(True)
        message_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(message_label)

        # Countdown display
        self.countdown_label = QLabel()
        self._update_countdown_label()
        self.countdown_label.setFont(QFont("Microsoft YaHei", 11))
        self.countdown_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.countdown_label)

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setMinimum(0)
        self.progress_bar.setMaximum(max(1, self.retry_after_seconds))
        self.progress_bar.setValue(self.remaining_seconds)
        self.progress_bar.setFormat("%v秒")
        self.progress_bar.setMinimumHeight(20)
        layout.addWidget(self.progress_bar)

        # Spacer
        layout.addStretch()

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(12)

        # Retry now button (enabled if remaining_seconds is 0)
        self.btn_retry_now = QPushButton("立即重试")
        self.btn_retry_now.setFont(QFont("Microsoft YaHei", 10))
        self.btn_retry_now.setMinimumHeight(36)
        self.btn_retry_now.setMinimumWidth(100)
        self.btn_retry_now.setEnabled(self.remaining_seconds == 0)
        self.btn_retry_now.clicked.connect(self._on_retry_now_clicked)
        button_layout.addWidget(self.btn_retry_now)

        # Wait and retry button
        self.btn_wait_retry = QPushButton("等待后重试")
        self.btn_wait_retry.setFont(QFont("Microsoft YaHei", 10))
        self.btn_wait_retry.setMinimumHeight(36)
        self.btn_wait_retry.setMinimumWidth(100)
        self.btn_wait_retry.clicked.connect(self._on_wait_retry_clicked)
        button_layout.addWidget(self.btn_wait_retry)

        # Cancel button
        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.setFont(QFont("Microsoft YaHei", 10))
        self.btn_cancel.setMinimumHeight(36)
        self.btn_cancel.setMinimumWidth(100)
        self.btn_cancel.clicked.connect(self._on_cancel_clicked)
        button_layout.addWidget(self.btn_cancel)

        layout.addLayout(button_layout)

    def _update_countdown_label(self) -> None:
        """Update the countdown display label."""
        if self.remaining_seconds > 0:
            self.countdown_label.setText(
                f"请等待 <b>{self.remaining_seconds}</b> 秒后重试"
            )
            self.countdown_label.setStyleSheet("color: #e67e22;")
        else:
            self.countdown_label.setText(
                f"<b>现在可以重试了！</b>"
            )
            self.countdown_label.setStyleSheet("color: #27ae60;")

    def _start_countdown(self) -> None:
        """Start the countdown timer."""
        self.timer = QTimer()
        self.timer.timeout.connect(self._on_timer_tick)
        self.timer.start(1000)  # 1 second interval

    def _on_timer_tick(self) -> None:
        """Handle timer tick."""
        if self.remaining_seconds > 0:
            self.remaining_seconds -= 1
            self.progress_bar.setValue(self.remaining_seconds)
            self._update_countdown_label()

            if self.remaining_seconds == 0:
                self.btn_retry_now.setEnabled(True)
                self.btn_retry_now.setFocus()
        else:
            self.timer.stop()

    def _on_retry_now_clicked(self) -> None:
        """Handle retry now button click."""
        self.retry_clicked.emit()
        self.accept()

    def _on_wait_retry_clicked(self) -> None:
        """Handle wait and retry button click."""
        if self.remaining_seconds > 0:
            # User chose to wait
            self.btn_wait_retry.setEnabled(False)
            self.btn_wait_retry.setText("等待中...")
        else:
            self.retry_clicked.emit()
            self.accept()

    def _on_cancel_clicked(self) -> None:
        """Handle cancel button click."""
        self.cancel_clicked.emit()
        self.reject()

    def get_retry_after(self) -> int:
        """
        Get the recommended retry-after time.

        Returns:
            Seconds to wait before retrying
        """
        return self.remaining_seconds

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()

        # Escape key - close dialog without saving
        if key == Qt.Key.Key_Escape:
            self.reject()
            return

        # Let the base class handle other keys
        super().keyPressEvent(event)


class RateLimitErrorDialog(QDialog):
    """
    Simplified rate limit error dialog with retry option.

    This is a more lightweight version that just shows the error
    and offers a single retry button.
    """

    retry_requested = pyqtSignal()
    cancel_requested = pyqtSignal()

    def __init__(
        self,
        parent=None,
        error_message: str = "请求过于频繁，请稍后再试",
        retry_after_seconds: int = 30
    ):
        """
        Initialize the dialog.

        Args:
            parent: Parent widget
            error_message: Error message to display
            retry_after_seconds: Seconds until rate limit resets
        """
        super().__init__(parent)
        self.setWindowTitle("API 请求限制")
        self.setModal(True)
        self.setMinimumWidth(380)

        self.retry_after_seconds = retry_after_seconds
        self._setup_ui(error_message)

    def _setup_ui(self, error_message: str) -> None:
        """Set up the dialog UI."""
        layout = QVBoxLayout()
        layout.setSpacing(16)
        layout.setContentsMargins(20, 20, 20, 20)
        self.setLayout(layout)

        # Warning icon
        icon_label = QLabel("⚠️")
        icon_label.setFont(QFont("Segoe UI Emoji", 28))
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(icon_label)

        # Title
        title = QLabel("请求频率超限")
        title.setFont(QFont("Microsoft YaHei", 13, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        # Error message
        msg_label = QLabel(error_message)
        msg_label.setFont(QFont("Microsoft YaHei", 10))
        msg_label.setWordWrap(True)
        msg_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(msg_label)

        # Retry info
        if self.retry_after_seconds > 0:
            info_label = QLabel(
                f"建议等待时间：<b>{self.retry_after_seconds}</b> 秒"
            )
            info_label.setFont(QFont("Microsoft YaHei", 9))
            info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            info_label.setStyleSheet("color: #7f8c8d;")
            layout.addWidget(info_label)

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(12)

        self.btn_retry = QPushButton("重试")
        self.btn_retry.setFont(QFont("Microsoft YaHei", 10))
        self.btn_retry.setMinimumHeight(38)
        self.btn_retry.setMinimumWidth(100)
        self.btn_retry.clicked.connect(self._on_retry_clicked)
        button_layout.addWidget(self.btn_retry)

        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.setFont(QFont("Microsoft YaHei", 10))
        self.btn_cancel.setMinimumHeight(38)
        self.btn_cancel.setMinimumWidth(100)
        self.btn_cancel.clicked.connect(self._on_cancel_clicked)
        button_layout.addWidget(self.btn_cancel)

        layout.addLayout(button_layout)

    def _on_retry_clicked(self) -> None:
        """Handle retry button click."""
        self.retry_requested.emit()
        self.accept()

    def _on_cancel_clicked(self) -> None:
        """Handle cancel button click."""
        self.cancel_requested.emit()
        self.reject()

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()

        # Escape key - close dialog without saving
        if key == Qt.Key.Key_Escape:
            self.reject()
            return

        # Let the base class handle other keys
        super().keyPressEvent(event)
