"""
Fanqie Account Management Dialog for AI Writer application.

Provides UI for CRUD operations on 番茄小说 writer accounts.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QLineEdit, QListWidget, QListWidgetItem,
    QMessageBox, QWidget, QGridLayout
)
from PyQt6.QtCore import Qt, pyqtSignal
from typing import Optional

from models.fanqie_account import FanqieAccount
from services.fanqie_account_manager import FanqieAccountManager


class FanqieAccountDialog(QDialog):
    """
    Dialog for managing 番茄小说 writer accounts.

    Signals:
        account_selected: Emitted when an account is selected (account_id)
    """

    account_selected = pyqtSignal(str)

    def __init__(self, account_manager: FanqieAccountManager, parent=None):
        """
        Initialize the account dialog.

        Args:
            account_manager: FanqieAccountManager instance
            parent: Parent widget
        """
        super().__init__(parent)
        self.account_manager = account_manager
        self._selected_account_id: Optional[str] = None
        self._editing_account_id: Optional[str] = None
        self.setObjectName("fanqieAccountDialog")
        self._setup_ui()
        self._setup_connections()
        self._apply_styles()
        self._refresh_account_list()
        # Initially hide the form
        self.form_widget.setVisible(False)
        self.cancel_form_btn.setVisible(False)
        self.save_form_btn.setVisible(False)

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        self.setWindowTitle("管理番茄账号")
        self.setMinimumSize(500, 480)
        self.setMaximumSize(500, 480)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)

        # Title
        title_label = QLabel("管理番茄账号")
        title_label.setObjectName("dialogTitle")
        title_label.setFixedHeight(36)
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Account list
        self.account_list = QListWidget()
        self.account_list.setObjectName("accountList")
        self.account_list.setFixedHeight(120)
        self.account_list.setSelectionMode(QListWidget.SelectionMode.SingleSelection)
        self.account_list.setStyleSheet("""
            QListWidget {
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                background-color: #ffffff;
                font-size: 14px;
                outline: none;
            }
            QListWidget::item {
                padding: 8px 12px;
                border: none;
                outline: none;
            }
            QListWidget::item:selected {
                background-color: #3498db;
                color: #ffffff;
                border: none;
                outline: none;
            }
            QListWidget::item:hover:!selected {
                background-color: #e8f4f8;
                border: none;
                outline: none;
            }
        """)
        layout.addWidget(self.account_list)

        # Buttons row (Add/Edit/Delete)
        button_row = QHBoxLayout()
        button_row.setSpacing(10)

        self.add_btn = QPushButton("添加账号")
        self.add_btn.setObjectName("addAccountBtn")
        self.add_btn.setFixedSize(100, 32)
        button_row.addWidget(self.add_btn)

        button_row.addStretch()

        self.edit_btn = QPushButton("编辑")
        self.edit_btn.setObjectName("editAccountBtn")
        self.edit_btn.setFixedSize(80, 32)
        self.edit_btn.setEnabled(False)
        button_row.addWidget(self.edit_btn)

        self.delete_btn = QPushButton("删除")
        self.delete_btn.setObjectName("deleteAccountBtn")
        self.delete_btn.setFixedSize(80, 32)
        self.delete_btn.setEnabled(False)
        button_row.addWidget(self.delete_btn)

        layout.addLayout(button_row)

        # Form container (for add/edit) - always visible but content changes
        self.form_container = QWidget()
        self.form_container.setObjectName("formContainer")
        self.form_container.setFixedHeight(170)
        form_container_layout = QVBoxLayout(self.form_container)
        form_container_layout.setContentsMargins(0, 0, 0, 0)
        form_container_layout.setSpacing(8)

        # Form area with fixed sizes
        self.form_widget = QWidget()
        self.form_widget.setObjectName("formWidget")
        self.form_widget.setFixedHeight(120)
        form_layout = QGridLayout(self.form_widget)
        form_layout.setContentsMargins(0, 0, 0, 0)
        form_layout.setSpacing(8)

        # Phone row
        phone_label = QLabel("手机号:")
        phone_label.setObjectName("phoneLabel")
        phone_label.setFixedSize(50, 36)
        phone_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.phone_input = QLineEdit()
        self.phone_input.setObjectName("phoneInput")
        self.phone_input.setPlaceholderText("请输入手机号")
        self.phone_input.setFixedSize(340, 36)
        form_layout.addWidget(phone_label, 0, 0)
        form_layout.addWidget(self.phone_input, 0, 1)

        # Password row
        password_label = QLabel("密码:")
        password_label.setObjectName("passwordLabel")
        password_label.setFixedSize(50, 36)
        password_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.password_input = QLineEdit()
        self.password_input.setObjectName("passwordInput")
        self.password_input.setPlaceholderText("请输入密码")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_input.setFixedSize(340, 36)
        form_layout.addWidget(password_label, 1, 0)
        form_layout.addWidget(self.password_input, 1, 1)

        # Nickname row
        nickname_label = QLabel("备注:")
        nickname_label.setObjectName("nicknameLabel")
        nickname_label.setFixedSize(50, 36)
        nickname_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.nickname_input = QLineEdit()
        self.nickname_input.setObjectName("nicknameInput")
        self.nickname_input.setPlaceholderText("可选，如'主号'、'备用'")
        self.nickname_input.setFixedSize(340, 36)
        form_layout.addWidget(nickname_label, 2, 0)
        form_layout.addWidget(self.nickname_input, 2, 1)

        form_container_layout.addWidget(self.form_widget)

        # Form buttons (save/cancel) - right aligned
        form_button_row = QHBoxLayout()
        form_button_row.setSpacing(10)
        form_button_row.addStretch()

        self.cancel_form_btn = QPushButton("取消")
        self.cancel_form_btn.setObjectName("cancelFormBtn")
        self.cancel_form_btn.setFixedSize(80, 32)
        form_button_row.addWidget(self.cancel_form_btn)

        self.save_form_btn = QPushButton("保存")
        self.save_form_btn.setObjectName("saveFormBtn")
        self.save_form_btn.setFixedSize(80, 32)
        form_button_row.addWidget(self.save_form_btn)

        form_container_layout.addLayout(form_button_row)

        layout.addWidget(self.form_container)

    def _setup_connections(self) -> None:
        """Connect signals and slots."""
        self.add_btn.clicked.connect(self._on_add_clicked)
        self.edit_btn.clicked.connect(self._on_edit_clicked)
        self.delete_btn.clicked.connect(self._on_delete_clicked)
        self.cancel_form_btn.clicked.connect(self._on_cancel_form)
        self.save_form_btn.clicked.connect(self._on_save_form)
        self.account_list.itemSelectionChanged.connect(self._on_selection_changed)

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            #dialogTitle {
                font-size: 18px;
                font-weight: bold;
                color: #2c3e50;
                padding: 10px 0;
            }

            QLabel {
                color: #2c3e50;
                font-size: 14px;
                min-height: 28px;
            }

            QLineEdit {
                padding: 4px 8px;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                font-size: 14px;
                background-color: #ffffff;
            }

            QLineEdit:focus {
                border-color: #3498db;
            }

            QPushButton {
                padding: 8px 16px;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                background-color: #ffffff;
                font-size: 14px;
                color: #2c3e50;
            }

            QPushButton:hover {
                background-color: #f5f5f5;
                border-color: #3498db;
            }

            #addAccountBtn {
                background-color: #3498db;
                color: #ffffff;
                border: none;
            }

            #addAccountBtn:hover {
                background-color: #2980b9;
            }

            #deleteAccountBtn {
                background-color: #e74c3c;
                color: #ffffff;
                border: none;
            }

            #deleteAccountBtn:hover {
                background-color: #c0392b;
            }

            #formWidget {
                background-color: #f8f9fa;
                border-radius: 4px;
                padding: 8px;
            }

            #formContainer {
                background-color: transparent;
            }
        """)

    def _refresh_account_list(self) -> None:
        """Refresh the account list display."""
        self.account_list.clear()
        accounts = self.account_manager.get_all_accounts()
        for account in accounts:
            item = QListWidgetItem(account.get_display_name())
            item.setData(Qt.ItemDataRole.UserRole, account.id)
            self.account_list.addItem(item)

    def _on_selection_changed(self) -> None:
        """Handle selection change."""
        has_selection = len(self.account_list.selectedItems()) > 0
        self.edit_btn.setEnabled(has_selection)
        self.delete_btn.setEnabled(has_selection)
        if has_selection:
            self._selected_account_id = self.account_list.selectedItems()[0].data(Qt.ItemDataRole.UserRole)

    def _on_add_clicked(self) -> None:
        """Handle add button click."""
        self._editing_account_id = None
        self.phone_input.clear()
        self.password_input.clear()
        self.nickname_input.clear()
        self.form_widget.setVisible(True)
        self.cancel_form_btn.setVisible(True)
        self.save_form_btn.setVisible(True)
        self.add_btn.setEnabled(False)
        self.edit_btn.setEnabled(False)
        self.delete_btn.setEnabled(False)
        self.account_list.setEnabled(False)

    def _on_edit_clicked(self) -> None:
        """Handle edit button click."""
        if not self._selected_account_id:
            return

        account = self.account_manager.get_account(self._selected_account_id)
        if account:
            self._editing_account_id = account.id
            self.phone_input.setText(account.phone)
            self.password_input.setText(account.password)
            self.nickname_input.setText(account.nickname)
            self.form_widget.setVisible(True)
            self.cancel_form_btn.setVisible(True)
            self.save_form_btn.setVisible(True)
            self.add_btn.setEnabled(False)
            self.edit_btn.setEnabled(False)
            self.delete_btn.setEnabled(False)
            self.account_list.setEnabled(False)

    def _on_delete_clicked(self) -> None:
        """Handle delete button click."""
        if not self._selected_account_id:
            return

        account = self.account_manager.get_account(self._selected_account_id)
        if not account:
            return

        reply = QMessageBox.question(
            self,
            "确认删除",
            f"确定要删除账号 '{account.get_display_name()}' 吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            self.account_manager.delete_account(self._selected_account_id)
            self._refresh_account_list()
            self._selected_account_id = None
            self.edit_btn.setEnabled(False)
            self.delete_btn.setEnabled(False)

    def _on_cancel_form(self) -> None:
        """Handle cancel form button click."""
        self._hide_form()

    def _on_save_form(self) -> None:
        """Handle save form button click."""
        phone = self.phone_input.text().strip()
        password = self.password_input.text().strip()
        nickname = self.nickname_input.text().strip()

        if not phone:
            QMessageBox.warning(self, "提示", "请输入手机号")
            return

        if not password:
            QMessageBox.warning(self, "提示", "请输入密码")
            return

        if self._editing_account_id:
            # Update existing
            self.account_manager.update_account(
                self._editing_account_id,
                phone=phone,
                password=password,
                nickname=nickname
            )
        else:
            # Add new
            self.account_manager.add_account(phone, password, nickname)

        self._hide_form()
        self._refresh_account_list()

    def _hide_form(self) -> None:
        """Hide the form and re-enable other controls."""
        self.form_widget.setVisible(False)
        self.cancel_form_btn.setVisible(False)
        self.save_form_btn.setVisible(False)
        self.add_btn.setEnabled(True)
        self.account_list.setEnabled(True)
        # Re-enable buttons if selection exists
        has_selection = len(self.account_list.selectedItems()) > 0
        self.edit_btn.setEnabled(has_selection)
        self.delete_btn.setEnabled(has_selection)
