"""
File Not Found Error Dialog for AI Writer application.

Provides a user-friendly dialog when a work file is not found,
with an option to remove the stale entry from the list.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QMessageBox, QWidget
)
from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtGui import QIcon


class FileNotFoundErrorDialog(QDialog):
    """
    Dialog shown when a work file is not found.

    Provides options to:
    - Remove the stale entry from the list
    - Dismiss the dialog

    Attributes:
        remove_requested: Signal emitted when user chooses to remove the entry
    """

    remove_requested = pyqtSignal(str)  # work_id

    def __init__(
        self,
        work_title: str,
        work_id: str,
        parent: QWidget = None
    ):
        """
        Initialize the file not found dialog.

        Args:
            work_title: Title of the work that was not found
            work_id: ID of the work that was not found
            parent: Parent widget
        """
        super().__init__(parent)
        self.work_title = work_title
        self.work_id = work_id

        self.setWindowTitle("作品文件不存在")
        self.setMinimumWidth(400)
        self.setModal(True)

        self._setup_ui()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the dialog UI."""
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        layout.setContentsMargins(30, 30, 30, 30)

        # Icon and message section
        icon_layout = QHBoxLayout()
        icon_layout.setSpacing(15)

        # Error icon
        icon_label = QLabel()
        icon_label.setFixedSize(48, 48)
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_label.setStyleSheet("""
            QLabel {
                background-color: #f39c12;
                border-radius: 24px;
                color: white;
                font-size: 28px;
                font-weight: bold;
            }
        """)
        icon_label.setText("!")
        icon_layout.addWidget(icon_label)

        # Message label
        message_widget = QWidget()
        message_layout = QVBoxLayout(message_widget)
        message_layout.setContentsMargins(0, 0, 0, 0)
        message_layout.setSpacing(8)

        # Title
        title_label = QLabel("作品文件不存在")
        title_label.setObjectName("titleLabel")
        title_label.setWordWrap(True)
        message_layout.addWidget(title_label)

        # Details
        details_label = QLabel(
            f"作品《{self.work_title}》的文件已不存在，可能已被其他程序删除或移动。\n\n"
            f"您可以选择从作品列表中移除该条目，或者稍后手动删除。"
        )
        details_label.setObjectName("detailsLabel")
        details_label.setWordWrap(True)
        message_layout.addWidget(details_label)

        icon_layout.addWidget(message_widget, 1)
        layout.addLayout(icon_layout)

        # Button section
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)

        # Remove button (primary action)
        self.btn_remove = QPushButton("从列表中移除")
        self.btn_remove.setObjectName("btnRemove")
        self.btn_remove.setFixedWidth(150)
        self.btn_remove.clicked.connect(self._on_remove_clicked)
        button_layout.addWidget(self.btn_remove)

        # Close button
        self.btn_close = QPushButton("关闭")
        self.btn_close.setObjectName("btnClose")
        self.btn_close.setFixedWidth(100)
        self.btn_close.clicked.connect(self.reject)
        button_layout.addWidget(self.btn_close)

        button_layout.addStretch()
        layout.addLayout(button_layout)

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            QDialog {
                background-color: #ffffff;
            }

            QLabel#titleLabel {
                font-size: 18px;
                font-weight: bold;
                color: #d35400;
            }

            QLabel#detailsLabel {
                font-size: 14px;
                color: #555555;
                line-height: 1.6;
            }

            QPushButton#btnRemove {
                background-color: #e74c3c;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
            }

            QPushButton#btnRemove:hover {
                background-color: #c0392b;
            }

            QPushButton#btnClose {
                background-color: #ecf0f1;
                color: #2c3e50;
                border: 1px solid #bdc3c7;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
            }

            QPushButton#btnClose:hover {
                background-color: #bdc3c7;
            }
        """)

    def _on_remove_clicked(self) -> None:
        """Handle remove button click."""
        self.remove_requested.emit(self.work_id)
        self.accept()

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()

        # Escape key - close dialog without saving
        if key == Qt.Key.Key_Escape:
            self.reject()
            return

        # Let the base class handle other keys
        super().keyPressEvent(event)

    @staticmethod
    def show_file_not_found_dialog(
        work_title: str,
        work_id: str,
        parent: QWidget = None
    ) -> bool:
        """
        Static convenience method to show the file not found dialog.

        Args:
            work_title: Title of the work that was not found
            work_id: ID of the work that was not found
            parent: Parent widget

        Returns:
            True if user chose to remove, False otherwise
        """
        dialog = FileNotFoundErrorDialog(work_title, work_id, parent)
        result = dialog.exec()
        return result == QDialog.DialogCode.Accepted


def show_file_not_found_dialog(
    work_title: str,
    work_id: str,
    parent: QWidget = None
) -> bool:
    """
    Show a file not found error dialog.

    This is a convenience function that creates and shows the dialog.

    Args:
        work_title: Title of the work that was not found
        work_id: ID of the work that was not found
        parent: Parent widget

    Returns:
        True if user chose to remove the entry, False otherwise
    """
    return FileNotFoundErrorDialog.show_file_not_found_dialog(
        work_title, work_id, parent
    )
