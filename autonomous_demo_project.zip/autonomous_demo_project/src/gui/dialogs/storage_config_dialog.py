"""
Storage configuration dialog for first-time setup.

Allows users to configure the storage root directory on first launch.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QFileDialog, QFrame, QMessageBox
)
from PyQt6.QtCore import Qt
import os


class StorageConfigDialog(QDialog):
    """
    Storage configuration dialog for first-time setup.

    Prompts users to select a storage root directory and shows
    derived paths for works, templates, and logs.
    """

    def __init__(self, settings, parent=None):
        """
        Initialize storage configuration dialog.

        Args:
            settings: Application settings instance
            parent: Parent widget
        """
        super().__init__(parent)
        self.settings = settings
        self.setObjectName("storageConfigDialog")
        self._setup_ui()
        self._setup_connections()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        self.setWindowTitle("AI Writer - 存储路径配置")
        self.setMinimumSize(650, 500)
        self.setModal(True)
        self.setWindowModality(Qt.WindowModality.ApplicationModal)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Title
        title_label = QLabel("欢迎使用 AI Writer")
        title_label.setObjectName("dialogTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Subtitle
        subtitle_label = QLabel("首次使用，请先配置存储路径\n所有作品、模板、日志和参考作品文件将存储在此目录下")
        subtitle_label.setObjectName("dialogSubtitle")
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle_label.setWordWrap(True)
        layout.addWidget(subtitle_label)

        # Storage configuration form (scrollable)
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        scroll_area.setObjectName("configFormScrollArea")

        form_container = QFrame()
        form_container.setObjectName("configForm")
        form_layout = QVBoxLayout(form_container)
        form_layout.setSpacing(15)

        # Storage root configuration
        self._setup_storage_root_section(form_layout)

        # Derived paths (read-only)
        self._setup_derived_paths_section(form_layout)

        form_layout.addStretch()
        scroll_area.setWidget(form_container)
        layout.addWidget(scroll_area)

        # Action buttons
        self._setup_action_buttons(layout)

    def _setup_storage_root_section(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up storage root configuration section.

        Args:
            parent_layout: Layout to add section to
        """
        section_title = QLabel("存储根目录")
        section_title.setObjectName("sectionTitle")
        parent_layout.addWidget(section_title)

        # Storage root row
        root_layout = QHBoxLayout()
        root_layout.setSpacing(10)

        self.storage_root_input = QLineEdit()
        self.storage_root_input.setObjectName("pathInput")
        self.storage_root_input.setPlaceholderText("选择存储根目录...")
        root_layout.addWidget(self.storage_root_input)

        self.btn_browse_root = QPushButton("浏览...")
        self.btn_browse_root.setObjectName("browseBtn")
        self.btn_browse_root.setFixedWidth(80)
        root_layout.addWidget(self.btn_browse_root)

        parent_layout.addLayout(root_layout)

    def _setup_derived_paths_section(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up derived paths display section.

        Args:
            parent_layout: Layout to add section to
        """
        section_title = QLabel("将创建以下目录")
        section_title.setObjectName("sectionTitle")
        parent_layout.addWidget(section_title)

        # Works directory
        works_layout = QHBoxLayout()
        works_layout.setSpacing(10)

        works_label = QLabel("作品库:")
        works_label.setFixedWidth(80)
        works_layout.addWidget(works_label)

        self.works_dir_input = QLineEdit()
        self.works_dir_input.setObjectName("readonlyPathInput")
        self.works_dir_input.setReadOnly(True)
        works_layout.addWidget(self.works_dir_input)

        parent_layout.addLayout(works_layout)

        # Templates directory
        templates_layout = QHBoxLayout()
        templates_layout.setSpacing(10)

        templates_label = QLabel("模板库:")
        templates_label.setFixedWidth(80)
        templates_layout.addWidget(templates_label)

        self.templates_dir_input = QLineEdit()
        self.templates_dir_input.setObjectName("readonlyPathInput")
        self.templates_dir_input.setReadOnly(True)
        templates_layout.addWidget(self.templates_dir_input)

        parent_layout.addLayout(templates_layout)

        # Logs directory
        logs_layout = QHBoxLayout()
        logs_layout.setSpacing(10)

        logs_label = QLabel("日志库:")
        logs_label.setFixedWidth(80)
        logs_layout.addWidget(logs_label)

        self.logs_dir_input = QLineEdit()
        self.logs_dir_input.setObjectName("readonlyPathInput")
        self.logs_dir_input.setReadOnly(True)
        logs_layout.addWidget(self.logs_dir_input)

        parent_layout.addLayout(logs_layout)

        # References directory
        references_layout = QHBoxLayout()
        references_layout.setSpacing(10)

        references_label = QLabel("参考作品:")
        references_label.setFixedWidth(80)
        references_layout.addWidget(references_label)

        self.references_dir_input = QLineEdit()
        self.references_dir_input.setObjectName("readonlyPathInput")
        self.references_dir_input.setReadOnly(True)
        references_layout.addWidget(self.references_dir_input)

        parent_layout.addLayout(references_layout)

    def _setup_action_buttons(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up action buttons section.

        Args:
            parent_layout: Layout to add section to
        """
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)

        self.btn_close = QPushButton("关闭")
        self.btn_close.setObjectName("closeBtn")
        self.btn_close.setFixedWidth(100)
        button_layout.addWidget(self.btn_close)

        button_layout.addStretch()

        self.btn_save = QPushButton("保存并继续")
        self.btn_save.setObjectName("saveBtn")
        self.btn_save.setFixedWidth(150)
        self.btn_save.setEnabled(False)  # Disabled until path is selected
        button_layout.addWidget(self.btn_save)

        parent_layout.addLayout(button_layout)

    def _setup_connections(self) -> None:
        """Connect signals and slots."""
        self.btn_browse_root.clicked.connect(self._browse_storage_root)
        self.btn_save.clicked.connect(self._save_and_continue)
        self.btn_close.clicked.connect(self.reject)
        self.storage_root_input.textChanged.connect(self._on_path_changed)

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            #storageConfigDialog {
                background-color: #f5f5f5;
            }

            #dialogTitle {
                font-size: 24px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 5px;
            }

            #dialogSubtitle {
                font-size: 14px;
                color: #7f8c8d;
                margin-bottom: 20px;
            }

            #configFormScrollArea {
                border: none;
                background-color: transparent;
            }

            #sectionTitle {
                font-size: 16px;
                font-weight: bold;
                color: #34495e;
                margin-top: 10px;
                padding-bottom: 5px;
                border-bottom: 2px solid #3498db;
            }

            #configForm {
                background-color: #ffffff;
                border-radius: 10px;
                padding: 20px;
            }

            #pathInput, #readonlyPathInput {
                padding: 10px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                font-size: 14px;
            }

            #readonlyPathInput {
                background-color: #ecf0f1;
                color: #7f8c8d;
            }

            #browseBtn {
                padding: 10px 15px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                background-color: #ffffff;
                font-size: 13px;
            }

            #browseBtn:hover {
                background-color: #ecf0f1;
            }

            #browseBtn:focus {
                border-color: #3498db;
                outline: 2px solid #f1c40f;
                outline-offset: -2px;
            }

            #closeBtn {
                background-color: #95a5a6;
                color: white;
                border: none;
                padding: 12px 20px;
                border-radius: 5px;
                font-size: 14px;
            }

            #closeBtn:hover {
                background-color: #7f8c8d;
            }

            #closeBtn:focus {
                outline: 2px solid #f1c40f;
                outline-offset: -2px;
            }

            #saveBtn {
                background-color: #145a32;  /* Darker green for WCAG AA compliance */
                color: white;
                border: none;
                padding: 12px 25px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
            }

            #saveBtn:hover {
                background-color: #0f4224;  /* Even darker on hover */
            }

            #saveBtn:focus {
                outline: 2px solid #f1c40f;
                outline-offset: -2px;
            }

            #saveBtn:disabled {
                background-color: #95a5a6;
                color: #bdc3c7;
            }

            #pathInput:focus, #readonlyPathInput:focus {
                border-color: #3498db;
                outline: 2px solid #f1c40f;
                outline-offset: -2px;
            }
        """)

    def _browse_storage_root(self) -> None:
        """Open directory browser for storage root selection."""
        current = self.storage_root_input.text()
        directory = QFileDialog.getExistingDirectory(
            self,
            "选择存储根目录",
            current if current and os.path.exists(current) else ""
        )
        if directory:
            self.storage_root_input.setText(directory)
            self._update_derived_paths(directory)

    def _on_path_changed(self, text: str) -> None:
        """
        Handle path input change.

        Args:
            text: Current path text
        """
        # Enable save button only if path is valid
        is_valid = text and os.path.isdir(text) and os.access(text, os.W_OK)
        self.btn_save.setEnabled(is_valid)

    def _update_derived_paths(self, root: str) -> None:
        """
        Update derived paths based on new root.

        Args:
            root: New storage root path
        """
        self.works_dir_input.setText(os.path.join(root, "works"))
        self.templates_dir_input.setText(os.path.join(root, "templates"))
        self.logs_dir_input.setText(os.path.join(root, "logs"))
        self.references_dir_input.setText(os.path.join(root, "references"))

    def _save_and_continue(self) -> None:
        """Save settings and close dialog."""
        root = self.storage_root_input.text().strip()

        if not root:
            QMessageBox.warning(
                self,
                "路径无效",
                "请指定存储根目录"
            )
            return

        # Update settings
        self.settings.set_storage_root(root)

        # Save to file
        if self.settings.save():
            self.accept()
        else:
            QMessageBox.critical(
                self,
                "保存失败",
                "保存配置失败，请检查目录权限"
            )

    def get_selected_path(self) -> str:
        """Get the selected storage root path."""
        return self.storage_root_input.text()

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()

        # Escape key - close dialog without saving
        if key == Qt.Key.Key_Escape:
            self.reject()
            return

        # Enter key - activate save button if enabled
        if key == Qt.Key.Key_Return or key == Qt.Key.Key_Enter:
            focused_widget = self.focusWidget()
            if isinstance(focused_widget, QPushButton):
                focused_widget.click()
                return
            elif self.btn_save.isEnabled():
                self._save_and_continue()
                return

        # Let the base class handle other keys
        super().keyPressEvent(event)
