"""
Volume Range Dialog for AI Writer application.

Allows users to select the range of volumes to generate during creation.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QFrame, QMessageBox, QSpinBox
)
from PyQt6.QtCore import Qt, pyqtSignal
from typing import Tuple, Optional


class VolumeRangeDialog(QDialog):
    """
    Volume range selection dialog.

    Prompts users to select start and end volume numbers for creation.

    Signals:
        range_confirmed: Emitted when user confirms the volume range
    """

    range_confirmed = pyqtSignal(int, int)  # start_volume, end_volume

    def __init__(self, parent=None, max_volumes: int = 100):
        """
        Initialize volume range dialog.

        Args:
            parent: Parent widget
            max_volumes: Maximum allowed volumes (default: 100)
        """
        super().__init__(parent)
        self.max_volumes = max_volumes
        self.setObjectName("volumeRangeDialog")
        self._setup_ui()
        self._setup_connections()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        self.setWindowTitle("选择卷数范围")
        self.setModal(True)
        self.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.setMinimumSize(400, 250)
        # Do NOT set fixed size - let dialog size adapt to content naturally

        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Title
        title_label = QLabel("选择创作卷数范围")
        title_label.setObjectName("dialogTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Subtitle
        subtitle_label = QLabel("请输入要生成的起始卷号和结束卷号")
        subtitle_label.setObjectName("dialogSubtitle")
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle_label.setWordWrap(True)
        layout.addWidget(subtitle_label)

        # Form container
        form_container = QFrame()
        form_container.setObjectName("formContainer")
        form_layout = QVBoxLayout(form_container)
        form_layout.setSpacing(15)

        # Start volume input
        self._setup_start_volume_section(form_layout)

        # End volume input
        self._setup_end_volume_section(form_layout)

        # Error label
        self._setup_error_label(form_layout)

        form_layout.addStretch()
        layout.addWidget(form_container)

        # Action buttons
        self._setup_action_buttons(layout)

    def _setup_start_volume_section(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up start volume input section.

        Args:
            parent_layout: Layout to add section to
        """
        section_layout = QHBoxLayout()
        section_layout.setSpacing(15)

        start_label = QLabel("起始卷号:")
        start_label.setObjectName("inputLabel")
        start_label.setFixedWidth(80)
        section_layout.addWidget(start_label)

        self.start_volume_input = QSpinBox()
        self.start_volume_input.setObjectName("volumeInput")
        self.start_volume_input.setRange(1, self.max_volumes)
        self.start_volume_input.setValue(1)
        self.start_volume_input.setMinimumHeight(40)
        # Set fixed size policy to prevent layout recalculation
        from PyQt6.QtWidgets import QSizePolicy
        self.start_volume_input.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        section_layout.addWidget(self.start_volume_input)

        parent_layout.addLayout(section_layout)

    def _setup_end_volume_section(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up end volume input section.

        Args:
            parent_layout: Layout to add section to
        """
        section_layout = QHBoxLayout()
        section_layout.setSpacing(15)

        end_label = QLabel("结束卷号:")
        end_label.setObjectName("inputLabel")
        end_label.setFixedWidth(80)
        section_layout.addWidget(end_label)

        self.end_volume_input = QSpinBox()
        self.end_volume_input.setObjectName("volumeInput")
        self.end_volume_input.setRange(1, self.max_volumes)
        self.end_volume_input.setValue(3)
        self.end_volume_input.setMinimumHeight(40)
        # Set fixed size policy to prevent layout recalculation
        from PyQt6.QtWidgets import QSizePolicy
        self.end_volume_input.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        section_layout.addWidget(self.end_volume_input)

        parent_layout.addLayout(section_layout)

    def _setup_error_label(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up error label for validation messages.

        Args:
            parent_layout: Layout to add section to
        """
        self.error_label = QLabel("")
        self.error_label.setObjectName("errorLabel")
        self.error_label.setWordWrap(True)
        self.error_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        parent_layout.addWidget(self.error_label)

    def _setup_action_buttons(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up action buttons section.

        Args:
            parent_layout: Layout to add section to
        """
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)
        button_layout.addStretch()

        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.setObjectName("cancelBtn")
        self.btn_cancel.setFixedWidth(100)
        self.btn_cancel.setAccessibleName("取消")
        self.btn_cancel.setAccessibleDescription("取消创作流程，关闭对话框")
        button_layout.addWidget(self.btn_cancel)

        self.btn_confirm = QPushButton("确认开始")
        self.btn_confirm.setObjectName("confirmBtn")
        self.btn_confirm.setFixedWidth(100)
        self.btn_confirm.setAccessibleName("确认开始")
        self.btn_confirm.setAccessibleDescription("确认卷数范围并开始创作")
        button_layout.addWidget(self.btn_confirm)

        parent_layout.addLayout(button_layout)

    def _setup_connections(self) -> None:
        """Connect signals and slots."""
        self.btn_confirm.clicked.connect(self._on_confirm)
        self.btn_cancel.clicked.connect(self.reject)
        self.start_volume_input.valueChanged.connect(self._on_value_changed)
        self.end_volume_input.valueChanged.connect(self._on_value_changed)

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            #volumeRangeDialog {
                background-color: #f5f5f5;
            }

            #dialogTitle {
                font-size: 20px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 5px;
            }

            #dialogSubtitle {
                font-size: 13px;
                color: #7f8c8d;
                margin-bottom: 15px;
            }

            #formContainer {
                background-color: #ffffff;
                border-radius: 10px;
                padding: 20px;
            }

            #inputLabel {
                font-size: 14px;
                font-weight: bold;
                color: #34495e;
            }

            #volumeInput {
                padding: 10px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                font-size: 14px;
            }

            #volumeInput:focus {
                border-color: #3498db;
            }

            #errorLabel {
                font-size: 13px;
                color: #e74c3c;
                margin-top: 10px;
            }

            #cancelBtn {
                padding: 12px 20px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                background-color: #ffffff;
                font-size: 14px;
            }

            #cancelBtn:hover {
                background-color: #ecf0f1;
            }

            #confirmBtn {
                background-color: #3498db;
                color: white;
                border: none;
                padding: 12px 20px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
            }

            #confirmBtn:hover {
                background-color: #2980b9;
            }

            #confirmBtn:disabled {
                background-color: #95a5a6;
            }
        """)

    def _on_value_changed(self) -> None:
        """Handle volume input value changes."""
        self._clear_error()

    def _clear_error(self) -> None:
        """Clear error message."""
        self.error_label.setText("")

    def _show_error(self, message: str) -> None:
        """
        Show error message.

        Args:
            message: Error message to display
        """
        self.error_label.setText(message)

    def _validate(self) -> bool:
        """
        Validate input values.

        Returns:
            True if valid, False otherwise
        """
        start = self.start_volume_input.value()
        end = self.end_volume_input.value()

        if start > end:
            self._show_error("结束卷号必须大于或等于起始卷号")
            return False

        if start < 1:
            self._show_error("起始卷号必须大于等于 1")
            return False

        if end > self.max_volumes:
            self._show_error(f"结束卷号不能超过 {self.max_volumes}")
            return False

        return True

    def _on_confirm(self) -> None:
        """Handle confirm button click."""
        if self._validate():
            start = self.start_volume_input.value()
            end = self.end_volume_input.value()
            self.range_confirmed.emit(start, end)
            self.accept()

    def get_volume_range(self) -> Tuple[int, int]:
        """
        Get the selected volume range.

        Returns:
            Tuple of (start_volume, end_volume)
        """
        return (
            self.start_volume_input.value(),
            self.end_volume_input.value()
        )

    def set_volume_range(self, start: int, end: int) -> None:
        """
        Set the volume range programmatically.

        Args:
            start: Start volume number
            end: End volume number
        """
        self.start_volume_input.setValue(start)
        self.end_volume_input.setValue(end)

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()

        # Escape key - close dialog without saving
        if key == Qt.Key.Key_Escape:
            self.reject()
            return

        # Let the base class handle other keys
        super().keyPressEvent(event)
