"""
Import Work Dialog for AI Writer application.

Provides options to import works from ZIP files or existing directories.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QRadioButton, QButtonGroup,
    QFileDialog, QLineEdit, QFrame
)
from PyQt6.QtCore import Qt, pyqtSignal
from typing import Optional
import os


class ImportWorkDialog(QDialog):
    """
    Dialog for importing works from external sources.

    Supports two import methods:
    - Import from ZIP file (exported work package)
    - Import from directory (existing work folder)

    Signals:
        work_imported: Emitted when a work is successfully imported
    """

    # Signal emitted when work is imported (work data)
    work_imported = pyqtSignal(dict)

    def __init__(self, settings, parent=None):
        """
        Initialize the import work dialog.

        Args:
            settings: Application settings instance
            parent: Parent widget
        """
        super().__init__(parent)
        self.settings = settings
        self.setObjectName("importWorkDialog")
        self._setup_ui()
        self._setup_connections()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        self.setWindowTitle("导入作品")
        self.setMinimumSize(500, 400)
        self.setModal(True)
        self.setWindowModality(Qt.WindowModality.ApplicationModal)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(25, 25, 25, 25)
        layout.setSpacing(20)

        # Title
        title_label = QLabel("导入作品")
        title_label.setObjectName("dialogTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Subtitle
        subtitle_label = QLabel("请选择导入方式")
        subtitle_label.setObjectName("dialogSubtitle")
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle_label)

        # Import method selection
        self._setup_import_method_selection(layout)

        # File/Directory path section
        self._setup_path_section(layout)

        # Action buttons
        self._setup_action_buttons(layout)

    def _setup_import_method_selection(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up import method selection radio buttons.

        Args:
            parent_layout: Layout to add section to
        """
        method_group = QGroupBox("导入方式")
        method_group.setObjectName("methodGroup")
        method_layout = QVBoxLayout(method_group)
        method_layout.setSpacing(15)

        # Radio button group
        self.method_buttons = QButtonGroup(self)

        # ZIP file import option
        self.zip_radio = QRadioButton("从 ZIP 文件导入")
        self.zip_radio.setObjectName("zipRadio")
        self.zip_radio.setChecked(True)
        self.zip_radio.setToolTip("从之前导出的 ZIP 作品包导入")
        method_layout.addWidget(self.zip_radio)
        self.method_buttons.addButton(self.zip_radio, 0)

        zip_desc = QLabel("适用于：从之前备份的 ZIP 文件恢复作品")
        zip_desc.setObjectName("methodDescription")
        zip_desc.setWordWrap(True)
        method_layout.addWidget(zip_desc)

        # Directory import option
        self.dir_radio = QRadioButton("从作品目录导入")
        self.dir_radio.setObjectName("dirRadio")
        self.dir_radio.setToolTip("从已有的作品文件夹导入")
        method_layout.addWidget(self.dir_radio)
        self.method_buttons.addButton(self.dir_radio, 1)

        dir_desc = QLabel("适用于：已有作品文件夹结构的情况")
        dir_desc.setObjectName("methodDescription")
        dir_desc.setWordWrap(True)
        method_layout.addWidget(dir_desc)

        parent_layout.addWidget(method_group)

    def _setup_path_section(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up file/directory path input section.

        Args:
            parent_layout: Layout to add section to
        """
        path_group = QGroupBox("文件路径")
        path_group.setObjectName("pathGroup")
        path_layout = QVBoxLayout(path_group)

        # Path input field
        path_input_layout = QHBoxLayout()

        self.path_input = QLineEdit()
        self.path_input.setObjectName("pathInput")
        self.path_input.setPlaceholderText("选择 ZIP 文件或作品目录...")
        self.path_input.setReadOnly(True)
        path_input_layout.addWidget(self.path_input)

        # Browse button
        self.browse_btn = QPushButton("浏览...")
        self.browse_btn.setObjectName("browseBtn")
        self.browse_btn.setFixedWidth(80)
        path_input_layout.addWidget(self.browse_btn)

        path_layout.addLayout(path_input_layout)

        # Help text
        help_label = QLabel("提示：点击浏览按钮选择要导入的文件或目录")
        help_label.setObjectName("helpLabel")
        help_label.setWordWrap(True)
        path_layout.addWidget(help_label)

        parent_layout.addWidget(path_group)

    def _setup_action_buttons(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up action buttons section.

        Args:
            parent_layout: Layout to add section to
        """
        # Error message label (hidden by default)
        self.error_label = QLabel("")
        self.error_label.setObjectName("errorLabel")
        self.error_label.setWordWrap(True)
        self.error_label.setVisible(False)
        parent_layout.addWidget(self.error_label)

        button_layout = QHBoxLayout()
        button_layout.addStretch()

        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.setObjectName("cancelBtn")
        self.btn_cancel.setFixedWidth(100)
        button_layout.addWidget(self.btn_cancel)

        self.btn_import = QPushButton("导入")
        self.btn_import.setObjectName("importBtn")
        self.btn_import.setFixedWidth(100)
        self.btn_import.setEnabled(False)  # Disabled until path selected
        button_layout.addWidget(self.btn_import)

        parent_layout.addLayout(button_layout)

    def _setup_connections(self) -> None:
        """Connect signals and slots."""
        self.zip_radio.toggled.connect(self._on_method_changed)
        self.browse_btn.clicked.connect(self._on_browse_clicked)
        self.btn_cancel.clicked.connect(self.reject)
        self.btn_import.clicked.connect(self._validate_and_import)
        self.path_input.textChanged.connect(self._on_path_changed)

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            #importWorkDialog {
                background-color: #f5f5f5;
            }

            #dialogTitle {
                font-size: 22px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 5px;
            }

            #dialogSubtitle {
                font-size: 14px;
                color: #7f8c8d;
                margin-bottom: 15px;
            }

            QGroupBox {
                font-weight: bold;
                font-size: 14px;
                color: #2c3e50;
                border: 1px solid #bdc3c7;
                border-radius: 8px;
                margin-top: 12px;
                padding-top: 10px;
                background-color: #ffffff;
            }

            QGroupBox::title {
                subcontrol-origin: margin;
                left: 15px;
                padding: 0 8px;
                color: #34495e;
            }

            QRadioButton {
                font-size: 14px;
                color: #2c3e50;
                spacing: 10px;
                padding: 8px;
                border: 1px solid transparent;
                border-radius: 4px;
                background-color: transparent;
                margin: 4px 0;
            }

            QRadioButton:hover {
                background-color: #f5f5f5;
            }

            QRadioButton:checked {
                background-color: #e3f2fd;
                color: #1976d2;
            }

            QRadioButton::indicator {
                width: 18px;
                height: 18px;
                border-radius: 9px;
                border: 2px solid #bdc3c7;
                background-color: #ffffff;
            }

            QRadioButton::indicator:checked {
                background-color: #3498db;
                border-color: #3498db;
            }

            #methodDescription {
                font-size: 12px;
                color: #7f8c8d;
                margin-left: 26px;
            }

            #pathInput {
                padding: 10px;
                border: 1px solid #bdc3c7;
                border-radius: 5px;
                font-size: 14px;
                background-color: #ffffff;
            }

            #pathInput:focus {
                border-color: #3498db;
            }

            #browseBtn {
                background-color: #3498db;
                color: white;
                border: none;
                padding: 10px 15px;
                border-radius: 5px;
                font-size: 14px;
            }

            #browseBtn:hover {
                background-color: #2980b9;
            }

            #cancelBtn {
                background-color: #95a5a6;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
            }

            #cancelBtn:hover {
                background-color: #7f8c8d;
            }

            #importBtn {
                background-color: #27ae60;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                font-size: 14px;
                font-weight: bold;
            }

            #importBtn:hover {
                background-color: #229954;
            }

            #importBtn:disabled {
                background-color: #bdc3c7;
                color: #7f8c8d;
            }

            #errorLabel {
                color: #e74c3c;
                font-size: 13px;
                font-weight: bold;
                background-color: #fdeaea;
                border: 1px solid #e74c3c;
                border-radius: 5px;
                padding: 10px 15px;
                margin-bottom: 10px;
            }

            #helpLabel {
                font-size: 12px;
                color: #95a5a6;
                margin-top: 8px;
            }
        """)

    def _on_method_changed(self, checked: bool) -> None:
        """
        Handle import method selection change.

        Args:
            checked: Whether the radio button is checked
        """
        # Clear path when method changes
        self.path_input.clear()
        self._update_placeholder()

    def _update_placeholder(self) -> None:
        """Update placeholder text based on selected method."""
        if self.zip_radio.isChecked():
            self.path_input.setPlaceholderText("选择 ZIP 文件...")
        else:
            self.path_input.setPlaceholderText("选择作品目录...")

    def _on_browse_clicked(self) -> None:
        """Handle browse button click."""
        if self.zip_radio.isChecked():
            # ZIP file selection
            file_path, _ = QFileDialog.getOpenFileName(
                self,
                "选择 ZIP 文件",
                "",
                "ZIP 文件 (*.zip);;所有文件 (*.*)"
            )
            if file_path:
                self.path_input.setText(file_path)
        else:
            # Directory selection
            dir_path = QFileDialog.getExistingDirectory(
                self,
                "选择作品目录",
                ""
            )
            if dir_path:
                self.path_input.setText(dir_path)

    def _on_path_changed(self, path: str) -> None:
        """
        Handle path input change.

        Args:
            path: Current path value
        """
        # Enable import button when path is provided
        self.btn_import.setEnabled(bool(path.strip()))

    def _validate_and_import(self) -> None:
        """Validate inputs and import work."""
        # Hide any previous error message
        self.error_label.setVisible(False)

        # Get selected path
        path = self.path_input.text().strip()
        if not path:
            self._show_error("请选择要导入的文件或目录")
            return

        # Validate path exists
        if not os.path.exists(path):
            self._show_error(f"指定的路径不存在：{path}")
            return

        # Validate based on selected method
        if self.zip_radio.isChecked():
            # ZIP file validation
            if not path.lower().endswith('.zip'):
                self._show_error("请选择 ZIP 文件")
                return
            import_method = "zip"
        else:
            # Directory validation
            if not os.path.isdir(path):
                self._show_error("请选择有效的目录")
                return
            import_method = "directory"

        # Emit import signal with work data
        work_data = {
            "import_path": path,
            "import_method": import_method
        }

        self.work_imported.emit(work_data)
        self.accept()

    def _show_error(self, message: str) -> None:
        """
        Display an error message to the user.

        Args:
            message: Error message to display
        """
        self.error_label.setText(message)
        self.error_label.setVisible(True)

    def get_import_data(self) -> dict:
        """
        Get the collected import data.

        Returns:
            Dictionary containing import parameters
        """
        return {
            "path": self.path_input.text().strip(),
            "method": "zip" if self.zip_radio.isChecked() else "directory"
        }

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()

        # Escape key - close dialog without saving
        if key == Qt.Key.Key_Escape:
            self.reject()
            return

        # Let the base class handle other keys
        super().keyPressEvent(event)


class QGroupBox(QFrame):
    """GroupBox widget for organizing form sections."""

    def __init__(self, title: str = "", parent=None):
        """
        Initialize group box.

        Args:
            title: Group box title
            parent: Parent widget
        """
        super().__init__(parent)
        self.title = title
        self.setLayout(QVBoxLayout())
