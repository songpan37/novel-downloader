"""
Multi-Title Experiment Dialog for AI Writer application.

Allows users to configure A/B testing experiments for book titles
on the 番茄 platform.
"""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QSpinBox, QComboBox,
    QCheckBox, QGroupBox, QFormLayout, QRadioButton,
    QButtonGroup
)
from PyQt6.QtCore import Qt, pyqtSignal
from typing import Optional, List, Dict


class MultiTitleExperimentDialog(QDialog):
    """
    Dialog for configuring multi-title A/B testing experiments.

    Allows users to set up experiments to test different book titles
    on the 番茄 platform to determine which performs best.

    Signals:
        experiment_started: Emitted when user starts the experiment
            (experiment_config: dict)
    """

    experiment_started = pyqtSignal(dict)  # experiment_config

    def __init__(
        self,
        parent=None,
        current_title: str = "",
        work_category: str = "",
        generated_titles: Optional[List[str]] = None
    ):
        """
        Initialize multi-title experiment dialog.

        Args:
            parent: Parent widget
            current_title: Current work title (if any)
            work_category: Work category for context
            generated_titles: List of titles to test (optional)
        """
        super().__init__(parent)
        self.current_title = current_title
        self.work_category = work_category
        self._generated_titles = generated_titles or []
        self._experiment_config: Dict = {}
        self.setObjectName("multiTitleExperimentDialog")
        self._setup_ui()
        self._setup_connections()
        self._apply_styles()

    def _setup_ui(self) -> None:
        """Set up the UI components."""
        self.setWindowTitle("多书名实验功能 - 番茄平台")
        self.setModal(True)
        self.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.setMinimumSize(600, 550)
        self.setFixedSize(600, 550)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # Title
        title_label = QLabel("多书名 A/B 测试实验")
        title_label.setObjectName("dialogTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        # Subtitle
        subtitle_label = QLabel(
            "通过 A/B 测试，让不同读者看到不同书名，找出最优书名方案"
        )
        subtitle_label.setObjectName("dialogSubtitle")
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle_label.setWordWrap(True)
        layout.addWidget(subtitle_label)

        # Titles selection group
        titles_group = QGroupBox("实验书名")
        titles_group.setObjectName("titlesGroup")
        titles_layout = QVBoxLayout(titles_group)

        # Show available titles
        if self._generated_titles:
            titles_info = QLabel(f"已选择 {len(self._generated_titles)} 个书名参与实验:")
            titles_info.setObjectName("titlesInfo")
            titles_layout.addWidget(titles_info)

            for i, title in enumerate(self._generated_titles[:5]):
                title_item = QLabel(f"  {i + 1}. {title}")
                title_item.setObjectName("titleItem")
                title_item.setWordWrap(True)
                titles_layout.addWidget(title_item)

            if len(self._generated_titles) > 5:
                more_label = QLabel(f"  ... 还有 {len(self._generated_titles) - 5} 个书名")
                more_label.setObjectName("moreLabel")
                titles_layout.addWidget(more_label)
        else:
            no_titles_label = QLabel(
                '暂无书名，请先使用"一键生成多书名"功能生成书名'
            )
            no_titles_label.setObjectName("noTitlesLabel")
            titles_layout.addWidget(no_titles_label)

        layout.addWidget(titles_group)

        # Experiment configuration group
        config_group = QGroupBox("实验配置")
        config_group.setObjectName("configGroup")
        config_layout = QFormLayout(config_group)

        # Traffic split ratio
        self.traffic_split_combo = QComboBox()
        self.traffic_split_combo.setObjectName("trafficSplitCombo")
        self.traffic_split_combo.addItems([
            "50% / 50% (平均分配)",
            "70% / 30% (偏向主标题)",
            "30% / 70% (偏向新标题)",
            "25% / 25% / 25% / 25% (四组均分)",
        ])
        config_layout.addRow("流量分配:", self.traffic_split_combo)

        # Experiment duration
        self.duration_spin = QSpinBox()
        self.duration_spin.setObjectName("durationSpin")
        self.duration_spin.setMinimum(1)
        self.duration_spin.setMaximum(90)
        self.duration_spin.setValue(7)
        self.duration_spin.setSuffix(" 天")
        self.duration_spin.setMinimumWidth(150)
        config_layout.addRow("实验时长:", self.duration_spin)

        # Minimum reads for statistical significance
        self.min_reads_spin = QSpinBox()
        self.min_reads_spin.setObjectName("minReadsSpin")
        self.min_reads_spin.setMinimum(100)
        self.min_reads_spin.setMaximum(100000)
        self.min_reads_spin.setValue(1000)
        self.min_reads_spin.setSuffix(" 次阅读")
        self.min_reads_spin.setMinimumWidth(150)
        config_layout.addRow("最小样本量:", self.min_reads_spin)

        layout.addWidget(config_group)

        # Success criteria group
        criteria_group = QGroupBox("成功标准")
        criteria_group.setObjectName("criteriaGroup")
        criteria_layout = QVBoxLayout(criteria_group)

        # Create button group for metric selection
        self.metric_group = QButtonGroup()
        self.metric_group.setObjectName("metricGroup")

        # Click-through rate option
        self.ctr_radio = QRadioButton("点击率 (CTR) - 推荐")
        self.ctr_radio.setObjectName("ctrRadio")
        self.ctr_radio.setChecked(True)
        criteria_layout.addWidget(self.ctr_radio)
        self.metric_group.addButton(self.ctr_radio)

        # Read completion rate option
        self.completion_radio = QRadioButton("阅读完成率")
        self.completion_radio.setObjectName("completionRadio")
        criteria_layout.addWidget(self.completion_radio)
        self.metric_group.addButton(self.completion_radio)

        # Collection rate option
        self.collection_radio = QRadioButton("收藏率")
        self.collection_radio.setObjectName("collectionRadio")
        criteria_layout.addWidget(self.collection_radio)
        self.metric_group.addButton(self.collection_radio)

        # Custom metric option
        self.custom_radio = QRadioButton("自定义指标")
        self.custom_radio.setObjectName("customRadio")
        criteria_layout.addWidget(self.custom_radio)
        self.metric_group.addButton(self.custom_radio)

        # Add description
        criteria_desc = QLabel(
            "番茄平台将根据选择的指标自动统计各书名的表现，"
            "实验结束后可查看详细的分析报告"
        )
        criteria_desc.setObjectName("criteriaDesc")
        criteria_desc.setWordWrap(True)
        criteria_layout.addWidget(criteria_desc)

        layout.addWidget(criteria_group)

        # Auto-apply option
        self.auto_apply_check = QCheckBox(
            "实验结束后自动应用表现最佳的书名"
        )
        self.auto_apply_check.setObjectName("autoApplyCheck")
        self.auto_apply_check.setChecked(True)
        layout.addWidget(self.auto_apply_check)

        # Action buttons
        self._setup_action_buttons(layout)

        # Info label
        info_label = QLabel(
            "注意: 实验期间，不同读者将看到不同的书名，系统会记录各书名的表现数据"
        )
        info_label.setObjectName("infoLabel")
        info_label.setWordWrap(True)
        info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(info_label)

    def _setup_action_buttons(
        self,
        parent_layout: QVBoxLayout
    ) -> None:
        """
        Set up action buttons section.

        Args:
            parent_layout: Layout to add section to
        """
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)
        button_layout.addStretch()

        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.setObjectName("cancelBtn")
        self.btn_cancel.setFixedWidth(100)
        button_layout.addWidget(self.btn_cancel)

        self.btn_start = QPushButton("开始实验")
        self.btn_start.setObjectName("startBtn")
        self.btn_start.setFixedWidth(120)
        self.btn_start.setEnabled(len(self._generated_titles) >= 2)
        button_layout.addWidget(self.btn_start)

        parent_layout.addLayout(button_layout)

    def _setup_connections(self) -> None:
        """Connect signals and slots."""
        self.btn_start.clicked.connect(self._on_start_experiment)
        self.btn_cancel.clicked.connect(self.reject)

    def _apply_styles(self) -> None:
        """Apply styles to the dialog."""
        self.setStyleSheet("""
            #multiTitleExperimentDialog {
                background-color: #f5f5f5;
            }

            #dialogTitle {
                font-size: 20px;
                font-weight: bold;
                color: #2c3e50;
                margin-bottom: 5px;
            }

            #dialogSubtitle {
                font-size: 13px;
                color: #7f8c8d;
                margin-bottom: 15px;
            }

            QGroupBox {
                font-size: 14px;
                font-weight: bold;
                color: #2c3e50;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                margin-top: 12px;
                padding-top: 12px;
                background-color: #ffffff;
            }

            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 8px;
                color: #9b59b6;
            }

            QComboBox {
                padding: 8px 12px;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                background-color: #ffffff;
                font-size: 13px;
                min-width: 200px;
            }

            QComboBox:hover {
                border-color: #9b59b6;
            }

            QComboBox:focus {
                border-color: #9b59b6;
                outline: none;
            }

            QSpinBox {
                padding: 8px 12px;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                background-color: #ffffff;
                font-size: 13px;
            }

            QSpinBox:hover {
                border-color: #9b59b6;
            }

            QSpinBox:focus {
                border-color: #9b59b6;
                outline: none;
            }

            QRadioButton {
                spacing: 10px;
                font-size: 13px;
                color: #2c3e50;
                padding: 6px;
                border: 1px solid transparent;
                border-radius: 4px;
                background-color: transparent;
            }

            QRadioButton:hover {
                background-color: #f5f5f5;
            }

            QRadioButton:checked {
                color: #9b59b6;
                font-weight: bold;
            }

            #titlesInfo {
                font-size: 13px;
                color: #2c3e50;
                font-weight: bold;
                margin-bottom: 8px;
            }

            #titleItem {
                font-size: 13px;
                color: #2c3e50;
                padding-left: 10px;
            }

            #moreLabel {
                font-size: 13px;
                color: #7f8c8d;
                font-style: italic;
                padding-left: 10px;
            }

            #noTitlesLabel {
                font-size: 13px;
                color: #e74c3c;
                padding: 10px;
                background-color: #fce4e4;
                border-radius: 4px;
            }

            #criteriaDesc {
                font-size: 12px;
                color: #7f8c8d;
                margin-top: 10px;
                padding: 8px;
                background-color: #f9f9f9;
                border-radius: 4px;
            }

            #autoApplyCheck {
                font-size: 13px;
                color: #2c3e50;
                padding: 8px;
            }

            #infoLabel {
                font-size: 12px;
                color: #7f8c8d;
                margin-top: 10px;
                padding: 8px;
                background-color: #fff3cd;
                border-radius: 4px;
            }

            QPushButton {
                padding: 10px 16px;
                border: 1px solid #e0e0e0;
                border-radius: 5px;
                font-size: 14px;
            }

            #cancelBtn {
                background-color: #ffffff;
                color: #2c3e50;
            }

            #cancelBtn:hover {
                background-color: #ecf0f1;
            }

            #startBtn {
                background-color: #9b59b6;
                color: white;
                border: none;
                font-weight: bold;
            }

            #startBtn:hover {
                background-color: #8e44ad;
            }

            #startBtn:disabled {
                background-color: #bdc3c7;
            }
        """)

    def _on_start_experiment(self) -> None:
        """Handle start experiment button click."""
        # Build experiment configuration
        traffic_split_text = self.traffic_split_combo.currentText()

        # Parse traffic split
        if "50% / 50%" in traffic_split_text:
            traffic_split = "50/50"
        elif "70% / 30%" in traffic_split_text:
            traffic_split = "70/30"
        elif "30% / 70%" in traffic_split_text:
            traffic_split = "30/70"
        elif "25% / 25% / 25% / 25%" in traffic_split_text:
            traffic_split = "25/25/25/25"
        else:
            traffic_split = "50/50"

        # Determine success metric
        if self.ctr_radio.isChecked():
            success_metric = "ctr"
        elif self.completion_radio.isChecked():
            success_metric = "completion_rate"
        elif self.collection_radio.isChecked():
            success_metric = "collection_rate"
        else:
            success_metric = "custom"

        self._experiment_config = {
            "titles": self._generated_titles,
            "traffic_split": traffic_split,
            "duration_days": self.duration_spin.value(),
            "min_reads": self.min_reads_spin.value(),
            "success_metric": success_metric,
            "auto_apply_best": self.auto_apply_check.isChecked(),
            "work_category": self.work_category,
            "current_title": self.current_title
        }

        # Emit signal and close dialog
        self.experiment_started.emit(self._experiment_config)
        self.accept()

    def get_experiment_config(self) -> Dict:
        """
        Get the experiment configuration.

        Returns:
            Dictionary containing experiment configuration
        """
        return self._experiment_config

    def keyPressEvent(self, event) -> None:
        """
        Handle key press events for keyboard navigation.

        Args:
            event: Key press event
        """
        from PyQt6.QtCore import Qt

        key = event.key()

        # Escape key - close dialog without saving
        if key == Qt.Key.Key_Escape:
            self.reject()
            return

        # Let the base class handle other keys
        super().keyPressEvent(event)
