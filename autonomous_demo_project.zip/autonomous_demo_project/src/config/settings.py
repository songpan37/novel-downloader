"""
Settings management for AI Writer application.

Handles loading, saving, and accessing application configuration
stored in JSON format.
"""
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional
from dataclasses import dataclass, field, asdict

# Add src to path for logger import
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.logger import get_logger


# Default configuration values
DEFAULT_CATEGORIES = ["玄幻", "都市", "科幻", "武侠", "历史", "言情", "悬疑", "网游", "其他"]


# Get the project root directory (parent of src/config)
def _get_project_root() -> str:
    """Get the project root directory path."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # Go up two levels: src/config -> src -> project_root
    return os.path.dirname(os.path.dirname(current_dir))


@dataclass
class ApiProviderConfig:
    """Configuration for a specific API provider."""
    provider: str = ""  # openai, anthropic, deepseek, qwen, etc.
    api_key: str = ""
    base_url: str = ""
    model: str = ""


@dataclass
class BrowserProviderConfig:
    """Configuration for a specific browser automation provider."""
    provider: str = ""  # deepseek, doubao, etc.
    phone_number: str = ""
    password: str = ""  # Optional password for DeepSeek password login
    chrome_path: str = r"C:\Program Files\Google\Chrome\Application\chrome.exe"


@dataclass
class AiSettings:
    """AI service settings."""
    # Call mode: "api" or "browser"
    call_mode: str = "api"

    # API provider configurations
    api_provider: str = "qwen"  # openai, anthropic, deepseek, qwen
    api_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"
    api_key: str = ""
    api_model: str = "qwen-plus"

    # Browser provider configurations
    browser_provider: str = "deepseek"  # deepseek, doubao
    browser_phone: str = ""
    browser_password: str = ""  # Optional password for DeepSeek password login
    browser_chrome_path: str = r"C:\Program Files\Google\Chrome\Application\chrome.exe"


@dataclass
class Settings:
    """
    Application settings container.

    Stores all configuration for the AI Writer application,
    including storage paths, API settings, and UI preferences.

    Attributes:
        storage_root: Root directory for all application data
        works_dir: Directory for storing works (storage_root/works)
        templates_dir: Directory for templates (storage_root/templates)
        logs_dir: Directory for logs (storage_root/logs)
        ai_settings: AI service configuration
        theme: UI theme (light/dark)
        language: UI language
        is_configured: Whether storage has been configured
    """
    storage_root: str = ""
    works_dir: str = ""
    templates_dir: str = ""
    logs_dir: str = ""
    ai_settings: AiSettings = field(default_factory=AiSettings)
    theme: str = "light"
    language: str = "zh-CN"
    is_configured: bool = False

    # Deprecated fields - kept for backward compatibility
    api_key: str = ""
    api_base_url: str = ""
    api_model: str = ""
    default_model: str = ""

    def __post_init__(self):
        """Initialize paths after dataclass construction."""
        self._ensure_directories()
        # Handle backward compatibility: if api_model is empty but default_model is set
        if not self.api_model and self.default_model:
            self.api_model = self.default_model

    @property
    def config_path(self) -> str:
        """Get the full path to the config file (in project root)."""
        project_root = _get_project_root()
        return os.path.join(project_root, "config.json")

    def load(self, config_path: Optional[str] = None) -> bool:
        """
        Load settings from JSON file.

        Args:
            config_path: Optional custom path to config file.
                        Uses default if not provided.

        Returns:
            True if settings loaded successfully, False otherwise.
        """
        path = config_path or self.config_path

        if not os.path.exists(path):
            return False

        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Use from_dict to properly handle nested structures
            loaded_settings = self.from_dict(data)

            # Copy loaded attributes to self
            for key in ['storage_root', 'works_dir', 'templates_dir', 'logs_dir',
                        'ai_settings', 'theme', 'language', 'is_configured',
                        'api_key', 'api_base_url', 'api_model', 'default_model']:
                if hasattr(loaded_settings, key):
                    setattr(self, key, getattr(loaded_settings, key))

            # Ensure derived paths are set
            self._ensure_directories()

            # Copy reference works to user's references directory if empty
            self._copy_reference_works()

            return True

        except (json.JSONDecodeError, IOError) as e:
            logger = get_logger()
            if logger:
                logger.error(f"Failed to load config: {e}")
            return False

    def save(self, config_path: Optional[str] = None) -> bool:
        """
        Save settings to JSON file.

        Args:
            config_path: Optional custom path to config file.

        Returns:
            True if settings saved successfully, False otherwise.
        """
        path = config_path or self.config_path

        try:
            # Ensure directory exists
            os.makedirs(os.path.dirname(path) or '.', exist_ok=True)

            # Convert to dict and filter internal fields
            data = {k: v for k, v in asdict(self).items() if not k.startswith('_')}

            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)

            return True

        except IOError as e:
            logger = get_logger()
            if logger:
                logger.error(f"Failed to save config: {e}")
            return False

    def set_storage_root(self, path: str) -> None:
        """
        Set the storage root directory and update derived paths.

        Args:
            path: New storage root directory path
        """
        self.storage_root = os.path.normpath(path) if path else path
        self._ensure_directories()
        self.is_configured = bool(path and os.path.isdir(path))
        # Copy default templates to user's templates directory
        self._copy_default_templates()
        # Copy reference works to user's references directory
        self._copy_reference_works()

    def _copy_default_templates(self) -> None:
        """
        Copy default template files from project prompts directory to user's templates directory.

        This ensures users have the latest default templates when they configure storage.
        Also copies missing templates if templates directory already exists.
        """
        if not self.templates_dir or not os.path.exists(self.templates_dir):
            return

        # Get the project root directory
        project_root = _get_project_root()
        prompts_dir = os.path.join(project_root, "prompts")

        if not os.path.exists(prompts_dir):
            return

        # List of template files to copy
        template_files = [
            "00_book_reference.pmpt",
            "01_analyze_pattern.pmpt",
            "02_literary_style.pmpt",
            "03_book_title.pmpt",
            "04_story_summary.pmpt",
            "05_worldbuilding.pmpt",
            "06_characters.pmpt",
            "07_cover_image.pmpt",
            "08_volume_outline.pmpt",
            "09_volume_characters.pmpt",
            "10_chapter_outline.pmpt",
            "11_chapter_content.pmpt",
            "12_plot_summary.pmpt",
            "13_character_status.pmpt",
            "README.md",
        ]

        # Check if templates directory is empty (no .pmpt files)
        existing_pmpt_files = [
            f for f in os.listdir(self.templates_dir)
            if f.endswith('.pmpt') and os.path.isfile(os.path.join(self.templates_dir, f))
        ]
        is_empty = len(existing_pmpt_files) == 0

        copied_count = 0
        for template_file in template_files:
            src_path = os.path.join(prompts_dir, template_file)
            dst_path = os.path.join(self.templates_dir, template_file)

            # Copy if: templates is empty, OR source exists and destination doesn't exist
            should_copy = is_empty or (os.path.exists(src_path) and not os.path.exists(dst_path))
            if should_copy and os.path.exists(src_path):
                try:
                    with open(src_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    with open(dst_path, 'w', encoding='utf-8') as f:
                        f.write(content)
                    copied_count += 1
                except IOError:
                    pass

        # Log the copy operation
        logger = get_logger()
        if logger and copied_count > 0:
            logger.info(f"Copied {copied_count} default templates to {self.templates_dir}")

    def _copy_reference_works(self) -> None:
        """
        Copy reference works from project references directory to user's references directory.

        This ensures users have reference works available when they configure storage.
        Checks if user's references directory is empty and copies if so.
        """
        if not self.storage_root:
            return

        # Get the project root directory
        project_root = _get_project_root()
        project_references_dir = os.path.join(project_root, "references")

        if not os.path.exists(project_references_dir):
            return

        # User's references directory
        user_references_dir = os.path.join(self.storage_root, "references")

        # Create user references directory if it doesn't exist
        os.makedirs(user_references_dir, exist_ok=True)

        # Check if user's references directory is empty (no subdirectories)
        existing_subdirs = [
            d for d in os.listdir(user_references_dir)
            if os.path.isdir(os.path.join(user_references_dir, d))
        ]
        is_empty = len(existing_subdirs) == 0

        if not is_empty:
            # User has their own reference works, don't overwrite
            logger = get_logger()
            if logger:
                logger.info(f"User references directory not empty, skipping copy: {user_references_dir}")
            return

        # Copy all category directories from project to user
        copied_count = 0
        for category_dir in os.listdir(project_references_dir):
            src_category_dir = os.path.join(project_references_dir, category_dir)
            dst_category_dir = os.path.join(user_references_dir, category_dir)

            if os.path.isdir(src_category_dir) and not os.path.exists(dst_category_dir):
                try:
                    # Copy entire directory tree using shutil
                    import shutil
                    shutil.copytree(src_category_dir, dst_category_dir)
                    copied_count += 1
                except (IOError, OSError):
                    pass

        # Log the copy operation
        logger = get_logger()
        if logger and copied_count > 0:
            logger.info(f"Copied {copied_count} reference work categories to {user_references_dir}")

    def get_reference_works_categories(self) -> list[str]:
        """
        Get available reference work categories from user's references directory.

        Returns:
            List of category names (subdirectory names in references directory)
        """
        if not self.storage_root:
            return DEFAULT_CATEGORIES.copy()

        references_dir = os.path.join(self.storage_root, "references")

        if not os.path.exists(references_dir):
            return DEFAULT_CATEGORIES.copy()

        # Get subdirectory names as categories
        categories = [
            d for d in os.listdir(references_dir)
            if os.path.isdir(os.path.join(references_dir, d))
        ]

        if not categories:
            return DEFAULT_CATEGORIES.copy()

        return sorted(categories)

    def get_reference_works_for_category(self, category: str) -> list[str]:
        """
        Get reference works for a specific category.

        Args:
            category: Category name (subdirectory name)

        Returns:
            List of reference work names (subdirectory names in category directory)
        """
        if not self.storage_root:
            return []

        references_dir = os.path.join(self.storage_root, "references", category)

        if not os.path.exists(references_dir):
            return []

        # Get subdirectory names as reference works
        works = [
            d for d in os.listdir(references_dir)
            if os.path.isdir(os.path.join(references_dir, d))
        ]

        return sorted(works)

    def get_reference_work_chapters(self, category: str, work: str) -> list[str]:
        """
        Get chapter files for a specific reference work.

        Args:
            category: Category name
            work: Work name

        Returns:
            List of chapter file paths
        """
        if not self.storage_root:
            return []

        work_dir = os.path.join(self.storage_root, "references", category, work)

        if not os.path.exists(work_dir):
            return []

        # Get .txt files as chapters
        chapters = [
            f for f in os.listdir(work_dir)
            if f.endswith('.txt') and os.path.isfile(os.path.join(work_dir, f))
        ]

        # Sort chapters naturally (handle numeric ordering)
        def natural_sort_key(s):
            import re
            return [int(text) if text.isdigit() else text.lower()
                    for text in re.split(r'(\d+)', s)]

        return sorted(chapters, key=natural_sort_key)

    def _ensure_directories(self) -> None:
        """Create storage directories if they don't exist."""
        if not self.storage_root:
            return

        # Set derived paths
        self.works_dir = os.path.join(self.storage_root, "works")
        self.templates_dir = os.path.join(self.storage_root, "templates")
        self.logs_dir = os.path.join(self.storage_root, "logs")

        # Create directories
        for directory in [self.storage_root, self.works_dir,
                         self.templates_dir, self.logs_dir]:
            os.makedirs(directory, exist_ok=True)

    def validate(self) -> tuple[bool, str]:
        """
        Validate current settings.

        Returns:
            Tuple of (is_valid, error_message).
            error_message is empty if valid.
        """
        if not self.storage_root:
            return False, "存储根目录未设置"

        if not os.path.isdir(self.storage_root):
            return False, "存储根目录不存在"

        if not os.access(self.storage_root, os.W_OK):
            return False, "存储根目录不可写"

        return True, ""

    @classmethod
    def get_default_categories(cls) -> list[str]:
        """Get default work categories."""
        return DEFAULT_CATEGORIES.copy()

    def to_dict(self) -> Dict[str, Any]:
        """Convert settings to dictionary."""
        return {
            'storage_root': self.storage_root,
            'works_dir': self.works_dir,
            'templates_dir': self.templates_dir,
            'logs_dir': self.logs_dir,
            'ai_settings': {
                'call_mode': self.ai_settings.call_mode,
                'api_provider': self.ai_settings.api_provider,
                'api_url': self.ai_settings.api_url,
                'api_key': self.ai_settings.api_key,
                'api_model': self.ai_settings.api_model,
                'browser_provider': self.ai_settings.browser_provider,
                'browser_phone': self.ai_settings.browser_phone,
                'browser_password': self.ai_settings.browser_password,
                'browser_chrome_path': self.ai_settings.browser_chrome_path,
            },
            'theme': self.theme,
            'language': self.language,
            'is_configured': self.is_configured,
            # Deprecated fields - for backward compatibility
            'api_key': self.api_key,
            'api_base_url': self.api_base_url,
            'api_model': self.api_model,
            'default_model': self.default_model,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Settings':
        """Create Settings instance from dictionary."""
        # Normalize path fields
        path_fields = ['storage_root', 'works_dir', 'templates_dir', 'logs_dir']
        for key in path_fields:
            if key in data and data[key]:
                data[key] = os.path.normpath(data[key])

        # Extract ai_settings if present
        ai_settings_data = data.pop('ai_settings', None)
        if ai_settings_data:
            # Filter out unknown fields for backward compatibility
            valid_ai_fields = {f.name for f in __import__('dataclasses').fields(AiSettings)}
            filtered_ai_data = {k: v for k, v in ai_settings_data.items() if k in valid_ai_fields}
            ai_settings = AiSettings(**filtered_ai_data)
        else:
            ai_settings = AiSettings()
            # Migrate from deprecated fields
            if data.get('api_key'):
                ai_settings.api_key = data.get('api_key', '')
            if data.get('api_base_url'):
                ai_settings.api_url = data.get('api_base_url', '')
            if data.get('api_model'):
                ai_settings.api_model = data.get('api_model', '')

        # Create settings instance with remaining data
        settings_data = {k: v for k, v in data.items() if hasattr(cls, k)}
        return cls(ai_settings=ai_settings, **settings_data)
