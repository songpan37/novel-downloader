"""
Constants for AI Writer application.

Contains application-wide constants including version information.
"""

# Application version information
__version__ = "1.0.0"
VERSION = "1.0.0"
VERSION_MAJOR = 1
VERSION_MINOR = 0
VERSION_PATCH = 0

# Application metadata
APP_NAME = "AI Writer"
APP_FULL_NAME = "AI Writer - AI 小说创作助手"
APP_DESCRIPTION = "AI 辅助创作网络小说的桌面应用"
APP_ORGANIZATION = "AI Writer"

# Copyright information
APP_COPYRIGHT = "Copyright © 2026 AI Writer"
APP_AUTHORS = ["AI Writer Team"]

# Build information (can be updated during CI/CD)
BUILD_NUMBER = "001"
BUILD_DATE = "2026-03-14"

# Navigation items
DEFAULT_CATEGORIES = ["玄幻", "都市", "科幻", "武侠", "历史", "言情", "悬疑", "网游", "其他"]

# Default configuration values
DEFAULT_CONFIG_FILE = "config.json"
DEFAULT_WORDS_PER_CHAPTER = 3000
DEFAULT_CHAPTERS_PER_VOLUME = 20
DEFAULT_MODEL = "claude-sonnet-4-5-20250929"
DEFAULT_THEME = "light"
DEFAULT_LANGUAGE = "zh-CN"

# File paths
WORKS_DIR_NAME = "works"
TEMPLATES_DIR_NAME = "templates"
LOGS_DIR_NAME = "logs"

# UI constants
MAIN_WINDOW_MIN_WIDTH = 1024
MAIN_WINDOW_MIN_HEIGHT = 768
MAIN_WINDOW_DEFAULT_WIDTH = 1400
MAIN_WINDOW_DEFAULT_HEIGHT = 900
NAV_PANEL_WIDTH = 200
NAV_ITEM_HEIGHT = 50

# Keyboard shortcuts
SHORTCUT_NEW_WORK = "Ctrl+N"
SHORTCUT_OPEN_WORK = "Ctrl+O"
SHORTCUT_SAVE = "Ctrl+S"
SHORTCUT_UNDO = "Ctrl+Z"
SHORTCUT_REDO = "Ctrl+Y"
SHORTCUT_QUIT = "Ctrl+Q"
SHORTCUT_ABOUT = "F1"
