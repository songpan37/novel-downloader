"""
AI Writer - Application Entry Point
"""
import sys
import os
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt

# Add src to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gui.main_window import MainWindow
from utils.logger import setup_logger
from config.settings import Settings
from gui.dialogs.storage_config_dialog import StorageConfigDialog
from utils.error_handler import init_error_handler


def main():
    """Main entry point for AI Writer application."""
    # Enable High DPI scaling
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QApplication(sys.argv)
    app.setApplicationName("AI Writer")
    app.setOrganizationName("AI Writer")

    # Setup logger
    logger = setup_logger()
    logger.info("AI Writer starting...")

    # Install global exception handler for graceful error handling
    init_error_handler()
    logger.info("Global error handler installed")

    # Load settings
    settings = Settings()

    # Use fixed config path in project root directory
    config_path = settings.config_path

    # Try to load existing config
    if os.path.exists(config_path):
        logger.info(f"Loading config from {config_path}")
        settings.load(config_path)

    # Check if storage is configured, show dialog if not
    if not settings.is_configured or not settings.storage_root:
        logger.info("Storage not configured, showing configuration dialog")
        config_dialog = StorageConfigDialog(settings)
        if config_dialog.exec() != StorageConfigDialog.DialogCode.Accepted:
            # User cancelled, exit application
            logger.warning("User cancelled storage configuration, exiting")
            sys.exit(1)
        logger.info(f"Storage configured: {settings.storage_root}")
        # Save config to project root directory
        settings.save(config_path)
        logger.info(f"Config saved to {config_path}")
    else:
        # Storage is already configured, check if templates directory needs initialization
        logger.info(f"Storage already configured: {settings.storage_root}")
        # Re-copy default templates if templates directory is empty or missing new templates
        settings._copy_default_templates()
        # Re-copy reference works if references directory is empty
        settings._copy_reference_works()
        logger.info("Template and reference initialization check completed")

    # Create and show main window
    window = MainWindow(settings)
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
