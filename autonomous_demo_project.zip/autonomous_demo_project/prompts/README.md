# 创作流程提示词模板说明

## 模板文件列表

本目录下包含 14 个提示词模板文件，对应创作流程的 14 个步骤：

| 序号 | 模板文件 | 对应步骤 | 占位符说明 |
|------|----------|----------|------------|
| 0 | `00_book_reference.pmpt` | 拆书参考 | `{novel_type}`, `{novel_name}`, `{start_chapter}`, `{end_chapter}`, `{novel_content}` |
| 1 | `01_analyze_pattern.pmpt` | 创作公式 | `{novel_type}`, `{start_chapter}`, `{end_chapter}`, `{book_reference}` |
| 2 | `02_literary_style.pmpt` | 文风设定 | `{novel_type}`, `{novel_name}`, `{start_chapter}`, `{end_chapter}`, `{novel_content}` |
| 3 | `03_book_title.pmpt` | 书名 | `{novel_type}`, `{book_reference}`, `{pattern_analysis}`, `{literary_style}` |
| 4 | `04_story_summary.pmpt` | 故事梗概 | `{novel_type}`, `{book_title}`, `{book_reference}`, `{pattern_analysis}`, `{literary_style}` |
| 5 | `05_worldbuilding.pmpt` | 时空设定 | `{novel_type}`, `{book_title}`, `{story_summary}`, `{literary_style}` |
| 6 | `06_characters.pmpt` | 人物设定 | `{novel_type}`, `{book_title}`, `{story_summary}`, `{worldbuilding}`, `{previous_volume_characters}` |
| 7 | `07_cover_image.pmpt` | 封面图片 | `{novel_type}`, `{book_title}`, `{author_name}`, `{story_summary}`, `{worldbuilding}`, `{characters}` |
| 8 | `08_volume_outline.pmpt` | 分卷大纲 | `{novel_type}`, `{book_title}`, `{story_summary}`, `{worldbuilding}`, `{characters}`, `{previous_volume_outline}`, `{total_volumes}`, `{current_volume}`, `{start_chapter}`, `{end_chapter}` |
| 9 | `09_volume_characters.pmpt` | 分卷人物 | `{novel_type}`, `{book_title}`, `{total_volumes}`, `{current_volume}`, `{worldbuilding}`, `{characters}`, `{previous_volume_characters}`, `{volume_outline}` |
| 10 | `10_chapter_outline.pmpt` | 章节大纲 | `{novel_type}`, `{book_title}`, `{total_volumes}`, `{current_volume}`, `{chapter_index}`, `{previous_chapter_index}`, `{worldbuilding}`, `{volume_characters}`, `{volume_outline}`, `{plot_summary}`, `{character_status}` |
| 11 | `11_chapter_content.pmpt` | 章节正文 | `{novel_type}`, `{book_title}`, `{chapter_index}`, `{previous_chapter_index}`, `{literary_style}`, `{worldbuilding}`, `{volume_characters}`, `{volume_outline}`, `{plot_summary}`, `{character_status}`, `{chapter_outline}`, `{previous_chapter_content}` |
| 12 | `12_plot_summary.pmpt` | 剧情总结 | `{novel_type}`, `{book_title}`, `{chapter_index}`, `{previous_plot_summary}`, `{chapter_content}` |
| 13 | `13_character_status.pmpt` | 人物总结 | `{novel_type}`, `{book_title}`, `{chapter_index}`, `{previous_character_status}`, `{chapter_content}` |

---

## 占位符分类与替换规则

### 占位符类型

#### 1. 基本信息类（所有步骤都可引用，只能后面的步骤引用前面的步骤）
| 占位符 | 说明 | 来源文件 |
|--------|------|----------|
| `{novel_type}` | 小说类型 | 用户输入 |
| `{novel_name}` | 小说名称 | 用户输入/步骤 0 生成 |
| `{book_title}` | 书名 | 步骤 3 生成 |
| `{author_name}` | 作者名 | 用户输入 |
| `{book_reference}` | 拆书分析报告 | 步骤 0 生成文件 |
| `{pattern_analysis}` | 创作公式分析报告 | 步骤 1 生成文件 |
| `{literary_style}` | 语言风格报告 | 步骤 2 生成文件 |
| `{story_summary}` | 故事梗概 | 步骤 4 生成文件 |
| `{worldbuilding}` | 时空设定 | 步骤 5 生成文件 |
| `{characters}` | 人物设定 | 步骤 6 生成文件 |

#### 2. 当前分卷信息类
| 占位符 | 说明 | 来源 |
|--------|------|------|
| `{total_volumes}` | 总卷数 | 用户输入 |
| `{current_volume}` | 当前卷数 | 当前进度 |
| `{volume_outline}` | 当前分卷大纲 | 步骤 8 生成文件 |
| `{volume_characters}` | 当前分卷人物 | 步骤 9 生成文件 |
| `{previous_volume_outline}` | 上一分卷大纲 | 上一卷生成文件 |
| `{previous_volume_characters}` | 上一分卷人物 | 上一卷生成文件 |

#### 3. 当前章节信息类
| 占位符 | 说明 | 来源 |
|--------|------|------|
| `{chapter_index}` | 当前章节号 | 当前进度 |
| `{previous_chapter_index}` | 上一章节号 | 当前进度 -1 |
| `{chapter_outline}` | 当前章节大纲 | 步骤 10 生成文件 |
| `{chapter_content}` | 当前章节正文 | 步骤 11 生成文件 |
| `{chapter_character}` | 当前章节人物 | 步骤 10 或单独生成 |
| `{previous_chapter_content}` | 上一章节正文 | 上一章节生成文件 |
| `{plot_summary}` | 前序章节剧情梗概 | 步骤 12 累积生成 |
| `{character_status}` | 前序章节人物状态 | 步骤 13 累积生成 |
| `{previous_plot_summary}` | 前序剧情摘要 | 步骤 12 累积生成 |
| `{previous_character_status}` | 前序人物状态 | 步骤 13 累积生成 |

---

### 替换规则

#### 规则 1：文件名匹配优先
先搜索占位符同名的不带 `.txt` 后缀的文件名，如果有，直接替换。
例如：`book_title`、`worldbuilding`、`story_summary` 等

```
搜索顺序：
1. steps/book_title.txt
2. steps/worldbuilding.txt
3. steps/story_summary.txt
...
```

#### 规则 2：current_前缀
以 `current_` 开头的占位符，表示引用当前卷或者当前章节的结果。

例如，在创建第 1 卷分卷信息时：
- `current_volume_characters` = 第 1 卷的分卷人物文件内容

例如，在创建第 1 卷第 1 章的章节正文时：
- `current_chapter_outline` = 第 1 卷第 1 章的章节大纲文件内容

#### 规则 3：previous_前缀
以 `previous_` 开头的占位符，表示引用前 1 卷或者前 1 章节的结果。

例如，在创建第 2 卷分卷信息时：
- `previous_volume_characters` = 第 1 卷的分卷人物文件内容

例如，在创建第 1 卷第 2 章的章节正文时：
- `previous_chapter_content` = 第 1 卷第 1 章的章节正文文件内容

#### 规则 4：分卷依赖
后面分卷的步骤依赖前面分卷的步骤结果：
- 第 N 卷的分卷大纲 可以引用 第 N-1 卷的分卷大纲和分卷人物
- 第 N 卷的分卷人物 可以引用 第 N-1 卷的分卷人物

#### 规则 5：章节依赖
后面章节的步骤依赖前面章节的步骤结果：
- 第 N 章的章节正文 依赖 第 N-1 章的章节正文（上下文接续）
- 第 N 章的章节正文 依赖 第 N 章的章节大纲（创作框架）
- 第 N 章的剧情总结 依赖 前 N-1 章的剧情摘要
- 第 N 章的人物总结 依赖 前 N-1 章的人物状态

---

## 文件存储结构

```
用户选择的存储根目录/
├── steps/                  # 各步骤生成的文件
│   ├── book_reference.txt
│   ├── pattern_analysis.txt
│   ├── literary_style.txt
│   ├── book_title.txt
│   ├── story_summary.txt
│   ├── worldbuilding.txt
│   ├── characters.txt
│   ├── volume_1_outline.txt
│   ├── volume_1_characters.txt
│   ├── volume_1_chapter_1_outline.txt
│   ├── volume_1_chapter_1_content.txt
│   ├── volume_1_chapter_1_plot_summary.txt
│   ├── volume_1_chapter_1_character_status.txt
│   └── ...
├── templates/              # 模板文件（从默认模板拷贝）
│   ├── 00_book_reference.pmpt
│   ├── 01_analyze_pattern.pmpt
│   ├── 02_literary_style.pmpt
│   └── ...
└── verification/           # 验证截图等
    └── ...
```

---

## 模板编辑功能

在创作流程的展示框里，点击正在创作或已完成创作的步骤时：

### 提示词按钮
- 位置：最右边
- 功能：弹出一个窗口，查看该步骤的提示词
- 操作：可以进行编辑和保存
- 保存位置：模板路径下的对应文件

### 重新生成按钮
- 位置：最右边（提示词按钮旁边）
- 功能：单独启动一个浏览器窗口，使用该步骤的提示词进行重新生成
- 结果：将该步骤原来的结果进行替换

---

## 使用示例

### 示例 1：创建第 1 卷第 1 章的章节正文

**使用的模板**：`11_chapter_content.pmpt`

**需要替换的占位符**：
- `{novel_type}` → 用户输入的小说类型
- `{book_title}` → 读取 `steps/book_title.txt` 内容
- `{chapter_index}` → 1
- `{previous_chapter_index}` → 无（第 1 章没有前一章）
- `{literary_style}` → 读取 `steps/literary_style.txt` 内容
- `{worldbuilding}` → 读取 `steps/worldbuilding.txt` 内容
- `{volume_characters}` → 读取 `steps/volume_1_characters.txt` 内容
- `{volume_outline}` → 读取 `steps/volume_1_outline.txt` 内容
- `{plot_summary}` → 无（第 1 章没有前序剧情）
- `{character_status}` → 无（第 1 章没有前序人物状态）
- `{chapter_outline}` → 读取 `steps/volume_1_chapter_1_outline.txt` 内容
- `{previous_chapter_content}` → 无（第 1 章没有前一章正文）

**替换逻辑**：
```python
def replace_placeholders(template, context):
    """
    context 包含：
    - novel_type, book_title, chapter_index 等基本信息
    - file_contents: 各个步骤生成的文件内容
    """
    result = template
    for placeholder, value in context.items():
        if value is not None:
            result = result.replace(f"{{{placeholder}}}", value)
        else:
            # 如果占位符没有对应值，移除该占位符及其相关说明
            result = remove_placeholder_section(result, placeholder)
    return result
```

### 示例 2：创建第 3 卷第 5 章的章节正文

**使用的模板**：`11_chapter_content.pmpt`

**依赖关系**：
- 书名：`steps/book_title.txt`
- 语言风格：`steps/literary_style.txt`
- 时空设定：`steps/worldbuilding.txt`
- 整书人物：`steps/characters.txt`
- 第 3 卷人物：`steps/volume_3_characters.txt`
- 第 3 卷大纲：`steps/volume_3_outline.txt`
- 前序剧情摘要：`steps/plot_summary.txt`（累积到第 3 卷第 4 章）
- 前序人物状态：`steps/character_status.txt`（累积到第 3 卷第 4 章）
- 第 3 卷第 5 章大纲：`steps/volume_3_chapter_5_outline.txt`
- 第 3 卷第 4 章正文：`steps/volume_3_chapter_4_content.txt`

---

## 注意事项

1. **模板文件拷贝**：项目启动后，用户选择了存储根目录，将默认模板拷贝到根目录的 `templates/` 路径下面。

2. **用户编辑**：用户在提示词模板界面进行编辑，结果都保存到模板路径下面的文件里。

3. **占位符处理**：
   - 如果占位符没有对应的内容（如第 1 章没有前一章），需要移除该占位符及其相关的说明文字
   - 避免在最终的提示词中出现空的占位符或无关的说明

4. **文件命名规范**：
   - 基本信息类文件：直接使用占位符名作为文件名，如 `book_title.txt`
   - 分卷类文件：`volume_{卷号}_outline.txt`、`volume_{卷号}_characters.txt`
   - 章节类文件：`volume_{卷号}_chapter_{章号}_outline.txt`、`volume_{卷号}_chapter_{章号}_content.txt`

5. **进度追踪**：使用 `feature_list.json` 和 `claude-progress.txt` 追踪创作进度。
